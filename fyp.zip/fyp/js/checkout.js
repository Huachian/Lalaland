var current_address_id = "";
function change_address(){
	document.getElementById("address_list_wrap").style.display = "block";
	document.getElementById("default_address").style.display = "none";

	current_address_id = document.querySelector('[name="confirm_address_id"]').value;

	var total_row = document.querySelectorAll('[name="select_address"]').length;

	for(var i=0; i<total_row; i++){
		var address_id = document.getElementById("select_address"+(i+1)).value;

		if(address_id == current_address_id){
			document.getElementById("select_address"+(i+1)).checked = true;
		}
	}
}

function radio_check(count){
	document.getElementById("select_address"+count).checked = true;
}

function select_shipping_address(){
	var total_row = document.querySelectorAll('[name="select_address"]').length;

	for(var i=0; i<total_row; i++){
		var address_id = document.getElementById("select_address"+(i+1));

		if(address_id.checked == true){
			var selected_address_id = address_id.value;
			var selected_name = document.getElementById("selected_name"+(i+1)).innerHTML;
			var selected_contact = document.getElementById("selected_contact"+(i+1)).innerHTML;
			var selected_address = document.getElementById("selected_address"+(i+1)).innerHTML;
			var selected_area = document.getElementById("selected_area"+(i+1)).innerHTML;
			var selected_postcode = document.getElementById("selected_postcode"+(i+1)).innerHTML;
			var selected_state = document.getElementById("selected_state"+(i+1)).innerHTML;
			var check_selected_default = document.getElementById("select_address_default_value"+(i+1)).value;
		}
	}

	document.querySelector('[name="confirm_address_id"]').value = selected_address_id;
	document.getElementById("confirm_name").innerHTML = selected_name;
	document.getElementById("confirm_contact").innerHTML = selected_contact;
	document.getElementById("confirm_address").innerHTML = selected_address;
	document.getElementById("confirm_area").innerHTML = selected_area;
	document.getElementById("confirm_postcode").innerHTML = selected_postcode;
	document.getElementById("confirm_state").innerHTML = selected_state;

	if(check_selected_default == "Default"){
		document.getElementById("default_tag").style.opacity = "1.0";
		document.getElementById("default_tag").style.position = "static";
	}
	else{
		document.getElementById("default_tag").style.opacity = "0";
		document.getElementById("default_tag").style.position = "absolute";
	}

	document.getElementById("address_list_wrap").style.display = "none";
	document.getElementById("default_address").style.display = "block";
}

function cancle_submit_address(){
	document.getElementById("address_list_wrap").style.display = "none";
	document.getElementById("default_address").style.display = "block";

	var total_row = document.querySelectorAll('[name="select_address"]').length;

	for(var i=0; i<total_row; i++){
		var address_id = document.getElementById("select_address"+(i+1)).value;

		if(address_id == current_address_id){
			document.getElementById("select_address"+(i+1)).checked = true;
		}
	}
}


function go_payment(){
	var total_row = document.querySelectorAll('[name="select_address"]').length;

	for(var i=0; i<total_row; i++){
		var address_checkbox = document.getElementById("select_address"+(i+1));

		if(address_checkbox.checked == true){
			var address_id = document.getElementById("address_id"+(i+1)).value;
		}
	}

	var buyer_message = document.getElementById("buyer_message").value;
  var total_payment = document.getElementById("total_payment").innerHTML;
  total_payment = total_payment.replace(/,/g, '');

  var operation = "check_voucher";

  if(selected_voucher_id != ""){
    $.ajax({
      url: "function/update_orders.php",
      type: "POST",
      data: {
        'operation': operation,
        'selected_voucher_id': selected_voucher_id
      },
      success: function(data){
        if(data == "yes"){
          sessionStorage.setItem('payment_page_valid', "yes");
          sessionStorage.setItem('address_id', address_id);
          sessionStorage.setItem('buyer_message', buyer_message);
          sessionStorage.setItem('total_payment', total_payment);
          sessionStorage.setItem('selected_voucher_id', selected_voucher_id);
          sessionStorage.setItem('selected_voucher_code', selected_voucher_code);
          window.location = "payment.php";
        }
        else{
          document.getElementById("selected_voucher_not_available_popup").style.display = "block";
          document.querySelector('body').style.overflow = "hidden";

          setTimeout(function(){
            $('#selected_voucher_not_available_popup').fadeOut('fast');
            $('body').css('overflow','auto');
            window.location = "checkout.php";
          }, 1500);
        }
      }
    });
  }
  else{
    sessionStorage.setItem('payment_page_valid', "yes");
    sessionStorage.setItem('address_id', address_id);
    sessionStorage.setItem('buyer_message', buyer_message);
    sessionStorage.setItem('total_payment', total_payment);
    sessionStorage.setItem('selected_voucher_id', selected_voucher_id);
    sessionStorage.setItem('selected_voucher_code', selected_voucher_code);
    window.location = "payment.php";
  }
}


function add_new_address_popup(){
  document.getElementById("add_address_wrap").style.display = "block";
  document.querySelector("body").style.overflow = "hidden";
}

function cancel_address(){
  document.getElementById("add_address_wrap").style.display = "none";
  document.querySelector("body").style.overflow = "auto";

  document.getElementById("address_name").value = "";
  document.getElementById("address_phone").value = "";
  document.getElementById("new_address").value = "";
  document.getElementById("address_postcode").value = "";
  document.getElementById("address_state").value = "";
  document.getElementById("address_area").value = "";

  document.getElementById("adds_name_error").innerHTML = "";
  document.getElementById("address_name").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_phone_error").innerHTML = "";
  document.getElementById("address_phone").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_add_error").innerHTML = "";
  document.getElementById("new_address").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_post_error").innerHTML = "";
  document.getElementById("address_postcode").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_state_error").innerHTML = "";
  document.getElementById("address_state").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_area_error").innerHTML = "";
  document.getElementById("address_area").style.border = "2px solid #f0f0f0";
  document.getElementById("set_new_default").checked = false;
}

//validate add address form
var valid_name = "no";
function nameValidation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  var name = document.getElementById("address_name").value;
  var error_message = document.getElementById("adds_name_error");
  var error_border = document.getElementById("address_name");
  
  if(name.match(space)){
    error_message.innerHTML = "Name is required.";
    error_border.style.border = "2px solid red";
    valid_name = "no";
  }
  else if(name.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_name = "yes";
  }
  else{
    error_message.innerHTML = "Please enter name as only Alphabet.";
    error_border.style.border = "2px solid red";
    valid_name = "no";
  }
}

var valid_phone = "no";
function phoneValidation()
{ 
  var space = /^\s*$/;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  var phoneNo = document.getElementById("address_phone").value;
  var error_message = document.getElementById("adds_phone_error");
  var error_border = document.getElementById("address_phone");


  if(phoneNo.match(space)){
    error_message.innerHTML = "Phone number is required.";
    error_border.style.border = "2px solid red";
    valid_phone = "no";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12){
    error_message.innerHTML = "Please enter a valid phone number.";
    error_border.style.border = "2px solid red";
    valid_phone = "no";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_phone = "yes";
  }
}

var valid_address = "no";
function addressValidation()
{
  var space = /^\s*$/;

  var address = document.getElementById("new_address").value;
  var error_message = document.getElementById("adds_add_error");
  var error_border = document.getElementById("new_address");

  //address
  if(!address.match(space)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_address = "yes";
  }
  else{
    error_message.innerHTML = "Address is required.";
    error_border.style.border = "2px solid red";
    valid_address = "no";
  }
}

var valid_postcode = "no";
function postcodeValidation()
{
  var pattern = /[0-9]{5}/;
  var space = /^\s*$/;

  var postcode = document.getElementById("address_postcode").value;
  var error_message = document.getElementById("adds_post_error");
  var error_border = document.getElementById("address_postcode");

  if(postcode.match(space)){
    error_message.innerHTML = "Postcode is required.";
    error_border.style.border = "2px solid red";
    valid_postcode = "no";
  }
  else if(isNaN(postcode)||postcode.length>5||!postcode.match(pattern)){
    error_message.innerHTML = "Please enter a valid postcode.";
    error_border.style.border = "2px solid red";
    valid_postcode = "no";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_postcode = "yes";
  }
}

var valid_state = "no";
function stateValidation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  var state = document.getElementById("address_state").value; 
  var error_message = document.getElementById("adds_state_error");
  var error_border = document.getElementById("address_state");
  
  if(state.match(space)){
    error_message.innerHTML = "State is required.";
    error_border.style.border = "2px solid red";
    valid_state = "no";
  }
  else if(state.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_state = "yes";
  }
  else{
    error_message.innerHTML = "Invalid state.";
    error_border.style.border = "2px solid red";
    valid_state = "no";
  }
}

var valid_area = "no";
function areaValidation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  var area = document.getElementById("address_area").value;
  var error_message = document.getElementById("adds_area_error");
  var error_border = document.getElementById("address_area");
  
  if(area.match(space)){
    error_message.innerHTML = "Area is required.";
    error_border.style.border = "2px solid red";
    valid_area = "no";
  }
  else if(area.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_area = "yes";
  }
  else{
    error_message.innerHTML = "Invalid area.";
    error_border.style.border = "2px solid red";
    valid_area = "no";
  }
}


function submit_address(){
  var operation = "add_new_address";

  nameValidation();
  phoneValidation();
  addressValidation();
  postcodeValidation();
  stateValidation();
  areaValidation();

  if(valid_name=="yes" && valid_phone=="yes" && valid_address=="yes" && valid_postcode=="yes" && valid_state=="yes" && valid_area=="yes"){
    var address_name = document.getElementById("address_name").value;
    var address_phone = document.getElementById("address_phone").value;
    var new_address = document.getElementById("new_address").value;
    var address_postcode = document.getElementById("address_postcode").value;
    var address_state = document.getElementById("address_state").value;
    var address_area = document.getElementById("address_area").value;

    var check_default = document.getElementById("set_new_default");

    if(check_default.checked == true){
      var address_default = "Default";
    }
    else if(check_default.checked == false){
      var address_default = "NotDefault";
    }


    $.ajax({
      url: "function/update_customer.php",
      type: "POST",
      data: {
        'operation': operation,
        'address_name': address_name,
        'address_phone': address_phone,
        'new_address': new_address,
        'address_postcode': address_postcode,
        'address_state': address_state,
        'address_area': address_area,
        'address_default': address_default
      },
    });

    document.getElementById("add_address_wrap").style.display = "none";
    document.getElementById("add_address_alert_wrap").style.display = "block";

    setTimeout(function(){
      $('#add_address_alert_wrap').fadeOut('fast');
      $('body').css('overflow','auto');
      location.reload();
    }, 1500);
  }
}


var temp_current_product_subtotal = "";
var temp_current_shipping_fee = "";
var temp_current_total_payment = "";
function voucher_popup(){
  document.getElementById("voucher_box_wrap").style.display = "block";
  document.querySelector('body').style.overflow = "hidden";


  var product_subtotal = document.getElementById('product_subtotal').innerHTML;
  product_subtotal = product_subtotal.replace(/,/g, '');
  product_subtotal = parseFloat(product_subtotal);
  var shipping_fee = document.getElementById('shipping_fee').innerHTML;
  shipping_fee = shipping_fee.replace(/,/g, '');
  shipping_fee = parseFloat(shipping_fee);
  var total_payment = document.getElementById('total_payment').innerHTML;
  total_payment = total_payment.replace(/,/g, '');
  total_payment = parseFloat(total_payment);

  //temporaly store summary price incase user cancel
  temp_current_product_subtotal = product_subtotal;
  temp_current_shipping_fee = shipping_fee;
  temp_current_total_payment = total_payment;



  var total_voucher = document.querySelectorAll('.voucher_display_row');
  var original_subtotal = document.getElementById('original_product_subtotal').value;
  original_subtotal = parseFloat(original_subtotal);

  for(var j=0; j<total_voucher.length; j++){
    var voucher_min_spend = document.getElementById("voucher_min_spend"+(j+1)).value;
    voucher_min_spend = parseFloat(voucher_min_spend);

    var voucher_quantity = document.getElementById("voucher_qty"+(j+1)).value;



    if(original_subtotal < voucher_min_spend || voucher_quantity <= 0){
      document.getElementById("voucher_display_row"+(j+1)).style.opacity = "0.5";
      document.getElementById("voucher_fufile"+(j+1)).value = "no";

      if(voucher_quantity <= 0){
        document.getElementById("qty_not_valid"+(j+1)).style.display = "block";
      }
      else{
        document.getElementById("qty_not_valid"+(j+1)).style.display = "none";
      }

      if(original_subtotal < voucher_min_spend){
        document.getElementById("min_spend_not_valid"+(j+1)).style.display = "block";
      }
      else{
        document.getElementById("min_spend_not_valid"+(j+1)).style.display = "none";
      }
    }
    else{
      document.getElementById("voucher_display_row"+(j+1)).style.opacity = "1";
      document.getElementById("min_spend_not_valid"+(j+1)).style.display = "none";
      document.getElementById("qty_not_valid"+(j+1)).style.display = "none";
      document.getElementById("voucher_fufile"+(j+1)).value = "yes";

      if(selected_voucher_i != ""){
        document.getElementById("voucher_card_left"+(selected_voucher_i)).style.border = "3px inset #ffb31a";
        document.getElementById("voucher_card_left"+(selected_voucher_i)).style.borderRight = "none";
        document.getElementById("voucher_card_right"+(selected_voucher_i)).style.border = "3px inset #ffb31a";
        document.getElementById("voucher_card_right"+(selected_voucher_i)).style.borderLeft = "none";
      }
    }
  }
}


function cancel_voucher_popup(){
  document.getElementById("voucher_box_wrap").style.display = "none";
  document.querySelector('body').style.overflow = "auto";

  document.getElementById('product_subtotal').innerHTML = temp_current_product_subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  document.getElementById('shipping_fee').innerHTML = temp_current_shipping_fee.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  document.getElementById('total_payment').innerHTML = temp_current_total_payment.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');

  var total_voucher = document.querySelectorAll('.voucher_display_row');
  for(var j=0; j<total_voucher.length; j++){
    document.getElementById("voucher_card_left"+(j+1)).style.border = "none";
    document.getElementById("voucher_card_left"+(j+1)).style.borderRight = "none";
    document.getElementById("voucher_card_right"+(j+1)).style.border = "none";
    document.getElementById("voucher_card_right"+(j+1)).style.borderLeft = "none";
  }

  current_applyed_voucher_id = selected_voucher_id;
  current_applyed_voucher_code = selected_voucher_code;
  current_applyed_voucher_i = selected_voucher_i;
}


var current_applyed_voucher_id = "";
var current_applyed_voucher_code = "";
var current_applyed_voucher_i = "";
function select_voucher(voucher_id, voucher_code, i){
  //check if current selected item fufile this voucher or not
  var voucher_fufile = document.getElementById("voucher_fufile"+i).value;

  if(voucher_fufile == "yes"){
    var total_voucher = document.querySelectorAll('.voucher_display_row');

    for(var j=0; j<total_voucher.length; j++){
      document.getElementById("voucher_card_left"+(j+1)).style.border = "none";
      document.getElementById("voucher_card_left"+(j+1)).style.borderRight = "none";
      document.getElementById("voucher_card_right"+(j+1)).style.border = "none";
      document.getElementById("voucher_card_right"+(j+1)).style.borderLeft = "none";
    }


    if(current_applyed_voucher_id == voucher_id){
      current_applyed_voucher_id = "";
      current_applyed_voucher_code = "";
      current_applyed_voucher_i = "";

      var product_subtotal = document.getElementById('original_product_subtotal').value;
      product_subtotal = product_subtotal.replace(/,/g, '');
      product_subtotal = parseFloat(product_subtotal);
      var shipping_fee = document.getElementById('original_shipping_fee').value;
      shipping_fee = shipping_fee.replace(/,/g, '');
      shipping_fee = parseFloat(shipping_fee);
      document.getElementById('product_subtotal').innerHTML = product_subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      document.getElementById('shipping_fee').innerHTML = shipping_fee.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    }
    else{
      document.getElementById("voucher_card_left"+(i)).style.border = "3px inset #ffb31a";
      document.getElementById("voucher_card_left"+(i)).style.borderRight = "none";
      document.getElementById("voucher_card_right"+(i)).style.border = "3px inset #ffb31a";
      document.getElementById("voucher_card_right"+(i)).style.borderLeft = "none";

      var voucher_type = document.getElementById("voucher_type"+(i)).value;

      if(voucher_type == "Product Discount"){
        current_applyed_voucher_id = voucher_id;
        current_applyed_voucher_code = voucher_code;
        current_applyed_voucher_i = i;
        var product_subtotal = document.getElementById('original_product_subtotal').value;
        product_subtotal = product_subtotal.replace(/,/g, '');
        product_subtotal = parseFloat(product_subtotal);

        var discount_amount = document.getElementById("voucher_discount_amount"+(i)).value;
        discount_amount = discount_amount.replace(/,/g, '');
        discount_amount = parseFloat(discount_amount);

        product_subtotal -= discount_amount;
        if(product_subtotal < 0){
          product_subtotal = 0;
        }

        var shipping_fee = document.getElementById('original_shipping_fee').value;
        shipping_fee = shipping_fee.replace(/,/g, '');
        shipping_fee = parseFloat(shipping_fee);

        document.getElementById('product_subtotal').innerHTML = product_subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        document.getElementById('shipping_fee').innerHTML = shipping_fee.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      }
      else{
        current_applyed_voucher_id = voucher_id;
        current_applyed_voucher_code = voucher_code;
        current_applyed_voucher_i = i;
        var shipping_fee = document.getElementById('original_shipping_fee').value;
        shipping_fee = shipping_fee.replace(/,/g, '');
        shipping_fee = parseFloat(shipping_fee);

        shipping_fee -= 10.00;

        if(shipping_fee < 0){
          shipping_fee = 0;
        }

        document.getElementById("voucher_card_left"+(i)).style.border = "3px inset #ffb31a";
        document.getElementById("voucher_card_left"+(i)).style.borderRight = "none";
        document.getElementById("voucher_card_right"+(i)).style.border = "3px inset #ffb31a";
        document.getElementById("voucher_card_right"+(i)).style.borderLeft = "none";

        var product_subtotal = document.getElementById('original_product_subtotal').value;
        product_subtotal = product_subtotal.replace(/,/g, '');
        product_subtotal = parseFloat(product_subtotal);

        document.getElementById('product_subtotal').innerHTML = product_subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        document.getElementById('shipping_fee').innerHTML = shipping_fee.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      }
    }

    calculate_total_payment();
  }
}


function calculate_total_payment(){
  var product_subtotal = document.getElementById('product_subtotal').innerHTML;
  product_subtotal = product_subtotal.replace(/,/g, '');
  product_subtotal = parseFloat(product_subtotal);

  var shipping_fee = document.getElementById('shipping_fee').innerHTML;
  shipping_fee = shipping_fee.replace(/,/g, '');
  shipping_fee = parseFloat(shipping_fee);

  var total_payment = product_subtotal + shipping_fee;

  document.getElementById('total_payment').innerHTML = total_payment.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

var selected_voucher_id = "";
var selected_voucher_code = "";
var selected_voucher_i = "";
function apply_voucher(){
  document.getElementById("voucher_box_wrap").style.display = "none";
  document.querySelector('body').style.overflow = "auto";

  if(current_applyed_voucher_code == ""){
    document.getElementById("selected_voucher_code").style.display = "none";
  }
  else{
    document.getElementById("selected_voucher_code").style.display = "inline";
  }

  document.getElementById("selected_voucher_code").innerHTML = current_applyed_voucher_code;

  selected_voucher_id = current_applyed_voucher_id;
  selected_voucher_code = current_applyed_voucher_code;
  selected_voucher_i = current_applyed_voucher_i;
}