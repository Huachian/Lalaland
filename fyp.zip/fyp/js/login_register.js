var empty_valid = "no";
function login_email_validation(){
	var space = /^\s*$/;

	var login_email = document.getElementById("login_email").value;
	//check space or empty
	if(login_email.match(space)){
		document.getElementById("login_email_error").innerHTML = "Email is required.";
		empty_valid = "no";
		document.getElementById("login_email").style.border = "2px solid red";
	}
	else{
		document.getElementById("login_email_error").innerHTML = "";
		document.getElementById("login_email").style.border = "2px solid #f0f0f0";
		empty_valid = "yes";
	}
}


function login_password_validation(){
	var space = /^\s*$/;

	var login_password = document.getElementById("login_pass").value;

	if(login_password.match(space)){
		document.getElementById("login_pass_error").innerHTML = "Password is required.";
		document.getElementById("login_pass").style.border = "2px solid red";
		empty_valid = "no";
	}
	else{
		document.getElementById("login_pass_error").innerHTML="";
		document.getElementById("login_pass").style.border = "2px solid #f0f0f0";
		empty_valid = "yes";
	}
}



function login_validation(product_id, custom_card_type, next_page){
	var operation = "login_validation";

	login_email_validation();
	login_password_validation();

	var login_email = document.getElementById("login_email").value;
	var login_password = document.getElementById("login_pass").value;

	//validate from databases
	if(empty_valid == "yes"){
		$.ajax({
			url: "function/login_register_validation.php",
			type: "POST",
			data: {
				'operation': operation,
				'login_email': login_email,
				'login_password': login_password
			},
			success: function(data){
				if(data == "customer"){
					if(product_id == "none" && custom_card_type == "none" && next_page == "none"){
						document.getElementById("login_success_alert_wrap").style.display = "block";
						document.querySelector("body").style.overflow = "hidden";

						setTimeout(function(){
							$('#login_success_alert_wrap').fadeOut('1000');
							window.location = "index.php";
						}, 1500);
					}
					else if(product_id != "none"){
						document.getElementById("login_success_alert_wrap").style.display = "block";
						document.querySelector("body").style.overflow = "hidden";

						setTimeout(function(){
							$('#login_success_alert_wrap').fadeOut('fast');
							window.location = "product_page.php?product_id="+product_id;
						}, 1500);
					}
					else if(custom_card_type != "none"){
						document.getElementById("login_success_alert_wrap").style.display = "block";
						document.querySelector("body").style.overflow = "hidden";

						setTimeout(function(){
							$('#login_success_alert_wrap').fadeOut('fast');
							window.location = "customization_card_information.php?custom_card_type="+custom_card_type;
						}, 1500);
					}
					else if(next_page != "none"){
						document.getElementById("login_success_alert_wrap").style.display = "block";
						document.querySelector("body").style.overflow = "hidden";

						setTimeout(function(){
							$('#login_success_alert_wrap').fadeOut('fast');
							window.location = next_page;
						}, 1500);
					}
				}
				else if(data == "admin"){
					if(next_page == "none"){
						document.getElementById("login_success_alert_wrap").style.display = "block";
						document.querySelector("body").style.overflow = "hidden";

						setTimeout(function(){
							$('#login_success_alert_wrap').fadeOut('1000');
							window.location = "admin/index.php";
						}, 1500);
					}
					else{
						document.getElementById("login_success_alert_wrap").style.display = "block";
						document.querySelector("body").style.overflow = "hidden";

						setTimeout(function(){
							$('#login_success_alert_wrap').fadeOut('fast');
							window.location = next_page;
						}, 1500);
					}
				}
				else{
					document.getElementById("login_error_wrap").style.display = "block";
				}
	        },
		});
	}
	else{
		document.getElementById("login_error_wrap").style.display = "block";
	}
}

function show_hide_password(operation)
{
	if(operation == "login_password"){
		var toggle = document.getElementById("toggle_login_password");
		var pass = document.getElementById("login_pass");
	}
	else if(operation == "register_password"){
		var toggle = document.getElementById("toggle_password");
		var pass = document.getElementById("reg_pass");
	}
	else if(operation == "confirm_register_password"){
		var toggle = document.getElementById("toggle_conpassword");
		var pass = document.getElementById("reg_confirm");
	}


	if(pass.type === 'password')
	{
		pass.setAttribute("type","text");
		toggle.classList.add('hide');
	}
	else
	{
		pass.setAttribute("type","password");
		toggle.classList.remove('hide');
	}
}

function show_register_form(){
	document.querySelector(".login_box").style.display = "none";
	document.querySelector(".register_box").style.display = "block";

	document.getElementById("login_email_error").innerHTML = "";
	document.getElementById("login_email").style.border = "2px solid #f0f0f0";
	document.getElementById("login_email").value = "";
	document.getElementById("login_pass_error").innerHTML="";
	document.getElementById("login_pass").style.border = "2px solid #f0f0f0";
	document.getElementById("login_pass").value = "";
	document.getElementById("login_error_wrap").style.display = "none";
}

function show_login_form(){
	document.querySelector(".login_box").style.display = "block";
	document.querySelector(".register_box").style.display = "none";

	document.getElementById("fname_error").innerHTML = "";
	document.getElementById("reg_fname").style.border = "2px solid #f0f0f0";
	document.getElementById("lname_error").innerHTML = "";
	document.getElementById("reg_lname").style.border = "2px solid #f0f0f0";
	document.getElementById("email_error").innerHTML = "";
	document.getElementById("reg_email").style.border = "2px solid #f0f0f0";
	document.getElementById("pass_error").innerHTML="";
	document.getElementById("reg_pass").style.border = "2px solid #f0f0f0";
	document.getElementById("new_password_tick_icon").style.display = "none";
	document.getElementById("new_password_cross_icon").style.display = "none";
	document.getElementById("conpass_error").innerHTML= "";
	document.getElementById("reg_confirm").style.border = "2px solid #f0f0f0";
	document.getElementById("confirm_password_tick_icon").style.display = "none";
	document.getElementById("confirm_password_cross_icon").style.display = "none";
	document.getElementById("gender_error").innerHTML = ""
	document.querySelector(".gender_radiobox").style.border = "none";
  	document.getElementById("add_error").innerHTML = "";
  	document.getElementById("reg_add").style.border = "2px solid #f0f0f0";
  	document.getElementById("postcode_error").innerHTML = "";
  	document.getElementById("reg_postcode").style.border = "2px solid #f0f0f0";
  	document.getElementById("state_error").innerHTML = "";
  	document.getElementById("reg_state").style.border = "2px solid #f0f0f0";
  	document.getElementById("area_error").innerHTML = "";
  	document.getElementById("reg_area").style.border = "2px solid #f0f0f0";
  	document.getElementById("phone_error").innerHTML = "";
  	document.getElementById("reg_phone").style.border = "2px solid #f0f0f0";
  	document.getElementById("register_error_wrap").style.display = "none";
}

var fname_valid = "no";
function fname_validation(){
	var fname = document.getElementById("reg_fname").value;
	var fname_error = document.getElementById("fname_error");
	var pattern = /^[a-zA-Z\s]+$/;
	var space = /^\s*$/;
	
	if(fname.match(space)){
		fname_error.innerHTML = "First name is required.";
		document.getElementById("reg_fname").style.border = "2px solid red";
		fname_valid = "no";
	}
	else if(fname.match(pattern)){
		fname_error.innerHTML = "";
		document.getElementById("reg_fname").style.border = "2px solid #f0f0f0";
		fname_valid = "yes";
	}
	else{
		fname_error.innerHTML = "Please enter name as only Alphabet.";
		document.getElementById("reg_fname").style.border = "2px solid red";
		fname_valid = "no";
	}
}

var lname_valid = "no";
function lname_validation(){
	var lname = document.getElementById("reg_lname").value;
	var lname_error = document.getElementById("lname_error");
	var pattern = /^[a-zA-Z\s]+$/;
	var space = /^\s*$/;

	if(lname.match(space)){
		lname_error.innerHTML = "Last name is required.";
		document.getElementById("reg_lname").style.border = "2px solid red";
		lname_valid = "no";
	}
	else if(lname.match(pattern)){
		lname_error.innerHTML = "";
		document.getElementById("reg_lname").style.border = "2px solid #f0f0f0";
		lname_valid = "yes";
	}
	else{
		lname_error.innerHTML = "Please enter name as only Alphabet.";
		document.getElementById("reg_lname").style.border = "2px solid red";
		lname_valid = "no";
	}
}

var email_valid = "no";
function email_validation(){
	var email = document.getElementById("reg_email").value;
	var email_error = document.getElementById("email_error");
	var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	var space = /^\s*$/;
	var operation = "check_register_email";

	$.ajax({
		url: "function/login_register_validation.php",
		type: "POST",
		data: {
			'operation': operation,
			'email': email
		},
		success: function(data){
			if(data == "no"){
				email_error.innerHTML = "This email has been use.";
				document.getElementById("reg_email").style.border = "2px solid red";
				email_valid = "no";
			}
			else if(email.match(space)){
				email_error.innerHTML = "Email address is required.";
				document.getElementById("reg_email").style.border = "2px solid red";
				email_valid = "no";
			}
			else if (email.match(pattern)){
				email_error.innerHTML = "";
				document.getElementById("reg_email").style.border = "2px solid #f0f0f0";
				email_valid = "yes";
			}
			else{
				email_error.innerHTML = "Please enter valid email address.";
				document.getElementById("reg_email").style.border = "2px solid red";
				email_valid = "no";
			}
		},
	});
}


function keyPressed_new_password(){
	var key = event.keyCode || event.charCode || event.which ;
	new_password_guide();
	return key;
}


var length_valid = "no";
var number_valid = "no";
var small_letter_valid = "no";
var upper_letter_valid = "no";
var symbol_valid = "no";
var new_password_valid = "no";
function new_password_guide(){
	document.getElementById("password_format").style.display = "block";
	var password = document.getElementById("reg_pass").value;
	document.getElementById("pass_error").innerHTML="";

	if(password.length == 0){
		document.getElementById("password_format").style.display = "none";
		var length_valid = "no";
	}
	else if(password.length >= 15){
		document.getElementById("characters").style.color = "#00e600";
		document.getElementById("characters").style.fontWeight = "bold";
		length_valid = "yes";
	}
	else{
		document.getElementById("characters").style.color = "grey";
		document.getElementById("characters").style.fontWeight = "normal";
		length_valid = "no";
	}

	if(password.match(/[0-9]/)){
		document.getElementById("number").style.color = "#00e600";
		document.getElementById("number").style.fontWeight = "bold";
		var number_valid = "yes";
	}
	else{
		document.getElementById("number").style.color = "grey";
		document.getElementById("number").style.fontWeight = "normal";
		number_valid = "no";
	}

	if(password.match(/[a-z]/)){
		document.getElementById("small_letter").style.color = "#00e600";
		document.getElementById("small_letter").style.fontWeight = "bold";
		var small_letter_valid = "yes";
	}
	else{
		document.getElementById("small_letter").style.color = "grey";
		document.getElementById("small_letter").style.fontWeight = "normal";
		small_letter_valid = "no";
	}

	if(password.match(/[A-Z]/)){
		document.getElementById("upper_letter").style.color = "#00e600";
		document.getElementById("upper_letter").style.fontWeight = "bold";
		var upper_letter_valid = "yes";
	}
	else{
		document.getElementById("upper_letter").style.color = "grey";
		document.getElementById("upper_letter").style.fontWeight = "normal";
		upper_letter_valid = "no";
	}

	if(password.match(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/)){
		document.getElementById("symbol").style.color = "#00e600";
		document.getElementById("symbol").style.fontWeight = "bold";
		var symbol_valid = "yes";
	}
	else{
		document.getElementById("symbol").style.color = "grey";
		document.getElementById("symbol").style.fontWeight = "normal";
		symbol_valid = "no";
	}

	if(length_valid == "yes" && number_valid == "yes" && small_letter_valid == "yes" && upper_letter_valid == "yes" && symbol_valid == "yes"){
		document.getElementById("new_password_tick_icon").style.display = "block";
		document.getElementById("new_password_cross_icon").style.display = "none";
		document.getElementById("pass_error").innerHTML = "";
		new_password_valid = "yes";
	}
	else{
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		new_password_valid = "no";
	}
}

var password_valid = "no";
function new_password_validation()
{
	var password = document.getElementById("reg_pass").value;
	var space = /^\s*$/;

	document.getElementById("password_format").style.display = "none";

	if(password.match(space))
	{
		document.getElementById("pass_error").innerHTML="New password is required.";
		document.getElementById("reg_pass").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		password_valid = "no";
	}
	else if(password.length < 15 || password.search(/[0-9]/) == -1 || password.search(/[a-z]/) == -1 || password.search(/[A-Z]/) == -1 || password.search(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/) == -1){
		document.getElementById("pass_error").innerHTML="Password format incorrect.";
		document.getElementById("reg_pass").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		password_valid = "no";
	}
	else
	{
		document.getElementById("pass_error").innerHTML="";
		document.getElementById("reg_pass").style.border = "2px solid #f0f0f0";
		password_valid = "yes";
	}

	var confirm_password = document.getElementById("reg_confirm").value;
	if(confirm_password.length != 0){
		confirm_password_validation();
	}
}


function keyPressed(){
	var key = event.keyCode || event.charCode || event.which ;
	return key;
}


var confirm_password_valid = "no";
function confirm_password_validation()
{
	var new_password = document.getElementById("reg_pass").value;
	var confirm_password = document.getElementById("reg_confirm").value;
	var space = /^\s*$/;

	if(confirm_password.match(space))
	{
		document.getElementById("conpass_error").innerHTML= "Confirm password is required.";
		document.getElementById("reg_confirm").style.border = "2px solid red";
		document.getElementById("confirm_password_tick_icon").style.display = "none";
		document.getElementById("confirm_password_cross_icon").style.display = "block";
		confirm_password_valid = "no";
	}
	else if(new_password == confirm_password)
	{
		document.getElementById("conpass_error").innerHTML= "";
		document.getElementById("reg_confirm").style.border = "2px solid #f0f0f0";
		document.getElementById("confirm_password_tick_icon").style.display = "block";
		document.getElementById("confirm_password_cross_icon").style.display = "none";
		confirm_password_valid = "yes";
	}
	else
	{
		document.getElementById("conpass_error").innerHTML= "Password does not match.";
		document.getElementById("reg_confirm").style.border = "2px solid red";
		document.getElementById("confirm_password_tick_icon").style.display = "none";
		document.getElementById("confirm_password_cross_icon").style.display = "block";
		confirm_password_valid = "no";
	}
}

function select_gender(){
	document.getElementById("gender_error").innerHTML = ""
	document.querySelector(".gender_radiobox").style.border = "none";
}

var valid_address = "no";
function addressValidation()
{
  	var space = /^\s*$/;

	var address = document.getElementById("reg_add").value;
	var error_message = document.getElementById("add_error");
	var error_border = document.getElementById("reg_add");

	//address
	if(!address.match(space)){
	  	error_message.innerHTML = "";
	  	error_border.style.border = "2px solid #f0f0f0";
	  	valid_address = "yes";
	}
	else{
		error_message.innerHTML = "Address is required.";
	    error_border.style.border = "2px solid red";
	    valid_address = "no";
	 }
}


var valid_postcode = "no";
function postcodeValidation()
{
  var pattern = /[0-9]{5}/;
  var space = /^\s*$/;

  var postcode = document.getElementById("reg_postcode").value;
  var error_message = document.getElementById("postcode_error");
  var error_border = document.getElementById("reg_postcode");

  if(postcode.match(space)){
    error_message.innerHTML = "Postcode is required.";
    error_border.style.border = "2px solid red";
    valid_postcode = "no";
  }
  else if(isNaN(postcode)||postcode.length>5||!postcode.match(pattern)){
    error_message.innerHTML = "Please enter a valid postcode.";
    error_border.style.border = "2px solid red";
    valid_postcode = "no";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_postcode = "yes";
  }
}


var valid_state = "no";
function stateValidation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  var state = document.getElementById("reg_state").value; 
  var error_message = document.getElementById("state_error");
  var error_border = document.getElementById("reg_state");

  if(state.match(space)){
    error_message.innerHTML = "State is required.";
    error_border.style.border = "2px solid red";
    valid_state = "no";
  }
  else if(state.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_state = "yes";
  }
  else{
    error_message.innerHTML = "Invalid state.";
    error_border.style.border = "2px solid red";
    valid_state = "no";
  }
}


var valid_area = "no";
function areaValidation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  var area = document.getElementById("reg_area").value;
  var error_message = document.getElementById("area_error");
  var error_border = document.getElementById("reg_area");
  
  if(area.match(space)){
    error_message.innerHTML = "Area is required.";
    error_border.style.border = "2px solid red";
    valid_area = "no";
  }
  else if(area.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_area = "yes";
  }
  else{
    error_message.innerHTML = "Invalid area.";
    error_border.style.border = "2px solid red";
    valid_area = "no";
  }
}


var valid_phone = "no";
function phoneValidation()
{ 
  var space = /^\s*$/;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  var phoneNo = document.getElementById("reg_phone").value;
  var error_message = document.getElementById("phone_error");
  var error_border = document.getElementById("reg_phone");

  if(phoneNo.match(space)){
    error_message.innerHTML = "Phone number is required.";
    error_border.style.border = "2px solid red";
    valid_phone = "no";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12){
    error_message.innerHTML = "Please enter a valid phone number.";
    error_border.style.border = "2px solid red";
    valid_phone = "no";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_phone = "yes";
  }
}


var gender_valid = "no";
function register(product_id){
	if(document.getElementById("reg_male").checked == true){
		var gender = "Male";
		gender_valid = "yes";
	}
	else if(document.getElementById("reg_female").checked == true){
		var gender = "Female";
		gender_valid = "yes";
	}
	else{
		document.getElementById("gender_error").innerHTML = "Gender is required."
		gender_valid = "no";
		document.querySelector(".gender_radiobox").style.border = "2px solid red";
	}


	if(fname_valid == "yes" && lname_valid == "yes" && email_valid == "yes" && password_valid == "yes" && confirm_password_valid == "yes" && valid_address == "yes" && valid_postcode == "yes" && valid_state == "yes" && valid_area == "yes" && valid_phone == "yes" && gender_valid == "yes"){
		var operation = "register";
		var fname = document.getElementById("reg_fname").value;
		var lname = document.getElementById("reg_lname").value;
		var email = document.getElementById("reg_email").value;
		var password = document.getElementById("reg_pass").value;
		var address = document.getElementById("reg_add").value;
		var postcode = document.getElementById("reg_postcode").value;
		var state = document.getElementById("reg_state").value;
		var area = document.getElementById("reg_area").value;
		var phoneNo = document.getElementById("reg_phone").value;

		$.ajax({
			url: "function/login_register_validation.php",
			type: "POST",
			data: {
				'operation': operation,
				'fname': fname,
				'lname': lname,
				'email': email,
				'password': password,
				'gender': gender,
				'phoneNo': phoneNo,
				'address': address,
				'postcode': postcode,
				'state': state,
				'area': area
			},
		});
		document.getElementById("register_error_wrap").style.display = "none";
		document.getElementById("register_alert_wrap").style.display = "block";
		document.querySelector("body").style.overflow = "hidden";

		setTimeout(function(){
			$('#register_alert_wrap').fadeOut('fast');
			$('body').css('overflow', 'auto');
			if(product_id == "none"){
				window.location = "login_register.php";
			}
			else{
				window.location = "login_register.php?product_id="+product_id;
			}
		}, 1500);
	}
	else{
		document.getElementById("register_error_wrap").style.display = "block";

		fname_validation();
		lname_validation();
		email_validation();
		new_password_validation();
		confirm_password_validation();
		addressValidation();
		postcodeValidation();
		stateValidation();
		areaValidation();
		phoneValidation();
	}
}

function login_press(){
	// Number 13 is the "Enter" key on the keyboard
	if (event.keyCode === 13) {
		document.getElementById("login_button").click();
	}
}