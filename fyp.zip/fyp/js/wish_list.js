function add_cart(counter) {
	event.preventDefault();
	var operation = "add_cart";
	var product_id = document.getElementById('product_id'+counter).value;
	var quantity = 1;
	var update_cart_qty = document.querySelector(".shopping_cart_calculate").innerHTML;

	update_cart_qty = parseInt(update_cart_qty) + 1;

	document.querySelector(".shopping_cart_calculate").innerHTML = update_cart_qty;

	document.getElementById("add_success_alert_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	setTimeout(function(){
		$('#add_success_alert_wrap').fadeOut('fast');
		$('body').css('overflow','auto');
	}, 1500);
				
	update_shopping_cart_databases(product_id, quantity, operation);
}

function update_shopping_cart_databases(product_id, quantity, operation){
	$.ajax({
		url: "function/update_wish_list.php",
		type: "POST",
		data: { 
			'product_id': product_id, 
			'quantity': quantity, 
			'operation': operation
		 },
		success: function(data){
			if(data == "login_false"){
				window.location = "login_reg_interface.php?product_id="+product_id;
			}
			else{
				document.querySelector(".shopping_cart_calculate").innerHTML = update_cart_qty;
				document.querySelector(".shopping_cart_calculate").id = "";
			}
		},           
	});
}

function delete_wish_list(counter, product_id) {
	document.getElementById('delete_product_id').value = product_id;
	document.getElementById('delete_product_counter').value = counter;

	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";
}

function cancel_delete(){
	document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
}

function delete_confirm_yes(){
	var operation = "delete_wish_list";

	var product_id = document.getElementById('delete_product_id').value;
	var counter = document.getElementById('delete_product_counter').value;

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/update_wish_list.php",
		type: "POST",
		data: {
			'operation': operation,
			'product_id': product_id
		},
		success: function(){
			document.getElementById("wishlist_product_row"+counter).style.display = "none";
		}
	});

	var total_wishlish_qty = document.getElementById("total_wishlish_qty").value;
	total_wishlish_qty = parseInt(total_wishlish_qty) - 1;
	document.getElementById("total_wishlish_qty").value = total_wishlish_qty;

	console.log(total_wishlish_qty);
	if(total_wishlish_qty == 0){
		document.getElementById("wish_list_dot").style.display = "none";
		document.getElementById("wish_list_title").style.display = "none";
		document.getElementById("empty_cart_wrap").style.display = "block";
	}
	else{
		document.getElementById("wish_list_dot").style.display = "block";
		document.getElementById("empty_cart_wrap").style.display = "none";
		document.getElementById("wish_list_title").style.display = "table-row";
	}
}