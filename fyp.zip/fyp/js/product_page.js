function add(){
	var quantity = document.querySelector('[name="quantity"]');
	quantity.value = parseInt(quantity.value) + 1;
}

function minus(){
	var quantity = document.querySelector('[name="quantity"]');

	if (parseInt(quantity.value) > 1){
		quantity.value = parseInt(quantity.value) - 1;
	}
}

function min_qty_check(){
	var quantity = document.querySelector('[name="quantity"]');

	if (quantity.value < 1){
		quantity.value = 1;
	}
}

function check_cart_product_qty(){
	var quantity = document.querySelector('[name="quantity"]');
	quantity = quantity.value;

	if(quantity >= 1000){
		document.querySelector('[name="quantity"]').value = 999;
		document.getElementById("max_qty_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";
	}
}

function close_max_qty_wrap(){
	$('#max_qty_wrap').fadeOut('fast');
	$('body').css('overflow','auto');
}

//add to cart
var update_cart_qty = "";
function add_cart(){
	var operation = "add_cart_2";
	var product_id = document.getElementById('product_id').value;
	var quantity = document.querySelector('[name="quantity"]');
	quantity.value = parseInt(quantity.value);
	quantity = quantity.value;

	update_shopping_cart_databases(product_id, quantity, operation);

	update_cart_qty = document.getElementById('total_in_cart_qty').value;
	update_cart_qty = parseInt(update_cart_qty) + parseInt(quantity);
}

function update_shopping_cart_databases(product_id, quantity, operation){
    $.ajax({
        url: "function/update_shopping_cart.php",
        type: "POST",
        data: {
        	'product_id': product_id,
        	'quantity': quantity,
        	'operation': operation
        },
        success: function(data){
			if(data == "login_false"){
				window.location = "login_register.php?product_id="+product_id;
			}
			else{
				document.getElementById("add_to_cart_popup_wrap").style.display = "block";
				document.getElementById('total_in_cart_qty').value = update_cart_qty;

				if(update_cart_qty > 99){
					document.querySelector(".shopping_cart_calculate").innerHTML = "99+";
				}
				else{
					document.querySelector(".shopping_cart_calculate").innerHTML = update_cart_qty;
				}

				document.querySelector(".shopping_cart_calculate").id = "";

				setTimeout(function(){
					$('#add_to_cart_popup_wrap').fadeOut('fast');
				}, 1000);
			}
        },
    });
}

function buy_now(){
	var operation = "buy_now";
	var product_id = document.getElementById('product_id').value;
	var quantity = document.querySelector('[name="quantity"]');
	quantity = parseInt(quantity.value);
	
	$.ajax({
        url: "function/update_shopping_cart.php",
        type: "POST",
        data: {
        	'product_id': product_id,
        	'quantity': quantity,
        	'operation': operation
        },
        success: function(data){
			if(data == "login_false"){
				window.location = "login_register.php?product_id="+product_id;
			}
			else{
				window.location = "shopping_cart.php?product_id="+product_id;
			}
        },
    });
}

function update_wishlist(product_id){
	event.preventDefault();

	var wish_list_status = document.getElementById('wish_list_status').value;
	var total_in_wish_list = document.getElementById('total_in_wish_list').value;
	total_in_wish_list = parseInt(total_in_wish_list);

	if(wish_list_status == "in_wish_list"){
		var operation = "delete_wish_list";
		total_in_wish_list -= 1;

		if(total_in_wish_list == 0){
			document.getElementById("wish_list_dot").style.display = "none";
		}
	}
	else{
		var operation = "add_to_wishlist";
		total_in_wish_list += 1;

		if(total_in_wish_list > 0){
			document.getElementById("wish_list_dot").style.display = "block";
		}
	}

	document.getElementById('total_in_wish_list').value = total_in_wish_list;

	$.ajax({
		url: "function/update_wish_list.php",
		type: "POST",
		data: {
			'product_id':product_id,
			'operation': operation
		},
		success: function(data){
			if(data == "login_false"){
				window.location = "login_register.php?product_id="+product_id;
			}
			else{
				if(wish_list_status == "in_wish_list"){
					document.getElementById('wish_list_icon_1').style.display = "block";
					document.getElementById('wish_list_icon_2').style.display = "none";
					document.getElementById('wish_list_status').value = "not_in_wish_list";
				}
				else{
					document.getElementById('wish_list_icon_1').style.display = "none";
					document.getElementById('wish_list_icon_2').style.display = "block";
					document.getElementById('wish_list_status').value = "in_wish_list";
				}
			}
		},
	});
}