//open filter pop up
function filter_pop_up(){
	document.querySelector(".filter_pop_up_wrap").style.display="block";
	document.querySelector(".search_pop_up_wrap").style.display = "none";
	document.querySelector("body").style.overflow = "hidden";
}

//close filter pop up
function close_filter_pop_up(){
	document.querySelector(".filter_pop_up_wrap").style.display="none";
	document.querySelector("body").style.overflow = "auto";
}

//add to cart
function add_cart(counter) {
	event.preventDefault();
	var operation = "add_cart_1";
	var product_id = document.getElementById('product_id'+counter).value;
	var quantity = 1;

	var update_cart_qty = document.getElementById('total_in_cart_qty').value;
	update_cart_qty = parseInt(update_cart_qty) + 1;

	$.ajax({
        url: "function/update_shopping_cart.php",
        type: "POST",
        data: { 
        	'product_id': product_id, 
        	'quantity': quantity, 
        	'operation': operation
        },
        success: function(data){
			if(data == "login_false"){
				window.location = "login_register.php?product_id="+product_id;
			}
			else{
				document.querySelector(".shopping_cart_calculate").id = "";
				
				document.getElementById('total_in_cart_qty').value = update_cart_qty;

				if(update_cart_qty > 99){
					document.querySelector(".shopping_cart_calculate").innerHTML = "99+";
				}
				else{
					document.querySelector(".shopping_cart_calculate").innerHTML = update_cart_qty;
				}
			}
        },           
    });
}


function update_wishlist(counter){
	event.preventDefault();
	var product_id = document.getElementById('product_id'+counter).value;

	var wish_list_status = document.getElementById('wish_list_status'+counter).value;
	var total_in_wish_list = document.getElementById('total_in_wish_list').value;
	total_in_wish_list = parseInt(total_in_wish_list);

	if(wish_list_status == "in_wish_list"){
		var operation = "delete_wish_list";
		total_in_wish_list -= 1;

		if(total_in_wish_list == 0){
			document.getElementById("wish_list_dot").style.display = "none";
		}
	}
	else{
		var operation = "add_to_wishlist";
		total_in_wish_list += 1;

		if(total_in_wish_list > 0){
			document.getElementById("wish_list_dot").style.display = "block";
		}
	}

	document.getElementById('total_in_wish_list').value = total_in_wish_list;

	$.ajax({
		url: "function/update_wish_list.php",
		type: "POST",
		data: {
			'product_id':product_id,
			'operation': operation
		},
		success: function(data){
			if(data == "login_false"){
				window.location = "login_register.php?product_id="+product_id;;
			}
			else{
				if(wish_list_status == "in_wish_list"){
					document.getElementById('wish_list_icon_1'+counter).style.display = "block";
					document.getElementById('wish_list_icon_2'+counter).style.display = "none";
					document.getElementById('wish_list_status'+counter).value = "not_in_wish_list";
				}
				else{
					document.getElementById('wish_list_icon_1'+counter).style.display = "none";
					document.getElementById('wish_list_icon_2'+counter).style.display = "block";
					document.getElementById('wish_list_status'+counter).value = "in_wish_list";
				}
			}
		},
	});
}

function change_filter_price(){
	var filter_price_range_slider = document.getElementById("filter_price_range_slider");
	var target_filter_price = document.getElementById("target_filter_price");
	target_filter_price.innerHTML = filter_price_range_slider.value;
}

function update_filter_page(filter_action, target_product_page){
	var host = location.host;
	var pathname = location.pathname;
	var current_url = window.location.href;

	var max_product_price = document.getElementById("max_price_value").value;
	max_product_price = parseFloat(max_product_price);

	if(filter_action == "filter_price"){
		var target_price = document.getElementById("filter_price_range_slider").value;
		target_price = parseFloat(target_price);
	
		if(target_price != max_product_price){
			var filter_price = "&filter_max_price="+target_price;
		}
		else{
			var filter_price="";
		}
	}
	else{
		var current_target_price = document.getElementById("filter_price_range_slider").value;
		current_target_price = parseFloat(current_target_price);

		if(current_target_price != max_product_price){
			var filter_price = "&filter_max_price="+current_target_price;
		}
		else{
			var filter_price="";
		}
	}


	if(filter_action == "gender"){
		var filter_gender = "";
		var gender_filter_option = document.querySelectorAll(".gender_filter_option");

		for(var i=0; i<gender_filter_option.length; i++){
			if(gender_filter_option[i].checked == true){
				filter_gender += "&filter_gender[]="+gender_filter_option[i].value;
			}
		}
	}
	else{
		var filter_gender = "";
		var gender_filter_option = document.querySelectorAll(".gender_filter_option");
		var current_filter_gender = "false";

		for(var i=0; i<gender_filter_option.length; i++){
			if(gender_filter_option[i].checked == true){
				filter_gender += "&filter_gender[]="+gender_filter_option[i].value;
				current_filter_gender = "true";
			}
		}
		
		if(current_filter_gender == "false"){
			filter_gender = "";
		}
	}


	if(filter_action == "product_type"){
		var filter_product_type = "";
		var product_type_filter_option = document.querySelectorAll(".product_type_filter_option");

		for(var i=0; i<product_type_filter_option.length; i++){
			if(product_type_filter_option[i].checked == true){
				filter_product_type += "&filter_product_type[]="+product_type_filter_option[i].value;
			}
		}
	}
	else{
		var filter_product_type = "";
		var product_type_filter_option = document.querySelectorAll(".product_type_filter_option");
		var current_filter_type = "false";

		for(var i=0; i<product_type_filter_option.length; i++){
			if(product_type_filter_option[i].checked == true){
				filter_product_type += "&filter_product_type[]="+product_type_filter_option[i].value;
				current_filter_type = "true";
			}
		}
		
		if(current_filter_type == "false"){
			filter_product_type = "";
		}
	}


	if(filter_action == "product_occasions"){
		var filter_product_occasions = "";
		var product_occasions_filter_option = document.querySelectorAll(".product_occasions_filter_option");

		for(var i=0; i<product_occasions_filter_option.length; i++){
			if(product_occasions_filter_option[i].checked == true){
				filter_product_occasions += "&filter_product_occasions[]="+product_occasions_filter_option[i].value;
			}
		}
	}
	else{
		var filter_product_occasions = "";
		var product_occasions_filter_option = document.querySelectorAll(".product_occasions_filter_option");
		var current_filter_occasions = "false";

		for(var i=0; i<product_occasions_filter_option.length; i++){
			if(product_occasions_filter_option[i].checked == true){
				filter_product_occasions += "&filter_product_occasions[]="+product_occasions_filter_option[i].value;
				current_filter_occasions = "true";
			}
		}
		
		if(current_filter_occasions == "false"){
			filter_product_occasions = "";
		}
	}

	var url_string = window.location.search;
	var url_parameters = new URLSearchParams(url_string);
	var current_search_keyword = url_parameters.get('search_keyword');
	if(current_search_keyword){
		search_keyword = "&search_keyword="+current_search_keyword;
	}
	else{
		search_keyword = "";
	}


	if(filter_action == "sort_by_price"){
		var sort_by_price_option = document.getElementById("sort_by_price").value;

		if(sort_by_price_option == "ASC"){
			var sort_by_price = "&sort_by_price="+sort_by_price_option;
		}
		else if(sort_by_price_option == "DESC"){
			var sort_by_price = "&sort_by_price="+sort_by_price_option;
		}
		else{
			var sort_by_price = "";
		}
	}
	else{
		var sort_by_price_option = document.getElementById("sort_by_price").value;

		if(sort_by_price_option == "ASC"){
			var sort_by_price = "&sort_by_price="+sort_by_price_option;
		}
		else if(sort_by_price_option == "DESC"){
			var sort_by_price = "&sort_by_price="+sort_by_price_option;
		}
		else{
			var sort_by_price = "";
		}
	}


	if(filter_action == "update_page"){
		window.location = "?"+filter_price+filter_gender+filter_product_type+filter_product_occasions+sort_by_price+search_keyword+"&product_page="+target_product_page;
	}
	else{
		if(filter_action != "sort_by_price"){
			sessionStorage.setItem('filter_pop_up', "yes");
		}
		window.location = "?"+filter_price+filter_gender+filter_product_type+filter_product_occasions+sort_by_price+search_keyword;
	}
}



//prevent history back page
window.onload = function(){
	var url = window.location.href;
	var params = (new URL(url)).searchParams;

	var price  = params.getAll('filter_max_price');
	if(price != ""){
		document.getElementById("filter_price_range_slider").value = price;
	}
	else{
		var max_product_price = document.getElementById("max_price_value").value;
		document.getElementById("filter_price_range_slider").value = max_product_price;
	}


	var gender  = params.getAll('filter_gender[]');
	if(gender != ""){
		var gender_filter_option = document.querySelectorAll(".gender_filter_option");

		var found_gender = "";
		for(var i=0; i<gender_filter_option.length; i++){
			found_gender = 0;
			var gender_value = gender_filter_option[i].value;

			for(var j=0; j<gender.length; j++){
				if(gender[j] == gender_value){
					found_gender++;
				}
			}

			if(found_gender != 0){
				gender_filter_option[i].checked = true;
			}
			else{
				gender_filter_option[i].checked = false;
			}
		}
	}
	else{
		var gender_filter_option = document.querySelectorAll(".gender_filter_option");

		for(var i=0; i<gender_filter_option.length; i++){
			gender_filter_option[i].checked = false;
		}
	}


	var product_type  = params.getAll('filter_product_type[]');
	if(product_type != ""){
		var product_type_filter_option = document.querySelectorAll(".product_type_filter_option");

		var found_product_type = "";
		for(var i=0; i<product_type_filter_option.length; i++){
			found_product_type = 0;
			var gender_value = product_type_filter_option[i].value;

			for(var j=0; j<product_type.length; j++){
				if(product_type[j] == gender_value){
					found_product_type++;
				}
			}

			if(found_product_type != 0){
				product_type_filter_option[i].checked = true;
			}
			else{
				product_type_filter_option[i].checked = false;
			}
		}
	}
	else{
		var product_type_filter_option = document.querySelectorAll(".product_type_filter_option");

		for(var i=0; i<product_type_filter_option.length; i++){
			product_type_filter_option[i].checked = false;
		}
	}


	var occasions  = params.getAll('filter_product_occasions[]');
	if(occasions != ""){
		var product_occasions_filter_option = document.querySelectorAll(".product_occasions_filter_option");

		var found_occasions = "";
		for(var i=0; i<product_occasions_filter_option.length; i++){
			found_occasions = 0;
			var gender_value = product_occasions_filter_option[i].value;

			for(var j=0; j<occasions.length; j++){
				if(occasions[j] == gender_value){
					found_occasions++;
				}
			}

			if(found_occasions != 0){
				product_occasions_filter_option[i].checked = true;
			}
			else{
				product_occasions_filter_option[i].checked = false;
			}
		}
	}
	else{
		var product_occasions_filter_option = document.querySelectorAll(".product_occasions_filter_option");

		for(var i=0; i<product_occasions_filter_option.length; i++){
			product_occasions_filter_option[i].checked = false;
		}
	}


	var sort_by_price  = params.getAll('sort_by_price');
	if(sort_by_price != ""){
		document.getElementById("sort_by_price").value = sort_by_price;
	}
	else{
		document.getElementById("sort_by_price").value = "none";
	}

}