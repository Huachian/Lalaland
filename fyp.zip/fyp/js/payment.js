function payment_validation(){
	var cardholder_name = document.getElementById("cardholder_name").value;
	var card_number = document.getElementById("card_number").value;
	var expiry_date = document.getElementById("expiry_date").value;
	var cvv = document.getElementById("cvv").value;


	var space = /^\s*$/;

	var	cardholder_name_valid = "no";
	if(cardholder_name.match(space)){
		document.getElementById("card_name_error").innerHTML = "Please enter card holder's name.";
		document.getElementById("cardholder_name").style.border = "2px solid red";
		cardholder_name_valid = "no";
	}
	else{
		document.getElementById("card_name_error").innerHTML = "";
		document.getElementById("cardholder_name").style.border = "2px solid grey";
		cardholder_name_valid = "yes";
	}

	var	card_number_valid = "no";
	if(card_number.length == 0){
		document.getElementById("card_number_error").innerHTML = "Please enter card number.";
		document.getElementById("card_number").style.border = "2px solid red";
		card_number_valid = "no";
	}
	else if(card_number.length != 19){
		document.getElementById("card_number_error").innerHTML = "Card number is invalid.";
		document.getElementById("card_number").style.border = "2px solid red";
		card_number_valid = "no";
	}
	else{
		document.getElementById("card_number_error").innerHTML = "";
		document.getElementById("card_number").style.border = "2px solid grey";
		card_number_valid = "yes";
	}


	var	expiry_date_valid = "no";
	var current_year = new Date().getFullYear().toString().substr(-2);
	var a = new Date();
	var current_month = ("0" + (a.getMonth() + 1)).slice(-2);
	if(expiry_date.length == 0){
		document.getElementById("card_expiry_error").innerHTML = "Please enter card expiry date.";
		document.getElementById("expiry_date").style.border = "2px solid red";
		expiry_date_valid = "no";
	}
	else if(expiry_date.length < 7 || expiry_date.substring(0, 2) > 12 || expiry_date.substring(0, 2) == 0){
		document.getElementById("card_expiry_error").innerHTML = "Invalid expiry date.";
		document.getElementById("expiry_date").style.border = "2px solid red";
		expiry_date_valid = "no";
	}
	else if(expiry_date.substring(5, 7) < current_year){
		document.getElementById("card_expiry_error").innerHTML = "Card is expired.";
		document.getElementById("expiry_date").style.border = "2px solid red";
		expiry_date_valid = "no";
	}
	else if(expiry_date.substring(0, 2) <= current_month){
		if(expiry_date.substring(5, 7) <= current_year){
			document.getElementById("card_expiry_error").innerHTML = "Card is expired.";
			document.getElementById("expiry_date").style.border = "2px solid red";
			expiry_date_valid = "no";
		}
		else{
			document.getElementById("card_expiry_error").innerHTML = "";
			document.getElementById("expiry_date").style.border = "2px solid grey";
			expiry_date_valid = "yes";
		}
	}
	else{
		document.getElementById("card_expiry_error").innerHTML = "";
		document.getElementById("expiry_date").style.border = "2px solid grey";
		expiry_date_valid = "yes";
	}


	var	cvv_valid = "no";
	if(cvv.length < 3){
		document.getElementById("card_cvv_error").innerHTML = "Please enter cvv number.";
		document.getElementById("cvv").style.border = "2px solid red";
		cvv_valid = "no";
	}
	else{
		document.getElementById("card_cvv_error").innerHTML = "";
		document.getElementById("cvv").style.border = "2px solid grey";
		cvv_valid = "yes";
	}


	if(cardholder_name_valid == "yes" && card_number_valid == "yes" && expiry_date_valid == "yes" && cvv_valid == "yes"){
		var operation = "order_success";

		let address_id = sessionStorage.getItem('address_id');
		let buyer_message = sessionStorage.getItem('buyer_message');
		let total_payment = sessionStorage.getItem('total_payment');
		total_payment = parseFloat(total_payment);
		// let voucher_id = sessionStorage.getItem('selected_voucher_id');
		// let voucher_code = sessionStorage.getItem('selected_voucher_code');


		$.ajax({
			url: "function/update_orders.php",
			type: "POST",
			data: {
				'operation': operation,
				'address_id': address_id,
				'buyer_message': buyer_message,
				'total_payment': total_payment
				// 'voucher_id': voucher_id,
				// 'voucher_code': voucher_code
			},
			success: function(data){
				if(data == "yes"){
					sessionStorage.setItem('payment_status', "done");

					document.getElementById('payment_process_wrap').style.display = "block";
					document.querySelector('body').style.overflow = "hidden";

					setTimeout(function(){
						$('#payment_process_wrap').fadeOut(1000);
						$('body').css('overflow','auto');
						order_success();
					}, 2500)
				}
				else{
					sessionStorage.setItem('payment_status', "havent_done");

					document.getElementById("checking_available_popup").style.display = "block";
			        document.querySelector('body').style.overflow = "hidden";

			        setTimeout(function(){
			          	$('#checking_available_popup').fadeOut('fast');
			        	$('body').css('overflow','auto');
			            window.location = "shopping_cart.php";
			        }, 2000);
				}
			},
		});
	}
	else{
		sessionStorage.setItem('payment_status', "havent_done");
	}
}


function order_success(){
	document.getElementById('order_success_alert_wrap').style.display = "block";
	document.querySelector('body').style.overflow = "hidden";
	
	setTimeout(function(){
		$('#order_success_alert_wrap').fadeOut(1000);
		$('body').css('overflow','auto');
		window.location = "view_purchase.php";
	}, 2500)
}

function click_payment(){
	// Number 13 is the "Enter" key on the keyboard
	if (event.keyCode === 13) {
		document.getElementById("pay_btn").click();
	}
}