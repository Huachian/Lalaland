function change_vertical_card_view(card_type){
	if(card_type == "vertical"){
		var current_view = document.getElementById("current_vertical_view").value;
	}
	else{
		var current_view = document.getElementById("current_horizontal_view").value;
	}
	
	if(current_view == "front"){
		if(card_type == "vertical"){
			document.getElementById("current_vertical_view").value = "back";
			document.getElementById("vertical_card_front").style.display = "none";
			document.getElementById("vertical_card_back").style.display = "block";
		}
		else{
			document.getElementById("current_horizontal_view").value = "back";
			document.getElementById("horizontal_card_front").style.display = "none";
			document.getElementById("horizontal_card_back").style.display = "block";
		}

		document.getElementById("card_edit_title").innerHTML = "Card Back";

		if(edit == "1"){
			if(card_type == "vertical"){
				document.getElementById("vertical_change_image_btn").style.display = "none";
			}
			else{
				document.getElementById("horizontal_change_image_btn").style.display = "none";
			}
		}
	}
	else{
		if(card_type == "vertical"){
			document.getElementById("current_vertical_view").value = "front";
			document.getElementById("vertical_card_front").style.display = "block";
			document.getElementById("vertical_card_back").style.display = "none";
		}
		else{
			document.getElementById("current_horizontal_view").value = "front";
			document.getElementById("horizontal_card_front").style.display = "block";
			document.getElementById("horizontal_card_back").style.display = "none";
		}
		

		document.getElementById("card_edit_title").innerHTML = "Card Front";

		if(edit == "1"){
			if(card_type == "vertical"){
				document.getElementById("vertical_change_image_btn").style.display = "inline";
			}
			else{
				document.getElementById("horizontal_change_image_btn").style.display = "inline";
			}
		}
	}
}

var edit = "0";
var temp_card_image = "";
var temp_card_message = "";
function edit_card(card_type){
	temp_card_message = document.getElementById("text_input").value;

	if(card_type == "vertical"){
		edit = "1";
		var current_view = document.getElementById("current_vertical_view").value;
		temp_card_image = document.getElementById("vertical_uploaded_image").src;

		if(current_view == "front"){
			document.getElementById("vertical_change_image_btn").style.display = "inline";
		}
		else{
			document.getElementById("vertical_change_image_btn").style.display = "none";
		}

		document.getElementById("text_input").disabled = false;
		document.getElementById("text_input").style.border = "2px solid #ffcc66";
		document.getElementById("text_input").style.background = "#fff7e6";
		document.getElementById("edit_btn").style.display = "none";
		document.getElementById("save_edit_btn").style.display = "block";
		document.getElementById("cancel_edit_btn").style.display = "block";
		document.getElementById("custom_selection_wrap").style.height = "530px";
	}
	else{
		edit = "1";
		var current_view = document.getElementById("current_horizontal_view").value;
		temp_card_image = document.getElementById("horizontal_uploaded_image").src;

		if(current_view == "front"){
			document.getElementById("horizontal_change_image_btn").style.display = "inline";
		}
		else{
			document.getElementById("horizontal_change_image_btn").style.display = "none";
		}

		document.getElementById("text_input").disabled = false;
		document.getElementById("text_input").style.border = "2px solid #ffcc66";
		document.getElementById("text_input").style.background = "#fff7e6";
		document.getElementById("edit_btn").style.display = "none";
		document.getElementById("save_edit_btn").style.display = "block";
		document.getElementById("cancel_edit_btn").style.display = "block";
		document.getElementById("custom_selection_wrap").style.height = "530px";
	}
}

function save_dit_card(card_type, card_id){
	var operation = "save_edit_card";
	var space = /^\s*$/;

	var card_message = document.getElementById("text_input").value;

	if(card_message.match(space)){
		document.getElementById("save_edit_btn").innerHTML="You need to write something!";
		document.getElementById("save_edit_btn").style.background="#e6176d";
		document.getElementById("save_edit_btn").style.color = "white";
	}
	else{
		if(card_type == "vertical"){
			var card_image = $('#vertical_card_img_upload')[0].files;
		}
		else if(card_type == "horizontal"){
			var card_image = $('#horizontal_card_img_upload')[0].files;
		}

		var card_message = document.getElementById("text_input").value;

		var fd = new FormData();
		fd.append('operation',operation);
		fd.append('card_id', card_id);
		fd.append('card_image',card_image[0]);
		fd.append('card_message', card_message);

		
		$.ajax({
			url: "function/customization.php",
			type: "POST",
			data: fd,
			contentType: false,
		    processData: false,
		    success: function(data){
		    	edit = "0";
		    	if(card_type == "vertical"){
		    		document.getElementById("vertical_change_image_btn").style.display = "none";
		    	}
		    	else{
		    		document.getElementById("horizontal_change_image_btn").style.display = "none";
		    	}
		    	
				document.getElementById("text_input").disabled = true;
				document.getElementById("text_input").style.border = "2px solid #b3b3b3";
				document.getElementById("text_input").style.background = "rgba(242, 242, 242, 0.5)";

		    	document.getElementById("edit_btn").style.display = "block";
				document.getElementById("save_edit_btn").style.display = "none";
				document.getElementById("cancel_edit_btn").style.display = "none";
				document.getElementById("custom_selection_wrap").style.height = "500px";

		    	document.getElementById("card_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

		    	setTimeout(function(){
		    		document.getElementById("card_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
		    	}, 2000);
		    }
		});
	}
}

function cancel_edit_card(card_type, card_id){
	edit = "0";
	
	document.getElementById("text_input").disabled = true;
	document.getElementById("text_input").style.border = "2px solid #b3b3b3";
	document.getElementById("text_input").style.background = "rgba(242, 242, 242, 0.5)";

	document.getElementById("edit_btn").style.display = "block";
	document.getElementById("save_edit_btn").style.display = "none";
	document.getElementById("cancel_edit_btn").style.display = "none";
	document.getElementById("custom_selection_wrap").style.height = "500px";

	if(card_type == "vertical"){
		document.getElementById("vertical_change_image_btn").style.display = "none";
		document.getElementById("text_input").value = temp_card_message;
		document.getElementById("vertical_uploaded_image").src = temp_card_image;
		document.getElementById("vertical_demo_text").innerHTML = temp_card_message;
	}
	else{
		document.getElementById("horizontal_change_image_btn").style.display = "none";
		document.getElementById("text_input").value = temp_card_message;
		document.getElementById("horizontal_uploaded_image").src = temp_card_image;
		document.getElementById("horizontal_demo_text").innerHTML = temp_card_message;
	}
}

function update_demo_text(card_type){
	var text_content = document.getElementById("text_input").value;

	document.getElementById("save_edit_btn").innerHTML="Save Edit";
	document.getElementById("save_edit_btn").style.background="#00cc66";
	document.getElementById("save_edit_btn").style.color = "black";
	document.getElementById("card_edit_title").innerHTML = "Card Back";

	if(card_type == "vertical"){
		if(edit == "1"){
			document.getElementById("vertical_change_image_btn").style.display = "none";
		}
		document.getElementById("current_vertical_view").value = "back";
		document.getElementById("vertical_card_front").style.display = "none";
		document.getElementById("vertical_card_back").style.display = "block";
		document.getElementById("vertical_demo_text").innerHTML = text_content;
	}
	else if(card_type == "horizontal"){
		if(edit == "1"){
			document.getElementById("horizontal_change_image_btn").style.display = "none";
		}
		document.getElementById("current_horizontal_view").value = "back";
		document.getElementById("horizontal_card_front").style.display = "none";
		document.getElementById("horizontal_card_back").style.display = "block";
		document.getElementById("horizontal_demo_text").innerHTML = text_content;
	}
}


function upload_image(card_type){
	if(card_type == "vertical"){
		document.getElementById("vertical_card_img_upload").click();
	}
	else if(card_type == "horizontal"){
		document.getElementById("horizontal_card_img_upload").click();
	}
}


function preview_product_image(card_type){
	if(card_type == "vertical"){
		var file = document.getElementById("vertical_card_img_upload").files;
	}
	else if(card_type == "horizontal"){
		var file = document.getElementById("horizontal_card_img_upload").files;
	}

	if(file.length > 0){
		var fileReader = new FileReader();

		fileReader.onload = function(event){
			if(card_type == "vertical"){
				document.getElementById("vertical_uploaded_image").setAttribute("src", event.target.result);
			}
			else if(card_type == "horizontal"){
				document.getElementById("horizontal_uploaded_image").setAttribute("src", event.target.result);
			}
		}

		fileReader.readAsDataURL(file[0]);
	}
	else{
		var ori_card_image = document.getElementById("ori_card_image").value;

		if(card_type == "vertical"){
			document.getElementById("vertical_uploaded_image").setAttribute("src", ori_card_image);
		}
		else if(card_type == "horizontal"){
			document.getElementById("horizontal_uploaded_image").setAttribute("src", ori_card_image);
		}
		
	}
}