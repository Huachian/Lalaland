function send_reset_email(){
	var email = document.getElementById("reset_password_email").value;

	
	$.ajax({
		url: 'function/update_customer.php',
		type: 'POST',
		data: {
			'operation': "check_send_reset_email",
			'email': email
		},
		success: function(data){
			if(data == "no"){
				document.getElementById("reset_email_error_wrap").style.display = "block";
				document.getElementById("reset_email_error").innerHTML = "No account found with that email.";
				document.getElementById("reset_email_success_wrap").style.display = "none";
			}
			else if(data == "inactive"){
				document.getElementById("reset_email_error_wrap").style.display = "block";
				document.getElementById("reset_email_error").innerHTML = "Account is inactive, please contact admin.";
				document.getElementById("reset_email_success_wrap").style.display = "none";
			}
			else{
				document.getElementById("reset_email_error_wrap").style.display = "none";
				document.getElementById("reset_email_success_wrap").style.display = "block";
			}
		},
	});

	var operation = "send_reset_email";
	$.ajax({
		url: 'function/update_customer.php',
		type: 'POST',
		data: {
			'operation': operation,
			'email': email
		},
	});
}

function reset_error_message(){
	document.getElementById("reset_email_error_wrap").style.display = "none";
	document.getElementById("reset_email_success_wrap").style.display = "none";
}

function keyPressed_new_password(){
	var key = event.keyCode || event.charCode || event.which ;
	return key;
}

function keyPressed_confirm_password(){
	var key = event.keyCode || event.charCode || event.which ;
	return key;
}

var length_valid = "no";
var number_valid = "no";
var small_letter_valid = "no";
var upper_letter_valid = "no";
var symbol_valid = "no";
var new_password_valid = "no";
function new_password_guide(){
	document.getElementById("password_format").style.display = "block";
	var password = document.getElementById("reset_password").value;
	document.getElementById("pass_error").innerHTML="";

	if(password.length == 0){
		document.getElementById("password_format").style.display = "none";
		var length_valid = "no";
	}
	else if(password.length >= 15){
		document.getElementById("characters").style.color = "#00e600";
		document.getElementById("characters").style.fontWeight = "bold";
		length_valid = "yes";
	}
	else{
		document.getElementById("characters").style.color = "grey";
		document.getElementById("characters").style.fontWeight = "normal";
		length_valid = "no";
	}

	if(password.match(/[0-9]/)){
		document.getElementById("number").style.color = "#00e600";
		document.getElementById("number").style.fontWeight = "bold";
		var number_valid = "yes";
	}
	else{
		document.getElementById("number").style.color = "grey";
		document.getElementById("number").style.fontWeight = "normal";
		number_valid = "no";
	}

	if(password.match(/[a-z]/)){
		document.getElementById("small_letter").style.color = "#00e600";
		document.getElementById("small_letter").style.fontWeight = "bold";
		var small_letter_valid = "yes";
	}
	else{
		document.getElementById("small_letter").style.color = "grey";
		document.getElementById("small_letter").style.fontWeight = "normal";
		small_letter_valid = "no";
	}

	if(password.match(/[A-Z]/)){
		document.getElementById("upper_letter").style.color = "#00e600";
		document.getElementById("upper_letter").style.fontWeight = "bold";
		var upper_letter_valid = "yes";
	}
	else{
		document.getElementById("upper_letter").style.color = "grey";
		document.getElementById("upper_letter").style.fontWeight = "normal";
		upper_letter_valid = "no";
	}

	if(password.match(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/)){
		document.getElementById("symbol").style.color = "#00e600";
		document.getElementById("symbol").style.fontWeight = "bold";
		var symbol_valid = "yes";
	}
	else{
		document.getElementById("symbol").style.color = "grey";
		document.getElementById("symbol").style.fontWeight = "normal";
		symbol_valid = "no";
	}

	if(length_valid == "yes" && number_valid == "yes" && small_letter_valid == "yes" && upper_letter_valid == "yes" && symbol_valid == "yes"){
		document.getElementById("pass_error").innerHTML = "";
		new_password_valid = "yes";
	}
	else{
		new_password_valid = "no";
	}
}

var password_valid = "no";
function new_password_validation(){
	var password = document.getElementById("reset_password").value;
	var space = /^\s*$/;

	document.getElementById("password_format").style.display = "none";

	if(password.match(space))
	{
		document.getElementById("pass_error").innerHTML="New password is required.";
		document.getElementById("reset_password").style.border = "2px solid red";
		password_valid = "no";
	}
	else if(password.length < 15 || password.search(/[0-9]/) == -1 || password.search(/[a-z]/) == -1 || password.search(/[A-Z]/) == -1 || password.search(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/) == -1){
		document.getElementById("pass_error").innerHTML="Password format incorrect.";
		document.getElementById("reset_password").style.border = "2px solid red";
		password_valid = "no";
	}
	else
	{
		document.getElementById("pass_error").innerHTML="";
		document.getElementById("reset_password").style.border = "2px solid #f0f0f0";
		password_valid = "yes";
	}

	var confirm_password = document.getElementById("confirm_reset_password").value;
	if(confirm_password.length != 0){
		confirm_password_validation();
	}
}

var confirm_password_valid = "no";
function confirm_password_validation(){
	var new_password = document.getElementById("reset_password").value;
	var confirm_password = document.getElementById("confirm_reset_password").value;
	var space = /^\s*$/;

	if(confirm_password.match(space))
	{
		document.getElementById("conpass_error").innerHTML= "Confirm password is required.";
		document.getElementById("confirm_reset_password").style.border = "2px solid red";
		confirm_password_valid = "no";
	}
	else if(new_password == confirm_password)
	{
		document.getElementById("conpass_error").innerHTML= "";
		document.getElementById("confirm_reset_password").style.border = "2px solid #f0f0f0";
		confirm_password_valid = "yes";
	}
	else
	{
		document.getElementById("conpass_error").innerHTML= "Password does not match.";
		document.getElementById("confirm_reset_password").style.border = "2px solid red";
		confirm_password_valid = "no";
	}
}

function show_hide_password(operation)
{
	if(operation == "new_password"){
		var toggle = document.getElementById("toggle_password");
		var pass = document.getElementById("reset_password");
	}
	else if(operation == "confirm_new_password"){
		var toggle = document.getElementById("toggle_conpassword");
		var pass = document.getElementById("confirm_reset_password");
	}


	if(pass.type === 'password'){
		pass.setAttribute("type","text");
		toggle.classList.add('hide');
	}
	else{
		pass.setAttribute("type","password");
		toggle.classList.remove('hide');
	}
}

function reset_password(reset_token){
	new_password_validation();
	confirm_password_validation();

	if(password_valid == "yes" && confirm_password_valid == "yes"){
		var operation = "reset_password";
		var password = document.getElementById("reset_password").value;

		$.ajax({
		url: 'function/update_customer.php',
		type: 'POST',
		data: {
			'operation': operation,
			'reset_token': reset_token,
			'password': password
		},
		success: function(){
			document.getElementById("update_password_success").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

	    	setTimeout(function(){
	    		document.getElementById("update_password_success").style.display = "none";
				document.querySelector("body").style.overflow = "auto";
				window.location = "login_register.php";
	    	}, 2000);
		},
	});
	}
}