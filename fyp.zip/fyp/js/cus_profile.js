var current_first_name = "";
var current_last_name = "";
var current_phone_number = "";
var current_gender = "";


function edit_profile(){
  current_first_name = document.getElementById("first_name").value;
  current_last_name = document.getElementById("last_name").value;
  current_phone_number = document.getElementById("phone_number").value;
  var get_current_gender = document.getElementById("current_gender").value;
  if(get_current_gender == "Male"){
    current_gender = "Male";
  }
  else{
    current_gender = "Female";
  }

  document.getElementById("first_name").disabled = false;
  document.getElementById("last_name").disabled = false;
  document.getElementById("phone_number").disabled = false;
  document.getElementById("gender_male").disabled = false;
  document.getElementById("gender_female").disabled = false;

  document.getElementById("edit_profile_btn").style.display = "none";
  document.getElementById("cancel_edit_profile_btn").style.display = "inline";
  document.getElementById("save_edit_profile_btn").style.display = "inline";
}

function cancel_edit_profile(){
  document.getElementById("first_name").value = current_first_name;
  document.getElementById("last_name").value = current_last_name;
  document.getElementById("phone_number").value = current_phone_number;

  if(current_gender == "Male"){
    document.getElementById("gender_male").checked = true;
    document.getElementById("gender_female").checked = false;
  }
  else{
    document.getElementById("gender_male").checked = false;
    document.getElementById("gender_female").checked = true;
  }

  document.getElementById("first_name_error").innerHTML = "";
  document.getElementById("first_name").style.border = "2px solid #f0f0f0";
  document.getElementById("last_name_error").innerHTML = "";
  document.getElementById("last_name").style.border = "2px solid #f0f0f0";
  document.getElementById("phone_number_error").innerHTML = "";
  document.getElementById("phone_number").style.border = "2px solid #f0f0f0";

  document.getElementById("first_name").disabled = true;
  document.getElementById("last_name").disabled = true;
  document.getElementById("phone_number").disabled = true;
  document.getElementById("gender_male").disabled = true;
  document.getElementById("gender_female").disabled = true;

  document.getElementById("edit_profile_btn").style.display = "inline";
  document.getElementById("cancel_edit_profile_btn").style.display = "none";
  document.getElementById("save_edit_profile_btn").style.display = "none";
}

var valid_first_name = "false";
function first_name_validation()
{
  var space = /^\s*$/;
  var fname = document.getElementById("first_name").value;
  var pattern = /^[a-zA-Z\s]+$/;
  
  //first name
  if(fname.match(space))
  {
    document.getElementById("first_name_error").innerHTML = "First name is required.";
    document.getElementById("first_name").style.border = "2px solid red";
    valid_first_name = "false";
  }
  else if(fname.match(pattern))
  {
    document.getElementById("first_name_error").innerHTML = "";
    document.getElementById("first_name").style.border = "2px solid #f0f0f0";
    valid_first_name = "true";
  }
  else
  {
    document.getElementById("first_name_error").innerHTML = "Please enter name as only Alphabet.";
    document.getElementById("first_name").style.border = "2px solid red";
    valid_first_name = "false";
  }
}

var valid_last_name = "false";
function last_name_validation()
{
  var space = /^\s*$/;
  var lname = document.getElementById("last_name").value;
  var pattern = /^[a-zA-Z\s]+$/;

 //last name
 if(lname.match(space))
  {
    document.getElementById("last_name_error").innerHTML = "Last name is required.";
    document.getElementById("last_name").style.border = "2px solid red";
    valid_last_name = "false";
  }
  else if(lname.match(pattern))
  {
    document.getElementById("last_name_error").innerHTML = "";
    document.getElementById("last_name").style.border = "2px solid #f0f0f0";
    valid_last_name = "true";
  }
  else
  {
    document.getElementById("last_name_error").innerHTML = "Please enter name as only Alphabet.";
    document.getElementById("last_name").style.border = "2px solid red";
    valid_last_name = "false";
  }
}

var valid_phone = "false";
function phone_validation()
{
  var space = /^\s*$/;
  var phoneNo = document.getElementById("phone_number").value;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  //phone
  if(phoneNo.match(space))
  {
    document.getElementById("phone_number_error").innerHTML = "Phone number is required.";
    document.getElementById("phone_number").style.border = "2px solid red";
    valid_phone = "false";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12)
  {
    document.getElementById("phone_number_error").innerHTML = "Please enter a valid phone number.";
    document.getElementById("phone_number").style.border = "2px solid red";
    valid_phone = "false";
  }
  else
  {
    document.getElementById("phone_number_error").innerHTML = "";
    document.getElementById("phone_number").style.border = "2px solid #f0f0f0";
    valid_phone = "true";
  }
}

function save()
{
  first_name_validation();
  last_name_validation();
  phone_validation();

  if(valid_first_name == "true" && valid_last_name == "true" && valid_phone == "true"){
    document.getElementById("edit_profile_alert_wrap").style.display = "block";
    document.querySelector('body').style.overflow = "hidden";

    var first_name = document.getElementById("first_name").value;
    var last_name = document.getElementById("last_name").value;
    var phone_number = document.getElementById("phone_number").value;

    if(document.getElementById("gender_male").checked == true){
      var gender = "Male";
    }
    else{
      var gender = "Female";
    }

    document.getElementById("first_name").disabled = true;
    document.getElementById("last_name").disabled = true;
    document.getElementById("phone_number").disabled = true;
    document.getElementById("gender_male").disabled = true;
    document.getElementById("gender_female").disabled = true;
    document.getElementById("edit_profile_btn").style.display = "inline";
    document.getElementById("cancel_edit_profile_btn").style.display = "none";
    document.getElementById("save_edit_profile_btn").style.display = "none";

    update_cus_profile(first_name, last_name, phone_number, gender);

    setTimeout(function(){
      $('#edit_profile_alert_wrap').fadeOut('fast');
      $('body').css('overflow','auto');
    }, 1500); 
  }
}

function update_cus_profile(first_name, last_name, phone_number, gender){
  var operation = "update_profile";

  document.getElementById("sidebar_header").innerHTML = first_name +" "+ last_name;

    $.ajax({
        url: "function/update_customer.php",
        type: "POST",
        data: { 
          'operation': operation, 
          'first_name': first_name, 
          'last_name': last_name, 
          'phone_number': phone_number,
          'gender': gender
        },
    });
}