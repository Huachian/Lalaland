function login_validation(card_type){
	var operation = "check_login";

	$.ajax({
		url: "function/customization.php",
		type: "POST",
		data:{
			'operation': operation
		},
		success: function(data){
			if(data == "login_true"){
				window.location = "customization_upload_photo.php?custom_card_type="+card_type;
			}
			else{
				window.location = "login_register.php?custom_card_type="+card_type;
			}
		},
	});
}

function upload_image(card_type){
	if(card_type == "vertical"){
		document.getElementById("vertical_card_img_upload").click();
	}
	else if(card_type == "horizontal"){
		document.getElementById("horizontal_card_img_upload").click();
	}
}

var image_upload_valid = "false";
function preview_product_image(card_type){
	if(card_type == "vertical"){
		var file = document.getElementById("vertical_card_img_upload").files;

		document.getElementById("flat_vertical_demo_title_wrap").style.display = "none";
		document.getElementById("vertical_uploaded_image").style.display = "block";
	}
	else if(card_type == "horizontal"){
		var file = document.getElementById("horizontal_card_img_upload").files;

		document.getElementById("flat_horizontal_demo_title_wrap").style.display = "none";
		document.getElementById("horizontal_uploaded_image").style.display = "block";
	}

	document.getElementById("change_image_btn_wrap").style.display = "block";
	
	document.getElementById("image_upload_next_button").innerHTML="Next Step";
	document.getElementById("image_upload_next_button").style.background="#00b7b5";

	if(file.length > 0){
		var fileReader = new FileReader();

		fileReader.onload = function(event){
			if(card_type == "vertical"){
				document.getElementById("vertical_uploaded_image").setAttribute("src", event.target.result);
			}
			else if(card_type == "horizontal"){
				document.getElementById("horizontal_uploaded_image").setAttribute("src", event.target.result);
			}
		}

		image_upload_valid = "yes";

		fileReader.readAsDataURL(file[0]);
	}
}

function image_upload_validation(card_type){
	var operation = "save_card_img";
	
	if(image_upload_valid == "yes"){
		var fd = new FormData();
		
		if(card_type == "vertical"){
			var card_image = $('#vertical_card_img_upload')[0].files;
		}
		else if(card_type == "horizontal"){
			var card_image = $('#horizontal_card_img_upload')[0].files;
		}

		var card_price = 20;

		fd.append('operation',operation);
		fd.append('card_image',card_image[0]);
		fd.append('card_type', card_type);
		fd.append('card_price', card_price);

		$.ajax({
			url: "function/customization.php",
			type: "POST",
			data: fd,
			contentType: false,
		    processData: false,
		    success: function(data){
		    	var current_card_id = data;
		    	sessionStorage.setItem('current_card_id', current_card_id);
		    	window.location = "customization_upload_text.php?custom_card_type="+card_type;
		    }
		});
	}
	else{
		document.getElementById("image_upload_next_button").innerHTML="You forgot to add an image!";
		document.getElementById("image_upload_next_button").style.background="#e6176d";
	}
}

function close_set_name_pop_up(){
	document.getElementById("set_name_alert_wrap").style.display = "none";
	document.getElementById("card_name_input").value = "";
}


function update_demo_text(card_type){
	var text_content = document.getElementById("text_input").value;

	if(card_type == "vertical"){
		document.getElementById("vertical_demo_text").innerHTML = text_content;
	}
	else if(card_type == "horizontal"){
		document.getElementById("horizontal_demo_text").innerHTML = text_content;
	}

	document.getElementById("next_step_btn").innerHTML="Next Step";
	document.getElementById("next_step_btn").style.background="#00b7b5";

}


function text_validation(){
	var space = /^\s*$/;

	var card_message = document.getElementById("text_input").value;

	if(card_message.match(space)){
		document.getElementById("next_step_btn").innerHTML="You need to write something!";
		document.getElementById("next_step_btn").style.background="#e6176d";
	}
	else{
		document.getElementById("set_name_alert_wrap").style.display = "block";
	}
}

var card_name_valid = "false";
function card_name_validation(){
	var space = /^\s*$/;
	var card_name = document.getElementById("card_name_input").value;

	if(card_name.match(space)){
		document.getElementById("add_to_cart_btn").innerHTML="You forgot to name this project!";
		document.getElementById("add_to_cart_btn").style.background="#e6176d";
		card_name_valid = "false";
	}
	else{
		document.getElementById("add_to_cart_btn").innerHTML="Add To Cart";
		document.getElementById("add_to_cart_btn").style.background="#00b7b5";
		card_name_valid = "true";
	}
}


function save_card(){
	var operation = "add_to_cart";

	card_name_validation();

	var card_name = document.getElementById("card_name_input").value;
	var card_message = document.getElementById("text_input").value;

	if(card_name_valid == "true"){
		sessionStorage.setItem('step_pop_up', "no");
		var current_card_id = sessionStorage.getItem('current_card_id', current_card_id);

		$.ajax({
			url: "function/customization.php",
			type: "POST",
			data: {
				'operation': operation,
				'current_card_id': current_card_id,
				'card_name': card_name,
				'card_message': card_message
			},
		    success: function(data){
		    	document.getElementById("set_name_alert_wrap").style.display = "none";
		    	document.getElementById("card_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

		    	setTimeout(function(){
		    		document.getElementById("card_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					window.location = "customization_main_page.php";
		    	}, 2000);
		    }
		});
	}
}