
var current_password_valid = "no";
function current_password_validation()
{
	var password = document.getElementById("current_password").value;
	var space = /^\s*$/;

	if(password.match(space))
	{
		document.getElementById("current_password_error_message").innerHTML="Password is required.";
		document.getElementById("current_password").style.border = "2px solid red";
		current_password_valid = "no";
	}
	else
	{
		document.getElementById("current_password_error_message").innerHTML="";
		document.getElementById("current_password").style.border = "2px solid #f0f0f0";
		current_password_valid = "yes";
	}

	confirm_button_status();
}

var length_valid = "";
var number_valid = "";
var small_letter_valid = "";
var upper_letter_valid = "";
var symbol_valid = "";
var new_password_valid = "";
function new_password_guide(){
	document.getElementById("password_format").style.display = "block";
	var password = document.getElementById("new_password").value;
	document.getElementById("new_password_error_message").innerHTML="";

	if(password.length == 0){
		document.getElementById("password_format").style.display = "none";
		var length_valid = "no";
	}
	else if(password.length >= 15){
		document.getElementById("characters").style.color = "#00e600";
		document.getElementById("characters").style.fontWeight = "bold";
		length_valid = "yes";
	}
	else{
		document.getElementById("characters").style.color = "grey";
		document.getElementById("characters").style.fontWeight = "normal";
		length_valid = "no";
	}

	if(password.match(/[0-9]/)){
		document.getElementById("number").style.color = "#00e600";
		document.getElementById("number").style.fontWeight = "bold";
		var number_valid = "yes";
	}
	else{
		document.getElementById("number").style.color = "grey";
		document.getElementById("number").style.fontWeight = "normal";
		number_valid = "no";
	}

	if(password.match(/[a-z]/)){
		document.getElementById("small_letter").style.color = "#00e600";
		document.getElementById("small_letter").style.fontWeight = "bold";
		var small_letter_valid = "yes";
	}
	else{
		document.getElementById("small_letter").style.color = "grey";
		document.getElementById("small_letter").style.fontWeight = "normal";
		small_letter_valid = "no";
	}

	if(password.match(/[A-Z]/)){
		document.getElementById("upper_letter").style.color = "#00e600";
		document.getElementById("upper_letter").style.fontWeight = "bold";
		var upper_letter_valid = "yes";
	}
	else{
		document.getElementById("upper_letter").style.color = "grey";
		document.getElementById("upper_letter").style.fontWeight = "normal";
		upper_letter_valid = "no";
	}

	if(password.match(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/)){
		document.getElementById("symbol").style.color = "#00e600";
		document.getElementById("symbol").style.fontWeight = "bold";
		var symbol_valid = "yes";
	}
	else{
		document.getElementById("symbol").style.color = "grey";
		document.getElementById("symbol").style.fontWeight = "normal";
		symbol_valid = "no";
	}

	if(length_valid == "yes" && number_valid == "yes" && small_letter_valid == "yes" && upper_letter_valid == "yes" && symbol_valid == "yes"){
		document.getElementById("new_password_tick_icon").style.display = "block";
		document.getElementById("new_password_cross_icon").style.display = "none";
		document.getElementById("new_password_error_message").innerHTML = "";
		new_password_valid = "yes";
	}
	else{
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		new_password_valid = "no";
	}

	confirm_button_status();
}


function keyPressed(){
	var key = event.keyCode || event.charCode || event.which ;
	return key;
}

function keyPressed_new_password(){
	var key = event.keyCode || event.charCode || event.which ;
	new_password_guide();
	return key;
}

function new_password_validation()
{
	var password = document.getElementById("new_password").value;
	var space = /^\s*$/;

	document.getElementById("password_format").style.display = "none";

	if(password.match(space))
	{
		document.getElementById("new_password_error_message").innerHTML="New password is required.";
		document.getElementById("new_password").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
	}
	else if(password.length < 15 || password.search(/[0-9]/) == -1 || password.search(/[a-z]/) == -1 || password.search(/[A-Z]/) == -1 || password.search(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/) == -1){
		document.getElementById("new_password_error_message").innerHTML="Password format incorrect.";
		document.getElementById("new_password").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
	}
	else
	{
		document.getElementById("new_password_error_message").innerHTML="";
		document.getElementById("new_password").style.border = "2px solid #f0f0f0";
	}

	var confirm_password = document.getElementById("confirm_password").value;
	if(confirm_password.length != 0){
		confirm_password_validation();
	}

	confirm_button_status();
}

var confirm_password_valid = "no";
function confirm_password_validation()
{
	var new_password = document.getElementById("new_password").value;
	var confirm_password = document.getElementById("confirm_password").value;
	var space = /^\s*$/;

	if(confirm_password.match(space))
	{
		document.getElementById("confirm_password_error_message").innerHTML= "Confirm password is required.";
		document.getElementById("confirm_password").style.border = "2px solid red";
		document.getElementById("confirm_password_tick_icon").style.display = "none";
		document.getElementById("confirm_password_cross_icon").style.display = "block";
		confirm_password_valid = "no";
	}
	else if(new_password == confirm_password)
	{
		document.getElementById("confirm_password_error_message").innerHTML= "";
		document.getElementById("confirm_password").style.border = "2px solid #f0f0f0";
		document.getElementById("confirm_password_tick_icon").style.display = "block";
		document.getElementById("confirm_password_cross_icon").style.display = "none";
		confirm_password_valid = "yes";
	}
	else
	{
		document.getElementById("confirm_password_error_message").innerHTML= "Password does not match.";
		document.getElementById("confirm_password").style.border = "2px solid red";
		document.getElementById("confirm_password_tick_icon").style.display = "none";
		document.getElementById("confirm_password_cross_icon").style.display = "block";
		confirm_password_valid = "no";
	}

	confirm_button_status();
}

function confirm_button_status(){
	if(current_password_valid == "yes" && new_password_valid == "yes" && confirm_password_valid == "yes"){
		document.getElementById("confirm_change_password").style.opacity = "1";
	}
	else{
		document.getElementById("confirm_change_password").style.opacity = "0.7";
	}
}

function change_password(){
	if(current_password_valid == "yes" && new_password_valid == "yes" && confirm_password_valid == "yes"){
		var current_password = document.getElementById("current_password").value;

		var new_password = document.getElementById("new_password").value;
		var operation = "update_password";

		$.ajax({
			url: "function/update_customer.php",
			type: "POST",
			data: {
				'operation': operation,
				'new_password': new_password,
				'current_password': current_password
			},
			success: function(data){
				if(data == "update_success"){
					document.getElementById("change_password_success_wrap").style.display = "block";
					document.querySelector("body").style.overflow = "hidden";

					setTimeout(function(){
						$('#change_password_success_wrap').fadeOut('fast');
						$('body').css('overflow', 'auto');
						location.reload();
					}, 1500);
				}
				else if(data == "password_same_with_old"){
					document.getElementById("new_password_error_message").innerHTML="New password can't same with current password.";
					document.getElementById("new_password").style.border = "2px solid red";
					document.getElementById("new_password_tick_icon").style.display = "none";
					document.getElementById("new_password_cross_icon").style.display = "block";

					document.getElementById("same_with_old_password_error_wrap").style.display = "block";
					document.querySelector("body").style.overflow = "hidden";

					setTimeout(function(){
						$('#same_with_old_password_error_wrap').fadeOut('fast');
						$('body').css('overflow', 'auto');
					}, 1500);
				}
				else{
					document.getElementById("current_password_error_message").innerHTML="Invalid current password.";
					document.getElementById("current_password").style.border = "2px solid red";

					document.getElementById("change_password_error_wrap").style.display = "block";
					document.querySelector("body").style.overflow = "hidden";

					setTimeout(function(){
						$('#change_password_error_wrap').fadeOut('fast');
						$('body').css('overflow', 'auto');
					}, 1500);
				}
			},
		});
	}
}

function show_hide_current_password(){
  var toggle = document.getElementById("current_password_show_hide_icon");
  var pass = document.getElementById("current_password");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('show_password');
    toggle.classList.add('close_show_password');
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('close_show_password');
    toggle.classList.add('show_password');
  }
}

function show_hide_new_password(){
  var toggle = document.getElementById("new_password_show_hide_icon");
  var pass = document.getElementById("new_password");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('show_password');
    toggle.classList.add('close_show_password');
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('close_show_password');
    toggle.classList.add('show_password');
  }
}

function show_hide_confirm_password(){
  var toggle = document.getElementById("confirm_password_show_hide_icon");
  var pass = document.getElementById("confirm_password");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('show_password');
    toggle.classList.add('close_show_password');
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('close_show_password');
    toggle.classList.add('show_password');
  }
}