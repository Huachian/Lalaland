function add_new_address_popup(){
  document.getElementById("add_address_wrap").style.display = "block";
  document.querySelector("body").style.overflow = "hidden";
  valid_name="no";
  valid_phone="no";
  valid_address="no";
  valid_postcode="no";
  valid_state="no";
  valid_area="no";
}

function cancel_address(){
  document.getElementById("add_address_wrap").style.display = "none";
  document.getElementById("edit_address_wrap").style.display = "none";
  document.querySelector("body").style.overflow = "auto";

  document.getElementById("address_name").value = "";
  document.getElementById("address_phone").value = "";
  document.getElementById("new_address").value = "";
  document.getElementById("address_postcode").value = "";
  document.getElementById("address_state").value = "";
  document.getElementById("address_area").value = "";

  document.getElementById("adds_name_error").innerHTML = "";
  document.getElementById("address_name").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_phone_error").innerHTML = "";
  document.getElementById("address_phone").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_add_error").innerHTML = "";
  document.getElementById("new_address").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_post_error").innerHTML = "";
  document.getElementById("address_postcode").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_state_error").innerHTML = "";
  document.getElementById("address_state").style.border = "2px solid #f0f0f0";
  document.getElementById("adds_area_error").innerHTML = "";
  document.getElementById("address_area").style.border = "2px solid #f0f0f0";
  document.getElementById("set_new_default").checked = false;


  document.getElementById("edit_name_error").innerHTML = "";
  document.getElementById("edit_address_name").style.border = "2px solid #f0f0f0";
  document.getElementById("edit_phone_error").innerHTML = "";
  document.getElementById("edit_address_phone").style.border = "2px solid #f0f0f0";
  document.getElementById("edit_add_error").innerHTML = "";
  document.getElementById("edit_address").style.border = "2px solid #f0f0f0";
  document.getElementById("edit_post_error").innerHTML = "";
  document.getElementById("edit_address_postcode").style.border = "2px solid #f0f0f0";
  document.getElementById("edit_state_error").innerHTML = "";
  document.getElementById("edit_address_state").style.border = "2px solid #f0f0f0";
  document.getElementById("edit_area_error").innerHTML = "";
  document.getElementById("edit_address_area").style.border = "2px solid #f0f0f0";
  document.getElementById("edit_default").disabled = false;
  document.getElementById("edit_default").checked = false;
  document.getElementById("edit_default_label").style.color = "black";

  current_default = "";
}

var current_default = "";
function edit_address(address_id, counter){
  document.getElementById("edit_address_wrap").style.display = "block";
  document.querySelector("body").style.overflow = "hidden";

  document.getElementById("edit_address_id").value = address_id;
  document.getElementById("edit_address_row_counter").value = counter;

  var address_name = document.getElementById("name"+counter).innerHTML;
  var address_phone = document.getElementById("phone"+counter).innerHTML;
  var address = document.getElementById("address"+counter).innerHTML;
  var address_postcode = document.getElementById("postcode"+counter).innerHTML;
  var address_state = document.getElementById("state"+counter).innerHTML;
  var address_area = document.getElementById("area"+counter).innerHTML;

  current_default = "no"
  var check_default = document.getElementById("address_default_value"+counter).value;
  if(check_default == "Default"){
    document.getElementById("edit_default").disabled = true;
    document.getElementById("edit_default_label").style.color = "grey";
    current_default = "yes";
  }

  document.getElementById("edit_address_name").value = address_name;
  document.getElementById("edit_address_phone").value = address_phone;
  document.getElementById("edit_address").value = address;
  document.getElementById("edit_address_postcode").value = address_postcode;
  document.getElementById("edit_address_state").value = address_state;
  document.getElementById("edit_address_area").value = address_area;
}

var delete_address_id = "";
var delete_address_counter = "";

function delete_popup(address_id, counter){
  var operation = "delete_address";

  delete_address_id = address_id;
  delete_address_counter = counter;
  document.getElementById("delete_confirm_wrap").style.display = "block";
  document.querySelector('body').style.overflow = "hidden";
}

function cancel_delete(){
  document.getElementById("delete_confirm_wrap").style.display = "none";
  document.querySelector('body').style.overflow = "auto";
}

function confirm_delete(){
  var check_default = document.getElementById("address_default_value"+delete_address_counter).value;
  
  if(check_default == "Default"){
    document.getElementById("delete_confirm_wrap").style.display = "none";
    document.getElementById("delete_error_wrap").style.display = "block";
    document.querySelector('body').style.overflow = "hidden";
    setTimeout(function(){
      $('#delete_error_wrap').fadeOut('fast');
      $('body').css('overflow', 'auto');
    }, 1500);
  }
  else if(check_default == "NotDefault"){
    var operation = "delete_address";

    $.ajax({
      url:"function/update_customer.php",
      type: "POST",
      data:{
        'operation': operation,
        'delete_address_id': delete_address_id
      },
    });

    document.getElementById("address_list_row"+delete_address_counter).style.display = "none";
    document.getElementById("delete_confirm_wrap").style.display = "none";
    document.getElementById("delete_error_wrap").style.display = "none";
    document.querySelector('body').style.overflow = "auto";
  }
}


//validate add address form
var valid_name = "no";
function nameValidation(select)
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var name = document.getElementById("address_name").value;
    var error_message = document.getElementById("adds_name_error");
    var error_border = document.getElementById("address_name");
  }
  else if(select == "edit"){
    name = document.getElementById("edit_address_name").value;
    error_message = document.getElementById("edit_name_error");
    error_border = document.getElementById("edit_address_name"); 
  }
  
  if(name.match(space)){
    error_message.innerHTML = "Name is required.";
    error_border.style.border = "2px solid red";
    valid_name = "no";
  }
  else if(name.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_name = "yes";
  }
  else{
    error_message.innerHTML = "Please enter name as only Alphabet.";
    error_border.style.border = "2px solid red";
    valid_name = "no";
  }
}

var valid_phone = "no";
function phoneValidation(select)
{ 
  var space = /^\s*$/;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  if(select == "add"){
    var phoneNo = document.getElementById("address_phone").value;
    var error_message = document.getElementById("adds_phone_error");
    var error_border = document.getElementById("address_phone");
  }
  else if(select == "edit"){
    phoneNo = document.getElementById("edit_address_phone").value;
    error_message = document.getElementById("edit_phone_error");
    error_border = document.getElementById("edit_address_phone"); 
  }


  if(phoneNo.match(space)){
    error_message.innerHTML = "Phone number is required.";
    error_border.style.border = "2px solid red";
    valid_phone = "no";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12){
    error_message.innerHTML = "Please enter a valid phone number.";
    error_border.style.border = "2px solid red";
    valid_phone = "no";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_phone = "yes";
  }
}

var valid_address = "no";
function addressValidation(select)
{
  var space = /^\s*$/;

  if(select == "add"){
    var address = document.getElementById("new_address").value;
    var error_message = document.getElementById("adds_add_error");
    var error_border = document.getElementById("new_address");
  }
  else if(select == "edit"){
    address = document.getElementById("edit_address").value;
    error_message = document.getElementById("edit_add_error");
    error_border = document.getElementById("edit_address"); 
  }

  //address
  if(!address.match(space)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_address = "yes";
  }
  else{
    error_message.innerHTML = "Address is required.";
    error_border.style.border = "2px solid red";
    valid_address = "no";
  }
}

var valid_postcode = "no";
function postcodeValidation(select)
{
  var pattern = /[0-9]{5}/;
  var space = /^\s*$/;

  if(select == "add"){
    var postcode = document.getElementById("address_postcode").value;
    var error_message = document.getElementById("adds_post_error");
    var error_border = document.getElementById("address_postcode");
  }
  else if(select == "edit"){
    postcode = document.getElementById("edit_address_postcode").value;
    error_message = document.getElementById("edit_post_error");
    error_border = document.getElementById("edit_address_postcode"); 
  }

  if(postcode.match(space)){
    error_message.innerHTML = "Postcode is required.";
    error_border.style.border = "2px solid red";
    valid_postcode = "no";
  }
  else if(isNaN(postcode)||postcode.length>5||!postcode.match(pattern)){
    error_message.innerHTML = "Please enter a valid postcode.";
    error_border.style.border = "2px solid red";
    valid_postcode = "no";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_postcode = "yes";
  }
}

var valid_state = "no";
function stateValidation(select)
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var state = document.getElementById("address_state").value; 
    var error_message = document.getElementById("adds_state_error");
    var error_border = document.getElementById("address_state");
  }
  else if(select == "edit"){
    state = document.getElementById("edit_address_state").value;
    error_message = document.getElementById("edit_state_error");
    error_border = document.getElementById("edit_address_state"); 
  }
  
  if(state.match(space)){
    error_message.innerHTML = "State is required.";
    error_border.style.border = "2px solid red";
    valid_state = "no";
  }
  else if(state.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_state = "yes";
  }
  else{
    error_message.innerHTML = "Invalid state.";
    error_border.style.border = "2px solid red";
    valid_state = "no";
  }
}

var valid_area = "no";
function areaValidation(select)
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var area = document.getElementById("address_area").value;
    var error_message = document.getElementById("adds_area_error");
    var error_border = document.getElementById("address_area");
  }
  else if(select == "edit"){
    area = document.getElementById("edit_address_area").value;
    error_message = document.getElementById("edit_area_error");
    error_border = document.getElementById("edit_address_area"); 
  }
  
  if(area.match(space)){
    error_message.innerHTML = "Area is required.";
    error_border.style.border = "2px solid red";
    valid_area = "no";
  }
  else if(area.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #f0f0f0";
    valid_area = "yes";
  }
  else{
    error_message.innerHTML = "Invalid area.";
    error_border.style.border = "2px solid red";
    valid_area = "no";
  }
}

function submit_address(){
  var operation = "add_new_address";

  nameValidation('add');
  phoneValidation('add');
  addressValidation('add');
  postcodeValidation('add');
  stateValidation('add');
  areaValidation('add');

  if(valid_name=="yes" && valid_phone=="yes" && valid_address=="yes" && valid_postcode=="yes" && valid_state=="yes" && valid_area=="yes"){
    var address_name = document.getElementById("address_name").value;
    var address_phone = document.getElementById("address_phone").value;
    var new_address = document.getElementById("new_address").value;
    var address_postcode = document.getElementById("address_postcode").value;
    var address_state = document.getElementById("address_state").value;
    var address_area = document.getElementById("address_area").value;

    var check_default = document.getElementById("set_new_default");

    if(check_default.checked == true){
      var address_default = "Default";
    }
    else if(check_default.checked == false){
      var address_default = "NotDefault";
    }


    $.ajax({
      url: "function/update_customer.php",
      type: "POST",
      data: {
        'operation': operation,
        'address_name': address_name,
        'address_phone': address_phone,
        'new_address': new_address,
        'address_postcode': address_postcode,
        'address_state': address_state,
        'address_area': address_area,
        'address_default': address_default
      },
    });

    document.getElementById("add_address_wrap").style.display = "none";
    document.getElementById("add_address_alert_wrap").style.display = "block";

    setTimeout(function(){
      $('#add_address_alert_wrap').fadeOut('fast');
      $('body').css('overflow','auto');
      location.reload();
    }, 1500);
  }
}

function save_edit_address(){
  var operation = "save_edit_address";

  nameValidation('edit');
  phoneValidation('edit');
  addressValidation('edit');
  postcodeValidation('edit');
  stateValidation('edit');
  areaValidation('edit');

  if(valid_name=="yes" && valid_phone=="yes" && valid_address=="yes" && valid_postcode=="yes" && valid_state=="yes" && valid_area=="yes"){
    var address_id = document.getElementById("edit_address_id").value;
    var address_name = document.getElementById("edit_address_name").value;
    var address_phone = document.getElementById("edit_address_phone").value;
    var address = document.getElementById("edit_address").value;
    var address_postcode = document.getElementById("edit_address_postcode").value;
    var address_state = document.getElementById("edit_address_state").value;
    var address_area = document.getElementById("edit_address_area").value;


    var edit_default = document.getElementById("edit_default");
    var address_default = "";
    var counter = document.getElementById("edit_address_row_counter").value;

    if(current_default == "no"){
      if(edit_default.checked == true){
        address_default = "Default";

        var total_address_row = document.querySelectorAll(".address_list_row").length;
        for(var i=0; i<total_address_row; i++){
          document.getElementById("default_address_tag"+(i+1)).innerHTML = " ";
          document.getElementById("default_address_tag"+(i+1)).classList.remove("default_address_tag");
          document.getElementById("default_address_tag"+(i+1)).classList.add("not_default_address_tag");
          document.getElementById("address_default_value"+(i+1)).value = "NotDefault";
          document.getElementById("change_default_btn"+(i+1)).classList.remove("change_default_btn_no");
          document.getElementById("change_default_btn"+(i+1)).classList.add("change_default_btn_yes");
        }

        document.getElementById("address_default_value"+counter).value = "Default";
        document.getElementById("default_address_tag"+counter).innerHTML = "Default";
        document.getElementById("default_address_tag"+counter).classList.remove("not_default_address_tag");
        document.getElementById("default_address_tag"+counter).classList.add("default_address_tag");
        document.getElementById("change_default_btn"+counter).classList.remove("change_default_btn_yes");
        document.getElementById("change_default_btn"+counter).classList.add("change_default_btn_no");
      }
      else if(edit_default.checked == false){
        address_default = "NotDefault";
      }
    }
    else if(current_default == "yes"){
      address_default = "Default";
    }
    
    document.getElementById("name"+counter).innerHTML = address_name;
    document.getElementById("phone"+counter).innerHTML = address_phone;
    document.getElementById("address"+counter).innerHTML = address;
    document.getElementById("postcode"+counter).innerHTML = address_postcode;
    document.getElementById("state"+counter).innerHTML = address_state;
    document.getElementById("area"+counter).innerHTML = address_area;

    $.ajax({
      url: "function/update_customer.php",
      type: "POST",
      data: {
        'operation': operation,
        'address_id': address_id,
        'address_name': address_name,
        'address_phone': address_phone,
        'address': address,
        'address_postcode': address_postcode,
        'address_state': address_state,
        'address_area': address_area,
        'address_default': address_default
      },
    });

    document.getElementById("edit_default").checked = false;
    document.getElementById("edit_address_wrap").style.display = "none";
    document.getElementById("edit_address_alert_wrap").style.display = "block";

    setTimeout(function(){
      $('#edit_address_alert_wrap').fadeOut('fast');
      $('body').css('overflow', 'auto');
    }, 1500);
  }
}

function change_default_btn(address_id, counter){
  var operation = "change_default";

  $.ajax({
    url: "function/update_customer.php",
    type: "POST",
    data: {
      'operation': operation,
      'address_id': address_id,
    },
  });

  var total_address_row = document.querySelectorAll(".address_list_row").length;
  for(var i=0; i<total_address_row; i++){
    document.getElementById("default_address_tag"+(i+1)).innerHTML = " ";
    document.getElementById("default_address_tag"+(i+1)).classList.remove("default_address_tag");
    document.getElementById("default_address_tag"+(i+1)).classList.add("not_default_address_tag");
    document.getElementById("address_default_value"+(i+1)).value = "NotDefault";
    document.getElementById("change_default_btn"+(i+1)).classList.remove("change_default_btn_no");
    document.getElementById("change_default_btn"+(i+1)).classList.add("change_default_btn_yes");
  }

  document.getElementById("address_default_value"+counter).value = "Default";
  document.getElementById("default_address_tag"+counter).innerHTML = "Default";
  document.getElementById("default_address_tag"+counter).classList.remove("not_default_address_tag");
  document.getElementById("default_address_tag"+counter).classList.add("default_address_tag");
  document.getElementById("change_default_btn"+counter).classList.remove("change_default_btn_yes");
  document.getElementById("change_default_btn"+counter).classList.add("change_default_btn_no");
}