window.onload = function(){
	var total_row = document.querySelectorAll('input[type="checkbox"]').length;
	var total = 0;

	for (var i = 0; i < total_row; i++){
		if(document.getElementById("checkbox"+(i+1)).checked == true){
			select_product(i);
			var quantity = document.querySelector('[name="quantity'+(i+1)+'"]');
			quantity = parseInt(quantity.value);

			var product_price = document.getElementById('product_price'+(i+1)).innerHTML;
		  	product_price = product_price.replace(/,/g, '');
		  	product_price = parseFloat(product_price);

		  	total += quantity * product_price;
		  	document.getElementById('summary_price').innerHTML = total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
		}
	}
}


//check all checkbox
function checkall(source){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++){
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }

    select_all_product();
}

//shopping cart qty
function add_qty(counter){
	var operation = "add_qty";
	var product_type = document.getElementById('product_type'+counter).value;
	var product_id = document.getElementById('product_id'+counter).value;

	var quantity = document.querySelector('[name="quantity'+counter+'"]');
	quantity.value = parseInt(quantity.value) + 1;
	quantity = quantity.value;

  	var product_price = document.getElementById('product_price'+counter).innerHTML;
  	product_price = product_price.replace(/,/g, '');
  	product_price = parseFloat(product_price);

	var subtotal = document.getElementById('subtotal'+counter).innerHTML;
	subtotal = subtotal.replace(/,/g, '');
	subtotal = parseFloat(subtotal);
	subtotal = subtotal + product_price;
	
	document.getElementById('subtotal'+counter).innerHTML = subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
	var select_product = document.getElementById("checkbox"+counter);
	if(select_product.checked){
		var current_summary_price = document.getElementById('summary_price').innerHTML;
		current_summary_price = current_summary_price.replace(/,/g, '');
		current_summary_price = parseFloat(current_summary_price);
		current_summary_price += product_price;
		document.getElementById('summary_price').innerHTML = current_summary_price.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
	}

	refresh_total_qty_in_cart();
	update_shopping_cart_databases(product_id, quantity, operation, product_type);
}

function minus_qty(counter){
	var operation = "minus_qty";
	var product_type = document.getElementById('product_type'+counter).value;
	var product_id = document.getElementById('product_id'+counter).value;

 	var quantity = document.querySelector('[name="quantity'+counter+'"]');

	if(quantity.value > 1){
		quantity.value = parseInt(quantity.value) - 1;
		quantity = quantity.value;

		var product_price = document.getElementById('product_price'+counter).innerHTML;
		product_price = product_price.replace(/,/g, '');
		product_price = parseFloat(product_price);

		var subtotal = document.getElementById('subtotal'+counter).innerHTML;
		subtotal = subtotal.replace(/,/g, '');
		subtotal = parseFloat(subtotal);
		subtotal = subtotal - product_price;

		document.getElementById('subtotal'+counter).innerHTML = subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');

		var select_product = document.getElementById("checkbox"+counter);
		if(select_product.checked){
			var current_summary_price = document.getElementById('summary_price').innerHTML;
			current_summary_price = current_summary_price.replace(/,/g, '');
			current_summary_price = parseFloat(current_summary_price);
			current_summary_price -= product_price;
			document.getElementById('summary_price').innerHTML = current_summary_price.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
		}

		refresh_total_qty_in_cart();
		update_shopping_cart_databases(product_id, quantity, operation, product_type);
  	}
  	else if(quantity.value == 1){
		delete_confirm(counter, product_id);
  	}
}

function delete_confirm(counter, product_id){
	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	var product_name = document.getElementById('cart_product_name'+counter).innerHTML;
	document.getElementById('delete_product_name').innerHTML = product_name;

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});

	document.getElementById("delete_confirm_yes").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";

		delete_cart_item(counter);
	});
}

function manual_key_in(counter){
	var operation = "manual_key_in";
	var product_type = document.getElementById('product_type'+counter).value;
	var product_id = document.getElementById('product_id'+counter).value;
	var current_subtotal = document.getElementById('subtotal'+counter).innerHTML;
	current_subtotal = current_subtotal.replace(/,/g, '');
	current_subtotal = parseFloat(current_subtotal);

	var quantity = document.querySelector('[name="quantity'+counter+'"]');
	quantity = quantity.value;


	var product_price = document.getElementById('product_price'+counter).innerHTML;
	product_price = product_price.replace(/,/g, '');
	product_price = parseFloat(product_price);
	var subtotal = quantity * product_price;



	document.getElementById('subtotal'+counter).innerHTML = subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');

	var select_product = document.getElementById("checkbox"+counter);
	if(select_product.checked){
		var current_summary_price = document.getElementById('summary_price').innerHTML;
		current_summary_price = current_summary_price.replace(/,/g, '');
		current_summary_price = parseFloat(current_summary_price);
		current_summary_price -= current_subtotal;
		current_summary_price += subtotal;
		document.getElementById('summary_price').innerHTML = current_summary_price.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
	}

	refresh_total_qty_in_cart();
	update_shopping_cart_databases(product_id, quantity, operation, product_type);
}

function check_cart_product_qty(counter){
	var quantity = document.querySelector('[name="quantity'+counter+'"]');
	quantity = quantity.value;

	if(quantity >= 1000){
		quantity = 999;
		document.querySelector('[name="quantity'+counter+'"]').value = quantity;

		document.getElementById("max_qty_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";
		manual_key_in(counter);
	}
}

function close_max_qty_wrap(){
	$('#max_qty_wrap').fadeOut('fast');
	$('body').css('overflow','auto');
}

function min_qty_check(counter){
	var quantity = document.querySelector('[name="quantity'+counter+'"]');

	if (quantity.value < 1){
		quantity.value = 1;
		manual_key_in(counter);
	}
}

function delete_cart_item(counter) {
	var operation = "delete_cart_item";

	var product_type = document.getElementById('product_type'+counter).value;

	var product_id = document.getElementById('product_id'+counter).value;

	var quantity = document.getElementById("quantity"+counter).value;
	quantity = parseInt(quantity);

	var product_price = document.getElementById('product_price'+counter).innerHTML;
	product_price = product_price.replace(/,/g, '');
	product_price = parseFloat(product_price);

	var current_subtotal = document.getElementById('subtotal'+counter).innerHTML;
	current_subtotal = current_subtotal.replace(/,/g, '');
	current_subtotal = parseFloat(current_subtotal);

	var select_product = document.getElementById("checkbox"+counter);
	if(select_product.checked){
		var total = document.getElementById('summary_price').innerHTML;
		total = total.replace(/,/g, '');
		total = parseFloat(total);
		total -= current_subtotal;

	  	document.getElementById('summary_price').innerHTML = total.toFixed(2);
	}

  	var total_qty_in_cart = document.getElementById("total_qty_in_cart").innerHTML;
  	total_qty_in_cart = parseInt(total_qty_in_cart);
  	total_qty_in_cart -= quantity;

  	if(total_qty_in_cart == 0){
  		document.querySelector(".shopping_cart_calculate").id = "shopping_cart_calculate_none";
  		document.querySelector(".empty_cart_wrap").style.display = "block";
  		document.querySelector(".cart_product_header").id = "shopping_cart_calculate_none";
  		document.querySelector(".cart_summary").id = "disable_cart_summary";
  	}
  	document.getElementById('cart_product_status'+counter).value = "deleted";
  	document.getElementById('cart_product_row'+counter).style.display = "none";

  	refresh_total_qty_in_cart();
	update_shopping_cart_databases(product_id, quantity, operation, product_type);
}

var pro_id = [];
var qty = [];
var pro_price = [];
var total = 0;
var z = 0;
function select_product(counter){
	var total_row = document.querySelectorAll('[name="product_id"]').length;
	var select_product = document.getElementById("checkbox"+counter);

	var get_product_id = document.getElementById("checkbox"+counter).value;
	var get_quantity = document.getElementById("quantity"+counter).value;
	get_quantity = parseInt(get_quantity);
	var get_product_price = document.getElementById('product_price'+counter).innerHTML;
	get_product_price = get_product_price.replace(/,/g, '');
	get_product_price = parseFloat(get_product_price);

	total = 0;

	if(select_product.checked == true){
		var current_summary_price = document.getElementById('summary_price').innerHTML;
		current_summary_price = current_summary_price.replace(/,/g, '');
		current_summary_price = parseFloat(current_summary_price);
		total = current_summary_price + (get_quantity * get_product_price);

		z += 1;
	}
	else if(select_product.checked == false){
		var current_summary_price = document.getElementById('summary_price').innerHTML;
		current_summary_price = current_summary_price.replace(/,/g, '');
		current_summary_price = parseFloat(current_summary_price);
		total = current_summary_price - (get_quantity * get_product_price);

		z -= 1;
	}

	if(z == total_row){
		document.getElementById("select_all").checked = true;
	}
	else{
		document.getElementById("select_all").checked = false;
	}

	document.getElementById('summary_price').innerHTML = total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

function select_all_product(){
	var select_all = document.getElementById("select_all");
	var total_row = document.querySelectorAll('[name="product_id"]');

	if(select_all.checked == true){
		var total = 0;
		for(var i=0; i<total_row.length; i++){
			var get_product_id = document.getElementById("checkbox"+(i+1)).value;
			var get_quantity = document.getElementById("quantity"+(i+1)).value;
			get_quantity = parseInt(get_quantity);
			var get_product_price = document.getElementById('product_price'+(i+1)).innerHTML;
			get_product_price = get_product_price.replace(/,/g, '');
			get_product_price = parseFloat(get_product_price);

			total += get_quantity* get_product_price;
		}

		z = total_row.length;
	}
	else if(select_all.checked == false){
		total = 0;
		z = 0;
	}

	document.getElementById('summary_price').innerHTML = total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

function refresh_total_qty_in_cart(){
	var total_row = document.querySelectorAll('[name="product_id"]');
	var total_qty_in_cart = 0;

	for(i=0; i<total_row.length; i++){
		var cart_product_status = document.getElementById('cart_product_status'+(i+1)).value;
		
		if(cart_product_status == "normal"){
			var quantity = document.getElementById("quantity"+(i+1));
			quantity = parseInt(quantity.value);
			total_qty_in_cart += quantity;
		}
	}

	if(isNaN(total_qty_in_cart)){
		total_qty_in_cart = 0;
	}
	
	document.getElementById("total_qty_in_cart").innerHTML = total_qty_in_cart;

	if(total_qty_in_cart > 99){
		document.querySelector(".shopping_cart_calculate").innerHTML = "99+";
	}
	else{
		document.querySelector(".shopping_cart_calculate").innerHTML = total_qty_in_cart;
	}
}

function update_shopping_cart_databases(product_id, quantity, operation, product_type){
    $.ajax({
        url: "function/update_shopping_cart.php",
        type: "POST",
        data: { 
        	'product_id': product_id,
        	'product_type': product_type,
        	'quantity': quantity, 
        	'operation': operation
        },                   
    });
}

function close_max_amount_wrap(){
	$('#max_checkout_amount_wrap').fadeOut('fast');
	$('body').css('overflow','auto');
}

function update_status(){
	var operation = "update_status";
	var total_row = document.querySelectorAll('[name="product_id"]');
	var number_of_select = 0;
	var checkout_allow = "yes";

	var current_summary_price = document.getElementById('summary_price').innerHTML;
	current_summary_price = current_summary_price.replace(/,/g, '');
	current_summary_price = parseFloat(current_summary_price);

	if(current_summary_price > 99999.99){
		checkout_allow = "no";
		document.getElementById("max_checkout_amount_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";
	}

	for(var i=0; i<total_row.length; i++){
		var select_product = document.getElementById("checkbox"+(i+1));
		var product_stock = document.getElementById('product_stock'+(i+1)).value;
		var product_status = document.getElementById('product_status'+(i+1)).value;

		if(select_product.checked == true){
			if(product_stock != "In Stock" || product_status != "On Display"){
				document.getElementById("product_not_available_popup").style.display = "block";
				document.querySelector('body').style.overflow = "hidden";

				setTimeout(function(){
					$('#product_not_available_popup').fadeOut('fast');
					$('body').css('overflow','auto');
				}, 1500);

				checkout_allow = "no";
			}
		}

		if(i == (total_row.length-1) && checkout_allow == "yes"){
			for(var i=0; i<total_row.length; i++){
				var select_product = document.getElementById("checkbox"+(i+1));
				var product_type = document.getElementById('product_type'+(i+1)).value;
				var product_id = document.getElementById('product_id'+(i+1)).value;

				if(select_product.checked == true){
					$.ajax({
			            url: "function/update_shopping_cart.php",
			            type: "POST",
			            data: { 
			            	'product_id': product_id,
			            	'product_type': product_type,
			            	'operation': operation
			            },
			            success: function(data){
			            	sessionStorage.setItem('checkout_page_valid', "yes");
			                window.location = "checkout.php";
			            },                  
			        });

			        number_of_select++;
				}

				if(i==total_row.length-1 && number_of_select == 0){
					document.getElementById("empty_alert_wrap").style.display = "block";
					document.querySelector('body').style.overflow = "hidden";

					setTimeout(function(){
						$('#empty_alert_wrap').fadeOut('fast');
						$('body').css('overflow','auto');
					}, 1500); 
				}
			}
		}
	}

}