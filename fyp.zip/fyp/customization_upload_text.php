<?php
	session_start();
	include ("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: login_register.php?next=customization_main_page.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Upload your design | Easy Gift</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/customization_upload_text.css">
	<script type="text/javascript" src="js/customization_card.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php
		include ("navigation_bar.php");
	?>
	<script type="text/javascript">
		document.getElementById('custom_card_nav_btn').classList.add("active");
	</script>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="main_wrap">
		<div class="back_page">
			<button onclick="window.history.back()">
				&#60; Back
			</button>
		</div>

		<div class="page_row" id="page_row_1">
			<div class="card_demo_wrap">
				<div class="card_patern_wrap">
				<?php
					$custom_card_type = $_GET['custom_card_type'];

					if($custom_card_type == "vertical"){
				?>
					<div id="flat_vertical">
						<pre class="demo_text" id="vertical_demo_text"></pre>

						<div id="card_logo">
							<img src="image/navigation_top_bar/easy_gift_big_logo.PNG">
						</div>
					</div>
				<?php
					}
					else if($custom_card_type == "horizontal"){
				?>
					<div id="flat_horizontal">
						<pre class="demo_text" id="horizontal_demo_text"></pre>

						<div id="card_logo">
							<img src="image/navigation_top_bar/easy_gift_big_logo.PNG">
						</div>
					</div>
				<?php
					}
				?>
				</div>

				<div class="custom_selection_wrap">
					<div>
						<div class="upload_text_selection_header">
							Edit Card Back
						</div>
						<div class="upload_text_selection_description">
							<img src="image/customization/text_box_icon.png">
							<div>
								Customize your text below.
							</div>

							<div class="text_input_wrap">
								<textarea id="text_input" placeholder="Write your message here" onkeypress="update_demo_text('<?php echo $custom_card_type ?>')" onkeyup="update_demo_text('<?php echo $custom_card_type ?>')"></textarea>
							</div>
						</div>
						<div class="upload_text_selection_btn_wrap">
							<button id="next_step_btn" onclick="text_validation()">Next Step</button>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<div id="card_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/customization/tick_icon.png">
				<div>
					successfully added to your shopping cart
				</div>
			</div>
		</div>
	</div>

	<div id="set_name_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<div class="close_btn" onclick="close_set_name_pop_up()">
					<img src="image/customization/close_icon.png">
				</div>
				<img src="image/customization/good_icon.png">
				<div>
					Beautiful! Now just name this project so you can find it later.
				</div>
				<div>
					<input type="text" id="card_name_input" placeholder="Name this project" autocomplete="off">
				</div>
				<div>
					<button id="add_to_cart_btn" onclick="save_card()" onkeyup="card_name_validation()">
						Add To Cart
					</button>
				</div>
			</div>
		</div>
	</div>


	<?php
		include ("footer.php");
	?>

</body>
</html>