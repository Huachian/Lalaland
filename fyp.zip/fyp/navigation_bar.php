<?php
	include("dataconnection.php");

	$customer_id = "";

	if(isset($_SESSION["id"])){
		$customer_id = $_SESSION["id"];
	}

	$result = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id'");
	$total_in_cart = 0;

	while($row = mysqli_fetch_assoc($result)){
		$total_in_cart += $row['quantity'];
	}

	$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='waiting checkout'");

	while($row = mysqli_fetch_assoc($result)){
		$total_in_cart += 1;
	}

	$wish_list_result = mysqli_query($connect, "SELECT * FROM wish_list WHERE customer_id='$customer_id'");
	$total_in_wish_list = 0;

	while($row = mysqli_fetch_assoc($wish_list_result)){
		$total_in_wish_list += 1;
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>navigation bar</title>
	<link rel="stylesheet" type="text/css" href="css/navigation_bar.css">
</head>
<body>
	<nav>
		<div class="nav_logo">
			<a href="index.php"><img src="image/navigation_top_bar/easy_gift_big_logo.PNG"></a>
		</div>
		<div class="nav_medium">
			<ul>
				<li><a href="index.php" id="home_btn">Home</a></li>
				<!-- <li id="gender_group_nav">
					<a href="#" id="for_who_btn">For Who &#9662;</a>
					
					<ul class="for_who_dropdown">
						<div class="for_who_detail">
							<div class="for_him">
								<div>For Him</div>
								<br>
								<a href="search_result.php?filter_gender[]=For Him"><img src="image/navigation_top_bar/him.PNG"></a>
							</div>

							<div class="for_her">
								<div>For Her</div>
								<br>
								<a href="search_result.php?filter_gender[]=For Her"><img src="image/navigation_top_bar/her.PNG"></a>
							</div>

							<div class="for_kid">
								<div>For Kids</div>
								<br>
								<a href="search_result.php?filter_gender[]=For Kids"><img src="image/navigation_top_bar/kid.PNG"></a>
							</div>

							<div class="newborn">
								<div>Newborn</div>
								<br>
								<a href="search_result.php?filter_gender[]=Newborn"><img src="image/navigation_top_bar/newborn.PNG"></a>
							</div>
						</div>
					</ul>
				</li> -->
				<li id="shop_button_wrap">
					<a href="#" id="shop_button">PRODUCT &#9662;</a>
					<ul class="shop_nav_drop_down_wrap">
						<div id="shop_nav_drop_down_wrap_2">
							<!-- <div class="shop_nav_column">
								<div class="shop_filter_title">
									For Who
								</div>

								<div class="shop_nav_btn_wrap">
									<a href="search_result.php?filter_gender[]=For Him">
										<div class="shop_nav_btn">
											<span>For Him</span>
										</div>
									</a>
									<a href="search_result.php?filter_gender[]=For Her">
										<div class="shop_nav_btn">
											<span>For Her</span>
										</div>
									</a>
									<a href="search_result.php?filter_gender[]=For Kids">
										<div class="shop_nav_btn">
											<span>For Kids</span>
										</div>
									</a>
									<a href="search_result.php?filter_gender[]=Newborn">
										<div class="shop_nav_btn">
											<span>Newborn</span>
										</div>
									</a>
								</div>
							</div> -->
							
							<div class="shop_nav_column shop_nav_column_center">
								<div class="shop_filter_title">
									Gift Type
								</div>

								<div class="shop_nav_btn_wrap">
							<?php
								$result = mysqli_query($connect, "SELECT * FROM product_type");

								while($row = mysqli_fetch_assoc($result)){
							?>
									<a href="search_result.php?filter_product_type[]=<?php echo $row['product_type'] ?>">
										<div class="shop_nav_btn">
											<span><?php echo $row['product_type'] ?></span>
										</div>
									</a>
							<?php
								}
							?>
								</div>
							</div>

							<div class="shop_nav_column shop_nav_column_center">
								<div class="shop_filter_title">
									Occasion
								</div>

								<div class="shop_nav_btn_wrap">
							<?php
								$result = mysqli_query($connect, "SELECT * FROM product_occasions");

								while($row = mysqli_fetch_assoc($result)){
							?>
									<a href="search_result.php?filter_product_occasions[]=<?php echo $row['occasions_name'] ?>">
										<div class="shop_nav_btn">
											<span><?php echo $row['occasions_name'] ?></span>
										</div>
									</a>
							<?php
								}
							?>
								</div>
							</div>
						</div>
					</ul>
				</li>
				<!-- <li>
					<a href="customization_main_page.php" id="custom_card_nav_btn">Custom Card</a>
				</li> -->
				<!-- <li>
					<button id="search_icon" onclick="pop_search_bar()"><img src="image/navigation_top_bar/search_icon.png"></button>
				</li> -->
			</ul>
		</div>
		<div class="nav_right">
			<!-- <?php
				if(!isset($_SESSION["admin_position"])){
			?>
					<a href="shopping_cart.php" id="shopping_cart_btn"><img src="image/navigation_top_bar/shopping_cart.png"></a>
			<?php
				}

				if($total_in_cart == 0){
					$shopping_cart_calculate_none = "shopping_cart_calculate_none";
				}

				if($total_in_cart > 99){
					$total_in_cart = "99+";
				}
			?>
			<div class="shopping_cart_calculate" id="<?php echo $shopping_cart_calculate_none; ?>"><?php echo $total_in_cart; ?></div>
			<input type="hidden" id="total_in_cart_qty" value="<?php echo $total_in_cart ?>"> -->

			<?php
				if(!isset($_SESSION["admin_position"])){
			?>
					<a href="wish_list.php" id="wishlist_btn"><img src="image/navigation_top_bar/wishlist_icon.png"></a>
			<?php
				}

				if($total_in_wish_list == 0){
					$disable = "disable";
				}
				else{
					$disable = "";
				}
			?>
			<div class="wish_list_dot <?php echo $disable ?>" id="wish_list_dot" ></div>
			<input type="hidden" id="total_in_wish_list" value="<?php echo $total_in_wish_list ?>">

			<?php
				if(empty($_SESSION["id"])){
					?>
						<a href="login_register.php" id="log_res_btn">Login/Register</a>
					<?php
				}
				else if(isset($_SESSION["id"]) && !isset($_SESSION["admin_position"])){
						$result = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id'");
						$row = mysqli_fetch_assoc($result);
					?>
						<div class="profile">
							<button class="profile_name">Hi, <?php echo $row['first_name']; ?></button>
							<div class="profile_dropdown">
								<div class="arrow"></div>
							    <a href="cus_profile.php">My account</a>
							    <!-- <a href="view_purchase.php">My purchase</a> -->
							    <a href="logout.php">Logout</a>
							</div>
						</div>
					<?php
				}
				else if(isset($_SESSION["admin_position"])){
					?>
						<div class="profile" style="margin-right: 60px;">
							<button class="profile_name">Hi, Admin</button>
							<div class="profile_dropdown">
								<div class="arrow"></div>
							    <a href="admin/index.php">Admin Panel</a>
							    <a href="logout.php">Logout</a>
							</div>
						</div>
					<?php
				}
			?>
		</div>

		<!-- <div class="search_pop_up_wrap">
			<div id="search_close_area" onclick="close_search_bar()"></div>
			<div class="search_pop_up_box">
				<div id="search_bar_title">
					Search
				</div>
				<div id="search_input_wrap">
					<?php
						if(isset($_GET['search_keyword'])){
							$search_keyword = $_GET['search_keyword'];
						}
						else{
							$search_keyword = "";
						}
					?>
					<input type="text" id="top_search_bar" placeholder="Search our store" value="<?php echo $search_keyword ?>" onkeyup="enter_search_contain()" autocomplete="off">
					<br>
					<button id="search_button" onclick="search_product()">
						<img src="image/navigation_top_bar/search_icon.png">
					</button>
				</div>

			</div>
			<div id="close_search_btn" onclick="close_search_bar()">
				<img src="image/navigation_top_bar/cross_icon.png">
			</div>
		</div> -->
	</nav>
	


	<div class="menu_btn_wrap">
		<img src="image/navigation_top_bar/menu_icon.png">
	</div>


	<script type="text/javascript">
		function pop_search_bar(){
			document.querySelector(".search_pop_up_wrap").style.display = "block";
			document.querySelector(".filter_pop_up_wrap").style.display="none";
			document.querySelector("body").style.overflow = "hidden";
		}

		function close_search_bar(){
			document.querySelector(".search_pop_up_wrap").style.display = "none";
			document.querySelector("body").style.overflow = "auto";
		}

		function search_product(){
			var search_contain = document.getElementById("top_search_bar").value;

			window.location = "search_result.php?search_keyword="+search_contain;
		}

		function enter_search_contain(){
		  // Number 13 is the "Enter" key on the keyboard
		  if (event.keyCode === 13) {
		    document.getElementById("search_button").click();
		  }
		}
	</script>

</body>
</html>