<?php
	session_start();
	include "dataconnection.php";
	$customer_id = $_SESSION['id'];
  $order_id = $_GET['order_id'];

  if(!isset($_SESSION['id'])){
    header("Location: login_register.php?next=view_purchase.php");
  }

  if(isset($_SESSION["admin_position"])){
    header("Location: index.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>View Order | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/view_order.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php
    include("navigation_bar.php");
  ?>
  <script type="text/javascript">
    sessionStorage.setItem('checkout_page_valid', "no");
    sessionStorage.setItem('payment_page_valid', "no");
  </script>

  <div class="order_main_wrap">
    <div class="sidebar_wrap">
      <?php
        $customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id'");
        $customer = mysqli_fetch_assoc($customer_details);
      ?>
      <div class="sidebar_header">
        <?Php echo $customer['first_name']." ".$customer['last_name']; ?>
      </div>

      <div class="sidebar_menu">
        <div class="sidebar_contain_head">
          <img src="image/cus_profile/profile_icon.png">
          <a href="cus_profile.php">My Account</a>
        </div>
        <div class="sidebar_contain_body">
          <ul>
            <li>
              <a href="cus_profile.php">Profile</a>
            </li>
            <li>
              <a href="cus_address.php">Addresses</a>
            </li>
            <li>
              <a href="cus_password.php">Change Password</a>
            </li>
          </ul>
        </div>

        <div class="sidebar_contain_head">
          <img src="image/cus_profile/my_orders_icon.jpg">
          <a href="view_purchase.php" style="color: #82b0a1;">My Purchase</a>
        </div>
      </div>
    </div>

    <?php
      $select_order = mysqli_query($connect, "SELECT * FROM orders WHERE order_id='$order_id'");
      $order = mysqli_fetch_assoc($select_order);

      if($order['status'] == "Waiting for Shipment"){
        $order_status = "Waiting for Shipment";
        $order_pending_title = "";
        $delivery_date = "";
        $active_icon = "";
        $active_image = "delivery_icon.png";
      }
      else if($order['status'] == "Cancelled"){
        $order_status = "Cancelled";
        $order_pending_title = "cancelled_title";
        $delivery_date = "";
        $active_icon = "cancelled_icon";
        $active_image = "cancel_icon.png";
      }
      else if($order['status'] == "Pending"){
        $order_status = "Pending";
        $order_pending_title = "pending_title";
        $delivery_date = "";
        $active_icon = "";
        $active_image = "delivery_icon.png";
      }
      else if($order['status'] == "Shipped Out"){
        $order_status = "Order Shipped Out";
        $order_pending_title = "";

        $delivery_date = $order['delivery_date'];
        $delivery_date = strtotime($delivery_date);
        $delivery_date = date ("d-m-Y", $delivery_date);

        $active_icon = "active_icon";
        $active_image = "active_delivery_icon.png";
      }

      $order_date = $order['order_date'];
      $order_date = strtotime($order_date);
      $order_date = date ("d-m-Y H:i:s", $order_date);  
    ?>


    <div class="order_contain_wrap">
      <div class="order_contain_header">
        <button onclick="window_back()">&#60; Back</button>
        <div>ORDER ID. <?php echo $order_id ?></div>
      </div>

      <div class="order_flow">
        <div class="order_placed_icon active_icon"><img src="image/view_order/order_placed_icon.png"></div>
        <div class="order_flow_line active_icon_line"></div>
        <div class="order_procedur_1">
          <span>Order Placed</span>
          <br>
          <span><?php echo $order_date ?></span>
        </div>

        <div class="order_placed_icon active_icon"><img src="image/view_order/paid_icon.png"  style="margin-left : 16px;"></div>
        <div class="order_flow_line active_icon_line"></div>
        <div class="order_procedure_2">
          <span>Order Paid</span>
          <br>
          <span><?php echo $order_date ?></span>
        </div>

        <div class="order_placed_icon <?php echo $active_icon ?>"><img src="image/view_order/<?php echo $active_image ?>"></div>
        <div class="order_procedure_3">
          <span id="<?php echo $order_pending_title ?>"><?php echo $order_status ?></span>
          <br>
          <span><?php echo $delivery_date ?></span>
        </div>
      </div>

      <div class="order_delivery_address_wrap">
        <div class="order_delivery_address_title">Delivery Address</div>
        <div id="address_name"><?php echo $order['delivery_name'] ?></div>
        <div>
          <span id="address_phone"><?php echo $order['delivery_contact'] ?></span>
          <br>
          <span id="address"><?php echo $order['delivery_address'] ?> <?php echo $order['delivery_area'] ?>, <?php echo $order['delivery_postcode'] ?> <?php echo $order['delivery_state'] ?>.</span>
        </div>
      </div>

      <div class="order_product_wrap">
        <table>
          <?php
            $order_products = mysqli_query($connect, "SELECT * FROM order_products where order_id='$order_id'");

            while($order_products_row = mysqli_fetch_assoc($order_products)){
              $product_id = $order_products_row['product_id'];
              $product_type = $order_products_row['product_type'];
              $product_price = $order_products_row['product_price'];
              $promotion_amount = $order_products_row['promotion_amount'];

              if($product_type == "custom product"){
                $image_path = "admin/image/customization/";
              }
              else{
                $image_path = "admin/image/product_image/";
              }
          ?>
              <tr class="purchase_product_row">
                <td class="table_body_1">
                  <img src="<?php echo $image_path ?><?php echo $order_products_row["product_image"] ?>">
                </td>
                <td class="table_body_2">
                  <div class="purchase_product_name">
                    <?php
                      if($product_type == "custom product"){
                        $custom_result = mysqli_query($connect, "SELECT * FROM customization_card where card_id='$product_id'");
                        $custom_row = mysqli_fetch_assoc($custom_result)
                    ?>
                        <b>[Custom <?php echo $custom_row['card_type']; ?> card]</b> 
                    <?php
                      }
                    ?>
                    <?php echo $order_products_row['product_name']; ?>
                  </div>
                </td>
                <td class="table_body_3">
                  x<?php echo $order_products_row['quantity']; ?>
                </td>
                <td class="table_body_4">
                  <?php
                      if($promotion_amount != 0){
                       $product_promotion_price = $product_price - $promotion_amount;
                    ?>
                        <div class="cancel_normal_price">
                          RM<span><?php echo number_format($order_products_row['product_price'], 2); ?></span>
                        </div>
                        <div class="promotion_price">
                          RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_promotion_price,2); ?></span>
                        </div>
                    <?php
                      }
                      else{
                    ?>
                        <div>
                          RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_price, 2); ?></span>
                        </div>
                    <?php
                      }
                    ?>
                </td>
              </tr>
          <?php
            }
          ?>
        </table>
      </div>

      <div class="table_summary_wrap">
        <table class="table_summary_table">
          <tr>
            <td class="table_summary_title">
              <span>Product Subtotal</span>
            </td>
            <td class="table_summary_amount">
              <div>
                RM<span><?php echo number_format($order['product_subtotal'], 2) ?></span>
              </div>
            </td>
          </tr>
          <tr>
            <td class="table_summary_title">
              <span>Product Discount (voucher)</span>
            </td>
            <td class="table_summary_amount">
              <?php
                if($order['voucher_type'] == "Product Discount"){
                  $product_discount = $order['discount_amount'];
                }
                else{
                  $product_discount = 0;
                }
              ?>
              <div>
                -RM<span><?php echo number_format($product_discount, 2) ?></span>
              </div>
            </td>
          </tr>
          <tr>
            <td class="table_summary_title">
              <span>Shipping-Standard Delivery</span>
            </td>
            <td class="table_summary_amount">
              <div>
                RM<span><?php echo number_format($order['shipping_fee'], 2) ?></span>
              </div>
            </td>
          </tr>
          <tr>
            <td class="table_summary_title">
              <span>Shipping Discount</span>
            </td>
            <td class="table_summary_amount">
              <?php
                if($order['voucher_type'] == "Free Shipping"){
                  $shipping_discount = $order['discount_amount'];
                }
                else{
                  $shipping_discount = 0;
                }
              ?>
              <div>
                -RM<span><?php echo number_format($shipping_discount, 2) ?></span>
              </div>
            </td>
          </tr>
          <tr>
            <td class="table_summary_title">
              <span>Order Total</span>
            </td>
            <td class="table_summary_amount_2">
              <div>
                RM<span><?php echo number_format($order['total_amount'], 2) ?></span>
              </div>
            </td>
          </tr>
        </table>
      </div>


    </div>
  </div>


  <script type="text/javascript">
    function window_back(){
      window.history.back();
    }
  </script>

</body>
</html>