<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/customer.php");
	}

	$admin_id = $_SESSION["id"];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/customer.css">
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<script type="text/javascript" src="js/customer.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('customer_btn_wrap').style.background = "#ffff4d";
		document.getElementById('customer_btn_title').style.color = "black";
		document.getElementById('customer_icon').style.color = "black";
	</script>

	<input type="hidden" id="admin_id" value="<?php echo $admin_id ?>">

	<div class="customer_main_wrap">
		<div class="customer_second_wrap">
			<div id="customer_page_title">
				Customer List
			</div>

			<div id="customer_page_top_action_wrap">
				<div id="search_customer_wrap">
					<form autocomplete="off">
						<input type="text" name="search_customer" id="search_customer" placeholder="Search Customer" onkeyup="filter_table()">
					</form>
				</div>
			</div>

			<div id="customer_display_wrap">
				<table id="customer_table">
					<tr>
						<th>
							No
						</th>
						<th>
							Customer ID
						</th>
						<th>
							First Name
						</th>
						<th>
							Last Name
						</th>
						<th>
							Phone
						</th>
						<th>
							Email Address
						</th>
						<th>
							Gender
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_customer_details = mysqli_query($connect, "SELECT * FROM customer");
						$i = 0;

						while($customer_details_row = mysqli_fetch_assoc($select_customer_details)){
							$i++;
					?>
							<tr class="customer_row" id="customer_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<td class="customer_number_column" onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>', '<?php echo $i ?>')">
									<?php echo $customer_details_row['customer_id'] ?>

									<?php
										if($customer_details_row['reset_token'] != "inactive"){
											$display_none = "style='display: none;'";
										}
										else{
											$display_none = "";
										}
									?>
									<div id="inactive_label<?php echo $i ?>" class="inactive_label" <?php echo $display_none ?>>Inactive</div>
								</td>
								<td onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>', '<?php echo $i ?>')">
									<span id="first_name<?php echo $i ?>"><?php echo $customer_details_row['first_name'] ?></span>
								</td>
								<td onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>', '<?php echo $i ?>')">
									<span id="last_name<?php echo $i ?>"><?php echo $customer_details_row['last_name'] ?></span>
								</td>
								<td onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>', '<?php echo $i ?>')">
									<span id="phone<?php echo $i ?>"><?php echo $customer_details_row['phone'] ?></span>
								</td>
								<td onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>', '<?php echo $i ?>')">
									<span id="email<?php echo $i ?>"><?php echo $customer_details_row['email'] ?></span>
								</td>
								<td onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>', '<?php echo $i ?>')">
									<span id="gender<?php echo $i ?>"><?php echo $customer_details_row['gender'] ?></span>
								</td>
								<td id="customer_button_column">
									<button onclick="show_customer_details('<?php echo $customer_details_row['customer_id'] ?>')">
										<img src="image/customer/view_icon.png">
									</button>
									<?php
										if($admin_details['position'] == "Admin")
										{
											$delete_btn="hide_delete_btn";
										}
										else if($admin_details['position'] == "Superadmin")
										{
											$delete_btn="delete_btn";
										}
									?>
									<button class="<?php echo $delete_btn ?>" onclick="delete_customer('<?php echo $i ?>', '<?php echo $customer_details_row['customer_id'] ?>')">
										<img src="image/customer/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>
				</table>
			</div>
		</div>
	</div>


	<div id="customer_details_wrap">
		<div id="customer_details_wrap_2">
			<div id="customer_details_title">
				Customer Details
				<?php
				if($admin_details['position'] == "Admin")
				{
					$action_buttons="hide_view_password";
				}
				else if($admin_details['position'] == "Superadmin")
				{
					$action_buttons="view_password";
				}
				?>
				<button class="<?php echo $action_buttons?>" id="edit_admin_pass_button" onclick="show_access_password_pop_up()">
					<i class="fas fa-key"></i> Password
				</button>

				<div id="status_msg">
					Account Inactive
				</div>
			</div>

			<div id="customer_details_box">
				<button id="close_customer_details_btn" onclick="close_customer_details()">
					<img src="image/product/close_icon.png">
				</button>

				<table id="customer_details_table">
					<tr>
						<td class="customer_details_table_title">
							Customer ID
						</td>
						<td class="customer_details_table_contain">
							:<div id="customer_id" class="details_contain"></div>
							<input type="text" class="edit_customer_input_box" id="edit_customer_id" disabled>
						</td>
					</tr>
					<tr>
						<td class="customer_details_table_title">
							First name
						</td>
						<td class="customer_details_table_contain">
							:<div id="first_name" class="details_contain"></div>
							<input type="text" class="edit_customer_input_box" id="edit_customer_first_name" onblur="fname_validation('edit')">
							<div id="edit_fname_error" class="edit_error"></div>
						</td>
					</tr>
					<tr>
						<td class="customer_details_table_title">
							Last name
						</td>
						<td class="customer_details_table_contain">
							:<div id="last_name" class="details_contain"></div>
							<input type="text" class="edit_customer_input_box" id="edit_customer_last_name" onblur="lname_validation('edit')">
							<div id="edit_lname_error" class="edit_error"></div>							
						</td>
					</tr>
					<tr>
						<td class="customer_details_table_title">
							Gender
						</td>
						<td class="customer_details_table_contain">
							:<div id="gender" class="details_contain"></div>
							<select id="edit_customer_gender" class="edit_customer_input_box">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
						</td>
					</tr>
					<tr>
						<td class="customer_details_table_title">
							Phone
						</td>
						<td class="customer_details_table_contain">
							:<div id="phone" class="details_contain"></div>
							<input type="text" class="edit_customer_input_box" id="edit_customer_phone" onblur="phone_validation('edit')" data-mask="999-99999999">
							<div id="edit_phone_error" class="edit_error"></div>							
						</td>
					</tr>
					<tr>
						<td class="customer_details_table_title">
							Email
						</td>
						<td class="customer_details_table_contain">
							:<div id="email" class="details_contain"></div>
							<input type="text" class="edit_customer_input_box" id="edit_customer_email" onblur="email_validation('edit')">
							<div id="edit_email_error" class="edit_error"></div>							
						</td>
					</tr>
				</table>
			</div>
			<?php
				if($admin_details['position'] == "Admin")
				{
					$action_buttons="hide_action_buttons";
				}
				else if($admin_details['position'] == "Superadmin")
				{
					$action_buttons="action_buttons";
				}
			?>
			<div id="edit_customer_action_button" class="<?php echo $action_buttons?>">
				<div id="activate_btn_wrap">
					<button id="activate_btn" onclick="activate_customer()">
						Activate Account
					</button>
				</div>
				<div>
					<button id="edit_customer_details_btn" onclick="edit_customer_details()">
						<img src="image/customer/edit_icon.png">
					</button>
				</div>
				<div>	
					<button id="cancel_edit_details_btn" onclick="cancel_edit_customer()">
						<img src="image/customer/close_icon.png">
					</button>
				</div>
				<div>
					<button id="save_edit_details_btn">
						<img src="image/customer/save_icon.png" onclick="save_edit_customer()">
					</button>
				</div>
			</div>
		</div>
	</div>


	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/customer/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/customer/tick_icon.png">
				<div>
					Customer successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to deactivate this customer account?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_customer_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="activate_confirm_wrap">
		<div id="activate_confirm_box">
			<div id="activate_confirm_contain">
				<div id="activate_confirm_title">
					Do you want to activate back this customer account?
				</div>
				<div id="activate_confirm_btn">
					<button id="activate_confirm_yes" onclick="confirm_activate()">Yes</button>
					<button id="activate_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="access_pass_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<div id="close_btn">
					<img src="image/admin/close_icon.png" onclick="close_access_password_pop_up()">
				</div>
				<i class="far fa-address-card fa-6x"></i>
				<div>
					Enter your password to access
				</div>
				<div>
					<input type="password" id="access_password_input" placeholder="Enter your Password" onkeyup="update_enter_password_btn()">
				</div>
				<div>
					<button id="confirm_btn" onclick="confirm_access_pass()">
						Confirm
					</button>
				</div>
			</div>
		</div>
	</div>

	<div id="customer_pass_wrap">
		<div class="alert_box">
			<div class="top_left_header_admin_pass">
					<i class="fas fa-key"></i> Customer Password
				</div>
				<div class="admin_pass_alert_box_contain">
					<div class="admin_pass_close_btn">
						<img src="image/admin/close_icon.png" onclick="close_customer_pass()">
					</div>
					<div class="admin_pass_box">
						<div class="admin_pass_title">
							Password
						</div>
						<div class="admin_pass_contain">
						 	: <input type="password" id="customer_password_input" onkeyup="new_password_guide()"  onblur="edit_password_validation()" autocomplete="new-password" disabled>
						 	<div id="toggle_customer_password_icon" class="customer_show_pass_icon" onclick="show_hide_customer_password()"></div>

						 	<img src="image/admin_password/tick_icon.png" id="new_password_tick_icon">
				            <img src="image/admin_password/cross_icon.png" id="new_password_cross_icon">
				            <div id="new_password_error_message"></div>
				            <div id="edit_password_format">*Please use a strong password.<br> (<span id="edit_characters">Minimum 15 characters</span>, <span id="edit_number">1 number</span>, <span id="edit_small_letter">1 small letter</span>, <span id="edit_upper_letter">1 upper letter</span>, <span id="edit_symbol">1 symbol</span>)</div>
						</div>
					</div>
				</div>
				<div id="edit_admin_password_action_button">
				<button id="edit_customer_password_btn" onclick="edit_admin_pass()">
					<img src="image/admin/edit_icon.png">
				</button>
				<button id="cancel_edit_password_btn" onclick="cancel_edit_pass()">
					<img src="image/admin/close_icon.png">
				</button>
				<button id="save_edit_password_btn" onclick="save_edit_pass()">
					<img src="image/admin/save_icon.png">
				</button>
			</div>
			
		</div>
	</div>

</body>

	<script type="text/javascript">
		$("#access_password_input").keydown(function(event) {  
	 
	   if (event.keyCode == '32') {  
	       return false;
	      }  
		});
		
		$("#customer_password_input").keydown(function(event) {  
	 
	   if (event.keyCode == '32') {  
	       return false;
	      }  
		});



	    var side_bar_btn = document.getElementById('customer_btn_wrap');
	    var side_bar_btn = side_bar_btn.offsetTop;
	    document.getElementById('admin_side_navigation_wrap').scrollTop = side_bar_btn;
  	</script>
  	
  	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</html>