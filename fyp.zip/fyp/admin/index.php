<?php 
	session_start();
	include ("dataconnection.php");	

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/index.php");
	}


	$admin_id = $_SESSION["id"];
	$admin_position = $_SESSION["admin_position"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link href="css/index.css" type="text/css" rel="stylesheet">
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<script src="https://kit.fontawesome.com/49f22bfabd.js" crossorigin="anonymous"></script>
</head>
<body>
	<?php include"navigation_bar.php" ?>
	<script type="text/javascript">
		document.getElementById('dashboard_btn').style.background = "#ffff4d";
		document.getElementById('dashboard_btn_title').style.color = "black";
		document.getElementById('dashboard_icon').style.color = "black";
	</script>

	<?php 
		/* Number of admin */
		$admin_result = mysqli_query($connect,"SELECT * FROM admin");
 		$admin_count = mysqli_num_rows($admin_result);
 		$superadmin_result = mysqli_query($connect,"SELECT * FROM superadmin");
 		$admin_count += mysqli_num_rows($superadmin_result);

 		/* Number of product */
 		$product_result = mysqli_query($connect,"SELECT * FROM product");
 		$product_count = mysqli_num_rows($product_result);

 		/* Number of order by current month and year */
 		$month_order = mysqli_query($connect,"SELECT * FROM orders WHERE YEAR(order_date)=YEAR(now()) AND MONTH(order_date)=MONTH(curdate()); ");

		if(mysqli_num_rows($month_order) == NULL)
		{
			$month_order_count ='0';
		}
		else
		{
		    $month_order_count = mysqli_num_rows($month_order);
		}

		/* Number of registered customer */
 		$customer_result = mysqli_query($connect,"SELECT * FROM customer");
 		$customer_count = mysqli_num_rows($customer_result);


 		/* Total sales in current month and year */
 		$order_result = mysqli_query($connect,"SELECT sum(total_amount) as total_amount FROM orders WHERE YEAR(order_date)=YEAR(now()) AND MONTH(order_date)=MONTH(curdate()); ");
 		while ($row = mysqli_fetch_array($order_result)) { 
			$total_amount = $row['total_amount'];

			if($row['total_amount'] == NULL)
			{
				$total_amount = '0';
			}
		}

		/* Number of orders that is currently Waiting for Shipment */
		$order_to_be_ship =  mysqli_query($connect,"SELECT * FROM orders WHERE status = 'Waiting for Shipment'");
		
		if(mysqli_num_rows($order_to_be_ship) == NULL)
		{
			$order_to_be_ship_count ='0';
		}
		else
		{
		    $order_to_be_ship_count = mysqli_num_rows($order_to_be_ship);
		}
		
		/* Number of orderr that is currently pending */
		$order_pending =  mysqli_query($connect,"SELECT * FROM orders WHERE status = 'Pending'");
		
		if(mysqli_num_rows($order_pending) == NULL)
		{
			$order_pending_count ='0';
		}
		else
		{
		    $order_pending_count = mysqli_num_rows($order_pending);
		}

		/* Number of active promotion */
		$promotion=  mysqli_query($connect,"SELECT * FROM promotion WHERE status = 'Enable'");

		$promotion_products_count = 0;

		while ($promotion_row = mysqli_fetch_assoc($promotion)) { 

			$promotion_id = $promotion_row['promotion_id'];
			date_default_timezone_set("Asia/Kuala_Lumpur");
			$today_date = date("Y-m-d");
			$today_date = date_parse($today_date);

			$promotion_start_date = date_parse ($promotion_row['promotion_start_date']);
			$promotion_end_date = date_parse ($promotion_row['promotion_end_date']);


			if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
				$check_promotion_product = mysqli_query($connect,"SELECT * FROM promotion_products WHERE promotion_id = '$promotion_id'");

				while($check_product_row = mysqli_fetch_assoc($check_promotion_product))
				{
					$promotion_products_count++;
				}
			}
		}
		

		/* Number of active voucher */
		$voucher_active =  mysqli_query($connect,"SELECT * FROM voucher WHERE status = 'Enable' AND start_date <= CURDATE() AND end_date >= CURDATE()");
		$voucher_active_count = 0;
		if(mysqli_num_rows($voucher_active) == NULL)
		{
			$voucher_active_count='0';
		}
		else
		{
			$voucher_active_count = mysqli_num_rows($voucher_active);
		}
		
	?>

<div class="index_wrap">
	<div class="index_box">
		<div class="index_header">
			<h4>Dashboard</h4>
		</div>
		
		<div class="dashboard_card_wrap">
			<?php
				if($admin_position == "Admin")
				{
					$sales_link="index.php";
				}
				else if($admin_position == "Superadmin")
				{
					$sales_link="sales.php";
				}
			?>
			<div class="dashboard_cards" id="card_1">
				<a href="<?php echo $sales_link ?>">
					<div class="first_card">
						<div class="card_body">
							<span class="sales_icon"><i class="fas fa-chart-area fa-2x"></i></span>
							<div class="card_contain">
								<h5>Monthly Sales</h5>
								<h4>RM <?php echo number_format($total_amount,2) ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_1_footer">
							<?php
								if($admin_position == "Superadmin")
								{
									echo "View All";
								}
							?>
						</div>
					</div>
				</a>
			</div>
			
		
			<div class="dashboard_cards" id="card_2">
				<a href="order.php?filter=waiting for shipment">
					<div class="first_card">
						<div class="card_body">
							<span class="feedback_icon"><i class="fas fa-comments fa-2x"></i></span>
							<div class="card_contain">
								<h5 style="text-transform: capitalize;">Orders to be shipped</h5>
								<h4><?php echo $order_to_be_ship_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_2_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
			
			<div class="dashboard_cards" id="card_3">
				<a href="order.php?filter=pending">
					<div class="first_card">
						<div class="card_body">
							<span class="feedback_icon"><i class="fas fa-comments fa-2x"></i></span>
							<div class="card_contain">
								<h5 style="text-transform: capitalize;">Pending order</h5>
								<h4><?php echo $order_pending_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_3_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
			

			
			<div class="dashboard_cards" id="card_4">
				<a href="order.php">
					<div class="first_card">
						<div class="card_body">
							<span class="orders_icon"><i class="fas fa-file-alt fa-2x"></i></span>
							<div class="card_contain">
								<h5>Monthly Orders</h5>
								<h4><?php echo $month_order_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_4_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
			
			<div class="dashboard_cards" id="card_5">
				<a href="promotion.php">
					<div class="first_card">
						<div class="card_body">
							<span class="feedback_icon"><i class="fas fa-box fa-2x"></i></span>
							<div class="card_contain">
								<h5 style="text-transform: capitalize;">Promotion products</h5>
								<h4><?php echo $promotion_products_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_5_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
			
			<div class="dashboard_cards" id="card_6">
				<a href="voucher.php">
					<div class="first_card">
						<div class="card_body">
							<span class="feedback_icon"><i class="fas fa-comments fa-2x"></i></span>
							<div class="card_contain">
								<h5 style="text-transform: capitalize;">Active Voucher</h5>
								<h4><?php echo $voucher_active_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_6_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			

			
			<div class="dashboard_cards" id="card_7">
				<a href="product.php">
					<div class="first_card">
						<div class="card_body">
							<span class="products_icon"><i class="fas fa-box fa-2x"></i></span>
							<div class="card_contain">
								<h5>Products</h5>
								<h4><?php echo $product_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_7_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
			
			<div class="dashboard_cards" id="card_8">
				<a href="admin.php">
					<div class="first_card">
						<div class="card_body">
							<span class="admins_icon"><i class="fas fa-users-cog fa-2x"></i></span>
							<div class="card_contain">
								<h5>Admins</h5>
								<h4><?php echo $admin_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_8_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
			
			<div class="dashboard_cards" id="card_9">
				<a href="customer.php">
					<div class="first_card">
						<div class="card_body">
							<span class="customers_icon"><i class="fas fa-users fa-2x"></i></span>
							<div class="card_contain">
								<h5>Registered Customers</h5>
								<h4><?php echo $customer_count; ?></h4>
							</div>
						</div>
						<div class="card_footer" id="card_9_footer">
							View All
						</div>
					</div>
				</a>
			</div>
			
		</div>
	</div>
</div>

</body>
</html>