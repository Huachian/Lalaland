<?php
	session_start();
	include ("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/admin.php");
	}

	$admin_id = $_SESSION["id"];
	$admin_position = $_SESSION["admin_position"];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/admin.js"></script>
	<script src="https://kit.fontawesome.com/49f22bfabd.js" crossorigin="anonymous"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('admin_btn_wrap').style.background = "#ffff4d";
		document.getElementById('admin_btn_title').style.color = "black";
		document.getElementById('admin_icon').style.color = "black";
	</script>

	<input type="hidden" id="admin_id" value="<?php echo $admin_id ?>">

	<div class="admin_main_wrap">
		<div class="admin_second_wrap">
			<div id="admin_page_title">
				Admin List
			</div>

			<div id="admin_page_top_action_wrap">
				<div id="search_admin_wrap">
					<form autocomplete="off">
						<input type="text" id="search_admin" placeholder="Search Admin" onkeyup="filter_table()">
					</form>
				</div>
				<?php
					if($admin_position == "Admin")
					{
						$add_admin_btn="hide_add_admin_btn";
					}
					else if($admin_position == "Superadmin")
					{
						$add_admin_btn="add_admin_btn";
					}
				?>
				<div id="admin_page_top_btn_wrap" class="<?php echo $add_admin_btn ?>">
					<button onclick="add_admin_popup_form()">
						Add Admin
					</button>
				</div>
			</div>

			<div id="admin_display_wrap">
				<table id="admin_table">
					<tr>
						<th id="admin_no_column">
							No
						</th>
						<th id="admin_id_column">
							Admin ID
						</th>
						<th id="admin_first_name_column">
							First Name
						</th>
						<th id="admin_last_name_column">
							Last Name
						</th>
						<th id="admin_phone_column">
							Phone
						</th>
						<th id="admin_email_address_column">
							Email Address
						</th>
						<th id="admin_gender_column">
							Gender
						</th>
						<th id="admin_position_column">
							Position
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_admin_row = mysqli_query($connect, "SELECT * FROM superadmin");
						$i = 0;

						while($admin_row = mysqli_fetch_assoc($select_admin_row)){
							$i++;
					?>
							<tr class="admin_row" id="admin_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="admin_delete_status<?php echo $i ?>" value="0">
								<td class="admin_number_column" onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<?php echo $admin_row['superadmin_id'] ?>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<span id="first_name<?php echo $i ?>"><?php echo $admin_row['first_name'] ?></span>
								</td>
								<td class="lname_column" onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<span id="last_name<?php echo $i ?>"><?php echo $admin_row['last_name'] ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<span id="phone<?php echo $i ?>"><?php echo $admin_row['phone'] ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<span id="email<?php echo $i ?>"><?php echo $admin_row['email'] ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<span id="gender<?php echo $i ?>"><?php echo $admin_row['gender'] ?></span>
								</td>
								<td class="table_position_td" onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
									<?php
										if($admin_row['position'] == "Admin")
										{
											$font_color="admin_font";
										}
										else if($admin_row['position'] == "Superadmin")
										{
											$font_color="superadmin_font";
										}
									?>
									<div class="<?php echo $font_color ?>" id="position<?php echo $i ?>"><?php echo $admin_row['position'] ?></div>
								</td>
								<td id="admin_button_column">
									<button onclick="show_admin_details('<?php echo $admin_row['superadmin_id'] ?>', '<?php echo $i ?>')">
										<img src="image/customer/view_icon.png">
									</button>
									<?php
										if($admin_position == "Admin")
										{
											$delete_btn="hide_delete_btn";
										}
										else if($admin_position == "Superadmin")
										{
											$delete_btn="delete_btn";
										}
									?>
									<button class="<?php echo $delete_btn ?>" onclick="delete_admin('<?php echo $i ?>', '<?php echo $admin_row['superadmin_id'] ?>')">
										<img src="image/admin/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}

						$select_admin_row = mysqli_query($connect, "SELECT * FROM admin");
						while($admin_row = mysqli_fetch_assoc($select_admin_row)){
							$i++;
					?>
							<tr class="admin_row" id="admin_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="admin_delete_status<?php echo $i ?>" value="0">
								<td class="admin_number_column" onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<?php echo $admin_row['admin_id'] ?>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<span id="first_name<?php echo $i ?>"><?php echo $admin_row['first_name'] ?></span>
								</td>
								<td class="lname_column" onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<span id="last_name<?php echo $i ?>"><?php echo $admin_row['last_name'] ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<span id="phone<?php echo $i ?>"><?php echo $admin_row['phone'] ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<span id="email<?php echo $i ?>"><?php echo $admin_row['email'] ?></span>
								</td>
								<td onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<span id="gender<?php echo $i ?>"><?php echo $admin_row['gender'] ?></span>
								</td>
								<td class="table_position_td" onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
									<?php
										if($admin_row['position'] == "Admin")
										{
											$font_color="admin_font";
										}
										else if($admin_row['position'] == "Superadmin")
										{
											$font_color="superadmin_font";
										}
									?>
									<div class="<?php echo $font_color ?>" id="position<?php echo $i ?>"><?php echo $admin_row['position'] ?></div>
								</td>
								<td id="admin_button_column">
									<button onclick="show_admin_details('<?php echo $admin_row['admin_id'] ?>', '<?php echo $i ?>')">
										<img src="image/customer/view_icon.png">
									</button>
									<?php
										if($admin_position == "Admin")
										{
											$delete_btn="hide_delete_btn";
										}
										else if($admin_position == "Superadmin")
										{
											$delete_btn="delete_btn";
										}
									?>
									<button class="<?php echo $delete_btn ?>" onclick="delete_admin('<?php echo $i ?>', '<?php echo $admin_row['admin_id'] ?>')">
										<img src="image/admin/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>
				</table>
			</div>
		</div>
	</div>


	<div id="admin_details_wrap">
		<div id="admin_details_wrap_2">
			<div id="admin_details_title">
				Admin Details
				<?php
				if($admin_position == "Admin")
				{
					$action_buttons="hide_view_password";
				}
				else if($admin_position == "Superadmin")
				{
					$action_buttons="view_password";
				}
				?>
				<button class="<?php echo $action_buttons?>" id="edit_admin_pass_button" onclick="show_access_password_pop_up()">
					<i class="fas fa-key"></i> Password
				</button>
			</div>

			<div id="admin_details_box">
				<button id="close_admin_details_btn" onclick="close_admin_details()">
					<img src="image/product/close_icon.png">
				</button>

				<div id="image_preview_wrap">
					<img src="" id="admin_profile_picture_display">
					<br>
					<div id="image_image_blank" onclick="edit_upload_image()">
						<div>
							No Image
						</div>
					</div>
					<input type="file" id="upload_edit_admin_image" accept="image/*" onchange="preview_admin_image('edit')" disabled>
				</div>

				<table id="admin_details_table">
					<form autocomplete="off">
					<tr>
						<td class="admin_details_table_title">
							Position
						</td>
						<td class="admin_details_table_contain">
							:<div id="position" class="details_contain"></div>
							<select id="edit_admin_position" class="edit_admin_input_box">
								<option value="Admin">Admin</option>
								<option value="Superadmin">Superadmin</option>
							</select>
						</td>
					</tr>
					<tr>
						<td class="admin_details_table_title">
							Admin ID
						</td>
						<td class="admin_details_table_contain">
							:<div id="admin_details_id" class="details_contain"></div>
							<input type="text" class="edit_admin_input_box" id="edit_admin_id">
						</td>
					</tr>
					<tr>
						<td class="admin_details_table_title">
							First name
						</td>
						<td class="admin_details_table_contain">
							:<div id="first_name" class="details_contain"></div>
							<input type="text" class="edit_admin_input_box" id="edit_admin_first_name" onblur="fname_validation('edit')">
							<div id="edit_admin_fname_error" class="edit_admin_error"></div>
						</td>
					</tr>
					<tr>
						<td class="admin_details_table_title">
							Last name
						</td>
						<td class="admin_details_table_contain">
							:<div id="last_name" class="details_contain"></div>
							<input type="text" class="edit_admin_input_box" id="edit_admin_last_name" onblur="lname_validation('edit')">
							<div id="edit_admin_lname_error" class="edit_admin_error"></div>
						</td>
					</tr>
					<tr>
						<td class="admin_details_table_title">
							Phone
						</td>
						<td class="admin_details_table_contain">
							:<div id="phone" class="details_contain"></div>
							<input type="text" class="edit_admin_input_box" id="edit_admin_phone" onblur="phone_validation('edit')" data-mask="999-99999999">
							<div id="edit_admin_phone_error" class="edit_admin_error"></div>
						</td>
					</tr>
					<tr>
						<td class="admin_details_table_title">
							Email Address
						</td>
						<td class="admin_details_table_contain">
							:<div id="email" class="details_contain"></div>
							<input type="text" class="edit_admin_input_box" id="edit_admin_email" onblur="email_validation('edit')">
							<div id="edit_admin_email_error" class="edit_admin_error"></div>
						</td>
					</tr>
					<tr>
						<td class="admin_details_table_title">
							Gender
						</td>
						<td class="admin_details_table_contain">
							:<div id="gender" class="details_contain"></div>
							<select id="edit_admin_gender" class="edit_admin_input_box">
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
						</td>
					</tr>
					</form>
				</table>
			</div>
			<?php
				if($admin_position == "Admin")
				{
					$action_buttons="hide_action_buttons";
				}
				else if($admin_position == "Superadmin")
				{
					$action_buttons="action_buttons";
				}
			?>
			<div id="edit_admin_action_button" class="<?php echo $action_buttons?>">
				<button id="edit_admin_details_btn" onclick="edit_admin_details()">
					<img src="image/admin/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit_admin()">
					<img src="image/admin/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_admin()">
					<img src="image/admin/save_icon.png">
				</button>
			</div>
		</div>
	</div>


	<div id="add_new_admin_wrap">
		<div id="add_new_admin_wrap_2">
			<div id="add_admin_top_title">
				Add Admin
			</div>

			<div id="add_new_admin_details_box">
				<button id="close_admin_details_btn" onclick="close_insert_admin()">
					<img src="image/admin/close_icon.png">
				</button>

				<div id="upload_admin_img_wrap">
					<div id="upload_image_preview_wrap">
						<img src="" id="insert_admin_image_preview">
						<div id="upload_image_preview_empty" onclick="upload_image()">
							<div id="image_preview_empty_title">Upload Image</div>
						</div>
					</div>
					<div>
						<input type="file" name="product_image" accept="image/*" id="image_upload" onchange="preview_admin_image('add')">
					</div>
				</div>

				<div id="insert_admin_wrap">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">Position</div>
						<div class="details_contain_row">
							: 
							<select id="insert_admin_position" class="admin_details_input_box" onblur="admin_position_validation(); get_new_admin_id();" onchange="get_new_admin_id()">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="Admin">Admin</option>
								<option value="Superadmin">Superadmin</option>
							</select>
							<div id="insert_admin_position_error" class="insert_admin_error"></div>
						</div>
					</div>
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">Admin ID</div>
						<div class="details_contain_row">
							: <input type="text" class="admin_details_input_box" id="insert_admin_id" disabled>
						</div>
					</div>
					<form autocomplete="off">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">First name</div>
						<div class="details_contain_row">
							: <input type="text" class="admin_details_input_box" id="insert_admin_first_name" onblur="fname_validation('add')" placeholder="Enter First name">
							<div id="insert_admin_fname_error" class="insert_admin_error"></div>
						</div>
					</div>
					</form>
					<form autocomplete="off">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">Last name</div>
						<div class="details_contain_row">
							: <input type="text" class="admin_details_input_box" id="insert_admin_last_name" onblur="lname_validation('add')" placeholder="Enter Last name">
							<div id="insert_admin_lname_error" class="insert_admin_error"></div>
						</div>
					</div>
					</form>
					<form autocomplete="off">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">Phone</div>
						<div class="details_contain_row">
							: <input type="text" class="admin_details_input_box" id="insert_admin_phone" onblur="phone_validation('add')" placeholder="Enter Phone" data-mask="999-99999999">
							<div id="insert_admin_phone_error" class="insert_admin_error"></div>
						</div>
					</div>
					</form>
					<form autocomplete="off">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">Email Address</div>
						<div class="details_contain_row">
							: <input type="text" class="admin_details_input_box" id="insert_admin_email" onblur="email_validation('add')" placeholder="Enter Email address">
							<div id="insert_admin_email_error" class="insert_admin_error"></div>
						</div>
					</div>
					</form>
					<form autocomplete="off">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title">Gender</div>
						<div class="details_contain_row">
							: 
							<select id="insert_admin_gender" class="admin_details_input_box" onblur="admin_gender_validation()">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
							<div id="insert_admin_gender_error" class="insert_admin_error"></div>
						</div>
					</div>
					</form>
					<form autocomplete="off">
					<div id="admin_details_insert_pass_row">
						<div class="admin_details_insert_title">Password</div>
						<div class="details_pass_contain_row">
							: <input type="password" autocomplete="new-password" class="admin_details_input_box" id="insert_admin_password" onkeyup="password_guide()" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" onblur="pass_validation()" placeholder="Password">
							<div id="toggle_password_icon" class="show_password_icon" onclick="show_hide_password()"></div>
						</div>
						<img src="image/admin/tick_icon.png" id="password_tick_icon">
				     	<img src="image/admin/cross_icon.png" id="password_cross_icon">
				    	<div id="insert_admin_password_error_message"></div>
				  		<div id="password_format">*Please use a strong password.<br> (<span id="characters">Minimum 15 characters</span>, <span id="number">1 number</span>, <span id="small_letter">1 small letter</span>, <span id="upper_letter">1 upper letter</span>, <span id="symbol">1 symbol</span>)</div>
					</div>
					</form>
					<form autocomplete="off">
					<div id="admin_details_insert_row">
						<div class="admin_details_insert_title" id="admin_details_insert_conpass">Confirm Password</div>
						<div class="details_contain_row">
							: <input type="password" class="admin_details_input_box" id="insert_admin_confirm_password" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" onblur="confirm_password_validation()" placeholder="Confirm Password" autocomplete="new-password">
							<div id="toggle_confirm_password_icon" class="show_confirm_password_icon" onclick="show_hide_confirm_password()"></div>
						</div>
						<img src="image/admin/tick_icon.png" id="confirm_password_tick_icon">
				     	<img src="image/admin/cross_icon.png" id="confirm_password_cross_icon">
						<div id="insert_admin_conpass_error"></div>				     	
					</div>
					</form>
				</div>
			</div>

			<div id="add_admin_action_button">
				<button onclick="add_admin()">
					<img src="image/admin/save_icon.png">
				</button>
			</div>
		</div>
	</div>


	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="delete_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product/eror_icon.png">
				<div>
					Not allow to delete yourself
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Admin successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this admin?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_admin_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="access_pass_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<div id="close_btn">
					<img src="image/admin/close_icon.png" onclick="close_access_password_pop_up()">
				</div>
				<i class="far fa-address-card fa-6x"></i>
				<div>
					Enter your password to access
				</div>
				<div>
					<form autocomplete="off">
						<input type="password" id="access_password_input" placeholder="Enter your Password" onkeyup="update_enter_password_btn()" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" autocomplete="new-password">
					</form>
				</div>
				<div>
					<button id="confirm_btn" onclick="confirm_access_pass()">
						Confirm
					</button>
				</div>
			</div>
		</div>
	</div>

	<div id="admin_pass_wrap">
		<div class="alert_box">
			<div class="top_left_header_admin_pass">
					<i class="fas fa-key"></i> Admin Password
				</div>
				<div class="admin_pass_alert_box_contain">
					<div class="admin_pass_close_btn">
						<img src="image/admin/close_icon.png" onclick="close_admin_pass()">
					</div>
					<div class="admin_pass_box">
						<div class="admin_pass_title">
							Password
						</div>
						<form>
						<div class="admin_pass_contain">
						 	: <input type="password" id="admin_password_input" onkeyup="new_password_guide()" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" onblur="edit_password_validation()" autocomplete="new-password" disabled>
						 	<div id="toggle_admin_password_icon" class="admin_show_pass_icon" onclick="show_hide_admin_password()"></div>

						 	<img src="image/admin_password/tick_icon.png" id="new_password_tick_icon">
				            <img src="image/admin_password/cross_icon.png" id="new_password_cross_icon">
				            <div id="new_password_error_message"></div>
				            <div id="edit_password_format">*Please use a strong password.<br> (<span id="edit_characters">Minimum 15 characters</span>, <span id="edit_number">1 number</span>, <span id="edit_small_letter">1 small letter</span>, <span id="edit_upper_letter">1 upper letter</span>, <span id="edit_symbol">1 symbol</span>)</div>
						</div>
						</form>
					</div>
				</div>
				<div id="edit_admin_password_action_button">
				<button id="edit_admin_password_btn" onclick="edit_admin_pass()">
					<img src="image/admin/edit_icon.png">
				</button>
				<button id="cancel_edit_password_btn" onclick="cancel_edit_pass()">
					<img src="image/admin/close_icon.png">
				</button>
				<button id="save_edit_password_btn" onclick="save_edit_pass()">
					<img src="image/admin/save_icon.png">
				</button>
			</div>
			
		</div>
	</div>

</body>
	<script type="text/javascript">
	    var side_bar_btn = document.getElementById('admin_btn_wrap');
	    var side_bar_btn = side_bar_btn.offsetTop;
	    document.getElementById('admin_side_navigation_wrap').scrollTop = side_bar_btn;
  	</script>

  	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</html>