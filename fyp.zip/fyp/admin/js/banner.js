function close_banner_details(){

	if(edit_activity == 0){
		document.getElementById("banner_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}


var current_view_banner = "";
function show_banner_details(banner_id, i){
	var operation = "get_banner_details";

	current_view_banner = i;

	$.ajax({
		url: "function/update_banner.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'banner_id': banner_id
		},
		success: function(data){
			document.getElementById("banner_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			document.getElementById("details_banner_id").value = banner_id;
			document.getElementById("edit_banner_image_preview").src = "image/banner/"+data[0].banner_name;
			document.getElementById("banner_details_name").innerHTML = data[0].banner_name;
			document.getElementById("banner_details_status").innerHTML = data[0].banner_status;
			document.getElementById("upload_edit_banner_image").value = "";

			document.getElementById("banner_details_box").scrollTop = 0;
		}
	});

}

var temporary_name = "";
var temporary_image_src = "";
var edit_activity = "";
var current_banner_name = "";
function edit_banner(){
	edit_activity = 1;

	temporary_image_src = document.getElementById("edit_banner_image_preview").src; 

	document.getElementById("edit_banner_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	var current_banner_status = document.getElementById("banner_details_status").innerHTML;
	current_banner_name = document.getElementById("banner_details_name").innerHTML;

	document.getElementById("upload_edit_banner_image").style.display = "inline";
	document.getElementById("edit_banner_status").style.display = "inline";
	document.getElementById("edit_banner_name").style.display = "inline";

	document.getElementById("edit_banner_name").value = current_banner_name;
	document.getElementById("edit_banner_status").value = current_banner_status;
	temporary_name = document.getElementById("edit_banner_name").value;
	document.getElementById("banner_details_name").style.display = "none";
	document.getElementById("banner_details_status").style.display = "none";
}


function cancel_edit_banner(){
	edit_activity = 0;
	document.getElementById("edit_banner_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	document.getElementById("upload_edit_banner_image").style.display = "";
	document.getElementById("upload_edit_banner_image").style.display = "none";
	document.getElementById("edit_banner_name").style.display = "none";
	document.getElementById("edit_banner_status").style.display = "none";


	document.getElementById("edit_banner_image_preview").style.display = "inline-block";
	document.getElementById("banner_details_name").style.display = "inline-block";
	document.getElementById("banner_details_status").style.display = "inline-block";

	var banner_id = document.getElementById("details_banner_id").value;
	show_banner_details(banner_id, current_view_banner);
}


function save_edit_banner(){
	var operation = "save_edit_banner";

	var fd = new FormData();

	var banner_id = document.getElementById("details_banner_id").value;
	var banner_name = document.getElementById("edit_banner_name").value;
	var banner_image = $('#upload_edit_banner_image')[0].files;
	var banner_status = document.getElementById("edit_banner_status").value;

	fd.append('operation',operation);
	fd.append('banner_id',banner_id);
	fd.append('banner_image',banner_image[0]);
	fd.append('banner_status',banner_status);
	fd.append('banner_name',banner_name);
	fd.append('current_banner_name',current_banner_name);

	$.ajax({
		url: "function/update_banner.php",
		type: "POST",
		data: fd,
	    contentType: false,
	    processData: false,
	    success: function(data){
	    	if(data == "yes"){
	    		document.getElementById("banner_name"+current_view_banner).innerHTML = banner_name;
				document.getElementById("banner_status"+current_view_banner).innerHTML = banner_status;

				if(banner_status == "Display"){
					document.getElementById("banner_status"+current_view_banner).classList.remove("hide_tag");
					document.getElementById("banner_status"+current_view_banner).classList.add("display_tag");
				}
				else{
					document.getElementById("banner_status"+current_view_banner).classList.add("hide_tag");
					document.getElementById("banner_status"+current_view_banner).classList.remove("display_tag");
				}


	    		document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					cancel_edit_banner();
				}, 1500);
	    	}
	    	else{
	    		document.getElementById("min_error_alert_wrap").style.display = "block";

				setTimeout(function(){
					document.getElementById("min_error_alert_wrap").style.display = "none";
				}, 1500);
	    	}		
	    }
	});
}


function add_banner_popup(){
	document.getElementById("add_new_banner_wrap").style.display = "block";
	document.querySelector("body").style.overflow = "hidden";

	document.getElementById("add_new_banner_details_box").scrollTop = 0;
} 


function close_insert_banner(){
	document.getElementById("add_new_banner_wrap").style.display = "none";
	document.querySelector("body").style.overflow = "auto";

    document.getElementById("add_banner_error").innerHTML = "";
    document.getElementById("image_preview_empty").style.border = "1px solid #666666";
    document.getElementById("insert_image_upload").value = "";
    document.getElementById("insert_banner_status_error").innerHTML = "";
    document.getElementById("insert_status").style.border = "1px solid #666666";
    document.getElementById("insert_image_upload").value = "";
    document.getElementById("insert_banner_name").value = "";
    document.getElementById("insert_status").value = "0";
    document.getElementById("insert_banner_image_preview").style.display = "none";
	document.getElementById("image_preview_empty").style.display = "block";
}


var valid_status = "false";
function insert_status_validation()
{
  var status = document.getElementById("insert_status").value;
  var error_message = document.getElementById("insert_banner_status_error");
  var error_border = document.getElementById("insert_status");

  
  if(status == "0"){
    error_message.innerHTML = "Status is required.";
    error_border.style.border = "2px solid red";
    valid_status = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_status = "true";
  }
}


function upload_image(){
	document.getElementById("insert_image_upload").click();
}


function preview_banner_image(select){
	if(select == "add"){
		var file = document.getElementById("insert_image_upload").files;

		document.getElementById("insert_banner_image_preview").style.display = "inline";
		document.getElementById("image_preview_empty").style.display = "none";

		if(file.length > 0){
			var fileReader = new FileReader();

			fileReader.onload = function(event){
				document.getElementById("insert_banner_image_preview").setAttribute("src", event.target.result);
			}

			fileReader.readAsDataURL(file[0]);

			var file_name = file[0].name;
			document.getElementById("insert_banner_name").value = file_name;
		}
		else{
			document.getElementById("insert_banner_image_preview").style.display = "none";
			document.getElementById("image_preview_empty").style.display = "block";
			document.getElementById("insert_banner_name").value = "";
		}
	}
	else if(select == "edit"){
		var file = document.getElementById("upload_edit_banner_image").files;

		if(file.length > 0){
			var fileReader = new FileReader();

			fileReader.onload = function(event){
				document.getElementById("edit_banner_image_preview").setAttribute("src", event.target.result);
			}

			fileReader.readAsDataURL(file[0]);

			var file_name = file[0].name;
			document.getElementById("edit_banner_name").value = file_name;
		}
		else
	    {
	      document.getElementById("edit_banner_image_preview").src = temporary_image_src;
	      document.getElementById("edit_banner_name").value = temporary_name;
	    }
	}
}


valid_banner = "false";
function add_banner_image_validation()
{

	var file = document.getElementById("insert_image_upload").files;
	var error = document.getElementById("add_banner_error");
	var error_border = document.getElementById("image_preview_empty");  	

    if(file.length > 0){
    	error.innerHTML = "";
      	error_border.style.border = "2px solid lightgrey";
     	valid_banner = "true";	
      
    }
    else{
    	error.innerHTML = "Please Upload Image";
  		error_border.style.border = "2px solid red";
  		valid_banner = "false";
    }  

}

function add_banner(){
	var operation = "add_banner";

	add_banner_image_validation();
	insert_status_validation();
	var file = document.getElementById("insert_image_upload").files;

	if(valid_banner == "true" && valid_status == "true" && file.length>0){
		var fd = new FormData();
		var banner_image = $('#insert_image_upload')[0].files;
		var banner_status = document.getElementById("insert_status").value;


		fd.append('operation',operation);
		fd.append('banner_image',banner_image[0]);
		fd.append('banner_status',banner_status);

		$.ajax({
			url: "function/update_banner.php",
			type: "POST",
			data: fd,
		    contentType: false,
		    processData: false,
		    success: function(data){
		    	if(data == "banner_exist"){
		    		document.getElementById("add_error_alert_wrap").style.display = "block";

					setTimeout(function(){
						document.getElementById("add_error_alert_wrap").style.display = "none";
					}, 1500);
		    	}
		    	else{
		    		document.getElementById("add_success_alert_wrap").style.display = "block";
					document.querySelector("body").style.overflow = "hidden";

					setTimeout(function(){
						document.getElementById("add_success_alert_wrap").style.display = "none";
						document.querySelector("body").style.overflow = "auto";
						window.location = "banner.php";
					}, 1500);
		    	}
		    }
		});
	}
}

function filter_table(){
    var input = document.getElementById("search_banner");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("banner_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++){
    	var delete_status = document.getElementById("banner_delete_status"+i).value;
    	if(delete_status == 0){
    		if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
	            tr[i].style.display = "";
	            
	            found_result++;
	            if(found_result % 2 == 0){
	              tr[i].style.background = "none";
	            }
	            else{
	              tr[i].style.background = "#f2f2f2";
	            }

	            document.getElementById("table_number"+i).innerHTML = found_result;
	        }
	        else{
	            tr[i].style.display = "none";
	        }
    	}
    }
}

var target_delete_id = "";
var target_delete_name = "";
var target_delete_count = "";
function delete_banner_pop_up(banner_id, banner_name, counter){
	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	target_delete_id = banner_id;
	target_delete_name = banner_name;
	target_delete_count = counter;

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function delete_yes(){
	var operation = "delete_banner";

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/update_banner.php",
		type: "POST",
		data: {
			'operation': operation,
			'banner_id': target_delete_id,
			'banner_name': target_delete_name
		},
		success: function(data){
			if(data == "yes"){
				document.getElementById("banner_row"+target_delete_count).style.display = "none";
				document.getElementById("banner_delete_status"+target_delete_count).value = 1;
				filter_table();
			}
			else{
				document.getElementById("min_error_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("min_error_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
				}, 1500);
			}
		}
	});
}