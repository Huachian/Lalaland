var current_first_name = "";
var current_last_name = "";
var current_phone_number = "";
var current_gender = "";

var temporary_image_src = "";
function edit_profile(){
  temporary_image_src = document.getElementById("insert_profile_image_preview").src; 
  current_first_name = document.getElementById("first_name").value;
  current_last_name = document.getElementById("last_name").value;
  current_phone_number = document.getElementById("phone_number").value;
  var get_current_gender = document.getElementById("gender").value;
  if(get_current_gender == "Male"){
    current_gender = "Male";
  }
  else{
    current_gender = "Female";
  }

  document.getElementById("image_upload").disabled = false;
  document.getElementById("first_name").disabled = false;
  document.getElementById("last_name").disabled = false;
  document.getElementById("phone_number").disabled = false;
  document.getElementById("gender_male").disabled = false;
  document.getElementById("gender_female").disabled = false;

  document.getElementById("image_upload").style.display = "inline";
  document.getElementById("edit_profile_btn").style.display = "none";
  document.getElementById("cancel_edit_profile_btn").style.display = "inline";
  document.getElementById("save_edit_profile_btn").style.display = "inline";
  document.getElementById("upload_image_preview_empty").style.cursor = "pointer";
}

function cancel_edit_profile(){
  document.getElementById("first_name").value = current_first_name;
  document.getElementById("last_name").value = current_last_name;
  document.getElementById("phone_number").value = current_phone_number;
  document.getElementById("upload_image_preview_empty").style.cursor = "default";

  if(current_gender == "Male"){
    document.getElementById("gender_male").checked = true;
    document.getElementById("gender_female").checked = false;
  }
  else{
    document.getElementById("gender_male").checked = false;
    document.getElementById("gender_female").checked = true;
  }

  document.getElementById("first_name_error").innerHTML = "";
  document.getElementById("first_name").style.border = "2px solid #f0f0f0";
  document.getElementById("last_name_error").innerHTML = "";
  document.getElementById("last_name").style.border = "2px solid #f0f0f0";
  document.getElementById("phone_number_error").innerHTML = "";
  document.getElementById("phone_number").style.border = "2px solid #f0f0f0";

  document.getElementById("insert_profile_image_preview").src = temporary_image_src;
  document.getElementById("image_upload").value = "";
  document.getElementById("image_upload").disabled = true;
  document.getElementById("first_name").disabled = true;
  document.getElementById("last_name").disabled = true;
  document.getElementById("phone_number").disabled = true;
  document.getElementById("gender_male").disabled = true;
  document.getElementById("gender_female").disabled = true;

  document.getElementById("image_upload").style.display = "none";
  document.getElementById("edit_profile_btn").style.display = "inline";
  document.getElementById("cancel_edit_profile_btn").style.display = "none";
  document.getElementById("save_edit_profile_btn").style.display = "none";
}

var valid_first_name = "false";
function first_name_validation()
{
  var space = /^\s*$/;
  var fname = document.getElementById("first_name").value;
  var pattern = /^[a-zA-Z\s]+$/;
  
  //first name
  if(fname.match(space))
  {
    document.getElementById("first_name_error").innerHTML = "First name is required.";
    document.getElementById("first_name").style.border = "2px solid red";
    valid_first_name = "false";
  }
  else if(fname.match(pattern))
  {
    document.getElementById("first_name_error").innerHTML = "";
    document.getElementById("first_name").style.border = "2px solid #f0f0f0";
    valid_first_name = "true";
  }
  else
  {
    document.getElementById("first_name_error").innerHTML = "Please enter name as only Alphabet.";
    document.getElementById("first_name").style.border = "2px solid red";
    valid_first_name = "false";
  }
}

var valid_last_name = "false";
function last_name_validation()
{
  var space = /^\s*$/;
  var lname = document.getElementById("last_name").value;
  var pattern = /^[a-zA-Z\s]+$/;

 //last name
 if(lname.match(space))
  {
    document.getElementById("last_name_error").innerHTML = "Last name is required.";
    document.getElementById("last_name").style.border = "2px solid red";
    valid_last_name = "false";
  }
  else if(lname.match(pattern))
  {
    document.getElementById("last_name_error").innerHTML = "";
    document.getElementById("last_name").style.border = "2px solid #f0f0f0";
    valid_last_name = "true";
  }
  else
  {
    document.getElementById("last_name_error").innerHTML = "Please enter name as only Alphabet.";
    document.getElementById("last_name").style.border = "2px solid red";
    valid_last_name = "false";
  }
}

var valid_phone = "false";
function phone_validation()
{
  var space = /^\s*$/;
  var phoneNo = document.getElementById("phone_number").value;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  //phone
  if(phoneNo.match(space))
  {
    document.getElementById("phone_number_error").innerHTML = "Phone number is required.";
    document.getElementById("phone_number").style.border = "2px solid red";
    valid_phone = "false";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12)
  {
    document.getElementById("phone_number_error").innerHTML = "Please enter a valid phone number.";
    document.getElementById("phone_number").style.border = "2px solid red";
    valid_phone = "false";
  }
  else
  {
    document.getElementById("phone_number_error").innerHTML = "";
    document.getElementById("phone_number").style.border = "2px solid #f0f0f0";
    valid_phone = "true";
  }
}

function upload_image(){
  document.getElementById("image_upload").click();
}

var uploaded_image = "";
function preview_admin_image(select){

    var file = document.getElementById("image_upload").files;

    document.getElementById("insert_profile_image_preview").style.display = "inline";
    document.getElementById("upload_image_preview_empty").style.display = "none";

    if(file.length > 0){
      var fileReader = new FileReader();

      fileReader.onload = function(event){
        document.getElementById("insert_profile_image_preview").setAttribute("src", event.target.result);
        uploaded_image = event.target.result;
      }

      fileReader.readAsDataURL(file[0]);
      document.getElementById("insert_profile_image_preview").style.display = "inline";
      document.getElementById("upload_image_preview_empty").style.display = "none";
      document.getElementById("upload_image_preview_empty").style.cursor = "default";
      document.getElementById("admin_side_bar_picture").style.display = "inline";
    }
    else
    {
      document.getElementById("insert_profile_image_preview").src = temporary_image_src;
      document.getElementById("insert_profile_image_preview").style.display = "none";
      document.getElementById("upload_image_preview_empty").style.display = "inline-block";
      document.getElementById("upload_image_preview_empty").style.cursor = "pointer";
    }

}


function save(position){
  first_name_validation();
  last_name_validation();
  phone_validation();

  if(valid_first_name == "true" && valid_last_name == "true" && valid_phone == "true"){
    document.getElementById("edit_profile_alert_wrap").style.display = "block";
    document.querySelector('body').style.overflow = "hidden";

    var operation = "update_profile";
    var fd = new FormData();
    var profile_picture = $('#image_upload')[0].files;
    var first_name = document.getElementById("first_name").value;
    var last_name = document.getElementById("last_name").value;
    var phone_number = document.getElementById("phone_number").value;

    if(document.getElementById("gender_male").checked == true){
      var gender = "Male";
    }
    else{
      var gender = "Female";
    }

    fd.append('operation',operation);
    fd.append('profile_picture',profile_picture[0]);
    fd.append('first_name',first_name);
    fd.append('last_name',last_name);
    fd.append('phone_number',phone_number);
    fd.append('gender',gender);
    fd.append('position',position);

    document.getElementById("side_nav_admin_first_name").innerHTML = first_name;
    document.getElementById("side_nav_admin_last_name").innerHTML = last_name;


    if(profile_picture.length != 0){
      document.getElementById("admin_side_bar_picture_wrap").style.display = "inline";
      document.getElementById("admin_side_bar_picture_empty_wrap").style.display = "none";
      document.getElementById("admin_side_bar_profile").setAttribute("src", uploaded_image);
    }

    $.ajax({
          url: "function/update_admin.php",
          type: "POST",
          data: fd,
          contentType: false,
          processData: false,
          success: function(){

          document.getElementById("first_name").disabled = true;
          document.getElementById("last_name").disabled = true;
          document.getElementById("phone_number").disabled = true;
          document.getElementById("gender_male").disabled = true;
          document.getElementById("gender_female").disabled = true;
          document.getElementById("edit_profile_btn").style.display = "inline";
          document.getElementById("cancel_edit_profile_btn").style.display = "none";
          document.getElementById("save_edit_profile_btn").style.display = "none";
          document.getElementById("image_upload").style.display = "none";

          setTimeout(function(){
            $('#edit_profile_alert_wrap').fadeOut('fast');
            $('body').css('overflow','auto');
            }, 1500); 
          }
    });
  }
}
