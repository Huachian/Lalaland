function showdetails(i){
	var operation = "get_order_product";

	var order_id = document.getElementById("order_id"+i).value;
	var product = "";

	$.ajax({
		url: "function/order.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'order_id': order_id
		},
		success: function(data){

			for(var x=0; x<data.length; x++){
				var product_id = data[x].product_id;
				var product_type = data[x].product_type;
				var custom_card_type = data[x].custom_card_type;
                var product_name = data[x].product_name;
                var quantity = data[x].quantity;
                var product_price = parseFloat(data[x].product_price);
            	var discount = parseFloat(data[x].discount);
            	var amount = (quantity * (product_price-discount));

            	if(product_type == "custom product"){
            		var custom_prefix = "CUSTOM_0";
            		var custom_name_title = "[Custom " + custom_card_type + " card]-";
            		var view_custom_info = "<i class='fas fa-info-circle' id='view_custom_info' onclick='custom_card_details("+product_id+")'></i>"
            	}
            	else{
            		var custom_prefix = "";
            		var custom_name_title = "";
            		var view_custom_info = "";
            	}


            	if(product_type == "voucher"){
            		var negetif = "-";
            		amount = discount;
            	}
            	else{
            		var negetif = "";
            	}

            	product += 	"<tr>" +
			            		"<td class='order_product_table_body_1'>" + (x+1) + "</td>" +
			            		"<td class='order_product_table_body_2'>" + custom_prefix + product_id + " " + custom_name_title + product_name + view_custom_info + "</td>" +
			            		"<td class='order_product_table_body_3'>x " + quantity + "</td>" +
			            		"<td class='order_product_table_body_4'>RM" + product_price.toFixed(2) + "</td>" +
			            		"<td class='order_product_table_body_5'>RM" + discount.toFixed(2) + "</td>" +
			            		"<td class='order_product_table_body_6'>" + negetif + "RM" + amount.toFixed(2) + "</td>" +
		            		"</tr>";
			}

			document.getElementById("order_product_table_contain").innerHTML = product;
		    get_order_details(i);
			document.getElementById("order_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";
			document.getElementById("order_details_wrap_2").scrollTop = 0;
		},
	});

}

var current_view_product = "";
function get_order_details(i){
	var operation = "get_orders";
	current_view_product = i;

	var order_id = document.getElementById("order_id"+i).value;
	document.getElementById("order_id_in_view").value = order_id;

	$.ajax({
		url: "function/order.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'order_id': order_id
		},
		success: function(data){
			document.getElementById("receipt_order_id_display").innerHTML = order_id;
			document.getElementById("receipt_order_date_time").innerHTML = data[0].order_date;
			
			if(data[0].status == "Waiting for Shipment"){
				document.getElementById('receipt_order_status').getElementsByTagName('option')[0].selected = 'selected';
			}
			else if(data[0].status == "Cancelled"){
				document.getElementById('receipt_order_status').getElementsByTagName('option')[3].selected = 'selected';				
			}
			else if(data[0].status == "Pending"){
				document.getElementById('receipt_order_status').getElementsByTagName('option')[2].selected = 'selected';				
			}
			else{
				document.getElementById('receipt_order_status').getElementsByTagName('option')[1].selected = 'selected';
			}		

			if(data[0].status == "Waiting for Shipment"){
				document.getElementById("receipt_delivery_date").style.display = "none";
				document.getElementById("receipt_delivery_date").innerHTML = "";
			}
			else if(data[0].status == "Cancelled"){
				document.getElementById("receipt_delivery_date").style.display = "none";
				document.getElementById("receipt_delivery_date").innerHTML = "";			
			}
			else if(data[0].status == "Pending"){
				document.getElementById("receipt_delivery_date").style.display = "none";
				document.getElementById("receipt_delivery_date").innerHTML = "";			
			}
			else{
				document.getElementById("receipt_delivery_date").style.display = "inline";
				document.getElementById("receipt_delivery_date").innerHTML = data[0].delivery_date;
			}

			document.getElementById("receipt_customer_id").innerHTML = data[0].customer_id;
			document.getElementById("receipt_customer_name").innerHTML = data[0].customer_name;
			document.getElementById("receipt_customer_phone").innerHTML = data[0].customer_phone;
			document.getElementById("receipt_customer_email").innerHTML = data[0].customer_email;
			document.getElementById("delivery_name").innerHTML = data[0].delivery_name;
			document.getElementById("delivery_contact").innerHTML = data[0].delivery_contact;
			document.getElementById("delivery_address").innerHTML = data[0].delivery_address;
			document.getElementById("delivery_postcode").innerHTML = data[0].delivery_postcode;
			document.getElementById("delivery_area").innerHTML = data[0].delivery_area;
			document.getElementById("delivery_state").innerHTML = data[0].delivery_state;
			document.getElementById("customer_remark_contain").innerHTML = data[0].customer_remark;

			var product_subtotal = parseFloat(data[0].product_subtotal);
			var shipping_fee = parseFloat(data[0].shipping_fee);
			var discount_amount = parseFloat(data[0].discount_amount);
			var total_amount = parseFloat(data[0].total_amount);


			document.getElementById("merchandise_subtotal").innerHTML = product_subtotal.toFixed(2);
			document.getElementById("receipt_shipping_fee").innerHTML = shipping_fee.toFixed(2);
			document.getElementById("receipt_shipping_fee_discount").innerHTML = discount_amount.toFixed(2);
			document.getElementById("receipt_order_total").innerHTML = total_amount.toFixed(2);
		}
	});
}

var current_order_status = "";
var current_customer_remark = "";
var edit_activity = "";
function edit_order(){
	edit_activity = 1;
	current_order_status = document.getElementById("receipt_order_status").value;

	document.getElementById("receipt_order_status").disabled = false;
	document.getElementById("edit_order_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	current_customer_remark = document.getElementById("customer_remark_contain").innerHTML;
	var delivery_name = document.getElementById("delivery_name").innerHTML;
	var delivery_contact = document.getElementById("delivery_contact").innerHTML;
	var delivery_address = document.getElementById("delivery_address").innerHTML;
	var delivery_postcode = document.getElementById("delivery_postcode").innerHTML;
	var delivery_area = document.getElementById("delivery_area").innerHTML;
	var delivery_state = document.getElementById("delivery_state").innerHTML;

	document.getElementById("customer_remark_textarea").value = current_customer_remark;
	document.getElementById("edit_delivery_name").value = delivery_name;
	document.getElementById("edit_delivery_contact").value = delivery_contact;
	document.getElementById("edit_delivery_address").value = delivery_address;
	document.getElementById("edit_delivery_postcode").value = delivery_postcode;
	document.getElementById("edit_delivery_area").value = delivery_area;
	document.getElementById("edit_delivery_state").value = delivery_state;


	document.getElementById("customer_remark_contain").style.display = "none";
	document.getElementById("delivery_name").style.display = "none";
	document.getElementById("delivery_contact").style.display = "none";
	document.getElementById("delivery_address").style.display = "none";
	document.getElementById("delivery_postcode").style.display = "none";
	document.getElementById("delivery_area").style.display = "none";
	document.getElementById("delivery_state").style.display = "none";

	document.getElementById("customer_remark_textarea").style.display = "block";
	document.getElementById("edit_delivery_name").style.display = "inline";
	document.getElementById("edit_delivery_contact").style.display = "inline";
	document.getElementById("edit_delivery_address").style.display = "inline";
	document.getElementById("edit_delivery_postcode").style.display = "inline";
	document.getElementById("edit_delivery_area").style.display = "inline";
	document.getElementById("edit_delivery_state").style.display = "inline";

	document.getElementById("customer_remark_textarea").style.outline = "none";
	document.getElementById("edit_delivery_name").style.outline = "none";
	document.getElementById("edit_delivery_contact").style.outline = "none";
	document.getElementById("edit_delivery_address").style.outline = "none";
	document.getElementById("edit_delivery_postcode").style.outline = "none";
	document.getElementById("edit_delivery_area").style.outline = "none";
	document.getElementById("edit_delivery_state").style.outline = "none";
	document.getElementById("receipt_order_status").style.outline = "none";

	document.getElementById("customer_remark_textarea").style.border = "2px solid #003cb3";
	document.getElementById("edit_delivery_name").style.border = "2px solid #003cb3";
	document.getElementById("edit_delivery_contact").style.border = "2px solid #003cb3";
	document.getElementById("edit_delivery_address").style.border = "2px solid #003cb3";
	document.getElementById("edit_delivery_postcode").style.border = "2px solid #003cb3";
	document.getElementById("edit_delivery_area").style.border = "2px solid #003cb3";
	document.getElementById("edit_delivery_state").style.border = "2px solid #003cb3";
	document.getElementById("receipt_order_status").style.border = "2px solid #003cb3";
}

function cancel_edit_order(){
	edit_activity = 0;
	document.getElementById("receipt_order_status").value = current_order_status;
	document.getElementById("receipt_order_status").disabled = true;
	document.getElementById("customer_remark_contain").innerHTML = current_customer_remark;

	document.getElementById("edit_order_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	document.getElementById("customer_remark_contain").style.display = "block";
	document.getElementById("delivery_name").style.display = "inline";
	document.getElementById("delivery_contact").style.display = "inline";
	document.getElementById("delivery_address").style.display = "inline";
	document.getElementById("delivery_postcode").style.display = "inline";
	document.getElementById("delivery_area").style.display = "inline";
	document.getElementById("delivery_state").style.display = "inline";

	document.getElementById("customer_remark_textarea").style.display = "none";
	document.getElementById("edit_delivery_name").style.display = "none";
	document.getElementById("edit_delivery_contact").style.display = "none";
	document.getElementById("edit_delivery_address").style.display = "none";
	document.getElementById("edit_delivery_postcode").style.display = "none";
	document.getElementById("edit_delivery_area").style.display = "none";
	document.getElementById("edit_delivery_state").style.display = "none";
	document.getElementById("edit_order_error").innerHTML = "";
	document.getElementById("receipt_order_status").style.border = "2px solid lightgrey";

	get_order_details(current_view_product);
}

function save_edit_order(){
	order_name_validation();
	order_phone_validation();
	order_address_validation();
	order_postcode_validation();
	order_area_validation();
	order_state_validation();

	if(valid_name == "true" && valid_phone == "true" && valid_address == "true" && valid_postcode == "true" && valid_area == "true" && valid_state == "true"){
		var operation = "edit_order";
		edit_activity = 0;
		var order_id = document.getElementById("order_id_in_view").value;
		var order_status = document.getElementById("receipt_order_status").value;
		var customer_remark = document.getElementById("customer_remark_textarea").value;

		var delivery_name = document.getElementById("edit_delivery_name").value;
		var delivery_contact = document.getElementById("edit_delivery_contact").value;
		var delivery_address = document.getElementById("edit_delivery_address").value;
		var delivery_postcode = document.getElementById("edit_delivery_postcode").value;
		var delivery_area = document.getElementById("edit_delivery_area").value;
		var delivery_state = document.getElementById("edit_delivery_state").value;

		$.ajax({
			url: "function/order.php",
			type: "POST",
			data: {
				'operation': operation,
				'order_id': order_id,
				'delivery_name': delivery_name,
				'delivery_contact': delivery_contact,
				'delivery_address': delivery_address,
				'delivery_postcode': delivery_postcode,
				'delivery_area': delivery_area,
				'delivery_state': delivery_state,
				'customer_remark': customer_remark,
				'order_status': order_status
			},
			success: function(data){
				get_order_details(current_view_product);
				
				document.getElementById("receipt_order_status").disabled = true;
				
				document.getElementById("customer_remark_contain").innerHTML = customer_remark;
				document.getElementById("delivery_name").innerHTML = delivery_name;
				document.getElementById("delivery_contact").innerHTML = delivery_contact;
				document.getElementById("delivery_address").innerHTML = delivery_address;
				document.getElementById("delivery_postcode").innerHTML = delivery_postcode;
				document.getElementById("delivery_area").innerHTML = delivery_area;
				document.getElementById("delivery_state").innerHTML = delivery_state;

				document.getElementById("customer_remark_contain").style.display = "block";
				document.getElementById("delivery_name").style.display = "inline";
				document.getElementById("delivery_contact").style.display = "inline";
				document.getElementById("delivery_address").style.display = "inline";
				document.getElementById("delivery_postcode").style.display = "inline";
				document.getElementById("delivery_area").style.display = "inline";
				document.getElementById("delivery_state").style.display = "inline";

				document.getElementById("customer_remark_textarea").style.display = "none";
				document.getElementById("edit_delivery_name").style.display = "none";
				document.getElementById("edit_delivery_contact").style.display = "none";
				document.getElementById("edit_delivery_address").style.display = "none";
				document.getElementById("edit_delivery_postcode").style.display = "none";
				document.getElementById("edit_delivery_area").style.display = "none";
				document.getElementById("edit_delivery_state").style.display = "none";
				document.getElementById("receipt_order_status").style.border = "2px solid lightgrey";


				document.getElementById("edit_order_details_btn").style.display = "inline";
				document.getElementById("cancel_edit_details_btn").style.display = "none";
				document.getElementById("save_edit_details_btn").style.display = "none";
				document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector('body').style.overflow = "hidden";



				document.getElementById("customer_remark"+current_view_product).innerHTML = customer_remark;
				document.getElementById("order_status"+current_view_product).innerHTML = order_status;

				if(order_status == "Waiting for Shipment"){
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_shipped");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_pending");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_cancelled");					
					document.getElementById("order_status"+current_view_product).classList.add("order_status_waiting");
				}
				else if(order_status == "Pending"){
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_shipped");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_waiting");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_cancelled");
					document.getElementById("order_status"+current_view_product).classList.add("order_status_pending");
				}
				else if(order_status == "Cancelled"){
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_shipped");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_pending");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_waiting");
					document.getElementById("order_status"+current_view_product).classList.add("order_status_cancelled");
				}
				else{
					document.getElementById("order_status"+current_view_product).classList.add("order_status_shipped");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_cancelled");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_waiting");
					document.getElementById("order_status"+current_view_product).classList.remove("order_status_pending");
				}


				setTimeout(function(){
					$('#edit_success_alert_wrap').fadeOut('fast');
				}, 1500);
			},
		});
	}
	else{
		document.getElementById("edit_order_error").innerHTML = "Invalid address format.";
	}
}

function close_order_details(){
	if(edit_activity == 0){
		document.getElementById("order_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

//Order Edit Validation Starts
var valid_name = "";
function order_name_validation(){
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;
  var name = document.getElementById("edit_delivery_name").value;
  var error_message = document.getElementById("edit_order_error");
  var error_border = document.getElementById("edit_delivery_name");

  
  if(name.match(space)){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_name = "false";
  }
  else if(name.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #003cb3";
    valid_name = "true";
  }
  else{
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_name = "false";
  }
}

var valid_phone = "";
function order_phone_validation()
{ 
  var space = /^\s*$/;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;
  var phoneNo = document.getElementById("edit_delivery_contact").value;
  var error_message = document.getElementById("edit_order_error");
  var error_border = document.getElementById("edit_delivery_contact");

  if(phoneNo.match(space)){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_phone = "false";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_phone = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #003cb3";
    valid_phone = "true";
  }
}

var valid_address = "";
function order_address_validation()
{
	var space = /^\s*$/;
	var address = document.getElementById("edit_delivery_address").value;
	var error_message = document.getElementById("edit_order_error");
  	var error_border = document.getElementById("edit_delivery_address"); 

	if(address.match(space))
	{
    	error_message.innerHTML = "Invalid address format.";
    	error_border.style.border = "2px solid red";
    	valid_address = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "2px solid #003cb3";
    	valid_address = "true";
  	}

}

var valid_postcode = "";
function order_postcode_validation()
{
  var pattern = /[0-9]{5}/;
  var space = /^\s*$/;
  var postcode = document.getElementById("edit_delivery_postcode").value;
  var error_message = document.getElementById("edit_order_error");
  var error_border = document.getElementById("edit_delivery_postcode");


  if(postcode.match(space)){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_postcode = "false";
  }
  else if(isNaN(postcode)||postcode.length>5||!postcode.match(pattern)){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_postcode = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #003cb3";
    valid_postcode = "true";
  }
}

var valid_area = "";
function order_area_validation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;
  var area = document.getElementById("edit_delivery_area").value;
  var error_message = document.getElementById("edit_order_error");
  var error_border = document.getElementById("edit_delivery_area");

  
  if(area.match(space)){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_area = "false";
  }
  else if(area.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #003cb3";
    valid_area = "true";
  }
  else{
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_area = "false";
  }
}

var valid_state = "";
function order_state_validation()
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;
  var state = document.getElementById("edit_delivery_state").value;
  var error_message = document.getElementById("edit_order_error");
  var error_border = document.getElementById("edit_delivery_state");

  
  if(state.match(space)){
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_state = "false";
  }
  else if(state.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "2px solid #003cb3";
    valid_state = "true";
  }
  else{
    error_message.innerHTML = "Invalid address format.";
    error_border.style.border = "2px solid red";
    valid_state = "false";
  }
}


function close_card_details(){
	if(edit_activity == 0){
		document.getElementById("custom_card_details").style.display = "none";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

function custom_card_details(card_id){
	if(edit_activity == 0){
		var operation = "get_custom_details";

		$.ajax({
			url: "function/order.php",
			type: "POST",
			dataType: "json",
			data: {
				'operation': operation,
				'card_id': card_id
			},
			success: function(data){
				document.getElementById("card_id").value = card_id;
				document.getElementById("card_image").src = "image/customization/"+data[0].card_image;
				document.getElementById("card_name").innerHTML = data[0].card_name;
				document.getElementById("edit_card_type").value = data[0].card_type;
				document.getElementById("card_message_display").innerHTML = data[0].card_message;

				document.getElementById("toggle_download_card_img").href = "function/download_card_img.php?card_id="+card_id;


				document.getElementById("custom_card_details").style.display = "block";
				document.querySelector(".card_details_wrap").scrollTop = 0;
			},
		});
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

var current_card_message = "";
var current_card_type = "";
var edit_activity = "";
function edit_card(){
	edit_activity = 1;
	var card_message = document.getElementById("card_message_display").innerHTML;
	current_card_message = card_message;
	var card_type = document.getElementById("edit_card_type").value;
	current_card_type = card_type;

	document.getElementById("card_message_display").style.display = "none";
	document.getElementById("edit_card_message").value = card_message;
	
	document.getElementById("edit_card_message").style.display = "inline";

	document.getElementById("edit_card_details_btn").style.display = "none";
	document.getElementById("cancel_edit_card_details_btn").style.display = "inline";
	document.getElementById("save_card_details_btn").style.display = "inline";
}


function cancel_edit_card(){
	edit_activity = 0;

	document.getElementById("card_message_display").innerHTML = current_card_message;
	document.getElementById("edit_card_type").value = current_card_type;

	document.getElementById("card_message_display").style.display = "flex";
	document.getElementById("edit_card_type").disabled = true;
	document.getElementById("edit_card_message").style.display = "none";
	document.getElementById("card_message_error").style.display = "none";
	document.getElementById("edit_card_message").style.border = "2px solid #D3D3D3";

	document.getElementById("edit_card_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_card_details_btn").style.display = "none";
	document.getElementById("save_card_details_btn").style.display = "none";
}


function save_edit_card(){
	card_message_validation();

	if(card_message_valid == "true"){
		edit_activity = 0;
		var operation = "save_edit_card";
		var card_id = document.getElementById("card_id").value;
		var card_type = document.getElementById("edit_card_type").value;
		var card_message = document.getElementById("edit_card_message").value;

		document.getElementById("edit_card_type").value = card_type;
		document.getElementById("card_message_display").innerHTML = card_message;

		$.ajax({
			url: "function/order.php",
			type: "POST",
			data: {
				'operation': operation,
				'card_id': card_id,
				'card_type': card_type,
				'card_message': card_message
			},
		});

		document.getElementById("edit_card_type").disabled = true;
		document.getElementById("card_message_display").style.display = "block";
		document.getElementById("edit_card_message").style.display = "none";

		document.getElementById("edit_success_alert_wrap").style.display = "block";
		setTimeout(function(){
			$('#edit_success_alert_wrap').fadeOut('fast');
		}, 1500);

		document.getElementById("edit_card_details_btn").style.display = "inline";
		document.getElementById("cancel_edit_card_details_btn").style.display = "none";
		document.getElementById("save_card_details_btn").style.display = "none";
	}
}


var card_message_valid = "";
function card_message_validation(){
	var space = /^\s*$/;
	var card_message = document.getElementById("edit_card_message").value;

	if(card_message.match(space)){
		card_message_valid = "false";
		document.getElementById("card_message_error").style.display = "block";
		document.getElementById("edit_card_message").style.border = "2px solid red";
	}
	else{
		card_message_valid = "true";
	    document.getElementById("card_message_error").style.display = "none";
		document.getElementById("edit_card_message").style.border = "2px solid #D3D3D3";
  	}
}


function download_card_img(){
	var card_id = document.getElementById("card_id").value;
}

function filter_table(){
    var input = document.getElementById("search_order");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("order_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++){
        if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
            tr[i].style.display = "";
            found_result++;

            if(found_result % 2 == 0){
            	tr[i].style.background = "none";
            }
            else{
            	tr[i].style.background = "#f2f2f2";
            }
        }
        else{
        	
            tr[i].style.display = "none";
        }
    }
}


 
