function close_voucher_details(){
	if(edit_activity == 0){
		document.getElementById("voucher_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}


var current_i = "";
var current_voucher_id = "";
function show_voucher_details(voucher_id, i){
	var operation = "get_voucher_details";
	current_i = i;
	current_voucher_id = voucher_id;

	$.ajax({
		url: "function/voucher.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'voucher_id': voucher_id
		},
		success: function(data){
			document.getElementById("voucher_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			var min_spend = parseFloat(data[0].min_spend);
			var discount_amount = parseFloat(data[0].discount_amount);

			document.getElementById("voucher_code_div").innerHTML = data[0].voucher_code;
			document.getElementById("voucher_type").innerHTML = data[0].voucher_type;
			document.getElementById("min_spend").innerHTML = min_spend.toFixed(2);
			document.getElementById("discount_amount").innerHTML = discount_amount.toFixed(2);
			document.getElementById("voucher_description").innerHTML = data[0].description;
			document.getElementById("voucher_start_date").innerHTML = data[0].start_date_1;
			document.getElementById("edit_voucher_start_date").value = data[0].start_date;
			document.getElementById("voucher_end_date").innerHTML = data[0].end_date_1;
			document.getElementById("edit_voucher_end_date").value = data[0].end_date;
			document.getElementById("voucher_quantity").innerHTML = data[0].quantity;
			document.getElementById("voucher_status").innerHTML = data[0].status;

			if(data[0].status == "Expired"){
				document.getElementById("edit_voucher_status").disabled = true;
			}

			document.getElementById("voucher_details_wrap_2").scrollTop = 0;
		}
	});
}

var edit_activity = "";
function edit_voucher(){
	edit_activity = 1;
	
	document.getElementById("edit_voucher_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	var current_voucher_code = document.getElementById("voucher_code_div").innerHTML;
	var current_voucher_type = document.getElementById("voucher_type").innerHTML;
	var current_min_spend = document.getElementById("min_spend").innerHTML;
	var current_discount_amount = document.getElementById("discount_amount").innerHTML;
	var current_voucher_description = document.getElementById("voucher_description").innerHTML;

	var current_voucher_quantity = document.getElementById("voucher_quantity").innerHTML;
	var current_voucher_status = document.getElementById("voucher_status").innerHTML;

	document.getElementById("edit_voucher_code").style.display = "inline";
	document.getElementById("edit_voucher_type").style.display = "inline";
	document.getElementById("edit_voucher_min_spend").style.display = "inline";
	document.getElementById("edit_discount_amount").style.display = "inline";
	document.getElementById("edit_voucher_description").style.display = "inline";
	document.getElementById("edit_voucher_start_date").style.display = "inline";
	document.getElementById("edit_voucher_end_date").style.display = "inline";
	document.getElementById("edit_voucher_quantity").style.display = "inline";
	document.getElementById("edit_voucher_status").style.display = "inline";

	document.getElementById("edit_voucher_code").value = current_voucher_code;
	document.getElementById("edit_voucher_type").value = current_voucher_type;
	document.getElementById("edit_voucher_min_spend").value = current_min_spend;
	document.getElementById("edit_discount_amount").value = current_discount_amount;
	if(current_voucher_type == "Free Shipping"){
		document.getElementById("edit_discount_amount").disabled = true;
	}
	document.getElementById("edit_voucher_description").value = current_voucher_description;
	document.getElementById("edit_voucher_quantity").value = current_voucher_quantity;
	document.getElementById("edit_voucher_status").value = current_voucher_status;

	document.getElementById("voucher_code_div").style.display = "none";
	document.getElementById("voucher_type").style.display = "none";
	document.getElementById("min_spend").style.display = "none";
	document.getElementById("discount_amount").style.display = "none";
	document.getElementById("voucher_description").style.display = "none";
	document.getElementById("voucher_start_date").style.display = "none";
	document.getElementById("voucher_end_date").style.display = "none";
	document.getElementById("voucher_quantity").style.display = "none";
	document.getElementById("voucher_status").style.display = "none";
}

//EDIT and ADD voucher validation STARTS
var valid_code = "false";
function voucher_code_validation(select){
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

    if(select == "add"){
    	var voucher_code = document.getElementById("insert_voucher_code").value;
    	var error_message = document.getElementById("insert_voucher_code_error");
    	var error_border = document.getElementById("insert_voucher_code");
  	}
  	else if(select == "edit"){
  		voucher_code = document.getElementById("edit_voucher_code").value;
    	error_message = document.getElementById("edit_voucher_code_error");
    	error_border = document.getElementById("edit_voucher_code");
  	}

	if(voucher_code.match(space)){
	    error_message.innerHTML = "Voucher Code is required.";
	    error_border.style.border = "2px solid red";
	    valid_code = "false";
	}
	else{
	    error_message.innerHTML = "";
	    error_border.style.border = "1px solid #666666";
	    valid_code = "true";
	}
}

var valid_voucher_type = "false";
function voucher_type_validation(){
	var voucher_type = document.getElementById("insert_voucher_type").value;
	var error_message = document.getElementById("insert_voucher_type_error");
  	var error_border = document.getElementById("insert_voucher_type"); 

	if(voucher_type == "0")
	{
    	error_message.innerHTML = "Voucher Type is required.";
    	error_border.style.border = "2px solid red";
    	valid_voucher_type = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_voucher_type = "true";
  	}
}

function voucher_type(select){
	if(select == "add"){
		var voucher_type = document.getElementById("insert_voucher_type").value;
		var discount_amount = document.getElementById("insert_discount_amount");
		var error_message = document.getElementById("insert_discount_amount_error");
	}
	else if(select == "edit"){
		var voucher_type = document.getElementById("edit_voucher_type").value;
		var discount_amount = document.getElementById("edit_discount_amount");
		var error_message = document.getElementById("edit_discount_amount_error");
	}

	if(voucher_type == "Free Shipping"){
  		discount_amount.value = "10.00";
  		discount_amount.disabled = true;
  		error_message.innerHTML = "";
  		discount_amount.style.border = "1px solid #666666";
  		valid_discount_amount = "true";
  	}
  	else{
  		discount_amount.value = "";
  		discount_amount.disabled = false;
  	}
}

var valid_min_spend = "false";
function min_spend_validation(select)
{
	var space = /^\s*$/;


    if(select == "add"){
    	var min_spend = document.getElementById("insert_min_spend").value;
    	var error_message = document.getElementById("insert_min_spend_error");
    	var error_border = document.getElementById("insert_min_spend");
  	}
  	else if(select == "edit"){
  		min_spend = document.getElementById("edit_voucher_min_spend").value;
    	error_message = document.getElementById("edit_min_spend_error");
    	error_border = document.getElementById("edit_voucher_min_spend");
  	}

	if(min_spend.match(space)){
	    error_message.innerHTML = "Minimum Spend is required.";
	    error_border.style.border = "2px solid red";
	    valid_min_spend = "false";
	}
	else if(min_spend < 1){
	    error_message.innerHTML = "Minimum Spend cannot be less than RM 1";
	    error_border.style.border = "2px solid red";
	    valid_min_spend = "false";		
	}
	else if(min_spend > 99999.99){
	    error_message.innerHTML = "Maximum value is RM99,999.99";
	    error_border.style.border = "2px solid red";
	    valid_min_spend = "false";		
	}	
	else{
	    error_message.innerHTML = "";
	    error_border.style.border = "1px solid #666666";
	    valid_min_spend = "true";
	}

}

var valid_discount_amount = "false";
function discount_amount_validation(select)
{
	var space = /^\s*$/;

	if(select == "add"){
	  	var discount_amount = document.getElementById("insert_discount_amount").value;
	    var error_message = document.getElementById("insert_discount_amount_error");
	    var error_border = document.getElementById("insert_discount_amount");
	}
	else if(select == "edit"){
	  	discount_amount = document.getElementById("edit_discount_amount").value;
	    error_message = document.getElementById("edit_discount_amount_error");
	    error_border = document.getElementById("edit_discount_amount");
	}
	  
	if(discount_amount.match(space)){
	    error_message.innerHTML = "Discount Amount is required.";
	    error_border.style.border = "2px solid red";
	    valid_discount_amount = "false";
	}
	else if(discount_amount < 1){
	    error_message.innerHTML = "Discount Amount cannot be less than RM 1";
	    error_border.style.border = "2px solid red";
	    valid_discount_amount = "false";		
	}
	else if(discount_amount > 99999.99){
	    error_message.innerHTML = "Maximum value is RM99,999.99";
	    error_border.style.border = "2px solid red";
	    valid_discount_amount = "false";		
	}	
	else{
		error_message.innerHTML = "";
	    error_border.style.border = "1px solid #666666";
	    valid_discount_amount = "true";
	    
	}
}

var valid_voucher_description = "false";
function voucher_description_validation(select)
{
	var space = /^\s*$/;

	if(select == "add"){
    	var voucher_description = document.getElementById("insert_voucher_description").value;
    	var error_message = document.getElementById("insert_voucher_description_error");
    	var error_border = document.getElementById("insert_voucher_description"); 
  	}
  	else if(select == "edit"){
  		voucher_description = document.getElementById("edit_voucher_description").value;
    	error_message = document.getElementById("edit_voucher_description_error");
    	error_border = document.getElementById("edit_voucher_description"); 
  	}
    	

    if(voucher_description.match(space)){
    	error_message.innerHTML = "Description is required.";
    	error_border.style.border = "2px solid red";
    	valid_voucher_description = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_voucher_description = "true";
  	}
}

var valid_edit_start_date = "false";
function voucher_edit_start_date_validation()
{
	var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0'); 
	
	var maxyear = today.getFullYear() + 1;
	var max  = maxyear + '-' + mm + '-' + dd;
	//max date to set, one year apart from today's date

	var empty_start_date = document.getElementById("edit_voucher_start_date").value;
	var start_date = new Date($('#edit_voucher_start_date').val());
	var dd = String(start_date.getDate()).padStart(2, '0');
	var mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
	var start_date_yyyy = start_date.getFullYear();
	start_date = start_date_yyyy + '-' + mm + '-' + dd;

	var error = document.getElementById("edit_voucher_start_date_error");
	var error_border = document.getElementById("edit_voucher_start_date");

	var end_date = new Date($('#edit_voucher_end_date').val());
	dd = String(end_date.getDate()).padStart(2, '0');
	mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
	yyyy = end_date.getFullYear();
	end_date = yyyy + '-' + mm + '-' + dd;

	if(empty_start_date == ""){
	  error.innerHTML = "Start Date is required";
	  error_border.style.border = "2px solid red";
	  valid_edit_start_date = "false";
	}
	else if(start_date_yyyy > 9999){
	error.innerHTML = "Year must be 4 digit";
	error_border.style.border = "2px solid red";
	valid_edit_start_date = "false";
	}
	else if(start_date > end_date){
	error.innerHTML = "Start date cannot be after End date";
	error_border.style.border = "2px solid red";
	valid_edit_start_date = "false";
	}
	else if(start_date > max){
	error.innerHTML = "Start date cannot be more than one year from today";
	error_border.style.border = "2px solid red";
	valid_edit_start_date = "false";		
	}
	else{
	error.innerHTML = "";
	error_border.style.border = "1px solid #666666";
	valid_edit_start_date = "true";
	} 

	document.getElementById("edit_voucher_end_date").min = start_date;
}

function edit_check_end_date(){
	var selected_end_date = document.getElementById("edit_voucher_end_date").value;

	if(selected_end_date != ""){
		voucher_edit_end_date_validation();
	}
}

var valid_edit_end_date = "false";
function voucher_edit_end_date_validation()
{
	var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0'); 
	
	var maxyear = today.getFullYear() + 1;
	var max  = maxyear + '-' + mm + '-' + dd;
	//max date to set, one year apart from today's date

	var empty_end_date =  document.getElementById("edit_voucher_end_date").value;
	var end_date = new Date($('#edit_voucher_end_date').val());
	var dd = String(end_date.getDate()).padStart(2, '0');
	var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
	var end_date_yyyy = end_date.getFullYear();
	end_date = end_date_yyyy + '-' + mm + '-' + dd;

	var error = document.getElementById("edit_voucher_end_date_error");
	var error_border = document.getElementById("edit_voucher_end_date");

	var start_date = new Date($('#edit_voucher_start_date').val());
	dd = String(start_date.getDate()).padStart(2, '0');
	mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
	yyyy = start_date.getFullYear();
	start_date = yyyy + '-' + mm + '-' + dd;
		//the format of start date is now YYYY/MM/DD

	if(empty_end_date == ""){
    error.innerHTML = "Start Date is required";
    error_border.style.border = "2px solid red";
    valid_edit_end_date = "false";
	}
	else if(end_date_yyyy > 9999){
	error.innerHTML = "Year must be 4 digit";
	error_border.style.border = "2px solid red";
	valid_edit_end_date = "false";
	}
	else if(end_date < start_date){
	error.innerHTML = "End date cannot be before Start date";
	error_border.style.border = "2px solid red";
	valid_edit_end_date = "false";
	}
	else if(end_date > max){
	error.innerHTML = "End date cannot be more than one year from today";
	error_border.style.border = "2px solid red";
	valid_edit_end_date = "false";		
	}
	else{
	error.innerHTML = "";
	error_border.style.border = "1px solid #666666";
	valid_edit_end_date = "true";
	} 

	document.getElementById("edit_voucher_start_date").max = end_date;
}

function edit_check_start_date(){
	var selected_start_date = document.getElementById("edit_voucher_start_date").value;

	if(selected_start_date != ""){
		voucher_edit_start_date_validation()
	}
}

var valid_insert_start_date = "false";
function voucher_insert_start_date_validation()
{
	var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0'); 
	var yyyy = today.getFullYear();
	var maxyear = today.getFullYear() + 1;

	today = yyyy + '-' + mm + '-' + dd;
	//the format of today date is now YYYY/MM/DD

	var max  = maxyear + '-' + mm + '-' + dd;
	//max date to set, one year apart from today's date

	var empty_start_date = document.getElementById("insert_voucher_start_date").value
	var start_date = new Date($('#insert_voucher_start_date').val());
	var dd = String(start_date.getDate()).padStart(2, '0');
	var mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
	var start_date_yyyy = start_date.getFullYear();
	start_date = start_date_yyyy + '-' + mm + '-' + dd;

	var error = document.getElementById("insert_voucher_start_date_error");
	var error_border = document.getElementById("insert_voucher_start_date");

	var end_date = new Date($('#insert_voucher_end_date').val());
	var dd = String(end_date.getDate()).padStart(2, '0');
	var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
	var yyyy = end_date.getFullYear();
	end_date = yyyy + '-' + mm + '-' + dd;
	
	if(empty_start_date == ""){
	error.innerHTML = "Start date is required";
	error_border.style.border = "2px solid red";
	valid_insert_start_date = "false";
	}
	else if(start_date_yyyy > 9999){
	error.innerHTML = "Year must be 4 digit";
	error_border.style.border = "2px solid red";
	valid_insert_start_date = "false";
	}
	else if(start_date < today){
	error.innerHTML = "Date is over";
	error_border.style.border = "2px solid red";
	valid_insert_start_date = "false";
	}
	else if(start_date > end_date){
	error.innerHTML = "Start date cannot be after End date";
	error_border.style.border = "2px solid red";
	valid_insert_start_date = "false";
	}
	else if(start_date > max){
	error.innerHTML = "Start date cannot be more than one year from today";
	error_border.style.border = "2px solid red";
	valid_insert_start_date = "false";		
	}
	else{
	error.innerHTML = "";
	error_border.style.border = "1px solid #666666";
	valid_insert_start_date = "true";
	}


  	document.getElementById("insert_voucher_end_date").min = start_date;
  	document.getElementById("insert_voucher_start_date").min = today;
}


function insert_check_end_date(){
	var selected_insert_end_date = document.getElementById("insert_voucher_end_date").value;

	if(selected_insert_end_date != ""){
		voucher_insert_end_date_validation();
	}
}

  
var valid_insert_end_date = "false";
function voucher_insert_end_date_validation()
{

	var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0'); 
	var yyyy = today.getFullYear();

	var maxyear = today.getFullYear() + 1;
	var max  = maxyear + '-' + mm + '-' + dd;
	//max date to set, one year apart from today's date

	today = yyyy + '-' + mm + '-' + dd;
	//to convert format YYYY/MM/DD
	
	var empty_end_date =  document.getElementById("insert_voucher_end_date").value;
	var end_date = new Date($('#insert_voucher_end_date').val());
	var dd = String(end_date.getDate()).padStart(2, '0');
	var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
	var end_date_yyyy = end_date.getFullYear();
	end_date = end_date_yyyy + '-' + mm + '-' + dd;
	
	var error = document.getElementById("insert_voucher_end_date_error");
	var error_border = document.getElementById("insert_voucher_end_date");

	var start_date = new Date($('#insert_voucher_start_date').val());
	dd = String(start_date.getDate()).padStart(2, '0');
	mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
	yyyy = start_date.getFullYear();
	start_date = yyyy + '-' + mm + '-' + dd;


	if(empty_end_date == ""){
	error.innerHTML = "End Date is required";
	error_border.style.border = "2px solid red";
	valid_insert_end_date = "false";
	}
	else if(end_date_yyyy > 9999){
	error.innerHTML = "Year must be 4 digit";
	error_border.style.border = "2px solid red";
	valid_insert_end_date = "false";
	}
	else if(end_date < today){
	error.innerHTML = "Date is over";
	error_border.style.border = "2px solid red";
	valid_insert_end_date = "false";

	}
	else if(end_date < start_date){
	error.innerHTML = "End date cannot be before Start date";
	error_border.style.border = "2px solid red";
	valid_insert_end_date = "false";
	}
	else if(end_date > max){
	error.innerHTML = "End date cannot be more than one year from today";
	error_border.style.border = "2px solid red";
	valid_insert_end_date = "false";		
	}
	else{
	error.innerHTML = "";
	error_border.style.border = "1px solid #666666";
	valid_insert_end_date = "true";
	}

    document.getElementById("insert_voucher_start_date").max = end_date;
	document.getElementById("insert_voucher_end_date").min = today; 
}

function insert_check_start_date(){
	var selected_insert_start_date = document.getElementById("insert_voucher_start_date").value;

	if(selected_insert_start_date != ""){
		voucher_insert_start_date_validation();
	}
}

var valid_voucher_quantity = "false";
function voucher_quantity_validation(select)
{
	var space = /^\s*$/;

	if(select == "add"){
    	var voucher_quantity =  document.getElementById("insert_voucher_quantity").value;
    	var error_message = document.getElementById("insert_voucher_quantity_error");
    	var error_border = document.getElementById("insert_voucher_quantity");
  	}
  	else if(select == "edit"){
  		voucher_quantity =  document.getElementById("edit_voucher_quantity").value;
    	error_message = document.getElementById("edit_voucher_quantity_error");
    	error_border = document.getElementById("edit_voucher_quantity");
  	}

 	if(voucher_quantity.match(space)){
    	error_message.innerHTML = "Quantity is required.";
    	error_border.style.border = "2px solid red";
    	valid_voucher_quantity = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_voucher_quantity = "true";
  	}
	
}


var valid_voucher_status = "false";
function voucher_status_validation(select)
{
  if(select == "add"){
  	var voucher_status = document.getElementById("insert_voucher_status").value;
  	var error_message = document.getElementById("insert_voucher_status_error");
  	var error_border = document.getElementById("insert_voucher_status");
  }
  else{
  	var voucher_status = document.getElementById("edit_voucher_status").value;
	var error_message = document.getElementById("edit_voucher_status_error");
	var error_border = document.getElementById("edit_voucher_status");
  }

  
  if(voucher_status == "0"){
    error_message.innerHTML = "Status is required.";
    error_border.style.border = "2px solid red";
    valid_voucher_status = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_voucher_status = "true";
  }
}


//EDIT AND ADD PRODUCT VALIDATION ENDS

function cancel_edit_voucher(){
	edit_activity = 0;
	document.getElementById("edit_voucher_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	var voucher_code = document.getElementById("edit_voucher_code").innerHTML;

	document.getElementById("edit_voucher_code").style.display = "none";
	document.getElementById("edit_voucher_type").style.display = "none";
	document.getElementById("edit_voucher_min_spend").style.display = "none";
	document.getElementById("edit_discount_amount").style.display = "none";
	document.getElementById("edit_voucher_description").style.display = "none";
	document.getElementById("edit_voucher_start_date").style.display = "none";
	document.getElementById("edit_voucher_end_date").style.display = "none";
	document.getElementById("edit_voucher_quantity").style.display = "none";
	document.getElementById("edit_voucher_status").style.display = "none";

	document.getElementById("voucher_code_div").style.display = "inline";
	document.getElementById("voucher_type").style.display = "inline";
	document.getElementById("min_spend").style.display = "inline";
	document.getElementById("discount_amount").style.display = "inline";
	document.getElementById("voucher_description").style.display = "inline";
	document.getElementById("voucher_start_date").style.display = "inline";
	document.getElementById("voucher_end_date").style.display = "inline";
	document.getElementById("voucher_quantity").style.display = "inline";
	document.getElementById("voucher_status").style.display = "inline";

	document.getElementById("edit_voucher_code_error").innerHTML = "";
	document.getElementById("edit_voucher_code").style.border = "1px solid #666666";
	document.getElementById("edit_min_spend_error").innerHTML = "";
	document.getElementById("edit_voucher_min_spend").style.border = "1px solid #666666";
	document.getElementById("edit_discount_amount_error").innerHTML = "";
	document.getElementById("edit_discount_amount").style.border = "1px solid #666666";
	document.getElementById("edit_voucher_description_error").innerHTML = "";
	document.getElementById("edit_voucher_description").style.border = "1px solid #666666"
	document.getElementById("edit_voucher_start_date_error").innerHTML = "";
	document.getElementById("edit_voucher_start_date").style.border = "1px solid #666666"
	document.getElementById("edit_voucher_end_date_error").innerHTML = "";
	document.getElementById("edit_voucher_end_date").style.border = "1px solid #666666";
	document.getElementById("edit_voucher_quantity_error").innerHTML = "";
	document.getElementById("edit_voucher_quantity").style.border = "1px solid #666666";
	document.getElementById("edit_voucher_status_error").innerHTML = "";
	document.getElementById("edit_voucher_status").style.border = "1px solid #666666";

	

	show_voucher_details(current_voucher_id, current_i);
}


function edit_date_check_status(){
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var yyyy = today.getFullYear();

  today = yyyy + '-' + mm + '-' + dd;


  var end_date =  new Date(document.getElementById("edit_voucher_end_date").value);
  var dd = String(end_date.getDate()).padStart(2, '0');
  var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
  var yyyy = end_date.getFullYear();
  end_date = yyyy + '-' + mm + '-' + dd;

  if(end_date < today){
    document.getElementById("edit_voucher_status").value = "Expired";
    document.getElementById("edit_voucher_status").disabled = true;  
  }
  else{
    document.getElementById("edit_voucher_status").value = "0";
    document.getElementById("edit_voucher_status").disabled = false;
  }


}



function save_edit_voucher(){
	var operation = "edit_voucher";
	voucher_code_validation("edit");
	min_spend_validation("edit");
	discount_amount_validation("edit");
	voucher_description_validation("edit");
	voucher_quantity_validation("edit");
	voucher_edit_start_date_validation();
	voucher_edit_end_date_validation();
	voucher_status_validation("edit");

	if(valid_code == "true" && valid_min_spend == "true" && valid_discount_amount == "true" && valid_voucher_description == "true" && valid_voucher_quantity == "true" && valid_edit_start_date == "true" && valid_edit_end_date == "true" && valid_voucher_status == "true"){
				
		var voucher_code  = document.getElementById("edit_voucher_code").value;
		var type   = document.getElementById("edit_voucher_type").value;
		var min_spend  = document.getElementById("edit_voucher_min_spend").value;
		var discount_amount  = document.getElementById("edit_discount_amount").value;
		var description  = document.getElementById("edit_voucher_description").value;
		var start_date  = document.getElementById("edit_voucher_start_date").value;
		var end_date  = document.getElementById("edit_voucher_end_date").value;
		var quantity  = document.getElementById("edit_voucher_quantity").value;
		var status  = document.getElementById("edit_voucher_status").value;


		var new_start_date = start_date;
        new_start_date = new_start_date.split("-").reverse().join("-");

        var new_end_date = end_date;
        new_end_date = new_end_date.split("-").reverse().join("-");


		document.getElementById("voucher_code"+current_i).innerHTML = voucher_code;
		document.getElementById("voucher_type"+current_i).innerHTML = type;
		document.getElementById("voucher_start_date"+current_i).innerHTML = new_start_date;
		document.getElementById("voucher_end_date"+current_i).innerHTML = new_end_date;
		document.getElementById("voucher_qty"+current_i).innerHTML = quantity;
		document.getElementById("voucher_status"+current_i).innerHTML = status;


		$.ajax({
			url: "function/voucher.php",
			type: "POST",
			data: {
				'operation': operation,
				'current_voucher_id': current_voucher_id,
				'voucher_code': voucher_code,
				'type': type,
				'min_spend': min_spend,
				'discount_amount': discount_amount,
				'description': description,
				'start_date': start_date,
				'end_date': end_date,
				'quantity': quantity,
				'status': status
			},
		    success: function(data){
				document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					cancel_edit_voucher();
				}, 1500);

				if(status == "Disable") {
					document.getElementById("voucher_status"+current_i).classList.add("status_disable");
					document.getElementById("voucher_status"+current_i).classList.remove("status_expired");
					document.getElementById("voucher_status"+current_i).classList.remove("status_enable");
					document.getElementById("voucher_status"+current_i).classList.remove("status_waiting");
				}
				else if(status == "Enable")
				{
					var start_date = new Date($('#edit_voucher_start_date').val());
		          	dd = String(start_date.getDate()).padStart(2, '0');
		          	mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
		          	yyyy = start_date.getFullYear();
		          	start_date = yyyy + '-' + mm + '-' + dd;

		         	var today = new Date();
		          	var dd = String(today.getDate()).padStart(2, '0');
		         	var mm = String(today.getMonth() + 1).padStart(2, '0'); 
		          	var yyyy = today.getFullYear();
		          	today = yyyy + '-' + mm + '-' + dd; 


					if(start_date > today){
						document.getElementById("voucher_status"+current_i).innerHTML = "Waiting";
						document.getElementById("voucher_status"+current_i).classList.add("status_waiting");
						document.getElementById("voucher_status"+current_i).classList.remove("status_expired");
						document.getElementById("voucher_status"+current_i).classList.remove("status_disable");
						document.getElementById("voucher_status"+current_i).classList.remove("status_enable"); 
			        }
			        else{
			        	document.getElementById("voucher_status"+current_i).classList.add("status_enable");
						document.getElementById("voucher_status"+current_i).classList.remove("status_expired");
						document.getElementById("voucher_status"+current_i).classList.remove("status_disable");
						document.getElementById("voucher_status"+current_i).classList.remove("status_waiting"); 
			        }
				}
				else if(status == "Expired")
				{
					document.getElementById("voucher_status"+current_i).classList.add("status_expired");
					document.getElementById("voucher_status"+current_i).classList.remove("status_enable");
					document.getElementById("voucher_status"+current_i).classList.remove("status_disable");
					document.getElementById("voucher_status"+current_i).classList.remove("status_waiting");
				}
				
		    }
		});
	}
}

function close_insert_voucher(){
	document.getElementById("add_new_voucher_wrap").style.display = "none";
	document.querySelector("body").style.overflow = "auto";

	document.getElementById("insert_voucher_code_error").innerHTML = "";
	document.getElementById("insert_voucher_code").value = "";
	document.getElementById("insert_voucher_code").style.border = "1px solid #666666";
	document.getElementById("insert_voucher_type_error").innerHTML = "";
	document.getElementById("insert_voucher_type").value = "0";
  	document.getElementById("insert_voucher_type").style.border = "1px solid #666666";
    document.getElementById("insert_min_spend_error").innerHTML = "";
    document.getElementById("insert_min_spend").value = "";
    document.getElementById("insert_min_spend").style.border = "1px solid #666666";
	document.getElementById("insert_discount_amount_error").innerHTML = "";
	document.getElementById("insert_discount_amount").value = "";
	document.getElementById("insert_discount_amount").style.border = "1px solid #666666";
	document.getElementById("insert_voucher_description_error").innerHTML = "";
	document.getElementById("insert_voucher_description").value = "";
	document.getElementById("insert_voucher_description").style.border = "1px solid #666666";
	document.getElementById("insert_voucher_start_date_error").innerHTML = "";
	document.getElementById("insert_voucher_start_date").value = "";
	document.getElementById("insert_voucher_start_date").style.border = "1px solid #666666";
	document.getElementById("insert_voucher_end_date_error").innerHTML = "";
	document.getElementById("insert_voucher_end_date").value = "";
  	document.getElementById("insert_voucher_end_date").style.border = "1px solid #666666";
	document.getElementById("insert_voucher_quantity_error").innerHTML = "";
	document.getElementById("insert_voucher_quantity").value = "";
  	document.getElementById("insert_voucher_quantity").style.border = "1px solid #666666";
  	document.getElementById("insert_voucher_status_error").innerHTML = "";
  	document.getElementById("insert_voucher_status").value = "0";
  	document.getElementById("insert_voucher_status").style.border = "1px solid #666666";
}

function add_voucher_popup(){
	document.getElementById("add_new_voucher_wrap").style.display = "block";
	document.querySelector("body").style.overflow = "hidden";

	//show insert product error message div
	document.getElementById("insert_voucher_code_error").style.display = "block";
	document.getElementById("insert_voucher_type_error").style.display = "block";
	document.getElementById("insert_min_spend_error").style.display = "block";
	document.getElementById("insert_discount_amount_error").style.display = "block";
	document.getElementById("insert_voucher_description_error").style.display = "block";
	document.getElementById("insert_voucher_start_date_error").style.display = "block";
	document.getElementById("insert_voucher_end_date_error").style.display = "block";
	document.getElementById("insert_voucher_quantity_error").style.display = "block";

	document.getElementById("add_new_voucher_details_box").scrollTop = 0;

}


function add_voucher(){
	var operation = "add_voucher";

	voucher_code_validation("add");
	voucher_type_validation();
	min_spend_validation("add");
	discount_amount_validation("add");
	voucher_description_validation("add");
	voucher_insert_start_date_validation();
	voucher_insert_end_date_validation();
	voucher_quantity_validation("add");
	voucher_status_validation("add");

	if(valid_code  == "true" && valid_voucher_type  == "true" && valid_min_spend  == "true" && valid_discount_amount  == "true" && valid_voucher_description  == "true" && valid_insert_start_date  == "true" && valid_insert_end_date  == "true" && valid_voucher_quantity  == "true" && valid_voucher_status == "true"){
		var voucher_code  = document.getElementById("insert_voucher_code").value;
		var voucher_type   = document.getElementById("insert_voucher_type").value;
		var min_spend  = document.getElementById("insert_min_spend").value;
		var discount_amount  = document.getElementById("insert_discount_amount").value;
		var description  = document.getElementById("insert_voucher_description").value;
		var start_date  = document.getElementById("insert_voucher_start_date").value;
		var end_date  = document.getElementById("insert_voucher_end_date").value;
		var quantity  = document.getElementById("insert_voucher_quantity").value;
		var status  = document.getElementById("insert_voucher_status").value;

		$.ajax({
			url: "function/voucher.php",
			type: "POST",
			data: {
				'operation': operation,
				'voucher_code': voucher_code,
				'voucher_type': voucher_type,
				'min_spend': min_spend,
				'discount_amount': discount_amount,
				'description': description,
				'start_date': start_date,
				'end_date': end_date,
				'quantity': quantity,
				'status': status

			},
		    success: function(data){
		        document.getElementById("add_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("add_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					window.location = "voucher.php";
				}, 1500);

		    },
		});
	}
}

function filter_table(){
    var input = document.getElementById("search_voucher");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("voucher_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
        var delete_status = document.getElementById("voucher_delete_status"+i).value;
		if(delete_status == 0){
			if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
				tr[i].style.display = "";

				found_result++;
				if(found_result % 2 == 0){
					tr[i].style.background = "none";
				}
				else{
					tr[i].style.background = "#f2f2f2";
				}

				document.getElementById("table_number"+i).innerHTML = found_result;
			}
			else{
				tr[i].style.display = "none";
			}
		}
    }
}

var delete_voucher_id = "";
var delete_counter = "";
function delete_voucher(voucher_id, counter){
	delete_voucher_id = voucher_id;
	delete_counter = counter;
	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}


function delete_voucher_confirm(){
	var operation = "delete_voucher";

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/voucher.php",
		type: "POST",
		data: {
			'operation': operation,
			'voucher_id': delete_voucher_id
		},
		success: function(){
			document.getElementById("voucher_row"+delete_counter).style.display = "none";
			document.getElementById("voucher_delete_status"+delete_counter).value = 1;
			filter_table();
		}
	});
}