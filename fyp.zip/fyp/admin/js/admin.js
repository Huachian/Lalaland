function show_access_password_pop_up()
{
	if(edit_activity == 0){
		document.getElementById("access_pass_wrap").style.display = "block";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

function close_access_password_pop_up()
{
	document.getElementById("access_pass_wrap").style.display = "none";
	document.getElementById("access_password_input").value = "";

	document.getElementById("confirm_btn").style.background = "#000000";
	document.getElementById("confirm_btn").innerHTML = "Confirm";
}

function confirm_access_pass()
{
	var operation = "check_password";

	var admin_id = document.getElementById("admin_id").value;
	var password = document.getElementById("access_password_input").value;

	$.ajax({
		url: "function/update_admin.php",
		type: "POST",
		data: {
			'operation': operation,
			'admin_id': admin_id,
			'password': password
		},
		success: function(data){
			if(data == "valid"){
				get_admin_password_details();

				document.getElementById("access_pass_wrap").style.display = "none";
				document.getElementById("confirm_btn").style.background = "#000000";
				document.getElementById("confirm_btn").innerHTML = "Confirm";
			}
			else if(data == "not_superadmin"){
				document.getElementById("confirm_btn").style.background = "#e6176d";
				document.getElementById("confirm_btn").innerHTML = "No permission to access !";
			}
			else if(data == "not_valid"){
				document.getElementById("confirm_btn").style.background = "#e6176d";
				document.getElementById("confirm_btn").innerHTML = "Invalid Password !";
			}

			document.getElementById("access_password_input").value = "";
		}
	});
}

function update_enter_password_btn(){
	document.getElementById("confirm_btn").style.background = "#000000";
	document.getElementById("confirm_btn").innerHTML = "Confirm";
}

function get_admin_password_details(){
	var operation = "get_admin_password_details";
	
	var position = document.getElementById("position"+current_view_admin).innerHTML;

	$.ajax({
		url: "function/update_admin.php",
		type: "POST",
		data: {
			'operation': operation,
			'current_view_admin_id': current_view_admin_id,
			'position': position
		},
		success: function(data){
			document.getElementById("admin_pass_wrap").style.display = "block";
			document.getElementById("admin_password_input").value = data;

			var toggle = document.getElementById("toggle_admin_password_icon");
			var pass = document.getElementById("admin_password_input");
			pass.setAttribute("type","password");
		    toggle.classList.remove('admin_hide_pass_icon')
		    toggle.classList.add('admin_show_pass_icon');
		}
	});
}

var edit_password_activity = "";
function edit_admin_pass()
{
	edit_password_activity = "true";

	document.getElementById("admin_password_input").disabled = false;
	document.getElementById("edit_admin_password_btn").style.display = "none";
	document.getElementById("cancel_edit_password_btn").style.display = "inline";
	document.getElementById("save_edit_password_btn").style.display = "inline";
}

function cancel_edit_pass()
{
	edit_password_activity = "false";

	document.getElementById("admin_password_input").disabled = true;
	document.getElementById("edit_admin_password_btn").style.display = "inline";
	document.getElementById("cancel_edit_password_btn").style.display = "none";
	document.getElementById("save_edit_password_btn").style.display = "none";

	document.getElementById("new_password_tick_icon").style.display = "none";
	document.getElementById("new_password_cross_icon").style.display = "none";
	document.getElementById("new_password_error_message").innerHTML="";
	document.getElementById("admin_password_input").style.border = "2px solid #f0f0f0";

	get_admin_password_details();
}

var edit_new_password_valid = "";
function new_password_guide(){
	document.getElementById("edit_password_format").style.display = "block";
	var password = document.getElementById("admin_password_input").value;
	document.getElementById("new_password_error_message").innerHTML="";

	if(password.length == 0){
		document.getElementById("edit_password_format").style.display = "none";
		var length_valid = "no";
	}
	else if(password.length >= 15){
		document.getElementById("edit_characters").style.color = "#00e600";
		document.getElementById("edit_characters").style.fontWeight = "bold";
		length_valid = "yes";
	}
	else{
		document.getElementById("edit_characters").style.color = "grey";
		document.getElementById("edit_characters").style.fontWeight = "normal";
		length_valid = "no";
	}

	if(password.match(/[0-9]/)){
		document.getElementById("edit_number").style.color = "#00e600";
		document.getElementById("edit_number").style.fontWeight = "bold";
		var number_valid = "yes";
	}
	else{
		document.getElementById("edit_number").style.color = "grey";
		document.getElementById("edit_number").style.fontWeight = "normal";
		number_valid = "no";
	}

	if(password.match(/[a-z]/)){
		document.getElementById("edit_small_letter").style.color = "#00e600";
		document.getElementById("edit_small_letter").style.fontWeight = "bold";
		var small_letter_valid = "yes";
	}
	else{
		document.getElementById("edit_small_letter").style.color = "grey";
		document.getElementById("edit_small_letter").style.fontWeight = "normal";
		small_letter_valid = "no";
	}

	if(password.match(/[A-Z]/)){
		document.getElementById("edit_upper_letter").style.color = "#00e600";
		document.getElementById("edit_upper_letter").style.fontWeight = "bold";
		var upper_letter_valid = "yes";
	}
	else{
		document.getElementById("edit_upper_letter").style.color = "grey";
		document.getElementById("edit_upper_letter").style.fontWeight = "normal";
		upper_letter_valid = "no";
	}

	if(password.match(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/)){
		document.getElementById("edit_symbol").style.color = "#00e600";
		document.getElementById("edit_symbol").style.fontWeight = "bold";
		var symbol_valid = "yes";
	}
	else{
		document.getElementById("edit_symbol").style.color = "grey";
		document.getElementById("edit_symbol").style.fontWeight = "normal";
		symbol_valid = "no";
	}

	if(length_valid == "yes" && number_valid == "yes" && small_letter_valid == "yes" && upper_letter_valid == "yes" && symbol_valid == "yes"){
		document.getElementById("new_password_tick_icon").style.display = "block";
		document.getElementById("new_password_cross_icon").style.display = "none";
		document.getElementById("new_password_error_message").innerHTML = "";
		edit_new_password_valid = "yes";
	}
	else{
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		edit_new_password_valid = "no";
	}
}

var edit_password_valid = "";
function edit_password_validation(){
	document.getElementById("edit_password_format").style.display = "none";

	var password = document.getElementById("admin_password_input").value;
	var space = /^\s*$/;


	if(password.match(space))
	{
		document.getElementById("new_password_error_message").innerHTML="New password is required.";
		document.getElementById("admin_password_input").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		edit_password_valid = "false";
	}
	else if(password.length < 15 || password.search(/[0-9]/) == -1 || password.search(/[a-z]/) == -1 || password.search(/[A-Z]/) == -1 || password.search(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/) == -1){
		document.getElementById("new_password_error_message").innerHTML="Password format incorrect.";
		document.getElementById("admin_password_input").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		edit_password_valid = "false";
	}
	else
	{
		document.getElementById("new_password_error_message").innerHTML="";
		document.getElementById("admin_password_input").style.border = "2px solid #f0f0f0";
		edit_password_valid = "true";
	}
}

function close_admin_pass()
{
	if(edit_password_activity == "true"){
		document.getElementById("edit_error_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
	else{
		document.getElementById("admin_pass_wrap").style.display = "none";
	}
}

function show_hide_admin_password(){
  var toggle = document.getElementById("toggle_admin_password_icon");
  var pass = document.getElementById("admin_password_input");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('admin_show_pass_icon')
    toggle.classList.add('admin_hide_pass_icon');  
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('admin_hide_pass_icon')
    toggle.classList.add('admin_show_pass_icon');
    
  }
}


function save_edit_pass(){
	var operation = "save_edit_admin_pass";

	edit_password_validation();

	if(edit_password_valid == "true"){
		var new_password = document.getElementById("admin_password_input").value;
		var position = document.getElementById("position"+current_view_admin).innerHTML;

		$.ajax({
			url: "function/update_admin.php",
			type: "POST",
			data: {
				'operation': operation,
				'current_view_admin_id': current_view_admin_id,
				'new_password': new_password,
				'position': position
			},
		});

		document.getElementById("edit_success_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_success_alert_wrap').fadeOut('fast');
			cancel_edit_pass();
		}, 1500);
	}
}


function close_admin_details(){
	if(edit_activity == 0){
		document.getElementById("admin_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

var current_view_admin = "";
var current_view_admin_id = "";
function show_admin_details(admin_id, i){
	var operation = "get_admin_details";
	current_view_admin = i;
	current_view_admin_id = admin_id;
	var position = document.getElementById("position"+i).innerHTML;

	$.ajax({
		url: "function/admin.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'admin_id': admin_id,
			'position': position
		},
		success: function(data){
			document.getElementById("admin_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			if(data[0].profile_picture == "empty"){
				document.getElementById("image_image_blank").style.display = "block";
				document.getElementById("admin_profile_picture_display").style.display = "none";
			}
			else{
				document.getElementById("image_image_blank").style.display = "none";
				document.getElementById("admin_profile_picture_display").style.display = "inline";
			}

			document.getElementById("admin_profile_picture_display").src = "image/admin_profile/"+data[0].profile_picture;
			document.getElementById("admin_details_id").innerHTML = admin_id;
			document.getElementById("position").innerHTML = data[0].position;
			document.getElementById("first_name").innerHTML = data[0].first_name;
			document.getElementById("last_name").innerHTML = data[0].last_name;
			document.getElementById("phone").innerHTML = data[0].phone;
			document.getElementById("email").innerHTML = data[0].email;
			document.getElementById("gender").innerHTML = data[0].gender;

			document.getElementById("edit_admin_email_error").innerHTML = "";
			document.getElementById("edit_admin_email").style.border = "1px solid #666666";

			document.getElementById("admin_details_box").scrollTop = 0;
		}
	});
}

var edit_activity = "";
function edit_admin_details(){
	edit_activity = 1;

	document.getElementById("edit_admin_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	var admin_id = document.getElementById("admin_details_id").innerHTML;
	var position = document.getElementById("position").innerHTML;
	var first_name = document.getElementById("first_name").innerHTML;
	var last_name = document.getElementById("last_name").innerHTML;
	var phone = document.getElementById("phone").innerHTML;
	var email = document.getElementById("email").innerHTML;
	var gender = document.getElementById("gender").innerHTML;

	document.getElementById("admin_details_id").style.display = "none";
	document.getElementById("position").style.display = "none";
	document.getElementById("first_name").style.display = "none";
	document.getElementById("last_name").style.display = "none";
	document.getElementById("phone").style.display = "none";
	document.getElementById("email").style.display = "none";
	document.getElementById("gender").style.display = "none";

	document.getElementById("edit_admin_id").value = admin_id;
	document.getElementById("edit_admin_position").value = position;
	document.getElementById("edit_admin_first_name").value = first_name;
	document.getElementById("edit_admin_last_name").value = last_name;
	document.getElementById("edit_admin_phone").value = phone;
	document.getElementById("edit_admin_email").value = email;
	document.getElementById("edit_admin_gender").value = gender;

	var current_login_admin_id = document.getElementById("admin_id").value;
	if(current_view_admin_id == current_login_admin_id){
		document.getElementById("edit_admin_position").disabled = true;
	}

	document.getElementById("edit_admin_id").disabled = true;

	document.getElementById("upload_edit_admin_image").style.display = "inline";
	document.getElementById("upload_edit_admin_image").disabled = false;
	document.getElementById("image_image_blank").style.cursor = "pointer";
	document.getElementById("edit_admin_id").style.display = "inline";
	document.getElementById("edit_admin_position").style.display = "inline";
	document.getElementById("edit_admin_first_name").style.display = "inline";
	document.getElementById("edit_admin_last_name").style.display = "inline";
	document.getElementById("edit_admin_phone").style.display = "inline";
	document.getElementById("edit_admin_email").style.display = "inline";
	document.getElementById("edit_admin_gender").style.display = "inline";
}

function cancel_edit_admin(){
	edit_activity = 0;
	document.getElementById("upload_edit_admin_image").value = "";
	document.getElementById("edit_admin_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";
	document.getElementById("image_image_blank").style.cursor = "initial";
	var admin_id = document.getElementById("admin_details_id").innerHTML;
	var position = document.getElementById("position"+current_view_admin).innerHTML;
	document.getElementById("upload_edit_admin_image").disabled = true;

	var operation = "get_admin_details";

	$.ajax({
		url: "function/admin.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'admin_id': admin_id,
			'position': position
		},
		success: function(data){
			if(data[0].profile_picture == "empty"){
				document.getElementById("image_image_blank").style.display = "block";
				document.getElementById("admin_profile_picture_display").style.display = "none";
			}
			else{
				document.getElementById("image_image_blank").style.display = "none";
				document.getElementById("admin_profile_picture_display").style.display = "inline";
			}
			document.getElementById("admin_profile_picture_display").src = "image/admin_profile/"+data[0].profile_picture;
			document.getElementById("admin_details_id").innerHTML = admin_id;
			document.getElementById("position").innerHTML = data[0].position;
			document.getElementById("first_name").innerHTML = data[0].first_name;
			document.getElementById("last_name").innerHTML = data[0].last_name;
			document.getElementById("phone").innerHTML = data[0].phone;
			document.getElementById("email").innerHTML = data[0].email;
			document.getElementById("gender").innerHTML = data[0].gender;

			document.getElementById("admin_details_id").style.display = "inline";
			document.getElementById("position").style.display = "inline";
			document.getElementById("first_name").style.display = "inline";
			document.getElementById("last_name").style.display = "inline";
			document.getElementById("phone").style.display = "inline";
			document.getElementById("email").style.display = "inline";
			document.getElementById("gender").style.display = "inline";

			document.getElementById("upload_edit_admin_image").style.display = "none";
			document.getElementById("edit_admin_id").style.display = "none";
			document.getElementById("edit_admin_position").style.display = "none";
			document.getElementById("edit_admin_first_name").style.display = "none";
			document.getElementById("edit_admin_last_name").style.display = "none";
			document.getElementById("edit_admin_phone").style.display = "none";
			document.getElementById("edit_admin_email").style.display = "none";
			document.getElementById("edit_admin_gender").style.display = "none";

			document.getElementById("edit_admin_fname_error").innerHTML = "";
		    document.getElementById("edit_admin_first_name").style.border = "1px solid #666666";
			document.getElementById("edit_admin_lname_error").innerHTML = "";
		    document.getElementById("edit_admin_last_name").style.border = "1px solid #666666";
		    document.getElementById("edit_admin_phone_error").innerHTML = "";
		    document.getElementById("edit_admin_phone").style.border = "1px solid #666666";
			document.getElementById("edit_admin_email_error").innerHTML = "";
			document.getElementById("edit_admin_email").style.border = "1px solid #666666";
		}
	});
}

function close_insert_admin(){
	document.getElementById("add_new_admin_wrap").style.display = "none";
	document.querySelector("body").style.overflow = "auto";

	document.getElementById("insert_admin_fname_error").innerHTML = "";
    document.getElementById("insert_admin_first_name").style.border = "1px solid #666666";
    document.getElementById("insert_admin_first_name").value = "";
    document.getElementById("insert_admin_lname_error").innerHTML = "";
    document.getElementById("insert_admin_last_name").style.border = "1px solid #666666";
    document.getElementById("insert_admin_last_name").value = "";
    document.getElementById("insert_admin_phone_error").innerHTML = "";
    document.getElementById("insert_admin_phone").style.border = "1px solid #666666";
    document.getElementById("insert_admin_phone").value = "";
	document.getElementById("insert_admin_email_error").innerHTML = "";
	document.getElementById("insert_admin_email").style.border = "1px solid #666666";
	document.getElementById("insert_admin_email").value = "";
	document.getElementById("insert_admin_position_error").innerHTML = "";
  	document.getElementById("insert_admin_position").style.border = "1px solid #666666";
  	document.getElementById("insert_admin_position").value = "";
	document.getElementById("insert_admin_gender_error").innerHTML = "";
  	document.getElementById("insert_admin_gender").style.border = "1px solid #666666";
  	document.getElementById("insert_admin_gender").value = "";
	document.getElementById("insert_admin_password_error_message").innerHTML = "";
	document.getElementById("insert_admin_password").style.border = "1px solid #666666";
	document.getElementById("insert_admin_password").value = "";
	document.getElementById("insert_admin_conpass_error").innerHTML = "";
	document.getElementById("insert_admin_confirm_password").style.border = "1px solid #666666";
	document.getElementById("insert_admin_confirm_password").value = "";
	document.getElementById("image_upload").value = "";
	document.getElementById("insert_admin_image_preview").style.display = "none";
	document.getElementById("upload_image_preview_empty").style.display = "block";


}

function add_admin_popup_form(){
	document.getElementById("add_new_admin_wrap").style.display = "block";
	document.querySelector("body").style.overflow = "hidden";
	document.getElementById("add_new_admin_details_box").scrollTop = 0;
}

function get_new_admin_id(){
	var operation = "get_new_admin_id";

	var position = document.getElementById("insert_admin_position").value;

	$.ajax({
		url: "function/admin.php",
		type: "POST",
		data: {
			'operation': operation,
			'position': position
		},
		success: function(data){
			document.getElementById("insert_admin_id").value = data;
		}
	});
}

//EDIT AND INSERT ADMIN VALIDATION STARTS//
var valid_fname = "true";
function fname_validation(select){
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var fname = document.getElementById("insert_admin_first_name").value;
    var error_message = document.getElementById("insert_admin_fname_error");
    var error_border = document.getElementById("insert_admin_first_name");
  }
  else if(select == "edit"){
    fname = document.getElementById("edit_admin_first_name").value;
    error_message = document.getElementById("edit_admin_fname_error");
    error_border = document.getElementById("edit_admin_first_name"); 
  }
  
  if(fname.match(space)){
    error_message.innerHTML = "Name is required.";
    error_border.style.border = "2px solid red";
    valid_fname = "false";
  }
  else if(fname.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_fname = "true";
  }
  else{
    error_message.innerHTML = "Please enter name as only Alphabet.";
    error_border.style.border = "2px solid red";
    valid_fname = "false";
  }
}

var valid_lname = "true";
function lname_validation(select){
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var lname = document.getElementById("insert_admin_last_name").value;
    var error_message = document.getElementById("insert_admin_lname_error");
    var error_border = document.getElementById("insert_admin_last_name");
  }
  else if(select == "edit"){
    lname = document.getElementById("edit_admin_last_name").value;
    error_message = document.getElementById("edit_admin_lname_error");
    error_border = document.getElementById("edit_admin_last_name"); 
  }
  
  if(lname.match(space)){
    error_message.innerHTML = "Name is required.";
    error_border.style.border = "2px solid red";
    valid_lname = "false";
  }
  else if(lname.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_lname = "true";
  }
  else{
    error_message.innerHTML = "Please enter name as only Alphabet.";
    error_border.style.border = "2px solid red";
    valid_lname = "false";
  }
}

var valid_phone = "true";
function phone_validation(select)
{ 
  var space = /^\s*$/;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  if(select == "add"){
    var phoneNo = document.getElementById("insert_admin_phone").value;
    var error_message = document.getElementById("insert_admin_phone_error");
    var error_border = document.getElementById("insert_admin_phone");
  }
  else if(select == "edit"){
    phoneNo = document.getElementById("edit_admin_phone").value;
    error_message = document.getElementById("edit_admin_phone_error");
    error_border = document.getElementById("edit_admin_phone"); 
  }

  if(phoneNo.match(space)){
    error_message.innerHTML = "Phone number is required.";
    error_border.style.border = "2px solid red";
    valid_phone = "false";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12){
    error_message.innerHTML = "Please enter a valid phone number.";
    error_border.style.border = "2px solid red";
    valid_phone = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_phone = "true";
  }
}

var valid_email = "true";
function email_validation(select){
	var operation = "check_exist_email";
	var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	var space = /^\s*$/;

	if(select == "add"){
		var admin_id = document.getElementById("insert_admin_id").value;
		var email = document.getElementById("insert_admin_email").value;
		var email_error = document.getElementById("insert_admin_email_error");
		var error_border = document.getElementById("insert_admin_email");
	}
	else if(select == "edit"){
		var admin_id = document.getElementById("admin_details_id").innerHTML;
		var email = document.getElementById("edit_admin_email").value;
		var email_error = document.getElementById("edit_admin_email_error");
		var error_border = document.getElementById("edit_admin_email");
	}

  $.ajax({
    url: "function/admin.php",
    type: "POST",
    data: {
    	'admin_id': admin_id,
    	'email': email,
    	'operation' : operation
    },
    success: function(data){
      if(data == "yes"){
        email_error.innerHTML = "This email has been use.";
        error_border.style.border = "2px solid red";
        valid_email = "false";
      }
      else if(email.match(space)){
        email_error.innerHTML = "Email address is required.";
        error_border.style.border = "2px solid red";
        valid_email = "false";
      }
      else if (email.match(pattern)){
        email_error.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
        valid_email = "true";
      }
      else{
        email_error.innerHTML = "Please enter valid email address.";
        error_border.style.border = "2px solid red";
        valid_email = "false";
      }
    },
  });
	 
}

var valid_position = "true";
function admin_position_validation()
{
	var position = document.getElementById("insert_admin_position").value;
	var error_message = document.getElementById("insert_admin_position_error");
  	var error_border = document.getElementById("insert_admin_position"); 

	if(position == "0")
	{
    	error_message.innerHTML = "Position is required.";
    	error_border.style.border = "2px solid red";
    	valid_position = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_position = "true";
  	}

}

var valid_gender = "true";
function admin_gender_validation()
{
	var gender = document.getElementById("insert_admin_gender").value;
	var error_message = document.getElementById("insert_admin_gender_error");
  	var error_border = document.getElementById("insert_admin_gender"); 

	if(gender == "0")
	{
    	error_message.innerHTML = "Gender is required.";
    	error_border.style.border = "2px solid red";
    	valid_gender = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_gender = "true";
  	}
}

var length_valid = "";
var number_valid = "";
var small_letter_valid = "";
var upper_letter_valid = "";
var symbol_valid = "";
var new_password_valid = "";
function password_guide(){
	document.getElementById("password_format").style.display = "block";
	var password = document.getElementById("insert_admin_password").value;
	document.getElementById("insert_admin_password_error_message").innerHTML="";

	if(password.length == 0){
		document.getElementById("password_format").style.display = "none";
		var length_valid = "no";
	}
	else if(password.length >= 15){
		document.getElementById("characters").style.color = "#00e600";
		document.getElementById("characters").style.fontWeight = "bold";
		length_valid = "yes";
	}
	else{
		document.getElementById("characters").style.color = "grey";
		document.getElementById("characters").style.fontWeight = "normal";
		length_valid = "no";
	}

	if(password.match(/[0-9]/)){
		document.getElementById("number").style.color = "#00e600";
		document.getElementById("number").style.fontWeight = "bold";
		var number_valid = "yes";
	}
	else{
		document.getElementById("number").style.color = "grey";
		document.getElementById("number").style.fontWeight = "normal";
		number_valid = "no";
	}

	if(password.match(/[a-z]/)){
		document.getElementById("small_letter").style.color = "#00e600";
		document.getElementById("small_letter").style.fontWeight = "bold";
		var small_letter_valid = "yes";
	}
	else{
		document.getElementById("small_letter").style.color = "grey";
		document.getElementById("small_letter").style.fontWeight = "normal";
		small_letter_valid = "no";
	}

	if(password.match(/[A-Z]/)){
		document.getElementById("upper_letter").style.color = "#00e600";
		document.getElementById("upper_letter").style.fontWeight = "bold";
		var upper_letter_valid = "yes";
	}
	else{
		document.getElementById("upper_letter").style.color = "grey";
		document.getElementById("upper_letter").style.fontWeight = "normal";
		upper_letter_valid = "no";
	}

	if(password.match(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/)){
		document.getElementById("symbol").style.color = "#00e600";
		document.getElementById("symbol").style.fontWeight = "bold";
		var symbol_valid = "yes";
	}
	else{
		document.getElementById("symbol").style.color = "grey";
		document.getElementById("symbol").style.fontWeight = "normal";
		symbol_valid = "no";
	}

	if(length_valid == "yes" && number_valid == "yes" && small_letter_valid == "yes" && upper_letter_valid == "yes" && symbol_valid == "yes"){
		document.getElementById("password_tick_icon").style.display = "block";
		document.getElementById("password_cross_icon").style.display = "none";
		document.getElementById("insert_admin_password_error_message").innerHTML = "";
		new_password_valid = "yes";
	}
	else{
		document.getElementById("password_tick_icon").style.display = "none";
		document.getElementById("password_cross_icon").style.display = "block";
		new_password_valid = "no";
	}

}

var valid_pass = "";
function pass_validation()
{
	var password = document.getElementById("insert_admin_password").value;
	var space = /^\s*$/;

	document.getElementById("password_format").style.display = "none";

	if(password.match(space))
	{
		document.getElementById("insert_admin_password_error_message").innerHTML="Password is required.";
		document.getElementById("insert_admin_password").style.border = "2px solid red";
		document.getElementById("password_tick_icon").style.display = "none";
		document.getElementById("password_cross_icon").style.display = "block";
		valid_pass = "false";
	}
	else if(password.length < 15 || password.search(/[0-9]/) == -1 || password.search(/[a-z]/) == -1 || password.search(/[A-Z]/) == -1 || password.search(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/) == -1){
		document.getElementById("insert_admin_password_error_message").innerHTML="Password format incorrect.";
		document.getElementById("insert_admin_password").style.border = "2px solid red";
		document.getElementById("password_tick_icon").style.display = "none";
		document.getElementById("password_cross_icon").style.display = "block";
		valid_pass = "false";
	}
	else
	{
		document.getElementById("insert_admin_password_error_message").innerHTML="";
		document.getElementById("insert_admin_password").style.border = "2px solid #f0f0f0";
		valid_pass = "true";
	}

	var confirm_password = document.getElementById("insert_admin_confirm_password").value;
	if(confirm_password.length != 0){
		confirm_password_validation();
	}
}

var confirm_pass_valid = "false";
function confirm_password_validation()
{
	var new_password = document.getElementById("insert_admin_password").value;
	var confirm_password = document.getElementById("insert_admin_confirm_password").value;
	var error_border = document.getElementById("insert_admin_confirm_password");
	var conpass_error = document.getElementById("insert_admin_conpass_error");
	var space = /^\s*$/;

	if(confirm_password.match(space))
	{
		conpass_error.innerHTML= "Confirm password is required.";
		error_border.style.border = "2px solid red";
		document.getElementById("confirm_password_tick_icon").style.display = "none";
		document.getElementById("confirm_password_cross_icon").style.display = "block";
		confirm_pass_valid = "false";
	}
	else if(new_password == confirm_password)
	{
		conpass_error.innerHTML= "";
		error_border.style.border = "1px solid black";
		document.getElementById("confirm_password_tick_icon").style.display = "block";
		document.getElementById("confirm_password_cross_icon").style.display = "none";
		confirm_pass_valid = "true";
	}
	else
	{
		conpass_error.innerHTML= "Password does not match.";
		error_border.style.border = "2px solid red";
		document.getElementById("confirm_password_tick_icon").style.display = "none";
		document.getElementById("confirm_password_cross_icon").style.display = "block";
		confirm_pass_valid = "false";
	}
}

//EDIT AND ADD ADMIN VALIDATION END//

function show_hide_password(){
  var toggle = document.getElementById("toggle_password_icon");
  var pass = document.getElementById("insert_admin_password");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('show_password_icon');
    toggle.classList.add('hide_password_icon');
    
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('hide_password_icon');
    toggle.classList.add('show_password_icon');
    
  }
}

function show_hide_confirm_password(){
  var toggle = document.getElementById("toggle_confirm_password_icon");
  var pass = document.getElementById("insert_admin_confirm_password");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('show_confirm_password_icon');
    toggle.classList.add('hide_confirm_password_icon');
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('hide_confirm_password_icon');
    toggle.classList.add('show_confirm_password_icon');
  }
}

function keyPressed(){
	var key = event.keyCode || event.charCode || event.which ;
	return key;
}

function upload_image(){
	document.getElementById("image_upload").click();
}

function edit_upload_image(){
  document.getElementById("upload_edit_admin_image").click();
}

function preview_admin_image(select){
	if(select == "add"){
		var file = document.getElementById("image_upload").files;

		document.getElementById("insert_admin_image_preview").style.display = "inline";
		document.getElementById("upload_image_preview_empty").style.display = "none";

		if(file.length > 0){
			var fileReader = new FileReader();

			fileReader.onload = function(event){
				document.getElementById("insert_admin_image_preview").setAttribute("src", event.target.result);
			}

			fileReader.readAsDataURL(file[0]);
		}
	}
	else if(select == "edit"){
		var file = document.getElementById("upload_edit_admin_image").files;

		if(file.length > 0){
			var fileReader = new FileReader();

			fileReader.onload = function(event){
				document.getElementById("admin_profile_picture_display").setAttribute("src", event.target.result);
			}

			fileReader.readAsDataURL(file[0]);

			document.getElementById("image_image_blank").style.display = "none";
			document.getElementById("admin_profile_picture_display").style.display = "inline";
		}
		else{
			document.getElementById("image_image_blank").style.display = "block";
			document.getElementById("admin_profile_picture_display").style.display = "none";
		}
	}
}

function add_admin(){
	var operation = "add_admin";

	fname_validation("add");
	lname_validation("add");
	phone_validation("add");
	email_validation("add");
	admin_position_validation();
	admin_gender_validation();
	pass_validation();
	confirm_password_validation();

	if(valid_fname == "true" && valid_lname == "true" && valid_phone == "true" && valid_email == "true" && valid_position == "true" && valid_gender == "true" && valid_pass == "true" && confirm_pass_valid == "true"){
		var profile_picture = $('#image_upload')[0].files;
		var admin_id = document.getElementById("insert_admin_id").value;
		var first_name = document.getElementById("insert_admin_first_name").value;
		var last_name = document.getElementById("insert_admin_last_name").value;
		var gender = document.getElementById("insert_admin_gender").value;
		var email = document.getElementById("insert_admin_email").value;
		var phone = document.getElementById("insert_admin_phone").value;
		var password = document.getElementById("insert_admin_password").value;
		var position = document.getElementById("insert_admin_position").value;
		var current_login_id = document.getElementById("admin_id").value;

		var fd = new FormData();
		fd.append('operation',operation);
		fd.append('profile_picture',profile_picture[0]);
		fd.append('admin_id',admin_id);
		fd.append('first_name',first_name);
		fd.append('last_name',last_name);
		fd.append('gender',gender);
		fd.append('email',email);
		fd.append('phone',phone);
		fd.append('password',password);
		fd.append('position',position);
		fd.append('current_login_id',current_login_id);

		$.ajax({
			url: "function/admin.php",
			type: "POST",
			data: fd,
			contentType: false,
		    processData: false,
			success: function(data){
		        document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					window.location = "admin.php";
				}, 1500);
		    }
		});
	}
}

function filter_table(){
    var input = document.getElementById("search_admin");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("admin_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
    	var delete_status = document.getElementById("admin_delete_status"+i).value;
    	if(delete_status == 0){
    		if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
	            tr[i].style.display = "";
	            
	            found_result++;
	            if(found_result % 2 == 0){
	              tr[i].style.background = "none";
	            }
	            else{
	              tr[i].style.background = "#f2f2f2";
	            }

	            document.getElementById("table_number"+i).innerHTML = found_result;
	        }
	        else{
	            tr[i].style.display = "none";
	        }
    	}
    }
}

var delete_admin_id = "";
var delete_counter = "";
function delete_admin(counter, admin_id){
	delete_admin_id = admin_id;
	delete_counter = counter;
	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function delete_admin_confirm(){
	var current_login_id = document.getElementById("admin_id").value;
	var position = document.getElementById("position"+delete_counter).innerHTML;
	
	if(current_login_id == admin_id){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.getElementById("delete_error_alert_wrap").style.display = "block";
		document.querySelector("body").style.overflow = "hidden";

		setTimeout(function(){
			document.getElementById("delete_error_alert_wrap").style.display = "none";
			document.querySelector("body").style.overflow = "auto";
		}, 1500);
	}
	else{
		var operation = "delete_admin";

		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";

		$.ajax({
			url: "function/admin.php",
			type: "POST",
			data: {
				'operation': operation,
				'admin_id': delete_admin_id,
				'position': position
			},
			success: function(){
				document.getElementById("admin_row"+delete_counter).style.display = "none";
				document.getElementById("admin_delete_status"+delete_counter).value = 1;
				filter_table();
			}
		});
	}
}

function save_edit_admin(){
	var operation = "edit_admin";

	fname_validation("edit");
	lname_validation("edit");
	phone_validation("edit");
	email_validation("edit");

	if(valid_fname == "true" && valid_lname == "true" && valid_phone == "true" && valid_email == "true"){
		
		var fd = new FormData();
		var profile_picture = $('#upload_edit_admin_image')[0].files;

		var admin_id = document.getElementById("admin_details_id").innerHTML;
		var position = document.getElementById("edit_admin_position").value;
		var first_name = document.getElementById("edit_admin_first_name").value;
		var last_name = document.getElementById("edit_admin_last_name").value;
		var phone = document.getElementById("edit_admin_phone").value;
		var email = document.getElementById("edit_admin_email").value;
		var gender = document.getElementById("edit_admin_gender").value;
		var current_position = document.getElementById("position"+current_view_admin).innerHTML;

		fd.append('operation',operation);
		fd.append('profile_picture',profile_picture[0]);
		fd.append('admin_id',admin_id);
		fd.append('position',position);
		fd.append('first_name',first_name);
		fd.append('last_name',last_name);
		fd.append('phone',phone);
		fd.append('email',email);
		fd.append('gender',gender);
		fd.append('current_position',current_position);


		document.getElementById("first_name"+current_view_admin).innerHTML = first_name;
		document.getElementById("last_name"+current_view_admin).innerHTML = last_name;
		document.getElementById("phone"+current_view_admin).innerHTML = phone;
		document.getElementById("email"+current_view_admin).innerHTML = email;
		document.getElementById("gender"+current_view_admin).innerHTML = gender;
		document.getElementById("position"+current_view_admin).innerHTML = position;


		if(position == "Superadmin"){
			document.getElementById("position"+current_view_admin).classList.add("superadmin_font");
			document.getElementById("position"+current_view_admin).classList.remove("admin_font");
		}
		else{
			document.getElementById("position"+current_view_admin).classList.add("admin_font");
			document.getElementById("position"+current_view_admin).classList.remove("superadmin_font");
		}


		$.ajax({
			url: "function/admin.php",
			type: "POST",
			data: fd,
		    contentType: false,
		    processData: false,
		    success: function(){
		        cancel_edit_admin();

				document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
				}, 1500);
		    }
		});
	}
}