
valid_card_price = "false";
function card_price_validation(){
	var space = /^\s*$/;
	var card_price = document.getElementById("edit_card_price").value;
	var error_message =document.getElementById("edit_card_price_error");
	var error_border =document.getElementById("edit_card_price");

	if(card_price.match(space)){
        error_message.innerHTML = "Price is required.";
        error_border.style.border = "2px solid red";
        valid_card_price = "false";
	}
	else if(card_price < 1){
		error_message.innerHTML = "Price cannot be less than RM 1.";
        error_border.style.border = "2px solid red";
        valid_card_price = "false";
	}
	else if(card_price > 99999.99){
	    error_message.innerHTML = "Maximum price is RM99,999.99";
	    error_border.style.border = "2px solid red";
	    valid_card_price = "false";		
	}	
	else{
        error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
        valid_card_price = "true";
	}
}

function close_card_details(){
	if(edit_activity == 0){
		document.getElementById("custom_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

var current_view_card = "";
function show_card_details(card_id, i){
	var operation = "get_card_details";
	current_view_card = i;
	


	$.ajax({
		url: "function/product_customization.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'card_id': card_id
		},
		success: function(data){
			document.getElementById("custom_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			var card_price = parseFloat(data[0].card_price);

			document.getElementById("card_id").value = data[0].card_id;
			document.getElementById("card_type_div").innerHTML = data[0].card_type;
			document.getElementById("card_price_div").innerHTML= card_price.toFixed(2);
			document.getElementById("card_stock_div").innerHTML = data[0].card_stock;

			document.getElementById("custom_details_wrap2").scrollTop = 0;
		}
	});
}


var edit_activity = "";
function edit_card(){
	edit_activity = 1;

	document.getElementById("edit_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	var current_card_type = document.getElementById("card_type_div").innerHTML;
	var current_card_price = document.getElementById("card_price_div").innerHTML;
	var current_card_stock = document.getElementById("card_stock_div").innerHTML;

	document.getElementById("edit_card_type").style.display = "inline";
	document.getElementById("edit_card_price").style.display = "inline";
	document.getElementById("edit_card_stock").style.display = "inline";

	document.getElementById("edit_card_type").value = current_card_type;
	document.getElementById("edit_card_price").value = current_card_price;
	document.getElementById("edit_card_stock").value = current_card_stock;

	document.getElementById("card_type_div").style.display = "none";
	document.getElementById("card_price_div").style.display = "none";
	document.getElementById("card_stock_div").style.display = "none";
}

function cancel_edit(){
	edit_activity = 0;
	document.getElementById("edit_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	var card_id = document.getElementById("card_id").value;

	var operation = "get_card_details";

	$.ajax({
		url: "function/product_customization.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'card_id': card_id
		},
		success: function(data){
			document.getElementById("custom_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			var card_price = parseFloat(data[0].card_price);

			document.getElementById("card_id").value = data[0].card_id;
			document.getElementById("card_type_div").innerHTML = data[0].card_type;
			document.getElementById("card_price_div").innerHTML = card_price.toFixed(2);
			document.getElementById("card_stock_div").innerHTML = data[0].card_stock;

			document.getElementById("custom_details_wrap2").scrollTop = 0;
		}
	});

	document.getElementById("edit_card_type").style.display = "none";
	document.getElementById("edit_card_price").style.display = "none";
	document.getElementById("edit_card_stock").style.display = "none";

	document.getElementById("card_type_div").style.display = "inline-block";
	document.getElementById("card_price_div").style.display = "inline-block";
	document.getElementById("card_stock_div").style.display = "inline-block";

	document.getElementById("edit_card_price_error").innerHTML = "";
    document.getElementById("edit_card_price").style.border = "1px solid #666666";


}

function save_edit_type(){
	var operation = "save_edit";

	card_price_validation();

	if(valid_card_price == "true"){
		
		var fd = new FormData();

		var card_type = document.getElementById("edit_card_type").value;
		var card_price = document.getElementById("edit_card_price").value;
		var card_stock = document.getElementById("edit_card_stock").value;
		var card_id = document.getElementById("card_id").value;

		fd.append('operation',operation);
		fd.append('card_type',card_type);
		fd.append('card_price',card_price);
		fd.append('card_stock',card_stock);
		fd.append('card_id',card_id);

		document.getElementById("card_type_div").innerHTML = card_type;
		document.getElementById("card_price_div").innerHTML = card_price;
		document.getElementById("card_stock_div").innerHTML = card_stock;
		//for table view
		card_price = parseFloat(card_price);
		document.getElementById("card_price"+current_view_card).innerHTML = card_price.toFixed(2);
		document.getElementById("card_stock"+current_view_card).innerHTML = card_stock;
		
		if(card_stock == "In Stock"){
			document.getElementById("card_stock"+current_view_card).classList.remove("out_of_stock_tag");
			document.getElementById("card_stock"+current_view_card).classList.add("in_stock_tag");
		}
		else{
			document.getElementById("card_stock"+current_view_card).classList.add("out_of_stock_tag");
			document.getElementById("card_stock"+current_view_card).classList.remove("in_stock_tag");
		}
		

		$.ajax({
			url: "function/product_customization.php",
			type: "POST",
			data: fd,
		    contentType: false,
		    processData: false,
		    success: function(data){
		        cancel_edit();

				document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
				}, 1500);
		    }
		});
	}
}

function filter_table(){
    var input = document.getElementById("search_custom");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("custom_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
        if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
            tr[i].style.display = "";
            
            found_result++;
            if(found_result % 2 == 0){
              tr[i].style.background = "none";
            }
            else{
              tr[i].style.background = "#f2f2f2";
            }

            document.getElementById("table_number"+i).innerHTML = found_result;
        }
        else{
            tr[i].style.display = "none";
        }
    }
}