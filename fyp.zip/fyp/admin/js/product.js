function close_product_details(){

	if(edit_activity == 0){
		document.getElementById("product_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

var current_view_product = "";
var product_found_promotion = "";
function show_product_details(product_id, i){
	var operation = "get_product_details";
	current_view_product = i;
	product_found_promotion = document.getElementById("found_promotion"+i).value;

	$.ajax({
		url: "function/product.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'product_id': product_id
		},
		success: function(data){
			document.getElementById("product_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			var product_price = parseFloat(data[0].product_price);
			var found_promotion = data[0].found_promotion;

			document.getElementById("product_image").src = "image/product_image/"+data[0].product_image;
			document.getElementById("product_stock").innerHTML = data[0].product_stock;
			document.getElementById("product_status").innerHTML = data[0].product_status;
			document.getElementById("product_id").innerHTML = data[0].product_id;
			document.getElementById("product_name").innerHTML = data[0].product_name;
			document.getElementById("product_price").innerHTML = product_price.toFixed(2);
			
			if(found_promotion == "true"){
				var product_promotion_price = parseFloat(data[0].product_promotion_price);
				document.getElementById("promotion_price_dislay").innerHTML = product_promotion_price.toFixed(2);
				document.getElementById("product_price").classList.add("old_price_display");
				document.getElementById("promotion_word_display").innerHTML = "(Promotion price)";
			}
			else{
				document.getElementById("promotion_price_dislay").innerHTML = "";
				document.getElementById("product_price").classList.remove("old_price_display");
				document.getElementById("promotion_word_display").innerHTML = "";
			}

			document.getElementById("product_category").innerHTML = data[0].product_gender;
			document.getElementById("product_type").innerHTML = data[0].product_type;
			document.getElementById("product_occasions").innerHTML = data[0].product_occasions;
			document.getElementById("product_description_1").innerHTML = data[0].product_description_1;
			document.getElementById("product_description_2").innerHTML = data[0].product_description_2;

			document.getElementById("product_details_wrap_2").scrollTop = 0;
		}
	});
}
temporary_image_src = "";
var edit_activity = "";
function edit_product(){
	edit_activity = 1;
	temporary_image_src = document.getElementById("product_image").src;
	var current_product_stock = document.getElementById("product_stock").innerHTML;
	var current_product_status = document.getElementById("product_status").innerHTML;
	document.getElementById("edit_product_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	document.getElementById("availability_select_box").value = current_product_stock;
	document.getElementById("status_select_box").value = current_product_status;

	var current_product_id = document.getElementById("product_id").innerHTML;
	var current_product_name = document.getElementById("product_name").innerHTML;
	var current_product_price = document.getElementById("product_price").innerHTML;
	var current_product_category = document.getElementById("product_category").innerHTML;
	var current_product_type = document.getElementById("product_type").innerHTML;
	var current_product_occasions = document.getElementById("product_occasions").innerHTML;
	var current_product_description_1 = document.getElementById("product_description_1").innerHTML;
	var current_product_description_2 = document.getElementById("product_description_2").innerHTML;

	document.getElementById("availability_select_box").style.display = "inline";
	document.getElementById("status_select_box").style.display = "inline";
	document.getElementById("upload_edit_product_image").style.display = "inline";
	document.getElementById("edit_product_id").style.display = "inline";
	document.getElementById("edit_product_name").style.display = "inline";
	document.getElementById("edit_product_price").style.display = "inline";
	document.getElementById("edit_product_category").style.display = "inline";
	document.getElementById("edit_product_type").style.display = "inline";
	document.getElementById("edit_product_occasions").style.display = "inline";
	document.getElementById("edit_product_description_1").style.display = "inline";
	document.getElementById("edit_product_description_2").style.display = "inline";

	document.getElementById("edit_product_id").value = current_product_id;
	document.getElementById("edit_product_name").value = current_product_name;
	document.getElementById("edit_product_price").value = current_product_price;
	document.getElementById("edit_product_category").value = current_product_category;
	document.getElementById("edit_product_type").value = current_product_type;
	document.getElementById("edit_product_occasions").value = current_product_occasions;
	document.getElementById("edit_product_description_1").value = current_product_description_1;
	document.getElementById("edit_product_description_2").value = current_product_description_2;

	document.getElementById("product_id").style.display = "none";
	document.getElementById("product_name").style.display = "none";
	document.getElementById("product_price").style.display = "none";
	document.getElementById("product_category").style.display = "none";
	document.getElementById("product_type").style.display = "none";
	document.getElementById("product_occasions").style.display = "none";
	document.getElementById("product_description_1").style.display = "none";
	document.getElementById("product_description_2").style.display = "none";
	document.getElementById("product_stock").style.display = "none";
	document.getElementById("product_status").style.display = "none";
	document.getElementById("promotion_price_dislay").style.display = "none";
	document.getElementById("promotion_word_display").style.display = "none";
}

//EDIT and ADD product validation START
var valid_name = "false";
function product_name_validation(select){
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

    if(select == "add"){
    	var product_name = document.getElementById("insert_product_name").value;
    	var error_message = document.getElementById("insert_name_error");
    	var error_border = document.getElementById("insert_product_name");
  	}
  	else if(select == "edit"){
  		product_name = document.getElementById("edit_product_name").value;
    	error_message = document.getElementById("edit_name_error");
    	error_border = document.getElementById("edit_product_name");
  	}

	if(product_name.match(space)){
	    error_message.innerHTML = "Product Name is required.";
	    error_border.style.border = "2px solid red";
	    valid_name = "false";
	}
	else{
	    error_message.innerHTML = "";
	    error_border.style.border = "1px solid #666666";
	    valid_name = "true";
	}
}

var valid_price = "false";
function product_price_validation(select)
{
	var space = /^\s*$/;

	if(select == "add"){
	  	var price = document.getElementById("insert_product_price").value;
	    var error_message = document.getElementById("insert_price_error");
	    var error_border = document.getElementById("insert_product_price");
	}
	else if(select == "edit"){
	  	price = document.getElementById("edit_product_price").value;
	    error_message = document.getElementById("edit_price_error");
	    error_border = document.getElementById("edit_product_price");
	}
	  
	if(price.match(space)){
	    error_message.innerHTML = "Product Price is required.";
	    error_border.style.border = "2px solid red";
	    valid_price = "false";
	}
	else if(price < 1){
	    error_message.innerHTML = "Product Price cannot be less than RM 1";
	    error_border.style.border = "2px solid red";
	    valid_price = "false";		
	}
	else if(price > 99999.99){
	    error_message.innerHTML = "Maximum price is RM99,999.99";
	    error_border.style.border = "2px solid red";
	    valid_price = "false";		
	}
	else{
		error_message.innerHTML = "";
	    error_border.style.border = "1px solid #666666";
	    valid_price = "true";
	}
}

var valid_product_desdescription_1 = "false";
function product_desc1_validation(select)
{
	var space = /^\s*$/;

	if(select == "add"){
    	var description1 = document.getElementById("insert_product_description_1").value;
    	var error_message = document.getElementById("insert_desc1_error");
    	var error_border = document.getElementById("insert_product_description_1"); 
  	}
  	else if(select == "edit"){
  		description1 = document.getElementById("edit_product_description_1").value;
    	error_message = document.getElementById("edit_desc1_error");
    	error_border = document.getElementById("edit_product_description_1"); 
  	}
    	

    if(description1.match(space)){
    	error_message.innerHTML = "Description 1 is required.";
    	error_border.style.border = "2px solid red";
    	valid_product_desdescription_1 = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_product_desdescription_1 = "true";
  	}
}

var valid_type = "false";
function product_type_validation()
{
  var type = document.getElementById("insert_product_type").value;
  var error_message = document.getElementById("insert_type_error");
  var error_border = document.getElementById("insert_product_type");

  
  if(type == "0"){
    error_message.innerHTML = "Product Type is required.";
    error_border.style.border = "2px solid red";
    valid_type = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_type = "true";
  }
}

var valid_category = "false";
function product_category_validation()
{
	var category = document.getElementById("insert_product_category").value;
	var error_message = document.getElementById("insert_category_error");
  	var error_border = document.getElementById("insert_product_category"); 

	if(category == "0")
	{
    	error_message.innerHTML = "Category is required.";
    	error_border.style.border = "2px solid red";
    	valid_category = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_category = "true";
  	}

}

var valid_occasion = "false";
function product_occasion_validation()
{
    var occasion = document.getElementById("insert_product_occasions").value;
    var error_message = document.getElementById("insert_occasion_error");
    var error_border = document.getElementById("insert_product_occasions");


	if(occasion == "0")
	{
    	error_message.innerHTML = "Occasion is required.";
    	error_border.style.border = "2px solid red";
    	valid_occasion = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_occasion = "true";
  	}

}

var valid_availability = "false";
function product_availability_validation()
{
	var available = document.getElementById("insert_product_availability").value;
	var error_message = document.getElementById("insert_available_error");
  	var error_border = document.getElementById("insert_product_availability"); 

	if(available == "0")
	{
    	error_message.innerHTML = "Product Availability is required.";
    	error_border.style.border = "2px solid red";
    	valid_availability = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_availability = "true";
  	}

}

var valid_status = "false";
function add_status_validation()
{
	var status = document.getElementById("insert_product_status").value;
	var error_message = document.getElementById("insert_status_error");
  	var error_border = document.getElementById("insert_product_status"); 

	if(status == "0")
	{
    	error_message.innerHTML = "Status is required.";
    	error_border.style.border = "2px solid red";
    	valid_status = "false";
  	}
  	else{
    	error_message.innerHTML = "";
    	error_border.style.border = "1px solid #666666";
    	valid_status = "true";
  	}

}

valid_image = "false";
function add_image_validation()
{

	var file = document.getElementById("image_upload").files;
	var error = document.getElementById("add_image_upload_error");
	var error_border = document.getElementById("image_preview_empty");  	

    if(file.length > 0){
    	error.innerHTML = "";
      	error_border.style.border = "2px solid lightgrey";
     	valid_image = "true";	
      
    }
    else{
    	error.innerHTML = "Please Upload Image";
  		error_border.style.border = "2px solid red";
  		valid_image = "false";
    }  

}
//EDIT AND ADD PRODUCT VALIDATION ENDS

function cancel_edit_product(){
	edit_activity = 0;
	document.getElementById("edit_product_details_btn").style.display = "inline";
	document.getElementById("promotion_price_dislay").style.display = "inline";
	document.getElementById("promotion_word_display").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	var product_id = document.getElementById("product_id").innerHTML;

	var operation = "get_product_details";

	$.ajax({
		url: "function/product.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'product_id': product_id
		},
		success: function(data){
			document.getElementById("product_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			var product_price = parseFloat(data[0].product_price);
			
			document.getElementById("product_stock").innerHTML = data[0].product_stock;
			document.getElementById("product_status").innerHTML = data[0].product_status;
			document.getElementById("product_image").src = "image/product_image/"+data[0].product_image;
			document.getElementById("product_id").innerHTML = data[0].product_id;
			document.getElementById("product_name").innerHTML = data[0].product_name;
			document.getElementById("product_price").innerHTML = product_price.toFixed(2);
			document.getElementById("product_category").innerHTML = data[0].product_gender;
			document.getElementById("product_type").innerHTML = data[0].product_type;
			document.getElementById("product_occasions").innerHTML = data[0].product_occasions;
			document.getElementById("product_description_1").innerHTML = data[0].product_description_1;
			document.getElementById("product_description_2").innerHTML = data[0].product_description_2;

		}
	});

	document.getElementById("availability_select_box").style.display = "none";
	document.getElementById("status_select_box").style.display = "none";
	document.getElementById("upload_edit_product_image").style.display = "none";
	document.getElementById("edit_product_id").style.display = "none";
	document.getElementById("edit_product_name").style.display = "none";
	document.getElementById("edit_product_price").style.display = "none";
	document.getElementById("edit_product_category").style.display = "none";
	document.getElementById("edit_product_type").style.display = "none";
	document.getElementById("edit_product_occasions").style.display = "none";
	document.getElementById("edit_product_description_1").style.display = "none";
	document.getElementById("edit_product_description_2").style.display = "none";
	document.getElementById("upload_edit_product_image").value = "";

	document.getElementById("product_id").style.display = "inline-block";
	document.getElementById("product_name").style.display = "inline-block";
	document.getElementById("product_price").style.display = "inline-block";
	document.getElementById("product_category").style.display = "inline-block";
	document.getElementById("product_type").style.display = "inline-block";
	document.getElementById("product_occasions").style.display = "inline-block";
	document.getElementById("product_description_1").style.display = "inline-block";
	document.getElementById("product_description_2").style.display = "inline-block";
	document.getElementById("product_stock").style.display = "inline-block";
	document.getElementById("product_status").style.display = "inline-block";

	document.getElementById("edit_name_error").innerHTML = "";
    document.getElementById("edit_product_name").style.border = "1px solid #666666";
	document.getElementById("edit_price_error").innerHTML = "";
	document.getElementById("edit_product_price").style.border = "1px solid #666666";
	document.getElementById("edit_desc1_error").innerHTML = "";
	document.getElementById("edit_product_description_1").style.border = "1px solid #666666";
}

function save_edit_product(){
	var operation = "edit_product";

	product_name_validation("edit");
	product_price_validation("edit");
	product_desc1_validation("edit");

	if(valid_name == "true" && valid_price == "true" && valid_product_desdescription_1 == "true"){
		var fd = new FormData();
		var product_image = $('#upload_edit_product_image')[0].files;

		var product_id = document.getElementById("product_id").innerHTML;
		var product_availability = document.getElementById("availability_select_box").value;
		var status = document.getElementById("status_select_box").value;
		var product_name = document.getElementById("edit_product_name").value;
		var product_price = document.getElementById("edit_product_price").value;
		var product_category = document.getElementById("edit_product_category").value;
		var product_type = document.getElementById("edit_product_type").value;
		var product_occasions = document.getElementById("edit_product_occasions").value;
		var product_description_1 = document.getElementById("edit_product_description_1").value;
		var product_description_2 = document.getElementById("edit_product_description_2").value;

		fd.append('operation',operation);
		fd.append('product_image',product_image[0]);
		fd.append('product_type',product_type);
		fd.append('product_id',product_id);
		fd.append('product_name',product_name);
		fd.append('product_price',product_price);
		fd.append('product_category',product_category);
		fd.append('product_occasions',product_occasions);
		fd.append('product_description_1',product_description_1);
		fd.append('product_description_2',product_description_2);
		fd.append('product_availability',product_availability);
		fd.append('status',status);

		document.getElementById("product_name"+current_view_product).innerHTML = product_name;

		//change the outside price if dont have any promotion price cuz promotion price is number 1
		if(product_found_promotion == "false"){
			document.getElementById("product_price"+current_view_product).innerHTML = product_price;
		}
		
		document.getElementById("product_occasions"+current_view_product).innerHTML = product_occasions;
		document.getElementById("product_stock"+current_view_product).innerHTML = product_availability;
		if(product_availability == "In Stock"){
			document.getElementById("product_stock"+current_view_product).classList.remove("out_of_stock_tag");
			document.getElementById("product_stock"+current_view_product).classList.add("in_stock_tag");
		}
		else{
			document.getElementById("product_stock"+current_view_product).classList.add("out_of_stock_tag");
			document.getElementById("product_stock"+current_view_product).classList.remove("in_stock_tag");
		}
		document.getElementById("product_status"+current_view_product).innerHTML = status;
		if(status == "On Display"){
			document.getElementById("product_status"+current_view_product).classList.remove("product_status_hidden");
			document.getElementById("product_status"+current_view_product).classList.add("product_status_on_display");
		}
		else{
			document.getElementById("product_status"+current_view_product).classList.add("product_status_hidden");
			document.getElementById("product_status"+current_view_product).classList.remove("product_status_on_display");
		}

		$.ajax({
			url: "function/product.php",
			type: "POST",
			data: fd,
		    contentType: false,
		    processData: false,
		    success: function(data){
		        cancel_edit_product();

				document.getElementById("edit_success_alert_wrap").style.display = "block";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
				}, 1500);
		    }
		});
	}
}

function close_insert_product(){
	document.getElementById("add_new_product_wrap").style.display = "none";
	document.querySelector("body").style.overflow = "auto";

	var error_message = document.getElementById("insert_name_error").innerHTML = "";
	var error_border = document.getElementById("insert_product_name").style.border = "1px solid #666666";
    var error_message = document.getElementById("insert_price_error").innerHTML = "";
    var error_border = document.getElementById("insert_product_price").style.border = "1px solid #666666";
	var error_message = document.getElementById("insert_desc1_error").innerHTML = "";
	var error_border = document.getElementById("insert_product_description_1").style.border = "1px solid #666666";
	var error_message = document.getElementById("insert_type_error").innerHTML = "";
	var error_border = document.getElementById("insert_product_type").style.border = "1px solid #666666";
	var error_message = document.getElementById("insert_category_error").innerHTML = "";
  	var error_border = document.getElementById("insert_product_category").style.border = "1px solid #666666";
    var error_message = document.getElementById("insert_occasion_error").innerHTML = "";
    var error_border = document.getElementById("insert_product_occasions").style.border = "1px solid #666666";
	var error_message = document.getElementById("insert_available_error").innerHTML = "";
  	var error_border = document.getElementById("insert_product_availability").style.border = "1px solid #666666";
	var error_message = document.getElementById("insert_status_error").innerHTML = "";
  	var error_border = document.getElementById("insert_product_status").style.border = "1px solid #666666";
  	var error = document.getElementById("add_image_upload_error").innerHTML = "";
	var error_border = document.getElementById("image_preview_empty").style.border = "2px solid lightgrey";  	
	
	document.getElementById("image_upload").value = ""; 
	document.getElementById("insert_product_image_preview").style.display = "none";  
	document.getElementById("image_preview_empty").style.display = "block"; 
	document.getElementById("insert_product_type").value = "0"; 
	document.getElementById("insert_product_id").value = ""; 
	document.getElementById("insert_product_name").value = ""; 
	document.getElementById("insert_product_price").value = ""; 
	document.getElementById("insert_product_category").value = "0"; 
	document.getElementById("insert_product_occasions").value = "0"; 
	document.getElementById("insert_product_description_1").value = ""; 
	document.getElementById("insert_product_description_2").value = ""; 
	document.getElementById("insert_product_availability").value = "0"; 
	document.getElementById("insert_product_status").value = "0"; 

}

function add_product_popup(){
	document.getElementById("add_new_product_wrap").style.display = "block";
	document.querySelector("body").style.overflow = "hidden";

	//show insert product error message div
	document.getElementById("insert_type_error").style.display = "block";
	document.getElementById("insert_name_error").style.display = "block";
	document.getElementById("insert_price_error").style.display = "block";
	document.getElementById("insert_category_error").style.display = "block";
	document.getElementById("insert_occasion_error").style.display = "block";
	document.getElementById("insert_desc1_error").style.display = "block";
	document.getElementById("insert_available_error").style.display = "block";
	document.getElementById("insert_status_error").style.display = "block";

	document.getElementById("add_new_product_details_box").scrollTop = 0;

}

function get_new_product_id(){
	var operation = "get_product_id";

	var product_type = document.getElementById("insert_product_type").value;

	$.ajax({
		url: "function/product.php",
		type: "POST",
		data: {
			'operation': operation,
			'product_type': product_type
		},
		success: function(data){
			document.getElementById("insert_product_id").value = data;
		}
	});
}

function upload_image(){
	document.getElementById("image_upload").click();
}


function preview_product_image(select){
	if(select == "add"){
		var file = document.getElementById("image_upload").files;

		document.getElementById("insert_product_image_preview").style.display = "inline";
		document.getElementById("image_preview_empty").style.display = "none";

		if(file.length > 0){
			var fileReader = new FileReader();

			fileReader.onload = function(event){
				document.getElementById("insert_product_image_preview").setAttribute("src", event.target.result);
			}

			fileReader.readAsDataURL(file[0]);
			document.getElementById("add_image_upload_error").innerHTML = "";
			document.getElementById("image_preview_empty").style.border = "2px solid lightgrey";
			
		}
		else{
			document.getElementById("insert_product_image_preview").src = "";
			document.getElementById("insert_product_image_preview").style.display = "none";
			document.getElementById("image_preview_empty").style.display = "inline-block";
		}

	}
	else if(select == "edit"){
		var file = document.getElementById("upload_edit_product_image").files;

		if(file.length > 0){
			var fileReader = new FileReader();

			fileReader.onload = function(event){
				document.getElementById("product_image").setAttribute("src", event.target.result);
			}

			fileReader.readAsDataURL(file[0]);

		}
		else{
			document.getElementById("product_image").src = temporary_image_src;
		}
	}

}

function add_product(){
	var operation = "add_product";
	
	add_image_validation();
	product_name_validation("add");
	product_price_validation("add");
	product_desc1_validation("add");
	product_type_validation();
	product_category_validation();
	product_occasion_validation();
	product_availability_validation();
	add_status_validation();


	if(valid_image == "true" && valid_name == "true" && valid_price == "true" && valid_product_desdescription_1 == "true" && valid_type == "true" && valid_category == "true" && valid_occasion == "true" && valid_availability == "true" && valid_status == "true"){
		var fd = new FormData();
		var product_image = $('#image_upload')[0].files;

		var product_type = document.getElementById("insert_product_type").value;
		var product_id = document.getElementById("insert_product_id").value;
		var product_name = document.getElementById("insert_product_name").value;
		var product_price = document.getElementById("insert_product_price").value;
		var product_category = document.getElementById("insert_product_category").value;
		var product_occasions = document.getElementById("insert_product_occasions").value;
		var product_description_1 = document.getElementById("insert_product_description_1").value;
		var product_description_2 = document.getElementById("insert_product_description_2").value;
		var product_availability = document.getElementById("insert_product_availability").value;
		var product_status = document.getElementById("insert_product_status").value;

		fd.append('operation',operation);
		fd.append('product_image',product_image[0]);
		fd.append('product_type',product_type);
		fd.append('product_id',product_id);
		fd.append('product_name',product_name);
		fd.append('product_price',product_price);
		fd.append('product_category',product_category);
		fd.append('product_occasions',product_occasions);
		fd.append('product_description_1',product_description_1);
		fd.append('product_description_2',product_description_2);
		fd.append('product_availability',product_availability);
		fd.append('product_status',product_status);

		$.ajax({
			url: "function/product.php",
			type: "POST",
			data: fd,
		    contentType: false,
		    processData: false,
		    success: function(data){
		        document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					window.location = "product.php";
				}, 1500);
		    }
		});
	}
}

function filter_table(){
    var input = document.getElementById("search_product");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("product_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
        var delete_status = document.getElementById("product_delete_status"+i).value;
		if(delete_status == 0){
			if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
				tr[i].style.display = "";

				found_result++;
				if(found_result % 2 == 0){
					tr[i].style.background = "none";
				}
				else{
					tr[i].style.background = "#f2f2f2";
				}

				document.getElementById("table_number"+i).innerHTML = found_result;
			}
			else{
				tr[i].style.display = "none";
			}
		}
    }
}

var delete_product_id = "";
var delete_counter = "";
function delete_product(counter, product_id){
	delete_product_id = product_id;
	delete_counter = counter;

	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function delete_product_confirm(){
	var operation = "delete_product";

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/product.php",
		type: "POST",
		data: {
			'operation': operation,
			'product_id': delete_product_id
		},
		success: function(){
			document.getElementById("product_row"+delete_counter).style.display = "none";
			document.getElementById("product_delete_status"+delete_counter).value = 1;
			filter_table();
		}
	});
}