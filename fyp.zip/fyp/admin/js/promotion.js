function add_promotion_popup(){
	document.getElementById('add_new_promotion_wrap').style.display = "block";
}


function close_add_promotion_popup(){
  document.getElementById('add_new_promotion_wrap').style.display = "none";

  document.getElementById('insert_promotion_description').style.border = "1px solid #666666";
  document.getElementById('insert_description_error').innerHTML = "";
  document.getElementById('insert_promotion_start_date').style.border = "1px solid #666666";
  document.getElementById('insert_start_date_error').innerHTML = "";
  document.getElementById('insert_promotion_end_date').style.border = "1px solid #666666";
  document.getElementById('insert_end_date_error').innerHTML = "";
  document.getElementById('insert_promotion_status').style.border = "1px solid #666666";
  document.getElementById('insert_status_error').innerHTML = "";

  document.getElementById('promotion_product_details').innerHTML = "";
  document.getElementById('promotion_product_type').value = "0";
  document.getElementById('promotion_product_type').style.border = "1px solid #666666";
  document.getElementById('insert_product_type_error').innerHTML = "";

  document.getElementById('insert_promotion_description').value = "";
  document.getElementById('insert_promotion_start_date').value = "";
  document.getElementById('insert_promotion_end_date').value = "";
  document.getElementById('insert_promotion_status').value = "0";

  temp_add_promotion_product_type = 0;
  temp_add_product_id = "";
  temp_add_promotion_price = "";
}


function add_select_product_popup(){
  promotion_description_validation("add");
  promotion_insert_start_date_validation();
  promotion_insert_end_date_validation();
  promotion_status_validation("add");


  if(valid_description == "true" && valid_insert_start_date == "true" && valid_insert_end_date == "true" && valid_status == "true"){
    document.getElementById('add_new_promotion_wrap').style.display = "none";
    document.getElementById('select_promotion_product_wrap').style.display = "block";

    //incase admin choose product type then go back change promotion date (update the product list price incase got other prmotion)
    if(temp_add_promotion_product_type != 0){
      get_product("add");
    }
  }
}


function get_product(select){
  if(select == "add"){
    var operation = "get_product_list";
    var row = " ";

    var product_type = document.getElementById('promotion_product_type').value;
    var start_date = document.getElementById("insert_promotion_start_date").value;
    var end_date = document.getElementById("insert_promotion_end_date").value;

    $.ajax({
      url: "function/promotion.php",
      type: "POST",
      dataType: "json",
      data: {
        'operation': operation,
        'product_type': product_type,
        'start_date': start_date,
        'end_date': end_date
      },
      success: function(data){
  
        for(var x=0; x<data.length; x++){
          var product_id = data[x].product_id;
          var product_name = data[x].product_name;
          var product_price = parseFloat(data[x].product_price);
          var found_promotion = data[x].found_promotion;

          if(found_promotion == "true"){
            var found_promotion_display = "Found other promotion between this period";
            var promotion_price = parseFloat(data[x].promotion_price);
            promotion_price = "RM" + promotion_price.toFixed(2);
            var old_price_tag = "old_price_tag";
            var new_price_tag = "new_price_tag";
          }
          else{
            var found_promotion_display = "";
            var promotion_price = "";
            var old_price_tag = "";
            var new_price_tag = "";
          }

          row +=  "<tr class='promotion_product_row'>" +
                    "<td><input type='checkbox' class='select_promotion_product_checkbox' id='select_promotion_product_checkbox" + (x+1) + "' onclick='select_promotion_product(" + (x+1) + ")'></td>" +
                    "<td>" + (x+1) + "</td>" +
                    "<td>" + product_id + "<input type='hidden' id='product_id" + (x+1) + "' value='" + product_id + "'></td>" +
                    "<td>" + product_name + "</td>" +
                    "<td><span class='" + old_price_tag + "'>RM" + product_price.toFixed(2) + "</span><span class='"+new_price_tag+"'> "+promotion_price+"</span><input type='hidden' id='product_ori_price" + (x+1) + "' value='" + product_price.toFixed(2) + "'></td>" +
                    "<td>RM <input type='number' class='promotion_price_input_box' id='promotion_price_input_box" + (x+1) + "' min='1' onblur='promotion_discount_price_validation(" + (x+1) + ")' oninput='add_check_first_number(" + (x+1) + "); validate(this);' placeholder='Promotion Price' onkeypress='return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46' disabled><div id='add_discount_price_error" + (x+1) + "' class='add_discount_price_error'></div></td>" +
                    "<td class='found_promotion_display'>" + found_promotion_display + "</td>" +
                  "</tr>";
        }

        document.getElementById('promotion_product_details').innerHTML = row;



        //incase admin choose product type then go back change promotion date (update the product list price incase got other prmotion)
        if(temp_add_promotion_product_type != 0){
          var total_row = document.querySelectorAll('.promotion_price_input_box').length;

          current_checked = 0;

          for(var i=1; i<=total_row; i++){
            var checkbox = document.getElementById('select_promotion_product_checkbox'+i);
            var pro_id = document.getElementById('product_id'+i).value;
            var dis_price = document.getElementById('promotion_price_input_box'+i).value;

            if(pro_id == temp_add_product_id[i-1]){
              checkbox.checked = true;
              current_checked++;
              document.getElementById('promotion_price_input_box'+i).value = temp_add_promotion_price[i-1];
              document.getElementById('promotion_price_input_box'+i).disabled = false;
            }
          }

          check_all_add_new_discount_price();
        }

      },
    });

    document.getElementById('check_all').checked = false;
    check_product_type();
  }
}


function checkall(source){
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    var total_check_box = document.querySelectorAll('.select_promotion_product_checkbox').length;

    for (var i = 0; i < checkboxes.length; i++){
        if (checkboxes[i] != source){
          checkboxes[i].checked = source.checked;

          if(source.checked == true){
            current_checked = total_check_box;
            document.getElementById('promotion_price_input_box'+i).disabled = false;
          }
          else{
            current_checked = 0;
            document.getElementById('promotion_price_input_box'+i).value = "";
            document.getElementById('promotion_price_input_box'+i).disabled = true;
            document.getElementById("add_discount_price_error"+i).innerHTML = "";
            document.getElementById("promotion_price_input_box"+i).style.border = "1px solid #666666";
          }
        }
    }
}

var current_checked=0;
function select_promotion_product(i){
    var checkbox = document.getElementById('select_promotion_product_checkbox'+i);
    
    if(checkbox.checked == true){
      document.getElementById('promotion_price_input_box'+i).disabled = false;
      current_checked++;
    }
    else{
      document.getElementById('promotion_price_input_box'+i).value = "";
      document.getElementById('promotion_price_input_box'+i).disabled = true;
      document.getElementById("add_discount_price_error"+i).innerHTML = "";
      document.getElementById("promotion_price_input_box"+i).style.border = "1px solid #666666";
      current_checked--;
    }

    var total_check_box = document.querySelectorAll('.select_promotion_product_checkbox').length;

    if(current_checked == total_check_box){
      document.getElementById("check_all").checked = true;
    }
    else{
      document.getElementById("check_all").checked = false;
    }
}


var valid_discount_price = "false";
function promotion_discount_price_validation(i){
    var promotion_price =  document.getElementById("promotion_price_input_box"+i).value;
    promotion_price = parseFloat(promotion_price);
    var error = document.getElementById("add_discount_price_error"+i);
    var error_border = document.getElementById("promotion_price_input_box"+i);
    var product_ori_price = document.getElementById("product_ori_price"+i).value;
    
    if(isNaN(promotion_price)){
      error.innerHTML = "Promotion price is required";
      error_border.style.border = "2px solid red";
      valid_discount_price = "false";
    }
    else if(promotion_price < 1){
      error.innerHTML = "Minimun price is RM1.00";
      error_border.style.border = "2px solid red";
      valid_discount_price = "false";
    }
    else if(promotion_price > product_ori_price){
      error.innerHTML = "Promotion price is greater than original price";
      error_border.style.border = "2px solid red";
      valid_discount_price = "false";
    }
    else if(promotion_price == product_ori_price){
      error.innerHTML = "Promotion price is equal with original price";
      error_border.style.border = "2px solid red";
      valid_discount_price = "false";
    }
    else{
      error.innerHTML = "";
      error_border.style.border = "1px solid #666666";
      valid_discount_price = "true";
    }
}


var valid_check_empty = "";
function check_all_add_new_discount_price(){
  var total_row = document.querySelectorAll('.promotion_price_input_box').length;


  for(var i=1; i<=total_row; i++){
    var checkbox = document.getElementById('select_promotion_product_checkbox'+i);

    if(checkbox.checked == true){
      var promotion_price =  document.getElementById("promotion_price_input_box"+i).value;
      promotion_price = parseFloat(promotion_price);
      var error = document.getElementById("add_discount_price_error"+i);
      var error_border = document.getElementById("promotion_price_input_box"+i);
      var product_ori_price = document.getElementById("product_ori_price"+i).value;

      
      if(isNaN(promotion_price)){
        error.innerHTML = "Promotion price is required";
        error_border.style.border = "2px solid red";
        valid_check_empty = "false";
      }
      else if(promotion_price < 1){
        error.innerHTML = "Minimun price is RM1.00";
        error_border.style.border = "2px solid red";
        valid_check_empty = "false";
      }
      else if(promotion_price > product_ori_price){
        error.innerHTML = "Promotion price is greater than original price";
        error_border.style.border = "2px solid red";
        valid_check_empty = "false";
      }
      else if(promotion_price == product_ori_price){
        error.innerHTML = "Promotion price is equal with original price";
        error_border.style.border = "2px solid red";
        valid_check_empty = "false";
      }
      else{
        error.innerHTML = "";
        error_border.style.border = "1px solid #666666";
        valid_check_empty = "true";
      }
    }
  }
}


var valid_promotion_product_type = "false";
function check_product_type(){
  var promotion_product_type = document.getElementById("promotion_product_type").value;
  var error = document.getElementById("insert_product_type_error");
  var error_border = document.getElementById("promotion_product_type");

  if(promotion_product_type == 0){
    error.innerHTML = "Promotion type is required";
    error_border.style.border = "2px solid red";
    valid_promotion_product_type = "false";
  }
  else{
    error.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_promotion_product_type = "true";
  }
}

var add_select_product_valid = "";
function check_add_select_product(){
  var total_row = document.querySelectorAll('.select_promotion_product_checkbox').length;
  add_select_product_valid = "false";

  for(var i=1; i<=total_row; i++){
    var checkbox = document.getElementById('select_promotion_product_checkbox'+i);

    if(checkbox.checked == true){
      add_select_product_valid = "true";
    }
  }
}


function add_promotion(){
  var operation = "add_promotion";
  check_all_add_new_discount_price();
  check_product_type();
  check_add_select_product();
  

  if(valid_check_empty == "true" && valid_promotion_product_type == "true" && add_select_product_valid == "true"){
    var promotion_description = document.getElementById("insert_promotion_description").value;
    var start_date = document.getElementById("insert_promotion_start_date").value;
    var end_date = document.getElementById("insert_promotion_end_date").value;
    var promotion_status = document.getElementById("insert_promotion_status").value;
    var promotion_product_type = document.getElementById("promotion_product_type").value;

    var product_id = [];
    var promotion_price = [];

    var total_row = document.querySelectorAll('.promotion_price_input_box').length;

    for(var i=1; i<=total_row; i++){
      var checkbox = document.getElementById('select_promotion_product_checkbox'+i);

      if(checkbox.checked == true){
        var pro_id = document.getElementById('product_id'+i).value;
        product_id.push(pro_id);
        var dis_price = document.getElementById('promotion_price_input_box'+i).value;
        promotion_price.push(dis_price);
      }
    }

    $.ajax({
      url: "function/promotion.php",
      type: "POST",
      data: {
        'operation': operation,
        'promotion_description': promotion_description,
        'start_date': start_date,
        'end_date': end_date,
        'promotion_status': promotion_status,
        'promotion_product_type': promotion_product_type,
        'product_id': product_id,
        'promotion_price': promotion_price
      },
      success: function(data){
        document.getElementById("add_success_alert_wrap").style.display = "block";

        setTimeout(function(){
          $('#add_success_alert_wrap').fadeOut('fast');
          window.location = "promotion.php";
        }, 1500);
      },
    });

    temp_add_promotion_product_type = 0;
    temp_add_product_id = "";
    temp_add_promotion_price = "";
  }
  else{
    document.getElementById("set_promotion_product_alert_wrap").style.display = "block";

    if(add_select_product_valid != "true"){
      document.getElementById("set_promotion_product_alert_contain").innerHTML = "Please select product for this promotion";
    }
    else if(valid_check_empty != "true"){
      document.getElementById("set_promotion_product_alert_contain").innerHTML = "Please fill in all promotion price";
    }

    setTimeout(function(){
      $('#set_promotion_product_alert_wrap').fadeOut('fast');
    }, 1500);
  }
}




var temp_add_promotion_product_type = 0;
var temp_add_product_id = "";
var temp_add_promotion_price = "";
function back_to_add_promotion_popup(){
	document.getElementById('select_promotion_product_wrap').style.display = "none";
	document.getElementById('add_new_promotion_wrap').style.display = "block";

  temp_add_promotion_product_type = document.getElementById("promotion_product_type").value;

  temp_add_product_id = [];
  temp_add_promotion_price = [];

  var total_row = document.querySelectorAll('.promotion_price_input_box').length;

  for(var i=1; i<=total_row; i++){
    var checkbox = document.getElementById('select_promotion_product_checkbox'+i);

    if(checkbox.checked == true){
      var pro_id = document.getElementById('product_id'+i).value;
      temp_add_product_id.push(pro_id);
      var dis_price = document.getElementById('promotion_price_input_box'+i).value;
      temp_add_promotion_price.push(dis_price);
    }
  }
}


var current_view_promotion_id = "";
var current_view_promotion_i = "";
function promotion_details_popup(promotion_id, i){
  var operation = "get_promotion_details";

  current_view_promotion_id = promotion_id;
  current_view_promotion_i = i;

	document.getElementById('promotion_details_wrap').style.display = "block";
  document.querySelector('body').style.overflow = "hidden";


  $.ajax({
      url: "function/promotion.php",
      type: "POST",
      dataType: "json",
      data: {
        'operation': operation,
        'promotion_id': promotion_id
      },
      success: function(data){
        document.getElementById('description_div').innerHTML = data[0].promotion_description;
        document.getElementById('start_date_div').innerHTML = data[0].promotion_start_date_1;
        document.getElementById('edit_promotion_start_date').value = data[0].promotion_start_date;
        document.getElementById('end_date_div').innerHTML = data[0].promotion_end_date_1;
        document.getElementById('edit_promotion_end_date').value = data[0].promotion_end_date;
        document.getElementById('status_div').innerHTML = data[0].status;

        if(data[0].status == "Expired"){
          document.getElementById("edit_promotion_status").disabled = true;
        }
        else{
           document.getElementById("edit_promotion_status").disabled = false;
        }
      },
    });
}


function close_promotion_details_popup(){
	if(edit_activity == 0){
		document.getElementById('promotion_details_wrap').style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}


var edit_activity = ""
function edit_promotion_details(){
	edit_activity = 1;
	document.getElementById('description_div').style.display = "none";
	document.getElementById('start_date_div').style.display = "none";
	document.getElementById('end_date_div').style.display = "none";
	document.getElementById('status_div').style.display = "none";

	document.getElementById('edit_promotion_description').style.display = "inline";
	document.getElementById('edit_promotion_start_date').style.display = "inline";
	document.getElementById('edit_promotion_end_date').style.display = "inline";
	document.getElementById('edit_promotion_status').style.display = "inline";

	document.getElementById('cancel_edit_promotion_details_btn').style.display = "block";
	document.getElementById('save_edit_promotion_details_btn').style.display = "block";
	document.getElementById('edit_promotion_details_btn').style.display = "none";

  var promotion_description = document.getElementById('description_div').innerHTML;
  var status = document.getElementById('status_div').innerHTML;

  document.getElementById('edit_promotion_description').value = promotion_description;
  document.getElementById('edit_promotion_status').value = status;
}




function cancel_edit_promotion_details(){
	edit_activity = 0;
	document.getElementById('description_div').style.display = "block";
	document.getElementById('start_date_div').style.display = "block";
	document.getElementById('end_date_div').style.display = "block";
	document.getElementById('status_div').style.display = "block";

	document.getElementById('edit_promotion_description').style.display = "none";
	document.getElementById('edit_promotion_start_date').style.display = "none";
	document.getElementById('edit_promotion_end_date').style.display = "none";
	document.getElementById('edit_promotion_status').style.display = "none";

	document.getElementById('cancel_edit_promotion_details_btn').style.display = "none";
	document.getElementById('save_edit_promotion_details_btn').style.display = "none";
	document.getElementById('edit_promotion_details_btn').style.display = "block";

  document.getElementById("edit_description_error").innerHTML = "";
  document.getElementById("edit_start_date_error").innerHTML = "";
  document.getElementById("edit_end_date_error").innerHTML = "";
  document.getElementById("edit_status_error").innerHTML = "";
  
  document.getElementById("edit_promotion_description").style.border = "1px solid #666666";
  document.getElementById("edit_promotion_start_date").style.border = "1px solid #666666";
  document.getElementById("edit_promotion_end_date").style.border = "1px solid #666666";
  document.getElementById("edit_promotion_status").style.border = "1px solid #666666";

 

  promotion_details_popup(current_view_promotion_id, current_view_promotion_i);
}


function save_edit_promotion_details(){
  var operation = "save_edit_promotion_details";

  var promotion_description = document.getElementById('edit_promotion_description').value;
  var promotion_start_date = document.getElementById('edit_promotion_start_date').value;
  var promotion_end_date = document.getElementById('edit_promotion_end_date').value;
  var promotion_status = document.getElementById('edit_promotion_status').value;

  promotion_edit_start_date_validation();
  promotion_edit_end_date_validation();
  promotion_description_validation('edit');
  promotion_status_validation('edit');

  if(valid_description == "true" && valid_edit_start_date == "true" && valid_edit_end_date == "true" && valid_status == "true"){
    $.ajax({
      url: "function/promotion.php",
      type: "POST",
      data:{
        'operation': operation,
        'current_view_promotion_id': current_view_promotion_id,
        'promotion_description': promotion_description,
        'promotion_start_date': promotion_start_date,
        'promotion_end_date': promotion_end_date,
        'promotion_status': promotion_status
      },
      success: function(data){  
        var new_start_date = promotion_start_date;
        new_start_date = new_start_date.split("-").reverse().join("-");

        var new_end_date = promotion_end_date;
        new_end_date = new_end_date.split("-").reverse().join("-");

        document.getElementById('promotion_description'+current_view_promotion_i).innerHTML = promotion_description;
        document.getElementById('promotion_start_date'+current_view_promotion_i).innerHTML = new_start_date;
        document.getElementById('promotion_end_date'+current_view_promotion_i).innerHTML = new_end_date;
        document.getElementById('promotion_status'+current_view_promotion_i).innerHTML = promotion_status;

        document.getElementById("edit_success_alert_wrap").style.display = "block";
        document.querySelector('body').style.overflow = "hidden";

        setTimeout(function(){
          $('#edit_success_alert_wrap').fadeOut('fast');
          cancel_edit_promotion_details();
        }, 1500);
      
        if(promotion_status == "Disable"){
          document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_enable");
          document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_expired");
          document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_waiting");
          document.getElementById("promotion_status"+current_view_promotion_i).classList.add("status_disable");
        }
        else if(promotion_status == "Enable"){
          var start_date = new Date($('#edit_promotion_start_date').val());
          dd = String(start_date.getDate()).padStart(2, '0');
          mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
          yyyy = start_date.getFullYear();
          start_date = yyyy + '-' + mm + '-' + dd;

          var today = new Date();
          var dd = String(today.getDate()).padStart(2, '0');
          var mm = String(today.getMonth() + 1).padStart(2, '0'); 
          var yyyy = today.getFullYear();
          today = yyyy + '-' + mm + '-' + dd; 

          if(start_date > today){
            document.getElementById('promotion_status'+current_view_promotion_i).innerHTML = "Waiting";
            document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_disable");
            document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_expired");
            document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_enable");
            document.getElementById("promotion_status"+current_view_promotion_i).classList.add("status_waiting");
          }
          else{
            document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_disable");
            document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_expired");
            document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_waiting");
            document.getElementById("promotion_status"+current_view_promotion_i).classList.add("status_enable");
            
          }
        }
        else if(promotion_status == "Expired"){
          document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_disable");
          document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_enable");
          document.getElementById("promotion_status"+current_view_promotion_i).classList.remove("status_waiting");
          document.getElementById("promotion_status"+current_view_promotion_i).classList.add("status_expired");    
        }
      }
    });
  }
}

var delete_promotion_id = "";
var delete_counter = "";
function delete_promotion(counter, promotion_id){
  delete_promotion_id = promotion_id;
  delete_counter = counter;
  document.getElementById("delete_confirm_wrap").style.display = "block";
  document.querySelector('body').style.overflow = "hidden";

  document.getElementById("delete_confirm_no").addEventListener("click", function(){
    document.getElementById("delete_confirm_wrap").style.display = "none";
    document.querySelector('body').style.overflow = "auto";
  });
}


function delete_promotion_confirm(){
  var operation = "delete_promotion";

  document.getElementById("delete_confirm_wrap").style.display = "none";
  document.querySelector('body').style.overflow = "auto";

  $.ajax({
    url: "function/promotion.php",
    type: "POST",
    data: {
      'operation': operation,
      'promotion_id': delete_promotion_id
    },
    success: function(){
      document.getElementById("promotion_row"+delete_counter).style.display = "none";
      document.getElementById("promotion_delete_status"+delete_counter).value = 1;
      filter_table();
    }
  });
}


function view_select_product_popup(){
  if(edit_activity == 0){
    document.getElementById('promotion_details_wrap').style.display = "none";
    document.getElementById('view_select_promotion_product_wrap').style.display = "block";

    var operation = "view_promotion_product_list";
    var row = "";
    var j=0;

    $.ajax({
      url: "function/promotion.php",
      type: "POST",
      dataType: "json",
      data: {
        'operation': operation,
        'current_view_promotion_id': current_view_promotion_id
      },
      success: function(data){
        var product_type = data[0].product_type;

        for(var x=0; x<data.length; x++){
          var product_id = data[x].product_id;
          var product_name = data[x].product_name;
          var product_current_price = parseFloat(data[x].product_current_price);
          var promotion_price = parseFloat(data[x].promotion_price);
          var set_promotion = data[x].set_promotion;
          var found_promotion = data[x].found_promotion;


          if(found_promotion == "true"){
            var found_promotion_display = "Found other promotion between this period";
            var other_promotion_price = parseFloat(data[x].other_promotion_price);
            other_promotion_price = "RM" + other_promotion_price.toFixed(2);
            var old_price_tag = "old_price_tag";
            var new_price_tag = "new_price_tag";
          }
          else{
            var found_promotion_display = "";
            var other_promotion_price = "";
            var old_price_tag = "";
            var new_price_tag = "";
          }


          if(set_promotion == "yes"){
            var checked = "checked";
            j++;
          }
          else{
            var checked = "";
            promotion_price = "";
          }

          row +=  "<tr class='view_promotion_product_row'>" + 
                    "<td><input type='checkbox' class='edit_product_checkbox' id='edit_product_checkbox"+(x+1)+"' "+checked+" disabled onclick='edit_select_promotion_product(" + (x+1) + ")'></td>" +
                    "<td>"+(x+1)+"</td>" +
                    "<td><span id='edit_target_product_id"+(x+1)+"'>"+product_id+"</span></td>" +
                    "<td>"+product_name+"</td>" +
                    "<td><span class='" + old_price_tag + "'>RM" + product_current_price.toFixed(2) + "</span><span class='"+new_price_tag+"'> "+other_promotion_price+"</span><input type='hidden' id='edit_product_ori_price"+(x+1)+"' value='"+product_current_price.toFixed(2)+"'></td>" +
                    "<td>RM<input type='number' id='edit_promotion_price"+(x+1)+"' class='edit_promotion_price_input_box' min='1' placeholder='Promotion Price' onblur='edit_promotion_discount_price_validation(" + (x+1) + ")' oninput='edit_check_first_number(" + (x+1) + "); validate(this);' onkeypress='return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46' value='"+promotion_price+"' disabled><div id='edit_discout_price_error"+(x+1)+"' class=edit_discout_price_error></div></td>" +
                    "<td class='found_promotion_display'>" + found_promotion_display + "</td>" +
                  "</tr>";
        }

        document.getElementById('view_promotion_product').innerHTML = row;
        document.getElementById('view_promotion_product_type').value = product_type;

        var total_row = document.querySelectorAll(".edit_promotion_price_input_box").length;

        if(j == total_row){
          document.getElementById('edit_promotion_check_all').checked = true;
        }

        current_checked = j;
      },
    });
  }
  else{
    document.getElementById("edit_error_alert_wrap").style.display = "block";
    document.querySelector('body').style.overflow = "hidden";

    setTimeout(function(){
      $('#edit_error_alert_wrap').fadeOut('fast');
    }, 1500);
  }
}



function edit_promotion_product(){
  edit_activity = 1;
  document.getElementById('cancel_edit_promotion_product_btn').style.display = "block";
  document.getElementById('save_edit_promotion_product_btn').style.display = "block";
  document.getElementById('edit_promotion_product_btn').style.display = "none";
  
  var total_row = document.querySelectorAll(".edit_promotion_price_input_box").length;

  for(var i=1; i<=total_row; i++){
    document.getElementById('edit_product_checkbox'+i).disabled = false;

    var checkbox =  document.getElementById('edit_product_checkbox'+i);
    if(checkbox.checked == true){
      document.getElementById('edit_promotion_price'+i).disabled = false;
    }
  }

  document.getElementById('edit_promotion_check_all').disabled = false;
}


function edit_select_promotion_product(i){
  var checkbox = document.getElementById('edit_product_checkbox'+i);
  
  if(checkbox.checked == true){
    document.getElementById('edit_promotion_price'+i).disabled = false;
    current_checked++;
  }
  else{
    document.getElementById('edit_promotion_price'+i).value = "";
    document.getElementById('edit_promotion_price'+i).disabled = true;
    document.getElementById("edit_discout_price_error"+i).innerHTML = "";
    document.getElementById("edit_promotion_price"+i).style.border = "1px solid #666666";
    current_checked--;
  }

  var total_check_box = document.querySelectorAll('.edit_promotion_price_input_box').length;

  if(current_checked == total_check_box){
    document.getElementById("edit_promotion_check_all").checked = true;
  }
  else{
    document.getElementById("edit_promotion_check_all").checked = false;
  }
}


function edit_checkall(source){
    var total_check_box = document.querySelectorAll('.edit_promotion_price_input_box').length;

    for (var i = 1; i <= total_check_box; i++){
      document.getElementById('edit_product_checkbox'+i).checked = source.checked;

      if(source.checked == true){
        current_checked = total_check_box;
        document.getElementById('edit_promotion_price'+i).disabled = false;
      }
      else{
        current_checked = 0;
        document.getElementById('edit_promotion_price'+i).value = "";
        document.getElementById('edit_promotion_price'+i).disabled = true;
        document.getElementById("edit_discout_price_error"+i).innerHTML = "";
        document.getElementById("edit_promotion_price"+i).style.border = "1px solid #666666";
      }
    }
}


var valid_edit_discount_price = "";
function edit_promotion_discount_price_validation(i){
    var promotion_price =  document.getElementById("edit_promotion_price"+i).value;
    promotion_price = parseFloat(promotion_price);
    var error = document.getElementById("edit_discout_price_error"+i);
    var error_border = document.getElementById("edit_promotion_price"+i);
    var edit_product_ori_price = document.getElementById("edit_product_ori_price"+i).value;

    
    if(isNaN(promotion_price)){
      error.innerHTML = "Promotion price is required";
      error_border.style.border = "2px solid red";
      valid_edit_discount_price = "false";
    }
    else if(promotion_price < 1){
      error.innerHTML = "Minimun price is RM1.00";
      error_border.style.border = "2px solid red";
      valid_edit_discount_price = "false";
    }
    else if(promotion_price > edit_product_ori_price){
      error.innerHTML = "Promotion price is greater than original price";
      error_border.style.border = "2px solid red";
      valid_edit_discount_price = "false";
    }
    else if(promotion_price == edit_product_ori_price){
      error.innerHTML = "Promotion price is equal with original price";
      error_border.style.border = "2px solid red";
      valid_edit_discount_price = "false";
    }
    else{
      error.innerHTML = "";
      error_border.style.border = "1px solid #666666";
      valid_edit_discount_price = "true";
    }
}


function cancel_edit_promotion_product(){
  edit_activity = 0;
  document.getElementById('cancel_edit_promotion_product_btn').style.display = "none";
  document.getElementById('save_edit_promotion_product_btn').style.display = "none";
  document.getElementById('edit_promotion_product_btn').style.display = "block";
  document.getElementById('edit_promotion_check_all').disabled = true;

  view_select_product_popup();
}


function save_edit_promotion_product(){
  var operation = "edit_promotion_product";
  edit_check_all_add_new_discount_price();
  check_edit_select_product();

  if(valid_check_edit_empty == "true" && edit_select_product_valid == "true"){
    var product_id = [];
    var promotion_price = [];

    var total_row = document.querySelectorAll('.edit_promotion_price_input_box').length;

    for(var i=1; i<=total_row; i++){
      var checkbox = document.getElementById('edit_product_checkbox'+i);

      if(checkbox.checked == true){
        var pro_id = document.getElementById('edit_target_product_id'+i).innerHTML;
        product_id.push(pro_id);
        var dis_price = document.getElementById('edit_promotion_price'+i).value;
        promotion_price.push(dis_price);
      }
    }

    $.ajax({
      url: "function/promotion.php",
      type: "POST",
      data: {
        'operation': operation,
        'product_id': product_id,
        'promotion_price': promotion_price,
        'current_view_promotion_id': current_view_promotion_id
      },
      success: function(data){
        console.log(data);
        document.getElementById("edit_success_alert_wrap").style.display = "block";

        setTimeout(function(){
          $('#edit_success_alert_wrap').fadeOut('fast');
          cancel_edit_promotion_product();
        }, 1500);
      },
    });
  }
  else{
    document.getElementById("edit_promotion_product_alert_wrap").style.display = "block";

    if(edit_select_product_valid != "true"){
      document.getElementById("edit_promotion_product_alert_wrap_contain").innerHTML = "Please select product for this promotion";
    }
    else if(valid_check_empty != "true"){
      document.getElementById("edit_promotion_product_alert_wrap_contain").innerHTML = "Please fill in all promotion price";
    }

    setTimeout(function(){
      $('#edit_promotion_product_alert_wrap').fadeOut('fast');
    }, 1500);
  }
}

var edit_select_product_valid = "false";
function check_edit_select_product(){
  var total_row = document.querySelectorAll('.edit_promotion_price_input_box').length;
  edit_select_product_valid = "false";

  for(var i=1; i<=total_row; i++){
    var checkbox = document.getElementById('edit_product_checkbox'+i);

    if(checkbox.checked == true){
      edit_select_product_valid = "true";
    }
  }
}


var valid_check_edit_empty = "";
function edit_check_all_add_new_discount_price(){
  var total_row = document.querySelectorAll('.edit_promotion_price_input_box').length;

  for(var i=1; i<=total_row; i++){
    var checkbox = document.getElementById('edit_product_checkbox'+i);

    if(checkbox.checked == true){
      var promotion_price =  document.getElementById("edit_promotion_price"+i).value;
      promotion_price = parseFloat(promotion_price);
      var error = document.getElementById("edit_discout_price_error"+i);
      var error_border = document.getElementById("edit_promotion_price"+i);
      var edit_product_ori_price = document.getElementById("edit_product_ori_price"+i).value;

      
      if(isNaN(promotion_price)){
        error.innerHTML = "Promotion price is required";
        error_border.style.border = "2px solid red";
        valid_check_edit_empty = "false";
      }
      else if(promotion_price < 1){
        error.innerHTML = "Minimun price is RM1.00";
        error_border.style.border = "2px solid red";
        valid_check_edit_empty = "false";
      }
      else if(promotion_price > edit_product_ori_price){
        error.innerHTML = "Promotion price is greater than original price";
        error_border.style.border = "2px solid red";
        valid_check_edit_empty = "false";
      }
      else if(promotion_price == edit_product_ori_price){
        error.innerHTML = "Promotion price is equal with original price";
        error_border.style.border = "2px solid red";
        valid_check_edit_empty = "false";
      }
      else{
        error.innerHTML = "";
        error_border.style.border = "1px solid #666666";
        valid_check_edit_empty = "true";
      }
    }
  }
}


function back_to_view_promotion_popup(){
	if(edit_activity == 0){
		document.getElementById('view_select_promotion_product_wrap').style.display = "none";
		document.getElementById('promotion_details_wrap').style.display = "block";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}	
}


var valid_description = "false";
function promotion_description_validation(select){
	if(select == "add"){
    	var description =  document.getElementById("insert_promotion_description").value;
    	var error = document.getElementById("insert_description_error");
    	var error_border = document.getElementById("insert_promotion_description");
	}
	else if(select == "edit"){
		description =  document.getElementById("edit_promotion_description").value;
  	error = document.getElementById("edit_description_error");
  	error_border = document.getElementById("edit_promotion_description");
	}
  

  if(description == ""){
    error.innerHTML = "Promotion Description is required";
    error_border.style.border = "2px solid red";
    valid_description = "false";
  }
  else{
    error.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_description = "true";
  }  
}


function calendar_date_validation(select){
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var yyyy = today.getFullYear();
  //to convert format YYYY/MM/DD
  today = yyyy + '-' + mm + '-' + dd;
  
  if(select == "edit"){
    start_date = new Date($('#edit_promotion_start_date').val());
    dd = String(start_date.getDate()).padStart(2, '0');
    mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
    yyyy = start_date.getFullYear();
    start_date = yyyy + '-' + mm + '-' + dd;

    end_date = new Date($('#edit_promotion_end_date').val());
    dd = String(end_date.getDate()).padStart(2, '0');
    mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
    yyyy = end_date.getFullYear();
    end_date = yyyy + '-' + mm + '-' + dd;

    document.getElementById("edit_promotion_start_date").max = end_date;
    document.getElementById("edit_promotion_end_date").min = start_date;
  }
}


var valid_edit_start_date = "false";
function promotion_edit_start_date_validation(){
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var maxyear = today.getFullYear() + 1;

  var max  = maxyear + '-' + mm + '-' + dd;
  //max date to set, one year apart from today's date

  var empty_start_date = document.getElementById("edit_promotion_start_date").value;
  var start_date = new Date($('#edit_promotion_start_date').val());
  var dd = String(start_date.getDate()).padStart(2, '0');
  var mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
  var start_date_yyyy = start_date.getFullYear();
  start_date = start_date_yyyy + '-' + mm + '-' + dd;

  var error = document.getElementById("edit_start_date_error");
  var error_border = document.getElementById("edit_promotion_start_date");

  var end_date = new Date($('#edit_promotion_end_date').val());
  dd = String(end_date.getDate()).padStart(2, '0');
  mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
  yyyy = end_date.getFullYear();
  end_date = yyyy + '-' + mm + '-' + dd;

  if(empty_start_date == ""){
      error.innerHTML = "Start Date is required";
      error_border.style.border = "2px solid red";
      valid_edit_start_date = "false";
  }
  else if(start_date_yyyy > 9999){
    error.innerHTML = "Year must be 4 digit";
    error_border.style.border = "2px solid red";
    valid_edit_start_date = "false";
  }
  else if(start_date > end_date){
    error.innerHTML = "Start date cannot be after End date";
    error_border.style.border = "2px solid red";
    valid_edit_start_date = "false";
  }  
  else if(end_date > max){
    error.innerHTML = "Start date cannot be more than one year from today";
    error_border.style.border = "2px solid red";
    valid_edit_start_date = "false";    
  }
  else{
    error.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_edit_start_date = "true";
  } 

  document.getElementById("edit_promotion_end_date").min = start_date;
}

function edit_end_date_check(){
  var selected_end_date = document.getElementById("edit_promotion_end_date").value;

  if(selected_end_date != ""){
    promotion_edit_end_date_validation();
  }
}

var valid_edit_end_date = "false";
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var maxyear = today.getFullYear() + 1;

  var max  = maxyear + '-' + mm + '-' + dd;
  //max date to set, one year apart from today's date

function promotion_edit_end_date_validation(){
  var empty_end_date =  document.getElementById("edit_promotion_end_date").value;
  var end_date = new Date($('#edit_promotion_end_date').val());
  var dd = String(end_date.getDate()).padStart(2, '0');
  var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
  var end_date_yyyy = end_date.getFullYear();
  end_date = end_date_yyyy + '-' + mm + '-' + dd;

  var error = document.getElementById("edit_end_date_error");
  var error_border = document.getElementById("edit_promotion_end_date");

  var start_date = new Date($('#edit_promotion_start_date').val());
  dd = String(start_date.getDate()).padStart(2, '0');
  mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
  yyyy = start_date.getFullYear();
  start_date = yyyy + '-' + mm + '-' + dd;
    //the format of start date is now YYYY/MM/DD

  if(empty_end_date == ""){
    error.innerHTML = "Start Date is required";
    error_border.style.border = "2px solid red";
    valid_edit_end_date = "false";
  }
  else if(end_date_yyyy > 9999){
    error.innerHTML = "Year must be 4 digit";
    error_border.style.border = "2px solid red";
    valid_edit_end_date = "false";
  }
  else if(end_date < start_date){
    error.innerHTML = "End date cannot be before Start date";
    error_border.style.border = "2px solid red";
    valid_edit_end_date = "false";
  }
  else if(end_date > max){
    error.innerHTML = "End date cannot be more than one year from today";
    error_border.style.border = "2px solid red";
    valid_edit_end_date = "false";    
  }
  else{
    error.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_edit_end_date = "true";
  } 

  document.getElementById("edit_promotion_start_date").max = end_date;
}


function edit_start_date_check(){
  var selected_start_date = document.getElementById("edit_promotion_start_date").value;

  if(selected_start_date != ""){
    promotion_edit_start_date_validation();
  }
}


function edit_date_check_status(){
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var yyyy = today.getFullYear();

  today = yyyy + '-' + mm + '-' + dd;


  var end_date =  new Date(document.getElementById("edit_promotion_end_date").value);
  var dd = String(end_date.getDate()).padStart(2, '0');
  var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
  var yyyy = end_date.getFullYear();
  end_date = yyyy + '-' + mm + '-' + dd;

  if(end_date < today){
    document.getElementById("edit_promotion_status").value = "Expired";
    document.getElementById("edit_promotion_status").disabled = true;  
  }
  else{
    document.getElementById("edit_promotion_status").value = "0";
    document.getElementById("edit_promotion_status").disabled = false;
  }


}


var valid_insert_start_date = "false";
function promotion_insert_start_date_validation(){
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var yyyy = today.getFullYear();
  var maxyear = today.getFullYear() + 1;

  var max  = maxyear + '-' + mm + '-' + dd;
  //max date to set, one year apart from today's date

  today = yyyy + '-' + mm + '-' + dd;
  //the format of today date is now YYYY/MM/DD

  var empty_start_date = document.getElementById("insert_promotion_start_date").value;
  var start_date = new Date($('#insert_promotion_start_date').val());
  var dd = String(start_date.getDate()).padStart(2, '0');
  var mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
  var start_date_yyyy = start_date.getFullYear();
  start_date = start_date_yyyy + '-' + mm + '-' + dd;

  var error = document.getElementById("insert_start_date_error");
  var error_border = document.getElementById("insert_promotion_start_date");

  var end_date = new Date($('#insert_promotion_end_date').val());
  var dd = String(end_date.getDate()).padStart(2, '0');
  var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
  var yyyy = end_date.getFullYear();
  end_date = yyyy + '-' + mm + '-' + dd;
  
  document.getElementById("insert_promotion_end_date").min = start_date;
  document.getElementById("insert_promotion_start_date").min = today;


  if(empty_start_date == ""){
    error.innerHTML = "Start date is required";
    error_border.style.border = "2px solid red";
    valid_insert_start_date = "false";
  }
  else if(start_date_yyyy > 9999){
    error.innerHTML = "Year must be 4 digit";
    error_border.style.border = "2px solid red";
    valid_insert_start_date = "false";
  }
  else if(start_date < today){
    error.innerHTML = "Date is over";
    error_border.style.border = "2px solid red";
    valid_insert_start_date = "false";
  }
  else if(start_date > end_date){
    error.innerHTML = "Start date cannot be after End date";
    error_border.style.border = "2px solid red";
    valid_insert_start_date = "false";
  }
  else if(start_date > max){
    error.innerHTML = "Start date cannot be more than one year from today";
    error_border.style.border = "2px solid red";
    valid_insert_start_date = "false";    
  }
  else{
    error.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_insert_start_date = "true";
  }
}

function insert_end_date_check(){
  var end_date = document.getElementById("insert_promotion_end_date").value;

  if(end_date != ""){
    promotion_insert_end_date_validation();
  }
}

  
var valid_insert_end_date = "false";
function promotion_insert_end_date_validation(){

  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); 
  var yyyy = today.getFullYear();
  var maxyear = today.getFullYear() + 1;

  var max  = maxyear + '-' + mm + '-' + dd;
  //max date to set, one year apart from today's date

  today = yyyy + '-' + mm + '-' + dd;
  //to convert format YYYY/MM/DD
  
  var empty_end_date =  document.getElementById("insert_promotion_end_date").value;
  var end_date = new Date($('#insert_promotion_end_date').val());
  var dd = String(end_date.getDate()).padStart(2, '0');
  var mm = String(end_date.getMonth() + 1).padStart(2, '0'); 
  var end_date_yyyy = end_date.getFullYear();
  end_date = end_date_yyyy + '-' + mm + '-' + dd;
  
  var error = document.getElementById("insert_end_date_error");
  var error_border = document.getElementById("insert_promotion_end_date");

  var start_date = new Date($('#insert_promotion_start_date').val());
  dd = String(start_date.getDate()).padStart(2, '0');
  mm = String(start_date.getMonth() + 1).padStart(2, '0'); 
  yyyy = start_date.getFullYear();
  start_date = yyyy + '-' + mm + '-' + dd;

  document.getElementById("insert_promotion_start_date").max = end_date;
  document.getElementById("insert_promotion_end_date").min = today; 


  if(empty_end_date == ""){
    error.innerHTML = "End Date is required";
    error_border.style.border = "2px solid red";
    valid_insert_end_date = "false";
  }
  else if(end_date_yyyy > 9999){
    error.innerHTML = "Year must be 4 digit";
    error_border.style.border = "2px solid red";
    valid_insert_end_date = "false";
  }
  else if(end_date < today){
    error.innerHTML = "Date is over";
    error_border.style.border = "2px solid red";
    valid_insert_end_date = "false";

  }
  else if(end_date < start_date)
  {
    error.innerHTML = "End date cannot be before Start date";
    error_border.style.border = "2px solid red";
    valid_insert_end_date = "false";
  }  
  else if(end_date > max){
    error.innerHTML = "End date cannot be more than one year from today";
    error_border.style.border = "2px solid red";
    valid_insert_end_date = "false";    
  }
  else{
    error.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_insert_end_date = "true";
  }
}

function insert_start_date_check(){
  var selected_start_date = document.getElementById("insert_promotion_start_date").value;

  if(selected_start_date != ""){
    promotion_insert_start_date_validation()
  }
}


var valid_status = "";
function promotion_status_validation(select){
  if(select == "add"){
    var status = document.getElementById("insert_promotion_status").value;
    var error_message = document.getElementById("insert_status_error");
    var error_border = document.getElementById("insert_promotion_status");
  }
  else{
    var status = document.getElementById("edit_promotion_status").value;
    var error_message = document.getElementById("edit_status_error");
    var error_border = document.getElementById("edit_promotion_status");
  }

  
  if(status == "0"){
    error_message.innerHTML = "Status is required.";
    error_border.style.border = "2px solid red";
    valid_status = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_status = "true";
  }
}

function filter_table(){
    var input = document.getElementById("search_promotion");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("promotion_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
      var delete_status = document.getElementById("promotion_delete_status"+i).value;
      if(delete_status == 0){
        if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
              tr[i].style.display = "";
              
              found_result++;
              if(found_result % 2 == 0){
                tr[i].style.background = "none";
              }
              else{
                tr[i].style.background = "#f2f2f2";
              }

              document.getElementById("table_number"+i).innerHTML = found_result;
          }
          else{
              tr[i].style.display = "none";
          }
      }
    }
}
