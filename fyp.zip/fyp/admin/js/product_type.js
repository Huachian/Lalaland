function close_insert_product_type(){
	document.getElementById("add_new_type_wrap").style.display = "none";

	var error_message = document.getElementById("insert_product_type_error").innerHTML = "";
	var error_border = document.getElementById("insert_product_type").style.border = "1px solid #666666";
    var error_message = document.getElementById("insert_type_prefix_error").innerHTML = "";
    var error_border = document.getElementById("insert_type_prefix").style.border = "1px solid #666666";
    document.getElementById("insert_type_prefix").value = "";
    document.getElementById("insert_product_type").value = "";
}

function close_product_type_details(){
	if(edit_activity == 0){
		document.getElementById("type_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

function add_product_type_popup(){
	document.getElementById("add_new_type_wrap").style.display = "block";
	document.querySelector("body").style.overflow = "auto";

	//show insert product error message div
	document.getElementById("insert_type_prefix_error").style.display = "block";
	document.getElementById("insert_product_type_error").style.display = "block";

	document.getElementById("add_new_type_details_box").scrollTop = 0;
}

var valid_product_type = "true";
function product_type_validation(select){
	var space = /^\s*$/;
	var pattern = /^[a-zA-Z\s]+$/;
	var product_type_id = document.getElementById("product_type_id").value;

    if(select == "add"){
    	var operation = "check_add_product_type";
    	var product_type= document.getElementById("insert_product_type").value;
    	var error_message = document.getElementById("insert_product_type_error");
    	var error_border = document.getElementById("insert_product_type");
  	}
  	else if(select == "edit"){
  		var operation = "check_edit_product_type";
  		product_type = document.getElementById("edit_product_type").value;
    	error_message = document.getElementById("edit_product_type_error");
    	error_border = document.getElementById("edit_product_type");
  	}

	$.ajax({
	    url: "function/product_type.php",
	    type: "POST",
	    data: {
	    	'operation' : operation,
	    	'product_type_id': product_type_id,
	    	'product_type': product_type
	    },
	    success: function(data){
	      if(data == 'yes'){
	        error_message.innerHTML = "There is an existing Type.";
	        error_border.style.border = "2px solid red";
	        valid_product_type = "false";
	      }
	      else if(product_type.match(space)){
	        error_message.innerHTML = "Type is required.";
	        error_border.style.border = "2px solid red";
	        valid_product_type = "false";
	      }
	      else if (product_type.match(pattern)){
	        error_message.innerHTML = "";
	    	error_border.style.border = "1px solid #666666";
	        valid_product_type = "true";
	      }
	      else{
	        error_message.innerHTML = "Please insert Type as only Alphabet.";
	        error_border.style.border = "2px solid red";
	        valid_product_type = "false";
	      }
	    },
  	});


}

var valid_product_type_prefix = "true";
function product_type_prefix_validation(select){
	var space = /^\s*$/;
	var product_type_id = document.getElementById("product_type_id").value;

    if(select == "add"){
    	var operation = "check_add_prefix";
    	var prefix= document.getElementById("insert_type_prefix").value;
    	var error_message = document.getElementById("insert_type_prefix_error");
    	var error_border = document.getElementById("insert_type_prefix");
  	}
  	else if(select == "edit"){
  		var operation = "check_edit_prefix";
  		prefix = document.getElementById("edit_type_prefix").value;
    	error_message = document.getElementById("edit_prefix_error");
    	error_border = document.getElementById("edit_type_prefix");
  	}

	$.ajax({
	    url: "function/product_type.php",
	    type: "POST",
	    data: {
	    	'product_type_id': product_type_id,
	    	'prefix': prefix,
	    	'operation' : operation
	    },
	    success: function(data){
	     if(data == 'yes'){
	        error_message.innerHTML = "There is an existing Prefix.";
	        error_border.style.border = "2px solid red";
	        valid_product_type_prefix = "false";
	     }
	     else if(prefix.match(space)){
	        error_message.innerHTML = "Prefix is required.";
		    error_border.style.border = "2px solid red";
		    valid_product_type_prefix = "false";
	     }
	     else{
		    error_message.innerHTML = "";
		    error_border.style.border = "1px solid #666666";
		    valid_product_type_prefix = "true";
			}
	    },
  	});
}

var current_view_type = "";
function show_type_details(product_type_id, i){
	var operation = "get_type_details";
	current_view_type = i;

	$.ajax({
		url: "function/product_type.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'product_type_id': product_type_id
		},
		success: function(data){
			document.getElementById("type_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			document.getElementById("product_type_id").value = data[0].product_type_id;
			document.getElementById("type_prefix").innerHTML = data[0].prefix;
			document.getElementById("product_type").innerHTML = data[0].product_type;

			document.getElementById("type_details_wrap_2").scrollTop = 0;
		}
	});
}

var edit_activity = "";
var current_type_prefix = "";
var current_product_type = "";
function edit_type(){
	edit_activity = 1;

	document.getElementById("edit_type_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	current_type_prefix = document.getElementById("type_prefix").innerHTML;
	current_product_type = document.getElementById("product_type").innerHTML;

	document.getElementById("edit_type_prefix").style.display = "inline";
	document.getElementById("edit_product_type").style.display = "inline";

	document.getElementById("edit_type_prefix").value = current_type_prefix;
	document.getElementById("edit_product_type").value = current_product_type;

	document.getElementById("type_prefix").style.display = "none";
	document.getElementById("product_type").style.display = "none";
}

function cancel_edit_type(){
	edit_activity = 0;
	document.getElementById("edit_type_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	var product_type_id = document.getElementById("product_type_id").value;

	var operation = "get_type_details";

	$.ajax({
		url: "function/product_type.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'product_type_id': product_type_id
		},
		success: function(data){
			document.getElementById("type_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			document.getElementById("type_prefix").innerHTML = data[0].prefix;
			document.getElementById("product_type").innerHTML = data[0].product_type;

			document.getElementById("type_details_wrap_2").scrollTop = 0;
		}
	});

	document.getElementById("edit_type_prefix").style.display = "none";
	document.getElementById("edit_product_type").style.display = "none";

	document.getElementById("type_prefix").style.display = "inline-block";
	document.getElementById("product_type").style.display = "inline-block";

	document.getElementById("edit_prefix_error").innerHTML = "";
    document.getElementById("edit_type_prefix").style.border = "1px solid #666666";
	document.getElementById("edit_product_type_error").innerHTML = "";
	document.getElementById("edit_product_type").style.border = "1px solid #666666";

}

function save_edit_type(){
	var operation = "save_edit";

	product_type_validation("edit");
	product_type_prefix_validation("edit");

	if(valid_product_type == "true" && valid_product_type_prefix == "true"){

		document.getElementById("edit_confirm_wrap").style.display = "block";

		var prefix = document.getElementById("edit_type_prefix").value;
		var product_type = document.getElementById("edit_product_type").value;

		document.getElementById("old_prefix_display").innerHTML = current_type_prefix;
		document.getElementById("new_prifix_display").innerHTML = prefix;

		document.getElementById("old_type_display").innerHTML = current_product_type;
		document.getElementById("new_type_display").innerHTML = product_type;

		document.getElementById("edit_confirm_no").addEventListener("click", function(){
			document.getElementById("edit_confirm_wrap").style.display = "none";
			cancel_edit_type();
		});

		document.getElementById("edit_confirm_yes").addEventListener("click", function(){
			document.getElementById("edit_confirm_wrap").style.display = "none";

			var fd = new FormData();

			var prefix = document.getElementById("edit_type_prefix").value;
			var product_type = document.getElementById("edit_product_type").value;
			var product_type_id = document.getElementById("product_type_id").value;

			fd.append('operation',operation);
			fd.append('product_type',product_type);
			fd.append('prefix',prefix);
			fd.append('product_type_id',product_type_id);
			fd.append('current_type_prefix',current_type_prefix);
			fd.append('current_product_type',current_product_type);


			document.getElementById("prefix"+current_view_type).innerHTML = prefix;
			document.getElementById("product_type"+current_view_type).innerHTML = product_type;
			document.getElementById("type_prefix").innerHTML = prefix;
			document.getElementById("product_type").innerHTML = product_type;
			$.ajax({
				url: "function/product_type.php",
				type: "POST",
				data: fd,
			    contentType: false,
			    processData: false,
			    success: function(data){
			        cancel_edit_type();

					document.getElementById("edit_success_alert_wrap").style.display = "block";

					setTimeout(function(){
						document.getElementById("edit_success_alert_wrap").style.display = "none";
					}, 1500);
			    }
			});
		});
	}
}


function add_product_type(){
	var operation = "add_type";

	product_type_validation("add");
	product_type_prefix_validation("add");

	if(valid_product_type == "true" && valid_product_type_prefix == "true"){
		var fd = new FormData();

		var product_type = document.getElementById("insert_product_type").value;
		var prefix = document.getElementById("insert_type_prefix").value;

		fd.append('operation',operation);
		fd.append('product_type',product_type);
		fd.append('prefix',prefix);

		$.ajax({
			url: "function/product_type.php",
			type: "POST",
			data: fd,
		    contentType: false,
		    processData: false,
		    success: function(data){
		        document.getElementById("add_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("add_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					window.location = "product_type.php";
				}, 1500);
		    }
		});
	}
}

var delete_type_id = "";
var delete_type_name = "";
var delete_counter = "";
function delete_type(counter, product_type_id, product_type){
	delete_type_id = product_type_id;
	delete_type_name = product_type;
	delete_counter = counter;

	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function delete_type_confirm(){
	var operation = "delete_type";

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/product_type.php",
		type: "POST",
		data: {
			'operation': operation,
			'product_type_id': delete_type_id,
			'product_type': delete_type_name
		},
		success: function(data){
			if(data == "found_product_under_type"){
				document.getElementById("found_exist_product_alert").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("found_exist_product_alert").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
				}, 1500);
			}
			else{
				document.getElementById("product_type_row"+delete_counter).style.display = "none";
				document.getElementById("type_delete_status"+delete_counter).value = 1;
				filter_table();
			}
		}
	});
}

function filter_table(){
    var input = document.getElementById("search_product");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("product_type_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
        var delete_status = document.getElementById("type_delete_status"+i).value;
		if(delete_status == 0){
			if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
				tr[i].style.display = "";

				found_result++;
				if(found_result % 2 == 0){
					tr[i].style.background = "none";
				}
				else{
					tr[i].style.background = "#f2f2f2";
				}

				document.getElementById("table_number"+i).innerHTML = found_result;
			}
			else{
				tr[i].style.display = "none";
			}
		}
    }
}