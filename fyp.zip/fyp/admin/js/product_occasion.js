function close_insert_product_occasion(){
	document.getElementById("add_new_occasion_wrap").style.display = "none";

	var error_message = document.getElementById("insert_product_occasion_error").innerHTML = "";
	var error_border = document.getElementById("insert_product_occasion").style.border = "1px solid #666666";
	document.getElementById("insert_product_occasion").value = "";
}

function close_product_occasion_details(){
	if(edit_activity == 0){
		document.getElementById("occasion_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

function add_product_occasion_popup(){
	document.getElementById("add_new_occasion_wrap").style.display = "block";
	document.querySelector("body").style.overflow = "auto";

	document.getElementById("insert_product_occasion_error").style.display = "block";

	document.getElementById("add_new_occasion_details_box").scrollTop = 0;
}

var valid_occasion = "true";
function edit_product_occasion_validation(){
	var operation = "check_exist_product_occasion";
  	var space = /^\s*$/;
  	var pattern = /^[a-zA-Z\s]+$/;
  	var occasions_id= document.getElementById("occasions_id").value;

	var occasions_name = document.getElementById("edit_occasion").value;
	var error_message = document.getElementById("edit_occasion_error");
	var error_border = document.getElementById("edit_occasion");

  	$.ajax({
	    url: "function/product_occasion.php",
	    type: "POST",
	    data: {
	    	'occasions_id': occasions_id,
	    	'occasions_name': occasions_name,
	    	'operation' : operation
	    },
	    success: function(data){
		    if(data == 'yes'){
		      error_message.innerHTML = "There is an existing Occasion.";
		      error_border.style.border = "2px solid red";
		      valid_occasion = "false";
		    }
			else if(occasions_name.match(space)){
			    error_message.innerHTML = "Occasion is required.";
			    error_border.style.border = "2px solid red";
			    valid_occasion = "false";
			}
			else if(occasions_name.match(pattern)){
			    error_message.innerHTML = "";
			    error_border.style.border = "1px solid #666666";
			    valid_occasion = "true";
		  	}
			else{
			    error_message.innerHTML = "Please insert Occasion as only Alphabet.";
			    error_border.style.border = "2px solid red";
			    valid_occasion = "false";
			}
	    },
  	});
}

function add_product_occasion_validation(){
	var operation = "check_exist_add_product_occasion";
  	var space = /^\s*$/;
  	var pattern = /^[a-zA-Z\s]+$/;

	var occasions_name= document.getElementById("insert_product_occasion").value;
	var error_message = document.getElementById("insert_product_occasion_error");
	var error_border = document.getElementById("insert_product_occasion");


  	$.ajax({
	    url: "function/product_occasion.php",
	    type: "POST",
	    data: {
	    	'occasions_name': occasions_name,
	    	'operation' : operation
	    },
	    success: function(data){
		    if(data == 'yes'){
		      error_message.innerHTML = "There is an existing Occasion.";
		      error_border.style.border = "2px solid red";
		      valid_occasion = "false";
		    }
			else if(occasions_name.match(space)){
			    error_message.innerHTML = "Occasion is required.";
			    error_border.style.border = "2px solid red";
			    valid_occasion = "false";
			}
			else if(occasions_name.match(pattern)){
			    error_message.innerHTML = "";
			    error_border.style.border = "1px solid #666666";
			    valid_occasion = "true";
		  	}
			else{
			    error_message.innerHTML = "Please insert Occasion as only Alphabet.";
			    error_border.style.border = "2px solid red";
			    valid_occasion = "false";
			}
	    },
  	});
}


var current_view_occasions = "";
function show_occasion_details(occasions_id, i){
	var operation = "get_occasions_details";
	current_view_occasions = i;

	$.ajax({
		url: "function/product_occasion.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'occasions_id': occasions_id
		},
		success: function(data){
			document.getElementById("occasion_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			document.getElementById("occasions_id").value = data[0].occasions_id;
			document.getElementById("occasion").innerHTML = data[0].occasions_name;

			document.getElementById("occasion_details_wrap_2").scrollTop = 0;
		}
	});
}

var edit_activity = "";
var current_occasion_name = "";
function edit_occasion(){
	edit_activity = 1;
	document.getElementById("edit_occasion_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	current_occasion_name = document.getElementById("occasion").innerHTML;

	document.getElementById("edit_occasion").style.display = "inline";

	document.getElementById("edit_occasion").value = current_occasion_name;

	document.getElementById("occasion").style.display = "none";
}

function cancel_edit_occasion(){
	edit_activity = 0;
	document.getElementById("edit_occasion_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	var occasions_id = document.getElementById("occasions_id").value;

	var operation = "get_occasions_details";

	$.ajax({
		url: "function/product_occasion.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'occasions_id': occasions_id
		},
		success: function(data){
			document.getElementById("occasion_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			document.getElementById("occasion").innerHTML = data[0].occasions_name;

			document.getElementById("occasion_details_wrap_2").scrollTop = 0;
		}
	});

	document.getElementById("edit_occasion").style.display = "none";

	document.getElementById("occasion").style.display = "inline-block";

	document.getElementById("edit_occasion_error").innerHTML = "";
    document.getElementById("edit_occasion").style.border = "1px solid #666666";

}

function save_edit_occasion(){
	var operation = "save_edit";

	edit_product_occasion_validation();

	if(valid_occasion == "true"){
		document.getElementById("edit_confirm_wrap").style.display = "block";

		var occasions_name = document.getElementById("edit_occasion").value;
		document.getElementById("old_occasion_display").innerHTML = current_occasion_name;
		document.getElementById("new_occasion_display").innerHTML = occasions_name;

		document.getElementById("edit_confirm_no").addEventListener("click", function(){
			document.getElementById("edit_confirm_wrap").style.display = "none";
			cancel_edit_occasion();
		});

		document.getElementById("edit_confirm_yes").addEventListener("click", function(){
			document.getElementById("edit_confirm_wrap").style.display = "none";
			var occasions_name = document.getElementById("edit_occasion").value;
			var occasions_id = document.getElementById("occasions_id").value;

			document.getElementById("product_occasion"+current_view_occasions).innerHTML = occasions_name;
			document.getElementById("occasion").innerHTML = occasions_name;
			$.ajax({
				url: "function/product_occasion.php",
				type: "POST",
				data: {
					'operation': operation,
					'occasions_name': occasions_name,
					'occasions_id': occasions_id,
					'current_occasion_name': current_occasion_name
				},
			    success: function(data){
			        cancel_edit_occasion();

					document.getElementById("edit_success_alert_wrap").style.display = "block";
					document.querySelector("body").style.overflow = "hidden";

					setTimeout(function(){
						document.getElementById("edit_success_alert_wrap").style.display = "none";
						document.querySelector("body").style.overflow = "auto";
					}, 1500);
			    }
			});
		});
	}
}


function add_product_occasions(){
	var operation = "add_occasions";

	
	add_product_occasion_validation();

	if(valid_occasion == "true"){
		var occasion = document.getElementById("insert_product_occasion").value;

		$.ajax({
			url: "function/product_occasion.php",
			type: "POST",
			data: {
				'operation': operation,
				'occasion': occasion
			},
		    success: function(data){
		        document.getElementById("add_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("add_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
					window.location = "product_occasion.php";
				}, 1500);
		    }
		});
	}
}

var delete_occasions_id = "";
var delete_occasions_name = "";
var delete_counter = "";
function delete_occasions(counter, occasions_id, occasions_name){
	delete_occasions_id = occasions_id;
	delete_occasions_name = occasions_name;
	delete_counter = counter;

	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function delete_occasions_confirm(){
	var operation = "delete_occasions";

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/product_occasion.php",
		type: "POST",
		data: {
			'operation': operation,
			'occasions_id': delete_occasions_id,
			'occasions_name': delete_occasions_name
		},
		success: function(data){
			if(data == "found_product_under_occasions"){
				document.getElementById("found_exist_product_alert").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("found_exist_product_alert").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
				}, 1500);
			}
			else{
				document.getElementById("product_occasion_row"+delete_counter).style.display = "none";
				document.getElementById("occasion_delete_status"+delete_counter).value = 1;
				filter_table();
			}
		}
	});
}

function filter_table(){
    var input = document.getElementById("search_product");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("product_occasion_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
        var delete_status = document.getElementById("occasion_delete_status"+i).value;
		if(delete_status == 0){
			if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
				tr[i].style.display = "";

				found_result++;
				if(found_result % 2 == 0){
					tr[i].style.background = "none";
				}
				else{
					tr[i].style.background = "#f2f2f2";
				}

				document.getElementById("table_number"+i).innerHTML = found_result;
			}
			else{
				tr[i].style.display = "none";
			}
		}
    }
}