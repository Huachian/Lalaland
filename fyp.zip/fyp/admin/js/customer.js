function show_access_password_pop_up()
{
	if(edit_activity == 0){
		document.getElementById("access_pass_wrap").style.display = "block";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
	
}

function close_access_password_pop_up()
{
	document.getElementById("access_pass_wrap").style.display = "none";
	document.getElementById("access_password_input").value = "";

	document.getElementById("confirm_btn").style.background = "#000000";
	document.getElementById("confirm_btn").innerHTML = "Confirm";
}

function confirm_access_pass()
{
	var operation = "check_password";

	var admin_id = document.getElementById("admin_id").value;
	var password = document.getElementById("access_password_input").value;

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		data: {
			'operation': operation,
			'admin_id': admin_id,
			'password': password
		},
		success: function(data){
			if(data == "valid"){
				get_customer_password_details();

				document.getElementById("access_pass_wrap").style.display = "none";
				document.getElementById("confirm_btn").style.background = "#000000";
				document.getElementById("confirm_btn").innerHTML = "Confirm";
			}
			else if(data == "not_superadmin"){
				document.getElementById("confirm_btn").style.background = "#e6176d";
				document.getElementById("confirm_btn").innerHTML = "No permission to access !";
			}
			else if(data == "not_valid"){
				document.getElementById("confirm_btn").style.background = "#e6176d";
				document.getElementById("confirm_btn").innerHTML = "Invalid Password !";
			}

			document.getElementById("access_password_input").value = "";
		}
	});
}

function update_enter_password_btn(){
	document.getElementById("confirm_btn").style.background = "#000000";
	document.getElementById("confirm_btn").innerHTML = "Confirm";
}

function get_customer_password_details(){
	var operation = "get_customer_password_details";

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		data: {
			'operation': operation,
			'current_view_customer_id': current_view_customer_id
		},
		success: function(data){
			document.getElementById("customer_pass_wrap").style.display = "block";
			document.getElementById("customer_password_input").value = data;

			var toggle = document.getElementById("toggle_customer_password_icon");
			var pass = document.getElementById("customer_password_input");
			pass.setAttribute("type","password");
		    toggle.classList.remove('customer_hide_pass_icon')
		    toggle.classList.add('customer_show_pass_icon');
		}
	});
}

var edit_password_activity = "";
function edit_admin_pass()
{
	edit_password_activity = "true";

	document.getElementById("customer_password_input").disabled = false;
	document.getElementById("edit_customer_password_btn").style.display = "none";
	document.getElementById("cancel_edit_password_btn").style.display = "inline";
	document.getElementById("save_edit_password_btn").style.display = "inline";
}

function cancel_edit_pass()
{
	edit_password_activity = "false";

	document.getElementById("customer_password_input").disabled = true;
	document.getElementById("edit_customer_password_btn").style.display = "inline";
	document.getElementById("cancel_edit_password_btn").style.display = "none";
	document.getElementById("save_edit_password_btn").style.display = "none";

	document.getElementById("new_password_tick_icon").style.display = "none";
	document.getElementById("new_password_cross_icon").style.display = "none";
	document.getElementById("new_password_error_message").innerHTML="";
	document.getElementById("customer_password_input").style.border = "2px solid #f0f0f0";

	get_customer_password_details();
}

var edit_new_password_valid = "";
function new_password_guide(){
	document.getElementById("edit_password_format").style.display = "block";
	var password = document.getElementById("customer_password_input").value;
	document.getElementById("new_password_error_message").innerHTML="";

	if(password.length == 0){
		document.getElementById("edit_password_format").style.display = "none";
		var length_valid = "no";
	}
	else if(password.length >= 15){
		document.getElementById("edit_characters").style.color = "#00e600";
		document.getElementById("edit_characters").style.fontWeight = "bold";
		length_valid = "yes";
	}
	else{
		document.getElementById("edit_characters").style.color = "grey";
		document.getElementById("edit_characters").style.fontWeight = "normal";
		length_valid = "no";
	}

	if(password.match(/[0-9]/)){
		document.getElementById("edit_number").style.color = "#00e600";
		document.getElementById("edit_number").style.fontWeight = "bold";
		var number_valid = "yes";
	}
	else{
		document.getElementById("edit_number").style.color = "grey";
		document.getElementById("edit_number").style.fontWeight = "normal";
		number_valid = "no";
	}

	if(password.match(/[a-z]/)){
		document.getElementById("edit_small_letter").style.color = "#00e600";
		document.getElementById("edit_small_letter").style.fontWeight = "bold";
		var small_letter_valid = "yes";
	}
	else{
		document.getElementById("edit_small_letter").style.color = "grey";
		document.getElementById("edit_small_letter").style.fontWeight = "normal";
		small_letter_valid = "no";
	}

	if(password.match(/[A-Z]/)){
		document.getElementById("edit_upper_letter").style.color = "#00e600";
		document.getElementById("edit_upper_letter").style.fontWeight = "bold";
		var upper_letter_valid = "yes";
	}
	else{
		document.getElementById("edit_upper_letter").style.color = "grey";
		document.getElementById("edit_upper_letter").style.fontWeight = "normal";
		upper_letter_valid = "no";
	}

	if(password.match(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/)){
		document.getElementById("edit_symbol").style.color = "#00e600";
		document.getElementById("edit_symbol").style.fontWeight = "bold";
		var symbol_valid = "yes";
	}
	else{
		document.getElementById("edit_symbol").style.color = "grey";
		document.getElementById("edit_symbol").style.fontWeight = "normal";
		symbol_valid = "no";
	}

	if(length_valid == "yes" && number_valid == "yes" && small_letter_valid == "yes" && upper_letter_valid == "yes" && symbol_valid == "yes"){
		document.getElementById("new_password_tick_icon").style.display = "block";
		document.getElementById("new_password_cross_icon").style.display = "none";
		document.getElementById("new_password_error_message").innerHTML = "";
		edit_new_password_valid = "yes";
	}
	else{
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		edit_new_password_valid = "no";
	}
}

var edit_password_valid = "";
function edit_password_validation(){
	document.getElementById("edit_password_format").style.display = "none";

	var password = document.getElementById("customer_password_input").value;
	var space = /^\s*$/;


	if(password.match(space))
	{
		document.getElementById("new_password_error_message").innerHTML="New password is required.";
		document.getElementById("customer_password_input").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		edit_password_valid = "false";
	}
	else if(password.length < 15 || password.search(/[0-9]/) == -1 || password.search(/[a-z]/) == -1 || password.search(/[A-Z]/) == -1 || password.search(/[~\!\@\#\$\%\^\&\*\(\)\_\+\.\,\-\?\'\|\<\>\{\}\:\\\/]/) == -1){
		document.getElementById("new_password_error_message").innerHTML="Password format incorrect.";
		document.getElementById("customer_password_input").style.border = "2px solid red";
		document.getElementById("new_password_tick_icon").style.display = "none";
		document.getElementById("new_password_cross_icon").style.display = "block";
		edit_password_valid = "false";
	}
	else
	{
		document.getElementById("new_password_error_message").innerHTML="";
		document.getElementById("customer_password_input").style.border = "2px solid #f0f0f0";
		edit_password_valid = "true";
	}
}

function close_customer_pass()
{
	if(edit_password_activity == "true"){
		document.getElementById("edit_error_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
	else{
		document.getElementById("customer_pass_wrap").style.display = "none";
	}
}

function show_hide_customer_password(){
  var toggle = document.getElementById("toggle_customer_password_icon");
  var pass = document.getElementById("customer_password_input");

  if(pass.type === 'password')
  {
    pass.setAttribute("type","text");
    toggle.classList.remove('customer_show_pass_icon')
    toggle.classList.add('customer_hide_pass_icon');  
  }
  else
  {
    pass.setAttribute("type","password");
    toggle.classList.remove('customer_hide_pass_icon')
    toggle.classList.add('customer_show_pass_icon');
    
  }
}


function save_edit_pass(){
	var operation = "save_edit_customer_pass";

	edit_password_validation();

	if(edit_password_valid == "true"){
		var new_password = document.getElementById("customer_password_input").value;

		$.ajax({
			url: "function/customer.php",
			type: "POST",
			data: {
				'operation': operation,
				'current_view_customer_id': current_view_customer_id,
				'new_password': new_password
			},
		});

		document.getElementById("edit_success_alert_wrap").style.display = "block";

		setTimeout(function(){
			$('#edit_success_alert_wrap').fadeOut('fast');
			cancel_edit_pass();
		}, 1500);
	}
}


function close_admin_details(){
	if(edit_activity == 0){
		document.getElementById("admin_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}



function close_customer_details(){
	if(edit_activity == 0){
		document.getElementById("customer_details_wrap").style.display = "none";
		document.querySelector("body").style.overflow = "auto";
	}
	else{
		document.getElementById("edit_error_alert_wrap").style.display = "block";
		document.querySelector('body').style.overflow = "hidden";

		setTimeout(function(){
			$('#edit_error_alert_wrap').fadeOut('fast');
		}, 1500);
	}
}

var current_view_customer = "";
var current_view_customer_id = "";
function show_customer_details(customer_id, i){
	var operation = "get_customer_details";
	current_view_customer = i;
	current_view_customer_id = customer_id;

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'customer_id': customer_id
		},
		success: function(data){
			document.getElementById("customer_details_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";
			
			document.getElementById("customer_id").innerHTML = customer_id;
			document.getElementById("first_name").innerHTML = data[0].first_name;
			document.getElementById("last_name").innerHTML = data[0].last_name;
			document.getElementById("gender").innerHTML = data[0].gender;
			document.getElementById("phone").innerHTML = data[0].phone;
			document.getElementById("email").innerHTML = data[0].email;

			if(data[0].account_status == "inactive")
			{
				document.getElementById("status_msg").style.display = "block";
				document.getElementById("activate_btn").style.display = "inline-block";

			}
			else if (data[0].account_status == "inactive_admin") 
			{
				document.getElementById("status_msg").style.display = "block";
				document.getElementById("activate_btn").style.display = "none";
			}
			else
			{
				document.getElementById("status_msg").style.display = "none";
				document.getElementById("activate_btn").style.display = "none";
			}

			document.getElementById("customer_details_box").scrollTop = 0;
		}
	});
}

var edit_activity = 0;
function edit_customer_details(){
	edit_activity = 1;

	document.getElementById("edit_customer_details_btn").style.display = "none";
	document.getElementById("cancel_edit_details_btn").style.display = "inline";
	document.getElementById("save_edit_details_btn").style.display = "inline";

	var customer_id = document.getElementById("customer_id").innerHTML;
	var first_name = document.getElementById("first_name").innerHTML;
	var last_name = document.getElementById("last_name").innerHTML;
	var gender = document.getElementById("gender").innerHTML;
	var phone = document.getElementById("phone").innerHTML;
	var email = document.getElementById("email").innerHTML;

	document.getElementById("customer_id").style.display = "none";
	document.getElementById("first_name").style.display = "none";
	document.getElementById("last_name").style.display = "none";
	document.getElementById("gender").style.display = "none";
	document.getElementById("phone").style.display = "none";
	document.getElementById("email").style.display = "none";

	document.getElementById("edit_customer_id").value = customer_id;
	document.getElementById("edit_customer_first_name").value = first_name;
	document.getElementById("edit_customer_last_name").value = last_name;
	document.getElementById("edit_customer_gender").value = gender;
	document.getElementById("edit_customer_phone").value = phone;
	document.getElementById("edit_customer_email").value = email;

	document.getElementById("edit_customer_id").style.display = "inline";
	document.getElementById("edit_customer_first_name").style.display = "inline";
	document.getElementById("edit_customer_last_name").style.display = "inline";
	document.getElementById("edit_customer_gender").style.display = "inline";
	document.getElementById("edit_customer_phone").style.display = "inline";
	document.getElementById("edit_customer_email").style.display = "inline";

	//show edit details error message div
	document.getElementById("edit_fname_error").style.display = "block";
	document.getElementById("edit_lname_error").style.display = "block";
	document.getElementById("edit_phone_error").style.display = "block";
	document.getElementById("edit_email_error").style.display = "block";	
}

function cancel_edit_customer(){
	edit_activity = 0;
	document.getElementById("edit_customer_details_btn").style.display = "inline";
	document.getElementById("cancel_edit_details_btn").style.display = "none";
	document.getElementById("save_edit_details_btn").style.display = "none";

	var customer_id = document.getElementById("customer_id").innerHTML;

	var operation = "get_customer_details";

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		dataType: "json",
		data: {
			'operation': operation,
			'customer_id': customer_id
		},
		success: function(data){
			document.getElementById("first_name").innerHTML = data[0].first_name;
			document.getElementById("last_name").innerHTML = data[0].last_name;
			document.getElementById("gender").innerHTML = data[0].gender;
			document.getElementById("phone").innerHTML = data[0].phone;
			document.getElementById("email").innerHTML = data[0].email;

			document.getElementById("first_name"+current_view_customer).innerHTML = data[0].first_name;
			document.getElementById("last_name"+current_view_customer).innerHTML = data[0].last_name;
			document.getElementById("gender"+current_view_customer).innerHTML = data[0].gender;
			document.getElementById("phone"+current_view_customer).innerHTML = data[0].phone;
			document.getElementById("email"+current_view_customer).innerHTML = data[0].email;

			document.getElementById("customer_id").style.display = "inline";
			document.getElementById("first_name").style.display = "inline";
			document.getElementById("last_name").style.display = "inline";
			document.getElementById("gender").style.display = "inline";
			document.getElementById("phone").style.display = "inline";
			document.getElementById("email").style.display = "inline";

			document.getElementById("edit_customer_id").style.display = "none";
			document.getElementById("edit_customer_first_name").style.display = "none";
			document.getElementById("edit_customer_last_name").style.display = "none";
			document.getElementById("edit_customer_gender").style.display = "none";
			document.getElementById("edit_customer_phone").style.display = "none";
			document.getElementById("edit_customer_email").style.display = "none";

			document.getElementById("edit_fname_error").innerHTML = "";
	    	document.getElementById("edit_customer_first_name").style.border = "1px solid #666666";
			document.getElementById("edit_lname_error").innerHTML = "";
	    	document.getElementById("edit_customer_last_name").style.border = "1px solid #666666";
			document.getElementById("edit_phone_error").innerHTML = "";
	    	document.getElementById("edit_customer_phone").style.border = "1px solid #666666";
			document.getElementById("edit_email_error").innerHTML = "";
			document.getElementById("edit_customer_email").style.border = "1px solid #666666";
		}
	});


}

//Edit and Add customer validation starts

var valid_fname = "true";
function fname_validation(select)
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var fname = document.getElementById("").value;
    var error_message = document.getElementById("");
    var error_border = document.getElementById("");
  }
  else if(select == "edit"){
    fname = document.getElementById("edit_customer_first_name").value;
    error_message = document.getElementById("edit_fname_error");
    error_border = document.getElementById("edit_customer_first_name"); 
  }
  
  if(fname.match(space)){
    error_message.innerHTML = "First Name is required.";
    error_border.style.border = "2px solid red";
    valid_fname = "false";
  }
  else if(fname.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_fname = "true";
  }
  else{
    error_message.innerHTML = "Please enter name as only Alphabet.";
    error_border.style.border = "2px solid red";
    valid_fname = "false";
  }
}

var valid_lname = "true";
function lname_validation(select)
{
  var space = /^\s*$/;
  var pattern = /^[a-zA-Z\s]+$/;

  if(select == "add"){
    var lname = document.getElementById("").value;
    var error_message = document.getElementById("");
    var error_border = document.getElementById("");
  }
  else if(select == "edit"){
    lname = document.getElementById("edit_customer_last_name").value;
    error_message = document.getElementById("edit_lname_error");
    error_border = document.getElementById("edit_customer_last_name"); 
  }
  
  if(lname.match(space)){
    error_message.innerHTML = "Last Name is required.";
    error_border.style.border = "2px solid red";
    valid_lname = "false";
  }
  else if(lname.match(pattern)){
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_lname = "true";
  }
  else{
    error_message.innerHTML = "Please enter name as only Alphabet.";
    error_border.style.border = "2px solid red";
    valid_lname = "false";
  }
}

var valid_phone = "true";
function phone_validation(select)
{ 
  var space = /^\s*$/;
  var phonepattern = /^(\+?6?01)[0|1|2|3|4|6|7|8|9]\-*[0-9]{7,8}$/;

  if(select == "add"){
    var phoneNo = document.getElementById("").value;
    var error_message = document.getElementById("");
    var error_border = document.getElementById("");
  }
  else if(select == "edit"){
    phoneNo = document.getElementById("edit_customer_phone").value;
    error_message = document.getElementById("edit_phone_error");
    error_border = document.getElementById("edit_customer_phone"); 
  }


  if(phoneNo.match(space)){
    error_message.innerHTML = "Phone number is required.";
    error_border.style.border = "2px solid red";
    valid_phone = "false";
  }
  else if(!phoneNo.match(phonepattern) || phoneNo.length > 12){
    error_message.innerHTML = "Please enter a valid phone number.";
    error_border.style.border = "2px solid red";
    valid_phone = "false";
  }
  else{
    error_message.innerHTML = "";
    error_border.style.border = "1px solid #666666";
    valid_phone = "true";
  }
}

var email_valid = "true";
function email_validation(select){
	var operation = "check_exist_email";
	var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	var space = /^\s*$/;

	if(select == "add"){
		var email = document.getElementById("").value;
		var email_error = document.getElementById("");
		var error_border = document.getElementById("");
	}
	else if(select == "edit"){
		var customer_id = document.getElementById("customer_id").innerHTML;
		email = document.getElementById("edit_customer_email").value;
		email_error = document.getElementById("edit_email_error");
		error_border = document.getElementById("edit_customer_email");
	}

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		data: {
			'customer_id': customer_id,
			'email': email,
			'operation' : operation
		},
		success: function(data){
			if(data == "yes"){
				email_error.innerHTML = "This email has been use.";
				error_border.style.border = "2px solid red";
				email_valid = "false";
			}
			else if(email.match(space)){
				email_error.innerHTML = "Email address is required.";
				error_border.style.border = "2px solid red";
				email_valid = "false";
			}
			else if (email.match(pattern)){
				email_error.innerHTML = "";
				error_border.style.border = "1px solid #666666";
				email_valid = "true";
			}
			else{
				email_error.innerHTML = "Please enter valid email address.";
				error_border.style.border = "2px solid red";
				email_valid = "false";
			}
		},
	});
}

function save_edit_customer(){
	var operation = "update_edit_customer";
	
	fname_validation("edit");
	lname_validation("edit");
	phone_validation("edit");
	email_validation("edit");

	if(valid_fname == "true" && valid_lname == "true" && valid_phone == "true" && email_valid == "true"){
		edit_activity = 0;
		var customer_id = document.getElementById("customer_id").innerHTML;

		document.getElementById("edit_customer_details_btn").style.display = "inline";
		document.getElementById("cancel_edit_details_btn").style.display = "none";
		document.getElementById("save_edit_details_btn").style.display = "none";

		var first_name = document.getElementById("edit_customer_first_name").value;
		var last_name = document.getElementById("edit_customer_last_name").value;
		var gender = document.getElementById("edit_customer_gender").value;
		var phone = document.getElementById("edit_customer_phone").value;
		var email = document.getElementById("edit_customer_email").value;


		$.ajax({
			url: "function/customer.php",
			type: "POST",
			data: {
				'operation': operation,
				'customer_id': customer_id,
				'first_name': first_name,
				'last_name': last_name,
				'gender': gender,
				'phone': phone,
				'email': email
			},
			success: function(data){
		        cancel_edit_customer();

				document.getElementById("edit_success_alert_wrap").style.display = "block";
				document.querySelector("body").style.overflow = "hidden";

				setTimeout(function(){
					document.getElementById("edit_success_alert_wrap").style.display = "none";
					document.querySelector("body").style.overflow = "auto";
				}, 1500);
		    },
		});
	}
}

function activate_customer(){
	document.getElementById("activate_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("activate_confirm_no").addEventListener("click", function(){
		document.getElementById("activate_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function confirm_activate(){
	var operation = "activate_customer";

	document.getElementById("activate_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		data: {
			'operation': operation,
			'customer_id': current_view_customer_id
		},
		success: function(){
			document.getElementById("inactive_label"+current_view_customer).style.display = "none";
			document.getElementById("status_msg").style.display = "none";
			document.getElementById("activate_btn").style.display = "none";

			document.getElementById("edit_success_alert_wrap").style.display = "block";
			document.querySelector("body").style.overflow = "hidden";

			setTimeout(function(){
				document.getElementById("edit_success_alert_wrap").style.display = "none";
				document.querySelector("body").style.overflow = "auto";
			}, 1500);
		}
	});
}

var delete_counter = "";
var delete_customer_id = "";
function delete_customer(counter, customer_id){
	delete_counter = counter;
	delete_customer_id = customer_id;
	document.getElementById("delete_confirm_wrap").style.display = "block";
	document.querySelector('body').style.overflow = "hidden";

	document.getElementById("delete_confirm_no").addEventListener("click", function(){
		document.getElementById("delete_confirm_wrap").style.display = "none";
		document.querySelector('body').style.overflow = "auto";
	});
}

function delete_customer_confirm(){
	var operation = "delete_customer";

	document.getElementById("delete_confirm_wrap").style.display = "none";
	document.querySelector('body').style.overflow = "auto";

	$.ajax({
		url: "function/customer.php",
		type: "POST",
		data: {
			'operation': operation,
			'customer_id': delete_customer_id
		},
		success: function(){
			document.getElementById("inactive_label"+delete_counter).style.display = "block";
		}
	});
}

function filter_table(){
    var input = document.getElementById("search_customer");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("customer_table");
    var tr = table.getElementsByTagName("tr");

    var found_result = 0;

    for(var i = 1; i < tr.length; i++) {
    	if(tr[i].textContent.toUpperCase().indexOf(filter) > -1){
	        tr[i].style.display = "";
	        
	        found_result++;
	        if(found_result % 2 == 0){
	          tr[i].style.background = "none";
	        }
	        else{
	          tr[i].style.background = "#f2f2f2";
	        }

	        document.getElementById("table_number"+i).innerHTML = found_result;
	    }
	    else{
	        tr[i].style.display = "none";
	    }
    }
}