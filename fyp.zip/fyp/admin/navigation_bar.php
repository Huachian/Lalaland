<?php
	include ("dataconnection.php");
	$admin_id = $_SESSION["id"];
	$admin_position = $_SESSION["admin_position"];

	if($admin_position == "Admin"){
		$select_admin = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id = '$admin_id' ");
		$row = mysqli_fetch_assoc($select_admin);

		if($row['profile_picture'] == NULL){
			$profile_image_check = "false";
		}
		else{
			$profile_image_check = "true";
		}
	}

	if($admin_position == "Superadmin"){
		$select_superadmin = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id = '$admin_id' ");
		$row = mysqli_fetch_assoc($select_superadmin);

		if($row['profile_picture'] == NULL){
			$profile_image_check = "false";
		}
		else{
			$profile_image_check = "true";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/navigation_bar.css">
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<script src="https://kit.fontawesome.com/49f22bfabd.js" crossorigin="anonymous"></script>
</head>
<body>
	<div id="admin_top_navigation_wrap">
		<a href="index.php">
			<div id="easy_gift_logo">
				<img src="image/navigation_bar/easy_gift_big_logo.png">
			</div>
		</a>

		<div class="top_navigation_right_side">
			<div id="logout_btn_wrap">
				<form method="post">
					<button type="submit" name="logout">
						<i class="fas fa-sign-out-alt"></i>
						<span>Logout</span>
					</button>
				</form>
				<?php
					if(isset($_POST['logout'])){
						session_unset(); 
						session_destroy();
						header("location:../login_register.php");
					}
				?>
			</div>
		</div>
	</div>

	<?php
		if($admin_position == "Superadmin"){
			$select_admin_details = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$admin_id'");
			$admin_details = mysqli_fetch_assoc($select_admin_details);
		}
		else{
			$select_admin_details = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id='$admin_id'");
			$admin_details = mysqli_fetch_assoc($select_admin_details);
		}
	?>

	<div id="admin_side_navigation_wrap">
		<div id="admin_side_details_wrap">
			<div id="admin_side_details">
				<?php
					if($admin_details["profile_picture"] == ""){
						$admin_side_bar_picture = "disabled";
						$admin_side_bar_picture_empty = "";
					}
					else{
						$admin_side_bar_picture = "";
						$admin_side_bar_picture_empty = "disabled";
					}
				?>
				<div class="<?php echo $admin_side_bar_picture ?>" id="admin_side_bar_picture_wrap">
					<img src="image/admin_profile/<?php echo $admin_details["profile_picture"]; ?>" id="admin_side_bar_profile">
				</div>
				<div class="<?php echo $admin_side_bar_picture_empty ?>" id="admin_side_bar_picture_empty_wrap">
					<div id="admin_side_bar_picture_empty">
						<div>
							No Image
						</div>
					</div>
				</div>
				<div id="admin_side_name_wrap">
					<div id="admin_side_name"><span id="side_nav_admin_first_name"><?php echo $admin_details['first_name'] ?></span> <span id="side_nav_admin_last_name"><?php echo $admin_details['last_name'] ?></span></div>
					<div id="online_status_wrap">
						<div id="online_status_icon"></div>online
					</div>
				</div>
			</div>
		</div>

		<div id="side_bar_selection_wrap">
			<a href="index.php">
				<div class="side_bar_selection_row" id="dashboard_btn">
					<div class="side_bar_image_wrap">
						<i class="fas fa-tachometer-alt" id="dashboard_icon"></i>
					</div>
					<span id="dashboard_btn_title">Dashboard</span>
				</div>
			</a>
			<a href="order.php">
				<div class="side_bar_selection_row" id="order_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-file-alt" id="order_icon"></i>
					</div>
					<span id="order_btn_title">Order</span>
				</div>
			</a>
			<?php 
				if($admin_details['position'] == "Admin")
				{
					$sales_display="sales_hide";
				}
				else
				{
					$sales_display="side_bar_selection_row";
				}
			?>
			<a href="sales.php">
				<div class="<?php echo $sales_display ?>" id="sales_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-chart-bar" id="sales_icon"></i>
					</div>
					<span id="sales_btn_title">Sales</span>
				</div>
			</a>
			<a href="product.php">
				<div class="side_bar_selection_row" id="product_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-shopping-bag" id="product_icon"></i>
					</div>
					<span id="product_btn_title">Product</span>
				</div>
			</a>
			<a href="category.php">
				<div class="side_bar_selection_row" id="category_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-shopping-bag" id="category_icon"></i>
					</div>
					<span id="category_btn_title">Category</span>
				</div>
			</a>
			<a href="voucher.php">
				<div class="side_bar_selection_row" id="voucher_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-tag" id="voucher_icon"></i>
					</div>
					<span id="voucher_btn_title">Voucher</span>
				</div>
			</a>
			<a href="promotion.php">
				<div class="side_bar_selection_row" id="promotion_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-shopping-bag" id="promotion_icon"></i>
					</div>
					<span id="promotion_btn_title">Promotion</span>
				</div>
			</a>
			<a href="product_customization.php">
				<div class="side_bar_selection_row" id="custom_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-pencil-ruler" id="custom_icon"></i>
					</div>
					<span id="custom_btn_title">Customize</span>
				</div>
			</a>
			<a href="banner.php">
				<div class="side_bar_selection_row" id="banner_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="far fa-images" id="banner_icon"></i>
					</div>
					<span id="banner_btn_title">Banner</span>
				</div>
			</a>
			<a href="customer.php">
				<div class="side_bar_selection_row" id="customer_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-user" id="customer_icon"></i>
					</div>
					<span id="customer_btn_title">Customer</span>
				</div>
			</a>
			<a href="admin.php">
				<div class="side_bar_selection_row" id="admin_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-user-cog" id="admin_icon"></i>
					</div>
					<span id="admin_btn_title">Admin</span>
				</div>
			</a>
			<a href="admin_profile.php">
				<div class="side_bar_selection_row" id="profile_btn_wrap">
					<div class="side_bar_image_wrap">
						<i class="fas fa-cog" id="profile_icon"></i>
					</div>
					<span id="profile_btn_title">Profile</span>
				</div>
			</a>

		</div>
	</div>


	<div id="reminder_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<div class="close_btn">
					<?php  
					    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')   
					         $url = "https://";   
					    else  
					         $url = "http://";   
					    // Append the host(domain name, ip) to the URL.   
					    $url.= $_SERVER['HTTP_HOST'];   
					    
					    // Append the requested resource location to the URL   
					    $url.= $_SERVER['REQUEST_URI'];    
					?>  
					<form method="POST" action="<?php echo $url ?>">
						<input type="hidden" name="close_profile_remind">
						<button type="submit" id="close_profile_remind">
							<img src="image/admin/close_icon.png">
						</button>
					</form>
				</div>
				<div class="no_profile_icon">
					<img src="image/index/no_profile_pic_icon.png">
				</div>
				<div>
					It seems like you have not upload a Profile Image.
				</div>
				<div>
					<form method="POST" action="admin_profile.php">
						<input type="hidden" name="go_setting_profile">
						<button id="confirm_btn">
							Upload Now
						</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>

	<?php
		if(isset($_POST['close_profile_remind'])){
			$_SESSION["profile_pic_reminder_popup"] = "already_display";
		}

		if(isset($_SESSION["profile_pic_reminder_popup"]) || $profile_image_check == "true"){
	?>
			<script type="text/javascript">
				document.getElementById("reminder_wrap").style.display = "none";
			</script>
	<?php
		}
		else{
	?>		
			<script type="text/javascript">
				document.getElementById("reminder_wrap").style.display = "block";
			</script>
	<?php	
		}
	?>

	<script>
		//prevent form resubmit alert
	    if(window.history.replaceState){
	        window.history.replaceState(null, null, window.location.href);
	    }
	</script>
</html>