<?php
    session_start();

    if(!isset($_SESSION['id'])){
        header("Location: ../login_register.php");
    }

    if(isset($_SESSION['id'])){
        if($_SESSION["admin_position"] != "Superadmin"){
            header("Location: index.php");
        }
    }

    //include connection file 
    include("dataconnection.php");
    include('fpdf/fpdf.php');

    class PDF extends FPDF{
    function Header()
    {	
    	// Logo
        $this->Image('image/orders/easy_gift_big_logo.PNG',10,6,30);
        // Select Arial bold 15
        $this->SetFont('Arial','B',15);
        // Move to the right
        $this->Cell(60);
        // Framed title
        $this->Cell(80,10,'Order List',1,0,'C');
        // Line break
        $this->Ln(20);
    }

    function Footer()
    {
        // Go to 1.5 cm from bottom
        $this->SetY(-15);
        // Select Arial italic 8
        $this->SetFont('Arial','I',8);
        // Print centered page number
        $this->Cell(0,10,$this->PageNo(),0,0,'C');
    }
    }

    $display_heading = array('order_id'=>'Order ID', 'order_date'=> 'Order Date', 'total_amount'=> 'Total (RM)','status'=> 'Status','customer_remark'=> 'Customer Remark',);

    $result = mysqli_query($connect, "SELECT order_id, order_date, total_amount, status, customer_remark FROM orders") or die("database error:". mysqli_error($connect));
    $header = mysqli_query($connect, "SHOW columns FROM orders");

    $pdf = new PDF();
    // Move to left
    $pdf->SetLeftMargin(5);
    //header
    $pdf->AddPage('o');
    //footer page
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial','',11);
    foreach($display_heading as $heading) {
        $pdf->Cell(40,12,$heading,1);
    }
    foreach($result as $row) {
        $pdf->Ln();
    foreach($row as $column)
        $pdf->Cell(40,15,$column,1);
    }
    
    $pdf->Output();
?>