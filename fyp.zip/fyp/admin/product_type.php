<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/product_type.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/product_type.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/product_type.js"></script>
	<script src="https://kit.fontawesome.com/49f22bfabd.js" crossorigin="anonymous"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('category_btn_wrap').style.background = "#ffff4d";
		document.getElementById('category_btn_title').style.color = "black";
		document.getElementById('category_icon').style.color = "black";
	</script>
	<div class="type_main_wrap">
		<div class="type_second_wrap">
			<div class="back_btn_wrap">
				<a href="category.php"><button class="back_btn"><i class="fas fa-chevron-left"></i> Back</button></a>
			</div>
			<div class="type_page_title">
				Product Type
			</div>
			<div id="type_page_top_action_wrap">
				<div id="search_type_wrap">
					<input type="text" id="search_product" placeholder="Search Products" onkeyup="filter_table()">
				</div>
				<div id="product_type_page_top_btn_wrap">
					<button onclick="add_product_type_popup()">Add Type</button>
				</div>
			</div>

			<div id="product_type_display_wrap">
				<table id="product_type_table">
					<tr>
						<th id="product_no_column">
							No
						</th>
						<th id="product_type_prefix_column">
							Product ID Prefix
						</th>
						<th id="product_type_column">
							Product Type
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_product_type = mysqli_query($connect, "SELECT * FROM product_type ORDER BY product_type_id ASC");
						$i = 0;

						while($product_type_row = mysqli_fetch_assoc($select_product_type)){
							$i++;
					?>
							<tr class="product_type_row" id="product_type_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="type_delete_status<?php echo $i ?>" value="0">
								<td onclick="show_type_details('<?php echo $product_type_row['product_type_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td id="product_type_prefix_column" onclick="show_type_details('<?php echo $product_type_row['product_type_id'] ?>', '<?php echo $i ?>')">
									<span id="prefix<?php echo $i ?>"><?php echo $product_type_row['prefix'] ?></span>
								</td>
								<td id="product_type_column" onclick="show_type_details('<?php echo $product_type_row['product_type_id'] ?>', '<?php echo $i ?>')">
									<span id="product_type<?php echo $i ?>"><?php echo $product_type_row['product_type'] ?></span>
								</td>
								<td id="product_type_button_column">
									<button onclick="show_type_details('<?php echo $product_type_row['product_type_id']?>', '<?php echo $i ?>')">
										<img src="image/product_type/view_icon.png">
									</button>
									<button onclick="delete_type('<?php echo $i ?>', '<?php echo $product_type_row['product_type_id'] ?>', '<?php echo $product_type_row['product_type'] ?>')">
										<img src="image/product_type/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>

	<div id="type_details_wrap">
		<div id="type_details_wrap_2">
			<div id="type_details_title">
				Product Type Details
			</div>

			<div id="type_details_box">
				<button id="close_type_details_btn" onclick="close_product_type_details()">
					<img src="image/product_type/close_icon.png">
				</button>

				<table id="type_details_table">
					<tr>
						<input type="hidden" name="product_type_id" id="product_type_id">
						<td class="type_details_table_title">
							ID Prefix
						</td>
						<td class="type_details_table_contain">
							: <div id="type_prefix" class="details_contain"></div>
							<input type="text" name="edit_type_prefix" class="edit_type_input_box" id="edit_type_prefix" onblur="product_type_prefix_validation('edit')" >
							<div id="edit_prefix_error" class="edit_type_error"></div>
						</td>
					</tr>
					<tr>
						<td class="type_details_table_title">
							Type Name
						</td>
						<td class="type_details_table_contain">							
							: <div id="product_type" class="details_contain"></div>
							 <input type="text" name="edit_product_type" class="edit_type_input_box" id="edit_product_type" onblur="product_type_validation('edit')" >
							<div id="edit_product_type_error" class="edit_type_error"></div>
						</td>
					</tr>
				</table>
			</div>

			<div id="edit_type_action_button">
				<button id="edit_type_details_btn" onclick="edit_type()">
					<img src="image/product_type/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit_type()">
					<img src="image/product_type/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_type()">
					<img src="image/product_type/save_icon.png">
				</button>
			</div>

		</div>
	</div>

	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/tick_icon.png">
				<div>
					Product successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="add_new_type_wrap">
		<div id="add_new_type_wrap2">
			<div id="add_type_top_title">
				Add New Product Type
			</div>

			<div id="add_new_type_details_box">
				<button id="close_insert_type_btn" onclick="close_insert_product_type()">
				<img src="image/product_type/close_icon.png">
				</button>
				<div id="type_insert_row">
					<div class="type_insert_title">ID Prefix</div>
					<div class="details_contain_row">
						: <input type="text" name="insert_type_prefix" class="insert_type_input_box" id="insert_type_prefix" onblur="product_type_prefix_validation('add')" placeholder="Product Type ID Prefix">
						<div id="insert_type_prefix_error" class="insert_product_type_error"></div>
					</div>
				</div>
				<div id="type_insert_row">
					<div class="type_insert_title">Type Name</div>
					<div class="details_contain_row">
						: <input type="text" name="insert_product_type" class="insert_type_input_box" id="insert_product_type" onblur="product_type_validation('add')" placeholder="Type">
						<div id="insert_product_type_error" class="insert_product_type_error"></div>
					</div>
				</div>
							
			</div>
			<div id="add_product_type_action_button">
				<button onclick="add_product_type()">
					<img src="image/product_type/save_icon.png">
				</button>
			</div>
		</div>
	</div>

	<div id="add_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/tick_icon.png">
				<div>
					Product type successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="found_exist_product_alert" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/eror_icon.png">
				<div>
					Existing product found under this product type
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this product type?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_type_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="edit_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to change this product type?
				</div>
				<div id="edit_confirm_wrap_warning">
					**All of the product under this type will be involve**
				</div>
				<div style="text-align: center; margin-top: 20px;">
					<div>Product Type Id Prefix:</div>
					<div style="text-align: center;">
						<span id="old_prefix_display"></span> --> <span id="new_prifix_display"></span>
					</div>
				</div>
				<div style="text-align: center; margin-top: 15px;">
					<div>Type Name:</div>
					<div style="text-align: center;">
						<span id="old_type_display"></span> --> <span id="new_type_display"></span>
					</div>
				</div>
				<div id="delete_confirm_btn">
					<button id="edit_confirm_yes">Yes</button>
					<button id="edit_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

</body>
</html>