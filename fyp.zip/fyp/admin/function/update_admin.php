<?php
    session_start();
    include("../dataconnection.php");

    $operation = $_POST["operation"];
    $admin_id = $_SESSION['id'];
    $admin_position = $_SESSION["admin_position"];  

    if($operation == "update_profile"){
        $first_name = mysqli_real_escape_string($connect, $_POST["first_name"]);
        $last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
		$gender = mysqli_real_escape_string($connect, $_POST["gender"]);
        $phone_number = mysqli_real_escape_string($connect, $_POST["phone_number"]);
        $position = mysqli_real_escape_string($connect, $_POST["position"]);

        if($_FILES['profile_picture']["tmp_name"]){
            //img
            $targetDir = "../image/admin_profile/";
            $fileName = basename($_FILES["profile_picture"]["name"]);
            $targetFilePath = $targetDir . $fileName;
            $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

            $fileName = uniqid();
            $fileName .= ".".$fileType;
            $targetFilePath = $targetDir . $fileName;

            if($position == "Superadmin"){
                $result = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$admin_id'");
                $row = mysqli_fetch_assoc($result);
            }
            else{
                $result = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id='$admin_id'");
                $row = mysqli_fetch_assoc($result);
            }

            unlink("../image/admin_profile/".$row['profile_picture']);

            move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFilePath);

            if($position == "Superadmin"){
                mysqli_query($connect, "UPDATE superadmin SET profile_picture='$fileName', first_name='$first_name', last_name='$last_name', gender='$gender', phone='$phone_number' WHERE superadmin_id='$admin_id'");
            }
            else{
                mysqli_query($connect, "UPDATE admin SET profile_picture='$fileName', first_name='$first_name', last_name='$last_name', gender='$gender', phone='$phone_number' WHERE admin_id='$admin_id'");
            }
        }
        else{
            if($position == "Superadmin"){
                mysqli_query($connect, "UPDATE superadmin SET first_name='$first_name', last_name='$last_name', gender='$gender', phone='$phone_number' WHERE superadmin_id='$admin_id'");
            }
            else{
                mysqli_query($connect, "UPDATE admin SET first_name='$first_name', last_name='$last_name', gender='$gender', phone='$phone_number' WHERE admin_id='$admin_id'");
            }
        }
    }
	
	 if($operation == "update_password"){
        $current_password = mysqli_real_escape_string($connect, $_POST["current_password"]);
        $new_password = mysqli_real_escape_string($connect, $_POST["new_password"]);

        if($admin_position == "Superadmin"){
            $check_password = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$admin_id' AND password='$current_password'");
        }
        else{
            $check_password = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id='$admin_id' AND password='$current_password'");
        }

        $check_password_result = mysqli_num_rows($check_password);

        if($check_password_result > 0){
            if($current_password === $new_password){
                echo "password_same_with_old";
            }
            else{
                if($admin_position == "Superadmin"){
                    mysqli_query($connect, "UPDATE superadmin SET password='$new_password' WHERE superadmin_id='$admin_id'");
                }
                else{
                    mysqli_query($connect, "UPDATE admin SET password='$new_password' WHERE admin_id='$admin_id'");
                }
            
            echo "update_success";
            }
        }
        else{
            echo "update_fail";
        }  
    }


    if($operation == "check_password"){
        $admin_id = mysqli_real_escape_string($connect, $_POST["admin_id"]);
        $password = mysqli_real_escape_string($connect, $_POST["password"]);

        $result = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$admin_id' AND password='$password'");

        $result_count = mysqli_num_rows($result);

        if($result_count > 0){
            $row = mysqli_fetch_assoc($result);

            if($row['position'] == "Superadmin"){
                echo "valid";
            }
            else{
                echo "not_superadmin";
            }
        }
        else{
            echo "not_valid";
        }
    }
    

    if($operation == "get_admin_password_details"){
        $target_admin = mysqli_real_escape_string($connect, $_POST["current_view_admin_id"]);
        $position = mysqli_real_escape_string($connect, $_POST["position"]);

        if($position == "Superadmin"){
            $result = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$target_admin'");
            $row = mysqli_fetch_assoc($result);
        }
        else{
            $result = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id='$target_admin'");
            $row = mysqli_fetch_assoc($result);
        }

        echo $row['password'];
    }

    if($operation == "save_edit_admin_pass"){
        $target_admin = mysqli_real_escape_string($connect, $_POST["current_view_admin_id"]);
        $new_password = mysqli_real_escape_string($connect, $_POST["new_password"]);
        $position = mysqli_real_escape_string($connect, $_POST["position"]);

        $superadmin_result = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$target_admin'");
        $superadmin_row = mysqli_fetch_assoc($superadmin_result);
        $superadmin_email = $superadmin_row['email'];

        $admin_result = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id='$target_admin'");
        $admin_row = mysqli_fetch_assoc($admin_result);
        $admin_email = $admin_row['email'];


        if($position == "Superadmin"){
            if($superadmin_row['password'] != $new_password)
            {
                 require '../../phpmailer/PHPMailerAutoload.php';

                $mail = new PHPMailer;
                                // Enable verbose debug output

                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = "smtp.gmail.com";  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                $mail->Username = 'easygiftshop.malaysia@gmail.com';                 // SMTP username
                $mail->Password = 'easygiftfypproject';                           // SMTP password
                $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 465;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                    )
                    );                                    // TCP port to connect to
                $mail->setFrom('easygiftshop.malaysia@gmail.com', 'Easy Gift');
                $mail->addAddress($superadmin_email);     // Add a recipient

                $mail->addReplyTo('easygiftshop.malaysia@gmail.com', 'Easy Gift Admin');


                // Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Your Password Has Been Changed';
                $mail->Body    = "  <h1>
                                        <a href='http://localhost/fyp/index.php' style='color: black;'>
                                            <u>Easy Gift Store</u>
                                        </a>
                                    </h1>
                                    <div style='font-size: 20px; color:black;'>
                                        Your Password has been Changed
                                    </div>
                                    <div style='font-size: 15px; color:grey;'>
                                       Hello we are here to inform you that your password has been changed by the authority. Your new password is <span style='background-color: #b3ffff'>".$new_password."</span>.
                                    </div>
                                    <div style='margin-top: 60px; margin-bottom: 30px;'>
                                       <a href='".$_SERVER['SERVER_NAME']."/fyp/index.php'>Visit our store</a>
                                    </div>";

                $result=$mail->send();
            }
            mysqli_query($connect, "UPDATE superadmin SET password='$new_password' WHERE superadmin_id='$target_admin'");
        }
        else{
            if($admin_row['password'] != $new_password)
            {
                 require '../../phpmailer/PHPMailerAutoload.php';

                $mail = new PHPMailer;
                                // Enable verbose debug output

                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = "smtp.gmail.com";  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                $mail->Username = 'easygiftshop.malaysia@gmail.com';                 // SMTP username
                $mail->Password = 'easygiftfypproject';                           // SMTP password
                $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 465;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                    )
                    );                                    // TCP port to connect to
                $mail->setFrom('easygiftshop.malaysia@gmail.com', 'Easy Gift');
                $mail->addAddress($admin_email);     // Add a recipient

                $mail->addReplyTo('easygiftshop.malaysia@gmail.com', 'Easy Gift Admin');


                // Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Your Password Has Been Changed';
                $mail->Body    = "  <h1>
                                        <a href='http://localhost/fyp/index.php' style='color: black;'>
                                            <u>Easy Gift Store</u>
                                        </a>
                                    </h1>
                                    <div style='font-size: 20px; color:black;'>
                                        Your Password has been Changed
                                    </div>
                                    <div style='font-size: 15px; color:grey;'>
                                       Hello we are here to inform you that your password has been changed by the authority. Your new password is <span style='background-color: #b3ffff'>".$new_password."</span>.
                                    </div>
                                    <div style='margin-top: 60px; margin-bottom: 30px;'>
                                        <a href='".$_SERVER['SERVER_NAME']."/fyp/index.php'>Visit our store</a>
                                    </div>";

                $result=$mail->send();
            }
            mysqli_query($connect, "UPDATE admin SET password='$new_password' WHERE admin_id='$target_admin'");
        }
    }
?>