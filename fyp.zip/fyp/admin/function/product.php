<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_product_details"){
		$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);

		$select_product = mysqli_query($connect, "SELECT * FROM product where product_id='$product_id'");

		$data = array();
		while($product_row = mysqli_fetch_assoc($select_product)){
			$product_id = $product_row['product_id'];
			$product_image = $product_row["product_image"];
			$product_name = $product_row['product_name'];
			$product_price = $product_row['product_price'];
			$product_gender = $product_row['product_gender'];
			$product_type = $product_row['product_type'];
			$product_occasions = $product_row['product_occasions'];
			$product_description_1 = $product_row['product_description_1'];
			$product_description_2 = $product_row['product_description_2'];
			$product_stock = $product_row['product_stock'];
			$product_status = $product_row['product_status'];



			date_default_timezone_set("Asia/Kuala_Lumpur");
			$today_date = date("Y-m-d");
			$today_date = date_parse($today_date);

			$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

			$product_promotion_price = $product_price;
			$found_promotion = "false";

			if(mysqli_num_rows($check_promotion) != 0){
				while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
					$promotion_id = $check_promotion_row['promotion_id'];

					$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
					$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

					if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
						$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

						$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

						if(mysqli_num_rows($check_promotion_product) != 0){
							$found_promotion = "true";

							if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
								$product_promotion_price = $check_promotion_product_result['promotion_price'];
							}
						}
					}
				}
			}
			else{
				$found_promotion = "false";
				$product_promotion_price = "";
			}





		    $data[] = array("product_id" => $product_id,
		                    "product_image" => $product_image,
		                    "product_name" => $product_name,
		                    "product_price" => $product_price,
		                	"product_price" => $product_price,
		                	"product_gender" => $product_gender,
		                	"product_type" => $product_type,
		                	"product_occasions" => $product_occasions,
		                	"product_description_1" => $product_description_1,
		                	"product_description_2" => $product_description_2,
		                	"product_stock" => $product_stock,
		                	"product_status" => $product_status,
		                	"found_promotion" => $found_promotion,
		                	"product_promotion_price" => $product_promotion_price);
		}

		echo json_encode($data);
	}


	if($operation == "edit_product"){
		$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);
		$product_availability = mysqli_real_escape_string($connect, $_POST['product_availability']);
		$status = mysqli_real_escape_string($connect, $_POST['status']);
		$product_name = mysqli_real_escape_string($connect, $_POST['product_name']);
		$product_price = mysqli_real_escape_string($connect, $_POST['product_price']);
		$product_category = mysqli_real_escape_string($connect, $_POST['product_category']);
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$product_occasions = mysqli_real_escape_string($connect, $_POST['product_occasions']);
		$product_description_1 = mysqli_real_escape_string($connect, $_POST['product_description_1']);
		$product_description_2 = mysqli_real_escape_string($connect, $_POST['product_description_2']);

		if($_FILES['product_image']["tmp_name"]){
			//img
			$targetDir = "../image/product_image/";
			$fileName = basename($_FILES["product_image"]["name"]);
			$targetFilePath = $targetDir . $fileName;
			$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

			$fileName = uniqid();
			$fileName .= ".".$fileType;
			$targetFilePath = $targetDir . $fileName;

			$result = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
			$row = mysqli_fetch_assoc($result);

			unlink("../image/product_image/".$row['product_image']);

			move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFilePath);

			mysqli_query($connect, "UPDATE product SET product_image='$fileName', product_name='$product_name', product_price='$product_price', product_gender='$product_category', product_occasions='$product_occasions', product_description_1='$product_description_1', product_description_2='$product_description_2', product_stock='$product_availability', product_status='$status' WHERE product_id='$product_id'");
		}
		else{
			mysqli_query($connect, "UPDATE product SET product_name='$product_name', product_price='$product_price', product_gender='$product_category', product_occasions='$product_occasions', product_description_1='$product_description_1', product_description_2='$product_description_2', product_stock='$product_availability', product_status='$status' WHERE product_id='$product_id'");
		}	
	}


	if($operation == "get_product_id"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);


		$select_product_prefix = mysqli_query($connect, "SELECT * FROM product_type WHERE product_type='$product_type'");
		$product_prefix = mysqli_fetch_assoc($select_product_prefix);


		$select_last_product_id = mysqli_query($connect, "SELECT * FROM product WHERE product_type='$product_type' ORDER BY product_id desc");
		$check_empty_product = mysqli_num_rows($select_last_product_id);
		

		if($check_empty_product == 0){
			$product_id = $product_prefix['prefix']."001";
		}
		else{
			$last_product_id_row = mysqli_fetch_assoc($select_last_product_id);
			$last_product_id = $last_product_id_row['product_id'];

			$idd = str_replace($product_prefix['prefix'], "", $last_product_id); 
			$id = str_pad($idd + 1, 3, 0, STR_PAD_LEFT);   
			$product_id = $product_prefix['prefix'].$id;
		}

		echo $product_id;
	}


	if($operation == "add_product"){
		//img
		$targetDir = "../image/product_image/";
		$fileName = basename($_FILES["product_image"]["name"]);
		$targetFilePath = $targetDir . $fileName;
		$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

		$fileName = uniqid();
		$fileName .= ".".$fileType;
		$targetFilePath = $targetDir . $fileName;

		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);
		$product_name = mysqli_real_escape_string($connect, $_POST['product_name']);
		$product_price = mysqli_real_escape_string($connect, $_POST['product_price']);
		$product_gender = mysqli_real_escape_string($connect, $_POST['product_category']);
		$product_occasions = mysqli_real_escape_string($connect, $_POST['product_occasions']);
		$product_description_1 = mysqli_real_escape_string($connect, $_POST['product_description_1']);
		$product_description_2 = mysqli_real_escape_string($connect, $_POST['product_description_2']);
		$product_stock = mysqli_real_escape_string($connect, $_POST['product_availability']);
		$product_status = mysqli_real_escape_string($connect, $_POST['product_status']);

		move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFilePath);


		$result = mysqli_query($connect, "SELECT * FROM product_occasions WHERE occasions_name='$product_occasions'");
		$row = mysqli_fetch_assoc($result);
		$product_occasions_id = $row['occasions_id'];

		$result = mysqli_query($connect, "SELECT * FROM product_type WHERE product_type='$product_type'");
		$row = mysqli_fetch_assoc($result);
		$product_type_id = $row['product_type_id'];




		mysqli_query($connect, "INSERT INTO product (product_id, product_image, product_name, product_price, product_gender, product_type, product_occasions, product_description_1, product_description_2, product_stock, product_status, occasions_id, product_type_id) VALUES ('$product_id', '$fileName', '$product_name', '$product_price', '$product_gender', '$product_type', '$product_occasions', '$product_description_1', '$product_description_2', '$product_stock', '$product_status', '$product_occasions_id', '$product_type_id')");
	}


	if($operation == "delete_product"){
		$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);

		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
		$row = mysqli_fetch_assoc($result);
		$target_image = $row['product_image'];

		$result = mysqli_query($connect, "SELECT * FROM order_products WHERE product_image='$target_image'");
		$row_count = mysqli_num_rows($result);

		if($row_count == 0){
			unlink("../image/product_image/".$target_image);
		}

		mysqli_query($connect, "DELETE FROM shopping_cart where product_id='$product_id'");
		mysqli_query($connect, "DELETE FROM wish_list where product_id='$product_id'");
		mysqli_query($connect, "DELETE FROM promotion_products where product_id='$product_id'");
		mysqli_query($connect, "DELETE FROM product where product_id='$product_id'");
	}
?>