<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_admin_details"){
		$admin_id = mysqli_real_escape_string($connect, $_POST['admin_id']);
		$position = mysqli_real_escape_string($connect, $_POST['position']);

		if($position == "Superadmin"){
			$select_admin = mysqli_query($connect, "SELECT * FROM superadmin where superadmin_id='$admin_id'");
		}
		else{
			$select_admin = mysqli_query($connect, "SELECT * FROM admin where admin_id='$admin_id'");
		}

		$data = array();
		while($admin_row = mysqli_fetch_assoc($select_admin)){
			$profile_picture = $admin_row["profile_picture"];

			if(empty($profile_picture)){
				$profile_picture = "empty";
			}

			$first_name = $admin_row['first_name'];
			$last_name = $admin_row['last_name'];
			$gender = $admin_row['gender'];
			$email = $admin_row['email'];
			$phone = $admin_row['phone'];
			$position = $admin_row['position'];


		    $data[] = array("profile_picture" => $profile_picture,
		                    "first_name" => $first_name,
		                    "last_name" => $last_name,
		                    "gender" => $gender,
		                	"email" => $email,
		                	"phone" => $phone,
		                	"position" => $position);
		}

		echo json_encode($data);
	}


	if($operation == "check_exist_email"){
		$admin_id = mysqli_real_escape_string($connect, $_POST['admin_id']);
        $admin_email = mysqli_real_escape_string($connect, $_POST['email']);

        $check_email = mysqli_query($connect, "SELECT * FROM admin WHERE email='$admin_email'");
        $check_email_row = mysqli_num_rows($check_email);
        $email_result = mysqli_fetch_assoc($check_email);

        $check_email_1 = mysqli_query($connect, "SELECT * FROM superadmin WHERE email='$admin_email'");
        $check_email_row_1 = mysqli_num_rows($check_email_1);
        $email_result_1 = mysqli_fetch_assoc($check_email_1);

        $check_email_2 = mysqli_query($connect, "SELECT * FROM customer WHERE email='$admin_email'");
        $check_email_row_2 = mysqli_num_rows($check_email_2);
        
        if($check_email_row != 0 && $email_result['admin_id'] != $admin_id){
            echo "yes";
        }
        else if($check_email_row_1 != 0 && $email_result_1['admin_id'] != $admin_id){
            echo "yes";
        }
        else{
            if($check_email_row_2 != 0){
            	echo "yes";
            }
            else{
            	echo "no";
            }
        }
    }


    if($operation == "edit_admin"){
    	$admin_id = mysqli_real_escape_string($connect, $_POST['admin_id']);
    	$position = mysqli_real_escape_string($connect, $_POST['position']);
    	$first_name = mysqli_real_escape_string($connect, $_POST['first_name']);
    	$last_name = mysqli_real_escape_string($connect, $_POST['last_name']);
    	$phone = mysqli_real_escape_string($connect, $_POST['phone']);
    	$email = mysqli_real_escape_string($connect, $_POST['email']);
    	$gender = mysqli_real_escape_string($connect, $_POST['gender']);
    	$current_position = mysqli_real_escape_string($connect, $_POST['current_position']);

    	if($_FILES['profile_picture']["tmp_name"]){
			//img
			$targetDir = "../image/admin_profile/";
			$fileName = basename($_FILES["profile_picture"]["name"]);
			$targetFilePath = $targetDir . $fileName;
			$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

			$fileName = uniqid();
			$fileName .= ".".$fileType;
			$targetFilePath = $targetDir . $fileName;

			if($current_position == "Superadmin"){
				$result = mysqli_query($connect, "SELECT * FROM admin WHERE admin_id='$admin_id'");
				$row = mysqli_fetch_assoc($result);
			}
			else{
				$result = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$admin_id'");
				$row = mysqli_fetch_assoc($result);
			}

			unlink("../image/admin_profile/".$row['profile_picture']);

			move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFilePath);

			if($current_position == "Superadmin"){
				mysqli_query($connect, "UPDATE superadmin SET profile_picture='$fileName', first_name='$first_name', last_name='$last_name', gender='$gender', email='$email', phone='$phone', position='$position' WHERE superadmin_id='$admin_id'");
			}
			else{
				mysqli_query($connect, "UPDATE admin SET profile_picture='$fileName', first_name='$first_name', last_name='$last_name', gender='$gender', email='$email', phone='$phone', position='$position' WHERE admin_id='$admin_id'");
			}
		}
		else{
			if($current_position == "Superadmin"){
				mysqli_query($connect, "UPDATE superadmin SET first_name='$first_name', last_name='$last_name', gender='$gender', email='$email', phone='$phone', position='$position' WHERE superadmin_id='$admin_id'");
			}
			else{
				mysqli_query($connect, "UPDATE admin SET first_name='$first_name', last_name='$last_name', gender='$gender', email='$email', phone='$phone', position='$position' WHERE admin_id='$admin_id'");
			}
		}
    }


    if($operation == "get_new_admin_id"){
    	$position = mysqli_real_escape_string($connect, $_POST['position']);

    	if($position == "Superadmin"){
    		$select_last_admin_id = mysqli_query($connect, "SELECT * FROM superadmin ORDER BY superadmin_id desc");
			$last_admin_id_row = mysqli_fetch_assoc($select_last_admin_id);

			if(empty($last_admin_id_row)){
				$admin_id = "SUPERADMIN_0001";
			}
			else{
				$last_admin_id = $last_admin_id_row['superadmin_id'];
				$idd = str_replace("SUPERADMIN_0", "", $last_admin_id);
				$id = str_pad($idd + 1, 3, 0, STR_PAD_LEFT);
				$admin_id = "SUPERADMIN_0".$id;
			}
    	}
    	else{
    		$select_last_admin_id = mysqli_query($connect, "SELECT * FROM admin ORDER BY admin_id desc");
			$last_admin_id_row = mysqli_fetch_assoc($select_last_admin_id);

			if(empty($last_admin_id_row)){
				$admin_id = "ADMIN_0001";
			}
			else{
				$last_admin_id = $last_admin_id_row['admin_id'];
				$idd = str_replace("ADMIN_0", "", $last_admin_id);
				$id = str_pad($idd + 1, 3, 0, STR_PAD_LEFT);
				$admin_id = "ADMIN_0".$id;
			}
    	}

    	
		echo $admin_id;
    }


    if($operation == "add_admin"){
    	$admin_id = mysqli_real_escape_string($connect, $_POST['admin_id']);
    	$first_name = mysqli_real_escape_string($connect, $_POST['first_name']);
    	$last_name = mysqli_real_escape_string($connect, $_POST['last_name']);
    	$gender = mysqli_real_escape_string($connect, $_POST['gender']);
    	$email = mysqli_real_escape_string($connect, $_POST['email']);
    	$phone = mysqli_real_escape_string($connect, $_POST['phone']);
    	$password = mysqli_real_escape_string($connect, $_POST['password']);
    	$position = mysqli_real_escape_string($connect, $_POST['position']);
    	$current_login_id = mysqli_real_escape_string($connect, $_POST['current_login_id']);

    	if($_FILES['profile_picture']["tmp_name"]){
    		//img
			$targetDir = "../image/admin_profile/";
			$fileName = basename($_FILES["profile_picture"]["name"]);
			$targetFilePath = $targetDir . $fileName;
			$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

			$fileName = uniqid();
			$fileName .= ".".$fileType;
			$targetFilePath = $targetDir . $fileName;

			move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFilePath);

			if($position == "Superadmin"){
				mysqli_query($connect, "INSERT INTO superadmin (superadmin_id, profile_picture, first_name, last_name, gender, email, phone, password, position) VALUES ('$admin_id', '$fileName', '$first_name', '$last_name', '$gender', '$email', '$phone', '$password', '$position')");
			}
			else{
				mysqli_query($connect, "INSERT INTO admin (admin_id, profile_picture, first_name, last_name, gender, email, phone, password, position) VALUES ('$admin_id', '$fileName', '$first_name', '$last_name', '$gender', '$email', '$phone', '$password', '$position')");
			}
    	}
    	else{
    		if($position == "Superadmin"){
				mysqli_query($connect, "INSERT INTO superadmin (superadmin_id, first_name, last_name, gender, email, phone, password, position) VALUES ('$admin_id', '$first_name', '$last_name', '$gender', '$email', '$phone', '$password', '$position')");
			}
			else{
				mysqli_query($connect, "INSERT INTO admin (admin_id, first_name, last_name, gender, email, phone, password, position) VALUES ('$admin_id', '$first_name', '$last_name', '$gender', '$email', '$phone', '$password', '$position')");
			}
    	}
    }


    if($operation == "delete_admin"){
		$admin_id = mysqli_real_escape_string($connect, $_POST['admin_id']);
		$position = mysqli_real_escape_string($connect, $_POST['position']);

		if($position == "Superadmin"){
			mysqli_query($connect, "DELETE FROM superadmin where superadmin_id='$admin_id'");
		}
		else{
			mysqli_query($connect, "DELETE FROM admin where admin_id='$admin_id'");
		}
		
	}
?>