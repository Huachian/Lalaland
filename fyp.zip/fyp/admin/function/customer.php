<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];
    $admin_position = $_SESSION["admin_position"];
	if($operation == "get_customer_details"){
		$customer_id = mysqli_real_escape_string($connect, $_POST['customer_id']);

		$select_customer = mysqli_query($connect, "SELECT * FROM customer where customer_id='$customer_id'");

		$data = array();
		while($customer_row = mysqli_fetch_assoc($select_customer)){
			$first_name = $customer_row['first_name'];
			$last_name = $customer_row['last_name'];
			$email = $customer_row['email'];
			$gender = $customer_row['gender'];
			$phone = $customer_row['phone'];

            if($admin_position == "Admin"){
                if($customer_row['reset_token'] == "inactive"){
                    $account_status = "inactive_admin";
                }
                else{
                    $account_status = "active";
                }   
            }
            else{
                if($customer_row['reset_token'] == "inactive"){
                    $account_status = "inactive";
                }
                else{
                    $account_status = "active";
                }   
            }
            

		    $data[] = array("first_name" => $first_name,
		                    "last_name" => $last_name,
		                    "email" => $email,
		                    "gender" => $gender,
		                	"phone" => $phone,
                            "account_status" => $account_status);
		}

		echo json_encode($data);
	}


	if($operation == "check_exist_email"){
		$customer_id = mysqli_real_escape_string($connect, $_POST['customer_id']);
        $customer_email = mysqli_real_escape_string($connect, $_POST['email']);

        $check_email = mysqli_query($connect, "SELECT * FROM customer WHERE email='$customer_email'");
        $check_email_row = mysqli_num_rows($check_email);
        $email_result = mysqli_fetch_assoc($check_email);

        $check_email_1 = mysqli_query($connect, "SELECT * FROM superadmin WHERE email='$customer_email'");
        $check_email_row_1 = mysqli_num_rows($check_email_1);
        $email_result_1 = mysqli_fetch_assoc($check_email_1);

        $check_email_2 = mysqli_query($connect, "SELECT * FROM admin WHERE email='$customer_email'");
        $check_email_row_2 = mysqli_num_rows($check_email_2);
        
        if($check_email_row != 0 && $email_result['customer_id'] != $customer_id){
        	echo "yes";
        }
        else if($check_email_row_1 != 0){
            echo "yes";
        }
        else{
            if($check_email_row_2 != 0){
            	echo "yes";
            }
            else{
            	echo "no";
            }
        }
    }


    if($operation == "update_edit_customer"){
    	$customer_id = mysqli_real_escape_string($connect, $_POST['customer_id']);
    	$first_name = mysqli_real_escape_string($connect, $_POST['first_name']);
    	$last_name = mysqli_real_escape_string($connect, $_POST['last_name']);
    	$gender = mysqli_real_escape_string($connect, $_POST['gender']);
    	$phone = mysqli_real_escape_string($connect, $_POST['phone']);
    	$email = mysqli_real_escape_string($connect, $_POST['email']);

    	mysqli_query($connect, "UPDATE customer SET first_name='$first_name', last_name='$last_name',gender='$gender',phone='$phone',email='$email' WHERE customer_id='$customer_id'");
    }
    

    if($operation == "delete_customer"){
		$customer_id = mysqli_real_escape_string($connect, $_POST['customer_id']);

		mysqli_query($connect, "UPDATE customer SET reset_token='inactive' WHERE customer_id='$customer_id'");
	}


    if($operation == "check_password"){
        $admin_id = mysqli_real_escape_string($connect, $_POST["admin_id"]);
        $password = mysqli_real_escape_string($connect, $_POST["password"]);

        $result = mysqli_query($connect, "SELECT * FROM superadmin WHERE superadmin_id='$admin_id' AND password='$password'");

        $result_count = mysqli_num_rows($result);

        if($result_count > 0){
            $row = mysqli_fetch_assoc($result);

            if($row['position'] == "Superadmin"){
                echo "valid";
            }
            else{
                echo "not_superadmin";
            }
        }
        else{
            echo "not_valid";
        }
    }


    if($operation == "get_customer_password_details"){
        $target_customer = mysqli_real_escape_string($connect, $_POST["current_view_customer_id"]);

        $result = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$target_customer'");
        $row = mysqli_fetch_assoc($result);

        echo $row['password'];
    }

    if($operation == "save_edit_customer_pass"){
        $target_customer = mysqli_real_escape_string($connect, $_POST["current_view_customer_id"]);
        $new_password = mysqli_real_escape_string($connect, $_POST["new_password"]);

        $cus_result = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$target_customer'");
        $row = mysqli_fetch_assoc($cus_result);
        $cus_email = $row['email'];

        if($row['password'] != $new_password && $row['reset_token'] != "inactive")
        {
             require '../../phpmailer/PHPMailerAutoload.php';

            $mail = new PHPMailer;
                            // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = "smtp.gmail.com";  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'easygiftshop.malaysia@gmail.com';                 // SMTP username
            $mail->Password = 'easygiftfypproject';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;
            $mail->SMTPOptions = array(
                'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
                )
                );                                    // TCP port to connect to
            $mail->setFrom('easygiftshop.malaysia@gmail.com', 'Easy Gift');
            $mail->addAddress($cus_email);     // Add a recipient

            $mail->addReplyTo('easygiftshop.malaysia@gmail.com', 'Easy Gift Admin');


            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Your Password Has Been Changed';
            $mail->Body    = "  <h1>
                                    <a href='http://localhost/fyp/index.php' style='color: black;'>
                                        <u>Easy Gift Store</u>
                                    </a>
                                </h1>
                                <div style='font-size: 20px; color:black;'>
                                    Your Password has been Changed
                                </div>
                                <div style='font-size: 15px; color:grey;'>
                                   Hello we are here to inform you that your password has been changed by the authorities. Your new password is <span style='background-color: #b3ffff'>".$new_password."</span>. 
                                </div>
                                <div style='margin-top: 60px; margin-bottom: 30px;'>
                                    <a href='".$_SERVER['SERVER_NAME']."/fyp/index.php'>Visit our store</a>
                                </div>";

            $result=$mail->send();
        }

        mysqli_query($connect, "UPDATE customer SET password='$new_password' WHERE customer_id='$target_customer'");
    }

    if($operation == "activate_customer"){
        $customer_id = mysqli_real_escape_string($connect, $_POST["customer_id"]);

        mysqli_query($connect, "UPDATE customer SET reset_token=NULL WHERE customer_id='$customer_id'");
    }
?>