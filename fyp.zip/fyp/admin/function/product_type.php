<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_type_details"){
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);

		$select_type = mysqli_query($connect, "SELECT * FROM product_type WHERE product_type_id='$product_type_id'");

		while($prefix_row = mysqli_fetch_assoc($select_type)){
			$product_type_id = $prefix_row['product_type_id'];
			$prefix = $prefix_row['prefix'];
			$product_type = $prefix_row['product_type'];



		    $data[] = array("product_type_id" => $product_type_id,
		    				"prefix" => $prefix,
		               	 	"product_type" => $product_type);
		}

		echo json_encode($data);
	}

	if($operation == "save_edit"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$prefix = mysqli_real_escape_string($connect, $_POST['prefix']);
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);
		$current_type_prefix = mysqli_real_escape_string($connect, $_POST['current_type_prefix']);
		$current_product_type = mysqli_real_escape_string($connect, $_POST['current_product_type']);

		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_type='$current_product_type'");

		while($row = mysqli_fetch_assoc($result)){
			$pro_id = $row['product_id'];
			$pro_type = $row['product_type'];

			$new_pro_id = str_replace($current_type_prefix, $prefix, $pro_id);
			mysqli_query($connect, "UPDATE product SET product_type='$product_type', product_id='$new_pro_id' WHERE product_id='$pro_id'");
		}


		$result = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE product_id LIKE '%$current_type_prefix%'");

		while($row = mysqli_fetch_assoc($result)){
			$pro_id = $row['product_id'];

			$new_pro_id = str_replace($current_type_prefix, $prefix, $pro_id);
			mysqli_query($connect, "UPDATE shopping_cart SET product_id='$new_pro_id' WHERE product_id='$pro_id'");
		}


		$result = mysqli_query($connect, "SELECT * FROM wish_list WHERE product_id LIKE '%$current_type_prefix%'");

		while($row = mysqli_fetch_assoc($result)){
			$pro_id = $row['product_id'];

			$new_pro_id = str_replace($current_type_prefix, $prefix, $pro_id);
			mysqli_query($connect, "UPDATE wish_list SET product_id='$new_pro_id' WHERE product_id='$pro_id'");
		}


		$result = mysqli_query($connect, "SELECT * FROM promotion WHERE promotion_product_type='$current_product_type'");

		while($row = mysqli_fetch_assoc($result)){
			mysqli_query($connect, "UPDATE promotion SET promotion_product_type='$product_type' WHERE promotion_product_type='$current_product_type'");
		}


		$result = mysqli_query($connect, "SELECT * FROM promotion_products WHERE product_id LIKE '%$current_type_prefix%'");

		while($row = mysqli_fetch_assoc($result)){
			$pro_id = $row['product_id'];

			$new_pro_id = str_replace($current_type_prefix, $prefix, $pro_id);
			mysqli_query($connect, "UPDATE promotion_products SET product_id='$new_pro_id' WHERE product_id='$pro_id'");
		}


		mysqli_query($connect, "UPDATE product_type SET product_type='$product_type', prefix='$prefix' WHERE product_type_id='$product_type_id'");	
	}

	if($operation == "add_type"){

		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$prefix = mysqli_real_escape_string($connect, $_POST['prefix']);

		mysqli_query($connect, "INSERT INTO product_type (product_type, prefix) VALUES ('$product_type', '$prefix')");
	}


	if($operation == "delete_type"){
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);

		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_type='$product_type'");
		$type_qty = mysqli_num_rows($result);

		if($type_qty != 0){
			echo "found_product_under_type";
		}
		else{
			mysqli_query($connect, "DELETE FROM product_type WHERE product_type_id='$product_type_id'");
		}
	}


	//for edit product type
	if($operation == "check_edit_prefix"){
		$prefix = mysqli_real_escape_string($connect, $_POST['prefix']);
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);

        $check_prefix = mysqli_query($connect, "SELECT * FROM product_type WHERE prefix='$prefix'");
        $check_prefix_row = mysqli_num_rows($check_prefix);
        $result = mysqli_fetch_assoc($check_prefix);
        
        if($check_prefix_row != 0 && $result['product_type_id'] != $product_type_id){
            echo "yes";
        }
        else{
            echo "no"; 
        }
    }

    //for edit product type
    if($operation == "check_edit_product_type"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);

        $check_product_type = mysqli_query($connect, "SELECT * FROM product_type WHERE product_type='$product_type'");
        $check_product_type_row = mysqli_num_rows($check_product_type);
        $result = mysqli_fetch_assoc($check_product_type);
        
        if($check_product_type_row != 0 && $result['product_type_id'] != $product_type_id){
            echo "yes";
        }
        else{
            echo "no"; 
        }
    }


    //for add product type
	if($operation == "check_add_prefix"){
		$prefix = mysqli_real_escape_string($connect, $_POST['prefix']);
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);

        $check_prefix = mysqli_query($connect, "SELECT * FROM product_type WHERE prefix='$prefix'");
        $check_prefix_row = mysqli_num_rows($check_prefix);
        $result = mysqli_fetch_assoc($check_prefix);
        
        if($check_prefix_row != 0){
            echo "yes";
        }
        else{
            echo "no"; 
        }
    }

    //for add product type
    if($operation == "check_add_product_type"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$product_type_id = mysqli_real_escape_string($connect, $_POST['product_type_id']);

        $check_product_type = mysqli_query($connect, "SELECT * FROM product_type WHERE product_type='$product_type'");
        $check_product_type_row = mysqli_num_rows($check_product_type);
        $result = mysqli_fetch_assoc($check_product_type);
        
        if($check_product_type_row != 0){
            echo "yes";
        }
        else{
            echo "no"; 
        }
    }

?>