<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_voucher_details"){
		$voucher_id = mysqli_real_escape_string($connect, $_POST['voucher_id']);

		$select_voucher = mysqli_query($connect, "SELECT * FROM voucher where voucher_id='$voucher_id'");

		$data = array();
		while($voucher_row = mysqli_fetch_assoc($select_voucher)){
			$voucher_code = $voucher_row['voucher_code'];
			$voucher_type = $voucher_row['voucher_type'];
			$min_spend = $voucher_row['min_spend'];
			$discount_amount = $voucher_row['discount_amount'];
			$description = $voucher_row['description'];
			$start_date_1 = $voucher_row['start_date'];
			$start_date_1 = strtotime($start_date_1);
	    	$start_date_1 = date ("d-m-Y", $start_date_1);

			$start_date = $voucher_row['start_date'];
			$end_date_1 = $voucher_row['end_date'];
			$end_date_1 = strtotime($end_date_1);
	    	$end_date_1 = date ("d-m-Y", $end_date_1);

			$end_date = $voucher_row['end_date'];
			$quantity = $voucher_row['quantity'];
			$status = $voucher_row['status'];
			


		    $data[] = array("voucher_code" => $voucher_code,
		                	"voucher_type" => $voucher_type,
		                    "min_spend" => $min_spend,
		                	"discount_amount" => $discount_amount,
		                	"description" => $description,
		                	"start_date_1" => $start_date_1,
		                	"start_date" => $start_date,
		                	"end_date_1" => $end_date_1,
		                	"end_date" => $end_date,
		                	"quantity" => $quantity,
		                	"status" => $status);
		                
		}

		echo json_encode($data);
	}


	if($operation == "edit_voucher"){
		$voucher_id = mysqli_real_escape_string($connect, $_POST['current_voucher_id']);
		$voucher_code = mysqli_real_escape_string($connect, $_POST['voucher_code']);
		$voucher_type = mysqli_real_escape_string($connect, $_POST['type']);
		$min_spend = mysqli_real_escape_string($connect, $_POST['min_spend']);
		$discount_amount = mysqli_real_escape_string($connect, $_POST['discount_amount']);
		$description = mysqli_real_escape_string($connect, $_POST['description']);
		$start_date = mysqli_real_escape_string($connect, $_POST['start_date']);
		$end_date = mysqli_real_escape_string($connect, $_POST['end_date']);
		$quantity = mysqli_real_escape_string($connect, $_POST['quantity']);
		$status = mysqli_real_escape_string($connect, $_POST['status']);

		mysqli_query($connect, "UPDATE voucher SET voucher_code='$voucher_code', voucher_type='$voucher_type', min_spend='$min_spend', discount_amount='$discount_amount', description='$description', start_date='$start_date', end_date='$end_date', quantity='$quantity', status='$status' WHERE voucher_id='$voucher_id'");
	}


	if($operation == "add_voucher"){
		$voucher_code = mysqli_real_escape_string($connect, $_POST['voucher_code']);
		$voucher_type = mysqli_real_escape_string($connect, $_POST['voucher_type']);
		$min_spend = mysqli_real_escape_string($connect, $_POST['min_spend']);
		$discount_amount = mysqli_real_escape_string($connect, $_POST['discount_amount']);
		$description = mysqli_real_escape_string($connect, $_POST['description']);
		$start_date = mysqli_real_escape_string($connect, $_POST['start_date']);
		$end_date = mysqli_real_escape_string($connect, $_POST['end_date']);
		$quantity = mysqli_real_escape_string($connect, $_POST['quantity']);
		$status = mysqli_real_escape_string($connect, $_POST['status']);

		mysqli_query($connect, "INSERT INTO voucher (voucher_code, voucher_type, min_spend, discount_amount, description, start_date, end_date, quantity, status) VALUES ('$voucher_code', '$voucher_type', '$min_spend', '$discount_amount', '$description', '$start_date', '$end_date', '$quantity', '$status')");
	}


	if($operation == "delete_voucher"){
		$voucher_id = mysqli_real_escape_string($connect, $_POST['voucher_id']);

		mysqli_query($connect, "DELETE FROM voucher where voucher_id='$voucher_id'");
	}

?>