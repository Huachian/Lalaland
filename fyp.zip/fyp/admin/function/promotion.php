<?php
	session_start();
	include ("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_product_list"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		$selected_start_date = date_parse($_POST['start_date']);
		$selected_end_date = date_parse($_POST['end_date']);

		$data = array();

		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_type='$product_type'");

		while($row = mysqli_fetch_assoc($result)){
			$product_id = $row['product_id'];
			$product_name = $row['product_name'];
			$product_price = $row['product_price'];


			date_default_timezone_set("Asia/Kuala_Lumpur");
			$today_date = date("Y-m-d");
			$today_date = date_parse($today_date);

			$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

			$found_promotion = "false";
			$promotion_price = $product_price;

			if(mysqli_num_rows($check_promotion) != 0){
				while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
					$promotion_id = $check_promotion_row['promotion_id'];

					$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
					$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

					$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

					$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

					if(mysqli_num_rows($check_promotion_product) != 0){

						if($check_promotion_product_result['promotion_price'] < $promotion_price){
							$promotion_price = $check_promotion_product_result['promotion_price'];
						}

						if($selected_start_date >= $promotion_start_date && $selected_start_date <= $promotion_end_date){
							$found_promotion = "true";
						}
						else if($selected_start_date <= $promotion_start_date && $selected_end_date >= $promotion_start_date){
							$found_promotion = "true";
						}
						else{
							$found_promotion = "false";
						}
					}
				}
			}

			$data[] = array("product_id" => $product_id,
							"product_name" => $product_name,
							"product_price" => $product_price,
							"found_promotion" => $found_promotion,
							"promotion_price" => $promotion_price);
		}

		echo json_encode($data);
	}


	if($operation == "add_promotion"){
		$promotion_description = mysqli_real_escape_string($connect, $_POST['promotion_description']);
		$start_date = mysqli_real_escape_string($connect, $_POST['start_date']);
		$end_date = mysqli_real_escape_string($connect, $_POST['end_date']);
		$promotion_status = mysqli_real_escape_string($connect, $_POST['promotion_status']);
		$promotion_product_type = mysqli_real_escape_string($connect, $_POST['promotion_product_type']);
		$product_id = $_POST['product_id'];
		$promotion_price = $_POST['promotion_price'];

		mysqli_query($connect, "INSERT INTO promotion (promotion_description, promotion_start_date, promotion_end_date, promotion_product_type, status) VALUES ('$promotion_description', '$start_date', '$end_date', '$promotion_product_type', '$promotion_status')");

		$result = mysqli_query($connect, "SELECT * FROM promotion ORDER BY promotion_id DESC LIMIT 1");
		$row = mysqli_fetch_assoc($result);

		$promotion_id = $row['promotion_id'];

		$length = count($product_id);
		for($i=0; $i<$length; $i++){
			$result = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id[$i]'");
			$row = mysqli_fetch_assoc($result);
			$product_original_price = $row['product_price'];

			mysqli_query($connect, "INSERT INTO promotion_products (promotion_id, product_id, original_price, promotion_price) VALUES ('$promotion_id', '$product_id[$i]', '$product_original_price', '$promotion_price[$i]')");
		}
	}


	if($operation == "get_promotion_details"){
		$promotion_id = mysqli_real_escape_string($connect, $_POST['promotion_id']);

		$result = mysqli_query($connect, "SELECT * FROM promotion WHERE promotion_id='$promotion_id'");
		$row = mysqli_fetch_assoc($result);

		$promotion_start_date_1 = $row['promotion_start_date'];
		$promotion_start_date_1 = strtotime($promotion_start_date_1);
	    $promotion_start_date_1 = date ("d-m-Y", $promotion_start_date_1);

	    $promotion_end_date_1 = $row['promotion_end_date'];
		$promotion_end_date_1 = strtotime($promotion_end_date_1);
	    $promotion_end_date_1 = date ("d-m-Y", $promotion_end_date_1);

		$data = array();

		$data[] = array("promotion_description" => $row['promotion_description'],
							"promotion_start_date_1" => $promotion_start_date_1,
							"promotion_start_date" => $row['promotion_start_date'],
							"promotion_end_date_1" => $promotion_end_date_1,
							"promotion_end_date" => $row['promotion_end_date'],
							"status" => $row['status']);

		echo json_encode($data);
	}


	if($operation == "save_edit_promotion_details"){
		$promotion_id = mysqli_real_escape_string($connect, $_POST['current_view_promotion_id']);
		$promotion_description = mysqli_real_escape_string($connect, $_POST['promotion_description']);
		$promotion_start_date = mysqli_real_escape_string($connect, $_POST['promotion_start_date']);
		$promotion_end_date = mysqli_real_escape_string($connect, $_POST['promotion_end_date']);
		$promotion_status = mysqli_real_escape_string($connect, $_POST['promotion_status']);


		mysqli_query($connect, "UPDATE promotion SET promotion_description='$promotion_description', promotion_start_date='$promotion_start_date', promotion_end_date='$promotion_end_date', status='$promotion_status' WHERE promotion_id='$promotion_id'");
	}

	if($operation == "delete_promotion"){
		$promotion_id = mysqli_real_escape_string($connect, $_POST['promotion_id']);

		mysqli_query($connect, "DELETE FROM promotion where promotion_id='$promotion_id'");
		mysqli_query($connect, "DELETE FROM promotion_products where promotion_id='$promotion_id'");
	}


	if($operation == "view_promotion_product_list"){
		$promotion_id = mysqli_real_escape_string($connect, $_POST['current_view_promotion_id']);

		$result = mysqli_query($connect, "SELECT * FROM promotion WHERE promotion_id='$promotion_id'");
		$row = mysqli_fetch_assoc($result);

		$product_type = $row['promotion_product_type'];
		$selected_start_date = date_parse($row['promotion_start_date']);
		$selected_end_date = date_parse($row['promotion_end_date']);

		$data = array();

		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_type='$product_type'");

		while($row = mysqli_fetch_assoc($result)){
			$product_id = $row['product_id'];
			$product_name = $row['product_name'];
			$product_current_price = $row['product_price'];

			$check_promotion = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

			$check_promotion_result = mysqli_num_rows($check_promotion);
			
			if($check_promotion_result != 0){
				$check_promotion_result_row = mysqli_fetch_assoc($check_promotion);
				$promotion_price = $check_promotion_result_row['promotion_price'];
				$set_promotion = "yes";
			}
			else{
				$promotion_price = 0;
				$set_promotion = "no";
			}




			date_default_timezone_set("Asia/Kuala_Lumpur");
			$today_date = date("Y-m-d");
			$today_date = date_parse($today_date);

			$check_other_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

			$found_promotion = "false";
			$other_promotion_price = $product_current_price;

			if(mysqli_num_rows($check_other_promotion) != 0){
				while($check_promotion_row = mysqli_fetch_assoc($check_other_promotion)){
					$other_promotion_id = $check_promotion_row['promotion_id'];

					//check if this period got other promotion or not (except itself)
					if($other_promotion_id != $promotion_id){
						$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
						$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

						$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$other_promotion_id' AND product_id='$product_id'");

						$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

						if(mysqli_num_rows($check_promotion_product) != 0){

							if($check_promotion_product_result['promotion_price'] < $other_promotion_price){
								$other_promotion_price = $check_promotion_product_result['promotion_price'];
							}

							if($selected_start_date >= $promotion_start_date && $selected_start_date <= $promotion_end_date){
								$found_promotion = "true";
							}
							else if($selected_start_date <= $promotion_start_date && $selected_end_date >= $promotion_start_date){
								$found_promotion = "true";
							}
							else{
								$found_promotion = "false";
							}
						}
					}
				}
			}


			$data[] = array("product_id" => $product_id,
							"product_name" => $product_name,
							"product_current_price" => $product_current_price,
							"promotion_price" => $promotion_price,
							"set_promotion" => $set_promotion,
							"product_type" => $product_type,
							"found_promotion" => $found_promotion,
							"other_promotion_price" => $other_promotion_price);
		}

		echo json_encode($data);
	}


	if($operation == "edit_promotion_product"){
		$product_id = $_POST['product_id'];
		$promotion_price = $_POST['promotion_price'];
		$promotion_id = mysqli_real_escape_string($connect, $_POST['current_view_promotion_id']);

		mysqli_query($connect, "DELETE FROM promotion_products WHERE promotion_id='$promotion_id'");
		

		$length = count($product_id);
		for($i=0; $i<$length; $i++){
			$result = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id[$i]'");
			$row = mysqli_fetch_assoc($result);
			$product_original_price = $row['product_price'];

			mysqli_query($connect, "INSERT INTO promotion_products (promotion_id, product_id, original_price, promotion_price) VALUES ('$promotion_id', '$product_id[$i]', '$product_original_price', '$promotion_price[$i]')");
		}
	}
	
?>