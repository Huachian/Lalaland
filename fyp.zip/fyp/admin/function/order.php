<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];


	if($operation == "get_order_product"){
		$order_id = mysqli_real_escape_string($connect, $_POST['order_id']);

		$data = array();

		$select_order_products = mysqli_query($connect, "SELECT * FROM order_products WHERE order_id='$order_id'");

		while($order_products_row = mysqli_fetch_assoc($select_order_products)){
			$product_id = $order_products_row['product_id'];
			$product_type = $order_products_row['product_type'];
		    $product_name = $order_products_row['product_name'];
		    $quantity = $order_products_row['quantity'];
		    $product_price = $order_products_row['product_price'];
		    $discount = $order_products_row['promotion_amount'];

		    if($product_type == "custom product"){
		    	$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE card_id='$product_id'");
		    	$row = mysqli_fetch_assoc($result);
		    	$custom_card_type = $row['card_type'];
		    }
		    else{
		    	$custom_card_type = "";
		    }

		    $data[] = array("product_id" => $product_id,
		    				"product_type" => $product_type,
		    				"custom_card_type" => $custom_card_type,
		                    "product_name" => $product_name,
		                    "quantity" => $quantity,
		                    "product_price" => $product_price,
		                	"discount" => $discount);
		}


		$result = mysqli_query($connect, "SELECT * FROM orders WHERE order_id='$order_id'");

		while($row = mysqli_fetch_assoc($result)){
			if($row['voucher_code'] != ""){
				$voucher_code = $row['voucher_code'];
				$voucher_type = "[".$row['voucher_type']."]";
				$discount_amount = $row['discount_amount'];

				$data[] = array("product_id" => $voucher_type,
				    				"product_type" => "voucher",
				    				"custom_card_type" => "",
				                    "product_name" => $voucher_code,
				                    "quantity" => 1,
				                    "product_price" => 0,
				                	"discount" => $discount_amount);
			}
		}


		echo json_encode($data);
	}


	if($operation == "get_orders"){
		$order_id = mysqli_real_escape_string($connect, $_POST['order_id']);

		$select_order = mysqli_query($connect, "SELECT * FROM orders WHERE order_id='$order_id'");

		$data = array();

		while($order_row = mysqli_fetch_assoc($select_order)){
			$order_date = $order_row['order_date'];
			$order_date = $order_row['order_date'];
	    	$order_date = strtotime($order_date);
	    	$order_date = date ("d-m-Y H:i:s", $order_date);  

			$customer_id = $order_row['customer_id'];
			$product_subtotal = $order_row['product_subtotal'];
			$shipping_fee = $order_row['shipping_fee'];
			$voucher_type = $order_row['voucher_type'];
			$discount_amount = $order_row['discount_amount'];
			$total_amount = $order_row['total_amount'];
			$customer_remark = $order_row['customer_remark'];
			$status = $order_row['status'];
			$delivery_date = $order_row['delivery_date'];
			$delivery_date = $order_row['delivery_date'];
	    	$delivery_date = strtotime($delivery_date);
	    	$delivery_date = date ("d-m-Y", $delivery_date); 

			$delivery_name = $order_row['delivery_name'];
			$delivery_contact = $order_row['delivery_contact'];
			$delivery_address = $order_row['delivery_address'];
			$delivery_postcode = $order_row['delivery_postcode'];
			$delivery_state = $order_row['delivery_state'];
			$delivery_area = $order_row['delivery_area'];

			$select_customer_details = mysqli_query($connect, "SELECT * from customer WHERE customer_id='$customer_id'");
			$customer_details = mysqli_fetch_assoc($select_customer_details);

			$customer_name = $customer_details['first_name'] ." ". $customer_details['last_name'];
			$customer_email = $customer_details['email'];
			$customer_phone = $customer_details['phone'];

			if($voucher_type == "Product Discount"){
				$product_subtotal -= $discount_amount;
				$discount_amount = 0;
			}

			$data[] = array("order_date" => $order_date,
		                    "customer_id" => $customer_id,
		                    "customer_name" => $customer_name,
		                    "customer_email" => $customer_email,
		                    "customer_phone" => $customer_phone,
		                    "product_subtotal" => $product_subtotal,
		                    "shipping_fee" => $shipping_fee,
		                    "voucher_type" => $voucher_type,
		                    "shipping_fee" => $shipping_fee,
		                    "discount_amount" => $discount_amount,
		                    "total_amount" => $total_amount,
		                	"customer_remark" => $customer_remark,
		                	"status" => $status,
		                	"delivery_date" => $delivery_date,
		                	"delivery_name" => $delivery_name,
		                	"delivery_contact" => $delivery_contact,
		                	"delivery_address" => $delivery_address,
		                	"delivery_postcode" => $delivery_postcode,
		                	"delivery_state" => $delivery_state,
		                	"delivery_area" => $delivery_area);
		}

		echo json_encode($data);
	}


	if($operation == "edit_order"){
		$order_id = mysqli_real_escape_string($connect, $_POST['order_id']);
		$delivery_name = mysqli_real_escape_string($connect, $_POST['delivery_name']);
		$delivery_contact = mysqli_real_escape_string($connect, $_POST['delivery_contact']);
		$delivery_address = mysqli_real_escape_string($connect, $_POST['delivery_address']);
		$delivery_postcode = mysqli_real_escape_string($connect, $_POST['delivery_postcode']);
		$delivery_area = mysqli_real_escape_string($connect, $_POST['delivery_area']);
		$delivery_state = mysqli_real_escape_string($connect, $_POST['delivery_state']);
		$customer_remark = mysqli_real_escape_string($connect, $_POST['customer_remark']);
		
		if($_POST['order_status'] == "Waiting for Shipment"){
			$order_status = "Waiting for Shipment";
			$delivery_date = null;

			mysqli_query($connect, "UPDATE orders SET status='$order_status', delivery_date='$delivery_date', customer_remark='$customer_remark', delivery_name='$delivery_name', delivery_contact='$delivery_contact', delivery_address='$delivery_address', delivery_postcode='$delivery_postcode', delivery_area='$delivery_area', delivery_state='$delivery_state' WHERE order_id='$order_id'");
		}
		else if($_POST['order_status'] == "Pending"){
			$order_status = "Pending";
			$delivery_date = null;

			mysqli_query($connect, "UPDATE orders SET status='$order_status', delivery_date='$delivery_date', customer_remark='$customer_remark', delivery_name='$delivery_name', delivery_contact='$delivery_contact', delivery_address='$delivery_address', delivery_postcode='$delivery_postcode', delivery_area='$delivery_area', delivery_state='$delivery_state' WHERE order_id='$order_id'");

		}
		else if($_POST['order_status'] == "Cancelled"){
			$order_status = "Cancelled";
			$delivery_date = null;

			mysqli_query($connect, "UPDATE orders SET status='$order_status', delivery_date='$delivery_date', customer_remark='$customer_remark', delivery_name='$delivery_name', delivery_contact='$delivery_contact', delivery_address='$delivery_address', delivery_postcode='$delivery_postcode', delivery_area='$delivery_area', delivery_state='$delivery_state' WHERE order_id='$order_id'");

		}
		else if($_POST['order_status'] == "Shipped Out"){
			$order_status = "Shipped Out";

			$result = mysqli_query($connect, "SELECT * FROM orders WHERE order_id='$order_id'");
			$row = mysqli_fetch_assoc($result);

			if($row['status'] == "Shipped Out"){
				mysqli_query($connect, "UPDATE orders SET status='$order_status', customer_remark='$customer_remark', delivery_name='$delivery_name', delivery_contact='$delivery_contact', delivery_address='$delivery_address', delivery_postcode='$delivery_postcode', delivery_area='$delivery_area', delivery_state='$delivery_state' WHERE order_id='$order_id'");
			}
			else{
				ini_set('date.timezone','Asia/Kuala_Lumpur'); 
				$delivery_date = date('Y-m-d');

				mysqli_query($connect, "UPDATE orders SET status='$order_status', delivery_date='$delivery_date', customer_remark='$customer_remark', delivery_name='$delivery_name', delivery_contact='$delivery_contact', delivery_address='$delivery_address', delivery_postcode='$delivery_postcode', delivery_area='$delivery_area', delivery_state='$delivery_state' WHERE order_id='$order_id'");
			}
		}
	}


	if($operation == "get_custom_details"){
		$card_id = mysqli_real_escape_string($connect, $_POST['card_id']);

		$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE card_id='$card_id'");

		$data = array();
		while($row = mysqli_fetch_assoc($result)){
			$card_name = $row['card_name'];
			$card_type = $row['card_type'];
		    $card_image = $row["card_image"];
		    $card_message = $row['card_message'];


		    $data[] = array("card_name" => $card_name,
		    				"card_type" => $card_type,
		    				"card_image" => $card_image,
		                    "card_message" => $card_message,);
		}

		echo json_encode($data);
	}


	if($operation == "save_edit_card"){
		$card_id = mysqli_real_escape_string($connect, $_POST['card_id']);
		$card_type = mysqli_real_escape_string($connect, $_POST['card_type']);
		$card_message = mysqli_real_escape_string($connect, $_POST['card_message']);

		mysqli_query($connect, "UPDATE customization_card SET card_type='$card_type', card_message='$card_message' WHERE card_id='$card_id'");
	}
?>