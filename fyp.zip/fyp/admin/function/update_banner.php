<?php
	session_start();
	include ("../dataconnection.php");

	$operation = $_POST['operation'];


	if($operation == "add_banner"){
		$banner_status = mysqli_real_escape_string($connect, $_POST['banner_status']);

		// File upload path
		$targetDir = "../image/banner/";
		$fileName = basename($_FILES["banner_image"]["name"]);
		$targetFilePath = $targetDir . $fileName;

		/* $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION); */


		$result = mysqli_query($connect, "SELECT * FROM banner where banner_name='$fileName'");
		$result_count = mysqli_num_rows($result);

		if($result_count != 0){
			echo "banner_exist";
		}
		else{
			echo "banner_not_exist";

			move_uploaded_file($_FILES["banner_image"]["tmp_name"], $targetFilePath);
        
        	mysqli_query($connect, "INSERT INTO banner (banner_name, banner_status) VALUES ('$fileName', '$banner_status')");
		}
	}


	if($operation == "get_banner_details"){
		$banner_id = mysqli_real_escape_string($connect, $_POST['banner_id']);

		$result = mysqli_query($connect, "SELECT * FROM banner where banner_id='$banner_id'");

		$data = array();
		while($row = mysqli_fetch_assoc($result)){
			$banner_name = $row['banner_name'];
			$banner_status = $row['banner_status'];


		    $data[] = array("banner_name" => $banner_name,
		                    "banner_status" => $banner_status);
		}

		echo json_encode($data);
	}


	if($operation == "save_edit_banner"){
		$banner_id = mysqli_real_escape_string($connect, $_POST['banner_id']);
		$banner_name = mysqli_real_escape_string($connect, $_POST['banner_name']);
		$banner_status = mysqli_real_escape_string($connect, $_POST['banner_status']);
		$current_banner_name = mysqli_real_escape_string($connect, $_POST['current_banner_name']);


		if($banner_status == "Hide"){
			$result = mysqli_query($connect, "SELECT * FROM banner WHERE banner_status='Display'");


			$result_count = mysqli_num_rows($result);

			if($result_count == 2){
				$found = 0;

				while($row = mysqli_fetch_assoc($result)){
					if($row['banner_id'] == $banner_id){
						$found++;
					}
				}

				if($found != 0){
					echo "no";
				}
				else{
					echo "yes";

					if(!empty($_FILES['banner_image']["tmp_name"])){
						$targetDir = "../image/banner/";
						$fileName = basename($_FILES["banner_image"]["name"]);
						$targetFilePath = $targetDir . $fileName;
						$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

						unlink("../image/banner/".$current_banner_name);

						move_uploaded_file($_FILES["banner_image"]["tmp_name"], $targetFilePath);

						mysqli_query($connect, "UPDATE banner SET banner_name='$fileName', banner_status='$banner_status' WHERE banner_id='$banner_id'");
					}
					else{
						mysqli_query($connect, "UPDATE banner SET banner_status='$banner_status' WHERE banner_id='$banner_id'");
					}
				}
			}
			else{
				echo "yes";

				if(!empty($_FILES['banner_image']["tmp_name"])){
					$targetDir = "../image/banner/";
					$fileName = basename($_FILES["banner_image"]["name"]);
					$targetFilePath = $targetDir . $fileName;
					$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

					unlink("../image/banner/".$current_banner_name);

					move_uploaded_file($_FILES["banner_image"]["tmp_name"], $targetFilePath);

					mysqli_query($connect, "UPDATE banner SET banner_name='$fileName', banner_status='$banner_status' WHERE banner_id='$banner_id'");
				}
				else{
					mysqli_query($connect, "UPDATE banner SET banner_status='$banner_status' WHERE banner_id='$banner_id'");
				}
			}
		}
		else{
			echo "yes";

			if(!empty($_FILES['banner_image']["tmp_name"])){
				$targetDir = "../image/banner/";
				$fileName = basename($_FILES["banner_image"]["name"]);
				$targetFilePath = $targetDir . $fileName;
				$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

				unlink("../image/banner/".$current_banner_name);

				move_uploaded_file($_FILES["banner_image"]["tmp_name"], $targetFilePath);

				mysqli_query($connect, "UPDATE banner SET banner_name='$fileName', banner_status='$banner_status' WHERE banner_id='$banner_id'");
			}
			else{
				mysqli_query($connect, "UPDATE banner SET banner_status='$banner_status' WHERE banner_id='$banner_id'");
			}
		}	
	}


	if($operation == "delete_banner"){
		$banner_id = mysqli_real_escape_string($connect, $_POST['banner_id']);
		$banner_name = mysqli_real_escape_string($connect, $_POST['banner_name']);

		$result = mysqli_query($connect, "SELECT * FROM banner WHERE banner_status='Display'");


		$result_count = mysqli_num_rows($result);

		if($result_count == 2){
			$found = 0;

			while($row = mysqli_fetch_assoc($result)){
				if($row['banner_id'] == $banner_id){
					$found++;
				}
			}

			if($found > 0){
				echo "no";
			}
			else{
				echo "yes";
				unlink("../image/banner/".$banner_name);
				mysqli_query($connect, "DELETE FROM banner WHERE banner_id='$banner_id'");
			}
		}
		else{
			echo "yes";
			unlink("../image/banner/".$banner_name);
			mysqli_query($connect, "DELETE FROM banner WHERE banner_id='$banner_id'");
		}
	}
?>