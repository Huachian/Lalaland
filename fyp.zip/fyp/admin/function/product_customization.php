<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_card_details"){
		$card_id = mysqli_real_escape_string($connect, $_POST['card_id']);

		$select_card = mysqli_query($connect, "SELECT * FROM product_customization where product_customization_id='$card_id'");

		while($card_row = mysqli_fetch_assoc($select_card)){
			$card_id = $card_row['product_customization_id'];
			$card_type = $card_row['card_type'];
			$card_price = $card_row['card_price'];
			$card_stock = $card_row['card_stock'];

		    $data[] = array("card_id" => $card_id,
		    				"card_type" => $card_type,
		               	 	"card_price" => $card_price,
		               	 	"card_stock" => $card_stock);
		}

		echo json_encode($data);
	}

	if($operation == "save_edit"){
		$card_type = mysqli_real_escape_string($connect, $_POST['card_type']);
		$card_price = mysqli_real_escape_string($connect, $_POST['card_price']);
		$card_stock = mysqli_real_escape_string($connect, $_POST['card_stock']);
		$card_id = mysqli_real_escape_string($connect, $_POST['card_id']);

		mysqli_query($connect, "UPDATE product_customization SET card_type='$card_type', card_price='$card_price', card_stock='$card_stock' WHERE product_customization_id='$card_id'");
	}

	?>