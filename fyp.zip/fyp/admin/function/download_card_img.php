<?php
	include("../dataconnection.php");

	$card_id = mysqli_real_escape_string($connect, $_GET['card_id']);

	$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE card_id='$card_id'");
	$row = mysqli_fetch_assoc($result);

	$filepath = "../image/customization/" . $row["card_image"];

	$custom_filename = "custom_card_".$row["card_id"]."_".$row["card_name"].".";
	$filetype = pathinfo($row["card_image"], PATHINFO_EXTENSION);
	$custom_filename .= $filetype;

	header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.$custom_filename.'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filepath));
    flush(); // Flush system output buffer
    readfile($filepath);
?>