<?php
	session_start();
	include("../dataconnection.php");

	$operation = $_POST['operation'];

	if($operation == "get_occasions_details"){
		$occasions_id = mysqli_real_escape_string($connect, $_POST['occasions_id']);

		$select_occasion = mysqli_query($connect, "SELECT * FROM product_occasions where occasions_id='$occasions_id'");

		while($prefix_row = mysqli_fetch_assoc($select_occasion)){
			$occasions_id = $prefix_row['occasions_id'];
			$occasions_name = $prefix_row['occasions_name'];



		    $data[] = array("occasions_id" => $occasions_id,
		               	 	"occasions_name" => $occasions_name);
		}

		echo json_encode($data);
	}

	if($operation == "save_edit"){
		$occasions_name = mysqli_real_escape_string($connect, $_POST['occasions_name']);
		$occasions_id = mysqli_real_escape_string($connect, $_POST['occasions_id']);
		$current_occasion_name = mysqli_real_escape_string($connect, $_POST['current_occasion_name']);


		mysqli_query($connect, "UPDATE product SET product_occasions='$occasions_name' WHERE product_occasions='$current_occasion_name'");

		mysqli_query($connect, "UPDATE product_occasions SET occasions_name='$occasions_name' WHERE occasions_id='$occasions_id'");
	}


	if($operation == "add_occasions"){
		$occasion = mysqli_real_escape_string($connect, $_POST['occasion']);

		mysqli_query($connect, "INSERT INTO product_occasions (occasions_name) VALUES ('$occasion')");
	}


	if($operation == "delete_occasions"){
		$occasions_id = mysqli_real_escape_string($connect, $_POST['occasions_id']);
		$occasions_name = mysqli_real_escape_string($connect, $_POST['occasions_name']);

		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_occasions='$occasions_name'");
		$type_qty = mysqli_num_rows($result);

		if($type_qty != 0){
			echo "found_product_under_occasions";
		}
		else{
			mysqli_query($connect, "DELETE FROM product_occasions WHERE occasions_id='$occasions_id'");
		}
	}

    if($operation == "check_exist_product_occasion"){
		$occasions_name = mysqli_real_escape_string($connect, $_POST['occasions_name']);
		$occasions_id = mysqli_real_escape_string($connect, $_POST['occasions_id']);

        $check_occasion = mysqli_query($connect, "SELECT * FROM product_occasions WHERE occasions_name='$occasions_name'");
        $check_occasion_row = mysqli_num_rows($check_occasion);
        $result = mysqli_fetch_assoc($check_occasion);
        
        if($check_occasion_row != 0 && $result['occasions_id'] != $occasions_id){
            echo "yes";
        }
        else{
        
            echo "no";
            
        }
    }

 	if($operation == "check_exist_add_product_occasion"){
		$occasions_name = mysqli_real_escape_string($connect, $_POST['occasions_name']);

        $check_occasion = mysqli_query($connect, "SELECT * FROM product_occasions WHERE occasions_name='$occasions_name'");
        $check_occasion_row = mysqli_num_rows($check_occasion);
        
        if($check_occasion_row != 0){
        
            echo "yes";
            
        }
        else
        {
        	echo "no";
        }
    }
    
?>