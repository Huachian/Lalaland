<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/product_occasion.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/product_occasion.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/product_occasion.js"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('category_btn_wrap').style.background = "#ffff4d";
		document.getElementById('category_btn_title').style.color = "black";
		document.getElementById('category_icon').style.color = "black";
	</script>
	<div class="occasion_main_wrap">
		<div class="occasion_second_wrap">
			<div class="back_btn_wrap">
				<a href="category.php"><button class="back_btn"><i class="fas fa-chevron-left"></i> Back</button></a>
			</div>
			<div class="occasion_page_title">
				Product Occasion
			</div>
			<div id="occasion_page_top_action_wrap">
				<div id="search_occasion_wrap">
					<input type="text" id="search_product" placeholder="Search Products" onkeyup="filter_table()">
				</div>
				<div id="product_occasion_page_top_btn_wrap">
					<button onclick="add_product_occasion_popup()">Add Occasion</button>
				</div>
			</div>

			<div id="product_occasion_display_wrap">
				<table id="product_occasion_table">
					<tr>
						<th id="product_occasion_no_column">
							No
						</th>
						<th id="product_occasion_column">
							Product Occasion
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_product_occasion = mysqli_query($connect, "SELECT * FROM product_occasions ORDER BY occasions_id ASC");
						$i = 0;

						while($product_occasion_row = mysqli_fetch_assoc($select_product_occasion)){
							$i++;
					?>
							<tr class="product_occasion_row" id="product_occasion_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="occasion_delete_status<?php echo $i ?>" value="0">
								<td onclick="show_occasion_details('<?php echo $product_occasion_row['occasions_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td id="product_occasion_column" onclick="show_occasion_details('<?php echo $product_occasion_row['occasions_id'] ?>', '<?php echo $i ?>')">
									<span id="product_occasion<?php echo $i ?>"><?php echo $product_occasion_row['occasions_name'] ?></span>
								</td>
								<td id="product_occasion_button_column">
									<button onclick="show_occasion_details('<?php echo $product_occasion_row['occasions_id'] ?>', '<?php echo $i ?>')">
										<img src="image/product_occasions/view_icon.png">
									</button>
									<button onclick="delete_occasions('<?php echo $i ?>', '<?php echo $product_occasion_row['occasions_id'] ?>', '<?php echo $product_occasion_row['occasions_name'] ?>')">
										<img src="image/product_occasions/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>
	
	<div id="occasion_details_wrap">
		<div id="occasion_details_wrap_2">
			<div id="occasion_details_title">
				Occasion Details
			</div>

			<div id="occasion_details_box">
				<button id="close_occasion_details_btn" onclick="close_product_occasion_details()">
					<img src="image/product_type/close_icon.png">
				</button>

				<table id="occasion_details_table">
					<tr>
						<input type="hidden" name="occasions_id" id="occasions_id">
						<td class="occasion_details_table_title">
							Occasion
						</td>
						<td class="occasion_details_table_contain">
							:<div id="occasion" class="details_contain"></div>
							<input type="text" name="edit_occasion" class="edit_occasion_input_box" id="edit_occasion" onblur="edit_product_occasion_validation()" >
							<div id="edit_occasion_error" class="edit_occasion_error"></div>
						</td>
					</tr>
				</table>
			</div>

			<div id="edit_occasion_action_button">
				<button id="edit_occasion_details_btn" onclick="edit_occasion()">
					<img src="image/product_occasions/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit_occasion()">
					<img src="image/product_occasions/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_occasion()">
					<img src="image/product_occasions/save_icon.png">
				</button>
			</div>

		</div>
	</div>

	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/tick_icon.png">
				<div>
					Occasion successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="add_new_occasion_wrap">
		<div id="add_new_occasion_wrap2">
			<div id="add_occasion_top_title">
				Add New Occasion
			</div>

			<div id="add_new_occasion_details_box">
				<button id="close_insert_occasion_btn" onclick="close_insert_product_occasion()">
				<img src="image/product_type/close_icon.png">
				</button>
				<div id="occasion_insert_row">
					<div class="occasion_insert_title">Occasion</div>
					<div class="details_contain_row">
							: <input type="text" name="insert_product_occasion" class="insert_occasion_input_box" id="insert_product_occasion" onblur="add_product_occasion_validation()" placeholder="Occasion">
						<div id="insert_product_occasion_error" class="insert_product_occasion_error"></div>
					</div>
				</div>								
			</div>
			<div id="add_product_occasion_action_button">
				<button onclick="add_product_occasions()">
					<img src="image/product_occasions/save_icon.png">
				</button>
			</div>
		</div>
	</div>

	<div id="add_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/tick_icon.png">
				<div>
					Occasion successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="found_exist_product_alert" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_occasions/eror_icon.png">
				<div>
					Existing product found under this product occasion
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this occasion?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_occasions_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="edit_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to change this occasion?
				</div>
				<div id="edit_confirm_wrap_warning">
					**All of the product under this occasion will be involve**
				</div>
				<div style="text-align: center; margin-top: 20px;">
					<div>Product Occasion:</div>
					<div style="text-align: center;">
						<span id="old_occasion_display"></span> --> <span id="new_occasion_display"></span>
					</div>
				</div>
				<div id="delete_confirm_btn">
					<button id="edit_confirm_yes">Yes</button>
					<button id="edit_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

</body>
</html>