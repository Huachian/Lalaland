<?php
	session_start();
	include("dataconnection.php"); 

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/sales.php");
	}

	if(isset($_SESSION['id'])){
        if($_SESSION["admin_position"] != "Superadmin"){
            header("Location: index.php");
        }
    }
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/sales.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('sales_btn_wrap').style.background = "#ffff4d";
		document.getElementById('sales_btn_title').style.color = "black";
		document.getElementById('sales_icon').style.color = "black";
	</script>

	<div class="sales_main_wrap">
		<div class="sales_second_wrap">
			<div class="sales_page_title">
				Company Sales
			</div>
            <div class="all_graph_warp">
				<div class="graph_warp">
                    <div class="bg-white border rounded shadow">
                        <div class="border-b p-3">
                            <h5 class="font-bold uppercase text-gray-600">Monthly Sales (RM)</h5>
                        </div>
                        <div class="p-5">
                            <div id="chartContainer" style="width: 100%;"></div>
                            <?php
                            	$monthly_sale = array();

								for($i=1; $i<=12; $i++){
									$result = mysqli_query($connect,"SELECT * FROM orders WHERE YEAR(order_date)=YEAR(now()) AND MONTH(order_date)='$i'");

									$result_count = mysqli_num_rows($result);

									if($result_count > 0){
										$monthly_sale[$i] = 0;
										
										while($row = mysqli_fetch_assoc($result)){
											$monthly_sale[$i] += $row['total_amount'];
										}
									}
									else{
										$monthly_sale[$i] = 0;
									}

								}
                            ?>
                            <script>
                            	var options = {
								  chart: {
								    type: 'line'
								  },
								  series: [{
								    name: 'Sales (RM)',
								    data: [<?php echo $monthly_sale[1] ?>,<?php echo $monthly_sale[2] ?>,<?php echo $monthly_sale[3] ?>, <?php echo $monthly_sale[4] ?>, <?php echo $monthly_sale[5] ?>,<?php echo $monthly_sale[6] ?>,<?php echo $monthly_sale[7] ?>,<?php echo $monthly_sale[8] ?>, <?php echo $monthly_sale[9] ?>, <?php echo $monthly_sale[10] ?>, <?php echo $monthly_sale[11] ?>, <?php echo $monthly_sale[12] ?>]
								  }],
								  xaxis: {
								    categories: ["JAN","FEB","MAR","APR","MAY","JUN","JUL", "AUG","SEP", "OCT", "NOV", "DEC"]
								  }
								}

								var chart = new ApexCharts(document.querySelector("#chartContainer"), options);

								chart.render();
                            </script>
                        </div>
                    </div>
                </div>		
			</div>
		</div>
	</div>


</body>

</html>
