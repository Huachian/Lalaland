<?php
  session_start();
  include "dataconnection.php";

  if(!isset($_SESSION['id'])){
      header("Location: ../login_register.php?next=admin/admin_password.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/admin_password.css">
  <script type="text/javascript" src="js/admin_password.js"></script>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
  <?php include("navigation_bar.php");?>
  <script type="text/javascript">
    document.getElementById('profile_btn_wrap').style.background = "#ffff4d";
    document.getElementById('profile_btn_title').style.color = "black";
    document.getElementById('profile_icon').style.color = "black";
  </script>

  <div class="password_main_wrap">
    <div class="password_second_wrap">
      <div class="back_btn_wrap">
        <a href="admin_profile.php"><button class="back_btn"><i class="fas fa-chevron-left"></i> Back</button></a>
      </div>
      <div class="password_header">
        Change Password
      </div>

      <div class="change_password_box">
        <div class="change_password_body">
          <div id="change_password_form">
            <div class="password_form_row">
              <div class="password_form_title">Current Password</div>
              <div><input type="password" name="current_password" onblur="current_password_validation()" id="current_password" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }"><div class="show_password" onclick="show_hide_current_password()" id="current_password_show_hide_icon"></div></div>
            </div>
            <div id="current_password_error_message"></div>

            <div class="password_form_row">
              <div class="password_form_title">New Password</div>
              <div><input type="password" name="new_password" id="new_password" onkeyup="new_password_guide()" onkeydown="javascript: var keycode = keyPressed_new_password(event); if(keycode==32){ return false; }" onblur="new_password_validation()"><div class="show_password" onclick="show_hide_new_password()" id="new_password_show_hide_icon"></div></div>
            </div>
            <img src="image/admin_password/tick_icon.png" id="new_password_tick_icon">
            <img src="image/admin_password/cross_icon.png" id="new_password_cross_icon">
            <div id="new_password_error_message"></div>
            <div id="password_format">*Please use a strong password.<br> (<span id="characters">Minimum 15 characters</span>, <span id="number">1 number</span>, <span id="small_letter">1 small letter</span>, <span id="upper_letter">1 upper letter</span>, <span id="symbol">1 symbol</span>)</div>

            <div class="password_form_row">
              <div class="password_form_title">Confirm Password</div>
              <div><input type="password" name="confirm_password" id="confirm_password" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" onblur="confirm_password_validation()"><div class="show_password" onclick="show_hide_confirm_password()" id="confirm_password_show_hide_icon"></div></div>
            </div>
            <div id="confirm_password_error_message"></div>
            <img src="image/admin_password/tick_icon.png" id="confirm_password_tick_icon">
            <img src="image/admin_password/cross_icon.png" id="confirm_password_cross_icon">
          </div>
          <div id="change_password_btn" onclick="change_password()">
            <button id="confirm_change_password">Confirm</button>
          </div>
        </div>
      </div>
    </div>
  </div>

    <div id="change_password_error_wrap">
      <div id="change_password_error_box">
        <div id="change_password_error_contain">
          <img src="image/admin_password/eror_icon.png">
          <div>
            Current password is incorrect.
          </div>
        </div>
      </div>
    </div>

    <div id="same_with_old_password_error_wrap">
      <div id="change_password_error_box">
        <div id="change_password_error_contain">
          <img src="image/admin_password/eror_icon.png">
          <div>
            New password same with current password.
          </div>
        </div>
      </div>
    </div>

    <div id="change_password_success_wrap">
      <div id="change_password_success_box">
        <div id="change_password_success_contain">
          <img src="image/admin_password/tick_icon.png">
          <div>
            Password successfully changed.
          </div>
        </div>
      </div>
    </div>
</body>
  <script type="text/javascript">
    var side_bar_btn = document.getElementById('profile_btn_wrap');
    var side_bar_btn = side_bar_btn.offsetTop;
    document.getElementById('admin_side_navigation_wrap').scrollTop = side_bar_btn;
  </script>
</html>


