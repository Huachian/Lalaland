<?php
	session_start();
	include("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/product.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/product.css">
	<script type="text/javascript" src="js/product.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php include("navigation_bar.php"); ?>
	<script type="text/javascript">
		document.getElementById('product_btn_wrap').style.background = "#ffff4d";
		document.getElementById('product_btn_title').style.color = "black";
		document.getElementById('product_icon').style.color = "black";
	</script>


	<div class="product_main_wrap">
		<div class="product_second_wrap">
			<div id="product_page_title">
				Product List
			</div>

			<div id="product_page_top_action_wrap">
				<div id="search_product_wrap">
					<input type="text" id="search_product" placeholder="Search Products" onkeyup="filter_table()">
				</div>
				<div id="product_page_top_btn_wrap">
					<button onclick="add_product_popup()">Add Product</button>
				</div>
			</div>

			<div id="product_display_wrap">
				<table id="product_table">
					<tr>
						<th id="product_no_column">
							No
						</th>
						<th id="product_id_column">
							Product ID
						</th>
						<th id="product_name_column">
							Product Name
						</th>
						<th id="product_type_column">
							Product Type
						</th>
						<th>
							Product Occasion
						</th>
						<th id="product_price_column">
							Price
						</th>
						<th id="product_stock_column">
							Stock
						</th>
						<th id="product_status_column">
							Status 
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_product = mysqli_query($connect, "SELECT * FROM	product ORDER BY product_id DESC");
						$i = 0;

						while($product_row = mysqli_fetch_assoc($select_product)){
							$i++;
							$product_price = $product_row['product_price'];
							$product_id = $product_row['product_id'];
					?>
							<tr class="product_row" id="product_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="product_delete_status<?php echo $i ?>" value="0">
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
									<?php echo $product_row['product_id'] ?>
								</td>
								<td class="product_name_column" onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
									<span id="product_name<?php echo $i ?>"><?php echo $product_row['product_name'] ?></span>
								</td>
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
									<?php echo $product_row['product_type'] ?>
								</td>
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
									<span id="product_occasions<?php echo $i ?>"><?php echo $product_row['product_occasions'] ?></span>
								</td>
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')" class="product_row_price">

									<?php
										date_default_timezone_set("Asia/Kuala_Lumpur");
										$today_date = date("Y-m-d");
										$today_date = date_parse($today_date);

										$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

										$product_promotion_price = $product_price;
										$found_promotion = "false";

										if(mysqli_num_rows($check_promotion) != 0){
											while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
												$promotion_id = $check_promotion_row['promotion_id'];

												$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
												$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

												if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
													$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

													$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

													if(mysqli_num_rows($check_promotion_product) != 0){
														$found_promotion = "true";

														if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
															$product_promotion_price = $check_promotion_product_result['promotion_price'];
														}
													}
												}
											}
										}
										else{
											$found_promotion = "false";
										}


										if($found_promotion == "true"){
											$promotion_price_tag = "promotion_price_tag";
										}
										else{
											$promotion_price_tag = "";
										}

									?>
									<input type="hidden" id="found_promotion<?php echo $i ?>" value="<?php echo $found_promotion ?>">

									<span class="<?php echo $promotion_price_tag ?>">
										RM<span id="product_price<?php echo $i ?>"><?php
												if($found_promotion == "true"){
													echo number_format($product_promotion_price, 2);
												}
												else{
													echo number_format($product_row['product_price'], 2);
												}
											?>
										</span>
									</span>
								</td>
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
									<?php
										if($product_row['product_stock'] == "In Stock"){
											$product_stock_tag = "in_stock_tag";
										}
										else{
											$product_stock_tag = "out_of_stock_tag";
										}
									?>
									<span class="<?php echo $product_stock_tag ?>" id="product_stock<?php echo $i ?>"><?php echo $product_row['product_stock'] ?></span>
								</td>
								<td onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')" id="status_column">
									<?php
										if($product_row['product_status'] == "On Display"){
											$product_status_tag = "product_status_on_display";
										}
										else{
											$product_status_tag = "product_status_hidden";
										}
									?>
									<div class="<?php echo $product_status_tag ?>" id="product_status<?php echo $i ?>"><?php echo $product_row['product_status'] ?></div>
								</td>
								<td id="product_button_column">
									<button onclick="show_product_details('<?php echo $product_row['product_id'] ?>', '<?php echo $i ?>')">
										<img src="image/product/view_icon.png">
									</button>
									<button onclick="delete_product('<?php echo $i ?>', '<?php echo $product_row['product_id'] ?>')">
										<img src="image/product/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>

	<div id="product_details_wrap">
		<div id="product_details_wrap_2">
			<div id="product_details_title">
				Product Details
			</div>

			<div id="product_details_box">
				<button id="close_product_details_btn" onclick="close_product_details()">
					<img src="image/product/close_icon.png">
				</button>

				<div id="product_img">
					<img src="" id="product_image">
					<br>
					<input type="file" id="upload_edit_product_image" accept="image/*" onchange="preview_product_image('edit')">
				</div>

				<table id="product_details_table">
					<tr>
						<td class="product_details_table_title">
							Type
						</td>
						<td class="product_details_table_contain">
							:<div id="product_type" class="details_contain"></div>
							<select id="edit_product_type" class="edit_product_input_box" disabled>
								<?php
									$get_product_type = mysqli_query($connect, "SELECT * FROM product_type");
									while($product_type_row = mysqli_fetch_assoc($get_product_type)){
								?>
										<option value="<?php echo $product_type_row['product_type'] ?>"><?php echo $product_type_row['product_type'] ?></option>
								<?php
									}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Product ID
						</td>
						<td class="product_details_table_contain">
							:<div id="product_id" class="details_contain"></div>
							<input type="text" name="product_id" class="edit_product_input_box" id="edit_product_id" disabled>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Name
						</td>
						<td class="product_details_table_contain">
							:<div id="product_name" class="details_contain"></div>
							<input type="text" name="product_name" class="edit_product_input_box" id="edit_product_name" onblur="product_name_validation('edit')">
							<div id="edit_name_error" class="edit_product_error"></div>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Price (RM)
						</td>
						<td class="product_details_table_contain">
							:<div class="details_contain" style="display: flex"><div id="product_price"></div><div id="promotion_price_dislay"></div><div id="promotion_word_display"></div></div>
							<input type="number" name="product_price" class="edit_product_input_box" id="edit_product_price" onblur="product_price_validation('edit')" onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46" style="margin-left: 10px;">
							<div id="edit_price_error" class="edit_product_error"></div>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Category
						</td>
						<td class="product_details_table_contain">
							:<div id="product_category" class="details_contain"></div>
							<select id="edit_product_category" class="edit_product_input_box">
								<option value="For Him">For Him</option>
								<option value="For Her">For Her</option>
								<option value="For Kids">For Kids</option>
								<option value="Newborn">Newborn</option>
							</select>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Occasions
						</td>
						<td class="product_details_table_contain">
							:<div id="product_occasions" class="details_contain"></div>
							<select id="edit_product_occasions" class="edit_product_input_box" onblur="edit_occasion_validation()">
								<?php
									$get_product_occasions = mysqli_query($connect, "SELECT * FROM product_occasions");
									while($product_occasions_row = mysqli_fetch_assoc($get_product_occasions)){
								?>
										<option value="<?php echo $product_occasions_row['occasions_name'] ?>"><?php echo $product_occasions_row['occasions_name'] ?></option>
								<?php
									}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Description 1
						</td>
						<td class="product_details_table_contain">
							:<div id="product_description_1" class="details_contain"></div>
							<textarea id="edit_product_description_1" onblur="product_desc1_validation('edit')"></textarea>
							<div id="edit_desc1_error" class="edit_product_error"></div>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Description 2
						</td>
						<td class="product_details_table_contain">
							:<div id="product_description_2" class="details_contain"></div>
							<textarea id="edit_product_description_2"></textarea>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Availability
						</td>
						<td class="product_details_table_contain">
							:<div id="product_stock" class="details_contain"></div>
							<select id="availability_select_box" class="edit_product_input_box">
								<option value="In Stock">In Stock</option>
								<option value="Out of Stock">Out of Stock</option>
							</select>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							Status
						</td>
						<td class="product_details_table_contain">
							:<div id="product_status" class="details_contain"></div>
							<select id="status_select_box" class="edit_product_input_box">
								<option value="On Display">On Display</option>
								<option value="Hidden">Hidden</option>
							</select>
						</td>
					</tr>
				</table>
			</div>

			<div id="edit_product_action_button">
				<button id="edit_product_details_btn" onclick="edit_product()">
					<img src="image/product/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit_product()">
					<img src="image/product/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_product()">
					<img src="image/product/save_icon.png">
				</button>
			</div>
		</div>
	</div>


	<div id="add_new_product_wrap">
		<div id="add_new_product_wrap_2">
			<div id="add_product_top_title">
				Add Product
			</div>

			<div id="add_new_product_details_box">
				<button id="close_product_details_btn" onclick="close_insert_product()">
					<img src="image/product/close_icon.png">
				</button>

				<div id="upload_product_img_wrap">
					<div id="image_preview_wrap">
						<img src="" id="insert_product_image_preview">
						<div id="image_preview_empty" onclick="upload_image()">
							<div id="image_preview_empty_title">Upload Image</div>
						</div>
					</div>
					<div>
						<input type="file" name="product_image" accept="image/*" id="image_upload" onchange="preview_product_image('add')">
					</div>
						<div id="add_image_upload_error"></div>
				</div>

				<div id="insert_product_wrap">
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Type</div>
						<div class="details_contain_row">
							: 
							<select id="insert_product_type" class="insert_product_input_box" onchange="get_new_product_id()" onblur="product_type_validation()">
								<option disabled selected value="0"> -- select an option -- </option>
								<?php
									$get_product_type = mysqli_query($connect, "SELECT * FROM product_type");
									while($product_type_row = mysqli_fetch_assoc($get_product_type)){
								?>
										<option value="<?php echo $product_type_row['product_type'] ?>"><?php echo $product_type_row['product_type'] ?></option>
								<?php
									}
								?>
							</select>
							<div><span id="insert_type_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Product ID</div>
						<div class="details_contain_row">
							: <input type="text" name="insert_product_id" class="insert_product_input_box" id="insert_product_id" disabled>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Name</div>
						<div class="details_contain_row">
							: <input type="text" name="insert_product_name" class="insert_product_input_box" id="insert_product_name" onblur="product_name_validation('add')" placeholder="Product Name">
							<div><span id="insert_name_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Price (RM)</div>
						<div class="details_contain_row">
							: <input type="number" name="insert_product_price" class="insert_product_input_box" id="insert_product_price" onblur="product_price_validation('add')" onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46" placeholder="Product Price">
							<div><span id="insert_price_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Category</div>
						<div class="details_contain_row">
							: 
							<select id="insert_product_category" class="insert_product_input_box" onblur="product_category_validation()">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="For Him">For Him</option>
								<option value="For Her">For Her</option>
								<option value="For Kids">For Kids</option>
								<option value="Newborn">Newborn</option>
							</select>
							<div><span id="insert_category_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Occasions</div>
						<div class="details_contain_row">
							: 
							<select id="insert_product_occasions" class="insert_product_input_box" onblur="product_occasion_validation()">
								<option disabled selected value="0"> -- select an option -- </option>
								<?php
									$get_product_occasions = mysqli_query($connect, "SELECT * FROM product_occasions");
									while($product_occasions_row = mysqli_fetch_assoc($get_product_occasions)){
								?>
										<option value="<?php echo $product_occasions_row['occasions_name'] ?>"><?php echo $product_occasions_row['occasions_name'] ?></option>
								<?php
									}
								?>
							</select>
							<div><span id="insert_occasion_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Description 1</div>
						<div class="details_contain_row">
							: <textarea name="insert_product_description_1" class="insert_product_desc_input_box" id="insert_product_description_1" onblur="product_desc1_validation('add')"></textarea>
							<div><span id="insert_desc1_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Description 2</div>
						<div class="details_contain_row">
							: <textarea name="insert_product_description_2" class="insert_product_desc_input_box" id="insert_product_description_2"></textarea>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Availability</div>
						<div class="details_contain_row">
							: 
							<select id="insert_product_availability" class="insert_product_input_box" onblur="product_availability_validation()">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="In Stock">In Stock</option>
								<option value="Out of Stock">Out of Stock</option>
							</select>
							<div><span id="insert_available_error" class="insert_product_error"></span></div>
						</div>
					</div>
					<div id="product_details_insert_row">
						<div class="product_details_insert_title">Status</div>
						<div class="details_contain_row">
							: 
							<select id="insert_product_status" class="insert_product_input_box" onblur="add_status_validation()">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="On Display">On Display</option>
								<option value="Hidden">Hidden</option>
							</select>
							<div><span id="insert_status_error" class="insert_product_error"></span></div>
						</div>
					</div>
				</div>
			</div>

			<div id="add_product_action_button">
				<button onclick="add_product()">
					<img src="image/product/save_icon.png">
				</button>
			</div>
		</div>
	</div>


	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Product successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this product?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_product_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>


<script type="text/javascript">
	$("#insert_product_price").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
	})

	$("#edit_product_price").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
	})

	//allow only 2 decimal point
	$('#insert_product_price').on('keypress',function (event) {
	    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
	        event.preventDefault();
	    }
	    var input = $(this).val();
	    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
	        event.preventDefault();
	    }
	});

	$('#edit_product_price').on('keypress',function (event) {
	    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
	        event.preventDefault();
	    }
	    var input = $(this).val();
	    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
	        event.preventDefault();
	    }
	});

</script>

</body>
</html>