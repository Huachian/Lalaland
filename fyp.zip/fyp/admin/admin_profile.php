<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/admin_profile.php");
	}

	if(isset($_POST['go_setting_profile'])){
		$_SESSION["profile_pic_reminder_popup"] = "already_display";
	}

	$admin_id = $_SESSION['id'];
    $admin_position = $_SESSION["admin_position"];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/admin_profile.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/admin_profile.js"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('profile_btn_wrap').style.background = "#ffff4d";
		document.getElementById('profile_btn_title').style.color = "black";
		document.getElementById('profile_icon').style.color = "black";
	</script>

  <?php
    if($admin_position == "Superadmin"){
    	$result = mysqli_query($connect,"SELECT * FROM superadmin WHERE superadmin_id='$admin_id'");
    	$admin = mysqli_fetch_assoc($result);
    }
    else{
    	$result = mysqli_query($connect,"SELECT * FROM admin WHERE admin_id='$admin_id'");
    	$admin = mysqli_fetch_assoc($result);
    }
  ?>

		
	<div class="profile_main_wrap">
	  <div class="profile_second_wrap">
   		<div class="profile_header">
	        My Profile
	    </div>
  
	    <div class="profilebox">
		<div class="top_menu">
	        <a href="admin_password.php">
	        	<button>Change Password</button>
	        </a>
		</div>
		
		    <div class="profile_body">
		    	<table id="profile_table">
		    		<tr>
		    			<td colspan="2">
		    				<div id="upload_profile_img_wrap">
			    				<div id="upload_image_preview_wrap">
			    				<?php
			    					if(empty($admin["profile_picture"])){
			    						$img_display_none = "display_none";
			    						$empty_display = "";
			    					}
			    					else{
			    						$img_display_none = "";
			    						$empty_display = "display_none";
			    					}
			    				?>
									<img src="image/admin_profile/<?php echo $admin["profile_picture"] ?>" id="insert_profile_image_preview" class="<?php echo $img_display_none ?>">
									<div id="upload_image_preview_empty" onclick="upload_image()" class="<?php echo $empty_display ?>">
										<div id="image_preview_empty_title">Upload Image</div>
									</div>
								</div>
								<div>
									<input type="file" name="product_image" accept="image/*" id="image_upload" onchange="preview_admin_image()" disabled>
								</div>
							</div>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Position
		    			</td>
		    			<td>
		    				<input type="text" name="position" id="position" class="profile_input_box" value="<?php echo $admin['position'] ?>" disabled>
		    				<br>
		    				<span class="profile_error_messange" id="first_name_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				First name
		    			</td>
		    			<td>
		    				<input type="text" name="first_name" id="first_name" class="profile_input_box" value="<?php echo $admin['first_name'] ?>" disabled onblur="first_name_validation()">
		    				<br>
		    				<span class="profile_error_messange" id="first_name_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Last name
		    			</td>
		    			<td>
		    				<input type="text" name="last_name" id="last_name" class="profile_input_box" value="<?php echo $admin['last_name'] ?>" disabled onblur="last_name_validation()">
		    				<br>
		    				<span class="profile_error_messange" id="last_name_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Email address
		    			</td>
		    			<td>
		    				<input type="text" class="profile_input_box" name="email" value="<?php echo $admin['email'] ?>" disabled>
		    				<br>
		    				<span class="profile_error_messange"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Phone Number
		    			</td>
		    			<td>
		    				<input type="tel" name="phone_number" class="profile_input_box" id="phone_number" value="<?php echo $admin['phone'] ?>" disabled onblur="phone_validation()" data-mask="999-99999999">
		    				<br>
		    				<span class="profile_error_messange" id="phone_number_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1 gender_title">
		    				Gender
		    			</td>
		    			<td id="gender_selection">
		    				<input type="hidden" name="gender" id="gender" value="<?php echo $admin['gender'] ?>">
	    					<input type="radio" name="gender" id="gender_male" <?php if($admin['gender']=="Male") {echo "checked";}?> value="Male" disabled><div id="male_tag">Male</div>
	    					<input type="radio" name="gender" id="gender_female" <?php if($admin['gender']=="Female") {echo "checked";}?> value="Female" disabled><div id="female_tag">Female</div>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_btn_wrap" colspan="2">
		    				<button id="edit_profile_btn" onclick="edit_profile()">Edit</button>
		    				<button id="cancel_edit_profile_btn" onclick="cancel_edit_profile()">Cancel</button>
		    				<button id="save_edit_profile_btn" onclick="save('<?php echo $admin_position ?>')">Save</button>
		    			</td>
		    		</tr>
		    	</table>
		    </div>
		</div>
	</div>


	<div id="edit_profile_alert_wrap">
	    <div id="edit_profile_alert_box">
	      <div id="edit_profile_alert_contain">
	        <img src="image/admin_password/tick_icon.png">
	        <div>
	          Profile Successfully updated
	        </div>
	      </div>
	    </div>
  	</div>

  	<script>
		//prevent form resubmit alert
	    if(window.history.replaceState){
	        window.history.replaceState(null, null, window.location.href);
	    }

		var side_bar_btn = document.getElementById('profile_btn_wrap');
		var side_bar_btn = side_bar_btn.offsetTop;
		document.getElementById('admin_side_navigation_wrap').scrollTop = side_bar_btn;
	</script>

	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>