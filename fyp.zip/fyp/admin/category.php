<?php
	session_start();
	include("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/category.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/category.css">
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('category_btn_wrap').style.background = "#ffff4d";
		document.getElementById('category_btn_title').style.color = "black";
		document.getElementById('category_icon').style.color = "black";
	</script>
	<div class="category_main_wrap">
		<div class="category_second_wrap">
			<div class="button_box_wrap">
				<div class="button_box">
					<div class="category_msg">
						Manage
					</div>
					<div class="product_type_btn_wrap">
						<a href="product_type.php">
							<button class="type_btn">
								Product Type
							</button>
						</a>
					</div>
					<div>
						<a href="product_occasion.php">
							<button class="occasion_btn">
								Product Occasion
							</button>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>