<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/voucher.php");
	}

	$admin_id = $_SESSION["id"];

	include ("dataconnection.php");

	date_default_timezone_set("Asia/Kuala_Lumpur");
	$today_date = date("Y-m-d");
	$today_date = date_parse($today_date);

	$result = mysqli_query($connect, "SELECT * FROM voucher");

	while($row = mysqli_fetch_assoc($result)){
		if(date_parse($row['end_date']) < $today_date){
			$voucher_id = $row['voucher_id'];

			mysqli_query($connect, "UPDATE voucher SET status='Expired' WHERE voucher_id='$voucher_id'");
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/voucher.css">
	<script type="text/javascript" src="js/voucher.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php include("navigation_bar.php"); ?>
	<script type="text/javascript">
		document.getElementById('voucher_btn_wrap').style.background = "#ffff4d";
		document.getElementById('voucher_btn_title').style.color = "black";
		document.getElementById('voucher_icon').style.color = "black";
	</script>

	<div class="voucher_main_wrap">
		<div class="voucher_second_wrap">
			<div id="voucher_page_title">
				Voucher List
			</div>

			<div id="voucher_page_top_action_wrap">
				<div id="search_voucher_wrap">
					<input type="text" id="search_voucher" placeholder="Search Voucher" onkeyup="filter_table()">
				</div>
				<div id="voucher_page_top_btn_wrap">
					<button onclick="add_voucher_popup()">Add Voucher</button>
				</div>
			</div>

			<div id="voucher_display_wrap">
				<table id="voucher_table">
					<tr>
						<th id="voucher_no_column">
							No
						</th>
						<th id="voucher_code_column">
							Voucher Code
						</th>
						<th id="voucher_type_column">
							Voucher Type
						</th>
						<th id="voucher_start_date_column">
							Voucher Start Date
						</th>
						<th id="voucher_end_date_column">
							Voucher End Date
						</th>
						<th id="voucher_quantity_column">
							Quantity
						</th>
						<th>
							Status
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_voucher = mysqli_query($connect, "SELECT * FROM	voucher ORDER BY voucher_id DESC");
						$i = 0;

						while($voucher_row = mysqli_fetch_assoc($select_voucher)){
							$i++;
					?>
							<tr class="voucher_row" id="voucher_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="voucher_delete_status<?php echo $i ?>" value="0">
								<td onclick="show_voucher_details('<?php echo $voucher_row['voucher_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td id="voucher_code_column" onclick="show_voucher_details('<?php echo $voucher_row['voucher_id'] ?>', '<?php echo $i ?>')">
									<span id="voucher_code<?php echo $i ?>"><?php echo $voucher_row['voucher_code'] ?></span>
								</td>
								<td onclick="show_voucher_details('<?php echo $voucher_row['voucher_id']  ?>', '<?php echo $i ?>')">
									<span id="voucher_type<?php echo $i ?>"><?php echo $voucher_row['voucher_type'] ?></span>
								</td>
								<td onclick="show_voucher_details('<?php echo $voucher_row['voucher_id'] ?>', '<?php echo $i ?>')">
								<?php
									$start_date = $voucher_row['start_date'];
							    	$start_date = strtotime($start_date);
							    	$start_date = date ("d-m-Y", $start_date);
								?>
									<span id="voucher_start_date<?php echo $i ?>"><?php echo $start_date ?></span>
								</td>
								<td onclick="show_voucher_details('<?php echo $voucher_row['voucher_id'] ?>', '<?php echo $i ?>')">
								<?php
									$end_date = $voucher_row['end_date'];
							    	$end_date = strtotime($end_date);
							    	$end_date = date ("d-m-Y", $end_date);
								?>
									<span id="voucher_end_date<?php echo $i ?>"><?php echo $end_date ?></span>
								</td>
								<td onclick="show_voucher_details('<?php echo $voucher_row['voucher_id']  ?>', '<?php echo $i ?>')">
									<span id="voucher_qty<?php echo $i ?>"><?php echo $voucher_row['quantity'] ?></span>
								</td>
								<td onclick="show_voucher_details('<?php echo $voucher_row['voucher_id']  ?>', '<?php echo $i ?>')">
									<?php
										if($voucher_row['status'] == "Enable"){
											date_default_timezone_set("Asia/Kuala_Lumpur");
											$today_date = date("Y-m-d");
											$today_date = date_parse($today_date);

											$start_date = date_parse($voucher_row['start_date']);

											if($start_date > $today_date){
												//havent reah the date
												$status_color = "status_waiting";
												$status = "Waiting";
											}
											else{
												//if reach date
												$status_color="status_enable";
												$status = $voucher_row['status'];
											}
										}
										else if($voucher_row['status'] == "Disable"){
											$status_color="status_disable";
											$status = $voucher_row['status'];
										}
										else if($voucher_row['status'] == "Expired"){
											$status_color="status_expired";
											$status = $voucher_row['status'];
										}
									?>
									<div class="<?php echo $status_color ?>" id="voucher_status<?php echo $i ?>"><?php echo $status ?></div>
								</td>
								<td id="voucher_button_column">
									<button onclick="show_voucher_details('<?php echo $voucher_row['voucher_id'] ?>', '<?php echo $i ?>')">
										<img src="image/voucher/view_icon.png">
									</button>

									<button onclick="delete_voucher('<?php echo $voucher_row['voucher_id'] ?>', '<?php echo $i ?>')">
										<img src="image/voucher/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>


	<div id="voucher_details_wrap">
		<div id="voucher_details_wrap_2">
			<div id="voucher_details_title">
				Voucher Details
			</div>

			<div id="voucher_details_box">
				<button id="close_voucher_details_btn" onclick="close_voucher_details()">
					<img src="image/voucher/close_icon.png">
				</button>

				<table id="voucher_details_table">
					<tr>
						<td class="voucher_details_table_title">
							Voucher Code
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_code_div" class="details_contain"></div>
							<input type="text" name="voucher_code" class="edit_voucher_input_box" id="edit_voucher_code" onblur="voucher_code_validation('edit')">
							<div id="edit_voucher_code_error" class="edit_voucher_error"></div>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							Voucher Type
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_type" class="details_contain"></div>
							<select id="edit_voucher_type" class="edit_voucher_input_box" onchange="voucher_type('edit')">
								<option value="Free Shipping">Free Shipping</option>
								<option value="Product Discount">Product Discount</option>
							</select>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							Minimum Spend (RM)
						</td>
						<td class="voucher_details_table_contain">
							:<div id="min_spend" class="details_contain"></div>
							<input type="number" name="min_spend" min="0" onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46" class="edit_voucher_input_box" id="edit_voucher_min_spend" onblur="min_spend_validation('edit')">
							<div id="edit_min_spend_error" class="edit_voucher_error"></div>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							Discount Amount (RM)
						</td>
						<td class="voucher_details_table_contain">
							:<div id="discount_amount" class="details_contain"></div>
							<input type="number" name="discount_amount" min="1" onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46" class="edit_voucher_input_box" id="edit_discount_amount" onblur="discount_amount_validation('edit')">
							<div id="edit_discount_amount_error" class="edit_voucher_error"></div>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							Description 
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_description" class="details_contain"></div>
							<textarea id="edit_voucher_description" onblur="voucher_description_validation('edit')"></textarea>
							<div id="edit_voucher_description_error" class="edit_voucher_error"></div>
						</td>
					</tr>
					<tr>
						<?php
							date_default_timezone_set("Asia/Kuala_Lumpur");

							$maxDate = date('Y-m-d', strtotime('+1 year'));
						?>
						<td class="voucher_details_table_title">
							Start date
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_start_date" class="details_contain"></div>
							<input type="date" name="voucher_start_date" class="edit_voucher_input_box" id="edit_voucher_start_date" max="<?php echo $maxDate ?>" onblur="voucher_edit_start_date_validation()" oninput="edit_check_end_date()">
							<div><span id="edit_voucher_start_date_error" class="edit_voucher_error"></span></div>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							End date
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_end_date" class="details_contain"></div>
							<input type="date" name="edit_voucher_end_date" class="edit_voucher_input_box" id="edit_voucher_end_date" max="<?php echo $maxDate ?>" onblur="voucher_edit_end_date_validation();edit_date_check_status();"  onkeyup="edit_date_check_status()" onchange="edit_date_check_status()" oninput="edit_check_start_date()">
							<div><span id="edit_voucher_end_date_error" class="edit_voucher_error"></span></div>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							Quantity
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_quantity" class="details_contain"></div>
							<input type="number" name="voucher_quantity" class="edit_voucher_input_box" id="edit_voucher_quantity" min="1" onkeypress="return event.charCode>=48 && event.charCode<=57" onblur="voucher_quantity_validation('edit')">
							<div id="edit_voucher_quantity_error" class="edit_voucher_error"></div>
						</td>
					</tr>
					<tr>
						<td class="voucher_details_table_title">
							Status
						</td>
						<td class="voucher_details_table_contain">
							:<div id="voucher_status" class="details_contain"></div>
							<select id="edit_voucher_status" class="edit_voucher_input_box" onblur="voucher_status_validation('edit')">
								<option disabled value="0"> -- select an option -- </option>
								<option value="Enable">Enable</option>
								<option value="Disable">Disable</option>
								<option value="Expired" disabled>Expired</option>
							</select>
							<div id="edit_voucher_status_error" class="edit_voucher_error"></div>
						</td>
					</tr>
				</table>
			</div>
			<div id="edit_voucher_action_button">
				<button id="edit_voucher_details_btn" onclick="edit_voucher()">
					<img src="image/voucher/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit_voucher()">
					<img src="image/voucher/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_voucher()">
					<img src="image/voucher/save_icon.png">
				</button>
			</div>
		</div>
	</div>


	<div id="add_new_voucher_wrap">
		<div id="add_new_voucher_wrap_2">
			<div id="add_voucher_top_title">
				Add Voucher
			</div>

			<div id="add_new_voucher_details_box">
				<button id="close_voucher_details_btn" onclick="close_insert_voucher()">
					<img src="image/voucher/close_icon.png">
				</button>

				<div id="insert_voucher_wrap">
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Voucher Code</div>
						<div class="details_contain_row">
							: <input type="text" name="insert_voucher_code" class="insert_voucher_input_box" id="insert_voucher_code" onblur="voucher_code_validation('add')" placeholder="Voucher Code">
							<div><span id="insert_voucher_code_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Voucher Type</div>
						<div class="details_contain_row">
							: 
							<select id="insert_voucher_type" class="insert_voucher_input_box" onblur="voucher_type_validation()" onchange="voucher_type('add')">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="Free Shipping">Free Shipping</option>
								<option value="Product Discount">Product Discount</option>
							</select>
							<div><span id="insert_voucher_type_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Minimum Spend (RM)</div>
						<div class="details_contain_row">
							: <input type="number" name="insert_min_spend" class="insert_voucher_input_box" id="insert_min_spend" onblur="min_spend_validation('add')" min="1" onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46" placeholder="Minimum Spend">
							<div><span id="insert_min_spend_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Discount Amount (RM)</div>
						<div class="details_contain_row">
							: <input type="number" name="insert_discount_amount" class="insert_voucher_input_box" id="insert_discount_amount" onblur="discount_amount_validation('add')" min="1" onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46" placeholder="Discount Amount">
							<div><span id="insert_discount_amount_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Description</div>
						<div class="details_contain_row">
							: <textarea name="insert_voucher_description" class="insert_voucher_description_input_box" id="insert_voucher_description" onblur="voucher_description_validation('add')"></textarea>
							<div><span id="insert_voucher_description_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
						<?php
							date_default_timezone_set("Asia/Kuala_Lumpur");
							$today_date = date("Y-m-d");

							$maxDate = date('Y-m-d', strtotime('+1 year'));
						?>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Start Date</div>
						<div class="details_contain_row">
							: <input type="date" name="insert_voucher_start_date" class="insert_voucher_input_box" id="insert_voucher_start_date" min="<?php echo $today_date ?>" max="<?php echo $maxDate ?>" onblur="voucher_insert_start_date_validation()" oninput="insert_check_end_date()">
							<div><span id="insert_voucher_start_date_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">End Date</div>
						<div class="details_contain_row">
							: <input type="date" name="insert_voucher_end_date" class="insert_voucher_input_box" id="insert_voucher_end_date" min="<?php echo $today_date ?>" max="<?php echo $maxDate ?>" onblur="voucher_insert_end_date_validation()" oninput="insert_check_start_date()">
							<div><span id="insert_voucher_end_date_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Quantity</div>
						<div class="details_contain_row">
							: <input type="number" name="insert_voucher_quantity" class="insert_voucher_input_box" id="insert_voucher_quantity" onblur="voucher_quantity_validation('add')" onkeypress="return event.charCode>=48 && event.charCode<=57" min="1" placeholder="Quantity">
							<div><span id="insert_voucher_quantity_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
					<div id="voucher_details_insert_row">
						<div class="voucher_details_insert_title">Status</div>
						<div class="details_contain_row">
							: 
							<select id="insert_voucher_status" class="insert_voucher_input_box" onblur="voucher_status_validation('add')">
								<option disabled selected value="0"> -- select an option -- </option>
								<option value="Enable">Enable</option>
								<option value="Disable">Disable</option>
							</select>
							<div><span id="insert_voucher_status_error" class="insert_voucher_error"></span></div>
						</div>
					</div>
				</div>
			</div>

			<div id="add_voucher_action_button">
				<button onclick="add_voucher()">
					<img src="image/voucher/save_icon.png">
				</button>
			</div>
		</div>
	</div>


	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/voucher/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Voucher successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="add_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Voucher successfully added
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this voucher?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_voucher_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

</body>
	<script type="text/javascript">
		//ignore 0 if user input 0 at first number
		$("#edit_voucher_min_spend").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})

		$("#edit_discount_amount").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})

		$("#insert_voucher_quantity").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})

		$("#insert_min_spend").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})

		$("#insert_discount_amount").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})


		//allow only 2 decimal point
		$('#edit_voucher_min_spend').on('keypress',function (event) {
		    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
		        event.preventDefault();
		    }
		    var input = $(this).val();
		    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
		        event.preventDefault();
		    }
		});

		$('#edit_discount_amount').on('keypress',function (event) {
		    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
		        event.preventDefault();
		    }
		    var input = $(this).val();
		    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
		        event.preventDefault();
		    }
		});

		$('#insert_min_spend').on('keypress',function (event) {
		    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
		        event.preventDefault();
		    }
		    var input = $(this).val();
		    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
		        event.preventDefault();
		    }
		});

		$('#insert_discount_amount').on('keypress',function (event) {
		    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
		        event.preventDefault();
		    }
		    var input = $(this).val();
		    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
		        event.preventDefault();
		    }
		});
	</script>
</html>

