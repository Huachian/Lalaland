<?php
	session_start();
	include ("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/banner.php");
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/banner.css">
	<script type="text/javascript" src="js/banner.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('banner_btn_wrap').style.background = "#ffff4d";
		document.getElementById('banner_btn_title').style.color = "black";
		document.getElementById('banner_icon').style.color = "black";
	</script>

	<div class="banner_main_wrap">
		<div class="banner_second_wrap">
			<div class="banner_page_title">
				Banner 
			</div>
			<div id="banner_page_top_action_wrap">
				<div id="search_banner_wrap">
					<input type="text" id="search_banner" placeholder="Search Banner" onkeyup="filter_table()">
				</div>
				<div id="banner_page_top_btn_wrap">
					<button onclick="add_banner_popup()">Add Banner</button>
				</div>
			</div>

			<div id="banner_display_wrap">
				<table id="banner_table">
					<tr>
						<th id="banner_no_column">
							No
						</th>
						<th id="banner_name_column">
							Banner Name
						</th>
						<th id="banner_status_column">
							Status
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_banner = mysqli_query($connect, "SELECT * FROM banner ORDER BY banner_id ASC");
						$i = 0;

						while($banner_row = mysqli_fetch_assoc($select_banner)){
							$i++;
					?>
							<tr class="banner_row" id="banner_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="banner_delete_status<?php echo $i ?>" value="0">
								<td onclick="show_banner_details('<?php echo $banner_row['banner_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td id="banner_name" onclick="show_banner_details('<?php echo $banner_row['banner_id'] ?>', '<?php echo $i ?>')">
									<span id="banner_name<?php echo $i ?>"><?php echo $banner_row['banner_name'] ?></span>
								</td>
								<td id="banner_status" onclick="show_banner_details('<?php echo $banner_row['banner_id'] ?>', '<?php echo $i ?>')">

									<?php
										if($banner_row['banner_status'] == "Display"){
											$banner_display = "display_tag";
										}
										else{
											$banner_display = "hide_tag";
										}
									?>

									<div class="<?php echo $banner_display?>" id="banner_status<?php echo $i ?>"><?php echo $banner_row['banner_status'] ?></div>
								</td>
								<td id="banner_button_column">
									<button onclick="show_banner_details('<?php echo $banner_row['banner_id']?>', '<?php echo $i ?>')">
										<img src="image/banner/view_icon.png">
									</button>
									<button onclick="delete_banner_pop_up('<?php echo $banner_row['banner_id'] ?>', '<?php echo $banner_row['banner_name'] ?>', '<?php echo $i ?>')">
										<img src="image/banner/dustbin_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>

	<div id="banner_details_wrap">
		<div id="banner_details_wrap_2">
			<div id="banner_details_title">
				Banner Details
			</div>

			<div id="banner_details_box">
				<button id="close_banner_details_btn" onclick="close_banner_details()">
					<img src="image/banner/close_icon.png">
				</button>

				<table id="banner_details_table">
					<tr>
						<input type="hidden" name="banner_id" id="details_banner_id">
						<div id="details_image_preview_wrap">
							<img src="" id="edit_banner_image_preview">
							<br>
							<input type="file" id="upload_edit_banner_image" accept="image/*" onchange="preview_banner_image('edit')">
						</div>

						<td class="banner_details_table_title">
							Name
						</td>
						<td class="banner_details_table_contain">
							:<div id="banner_details_name" class="details_contain"></div>
							<input type="input" class="edit_banner_input_box" id="edit_banner_name" disabled>
						</td>
					</tr>
					<tr>
						<td class="banner_details_table_title">
							Status
						</td>
						<td class="banner_details_table_contain">
							:<div id="banner_details_status" class="details_contain"></div>
							<select id="edit_banner_status" class="edit_banner_input_box">
								<option value="Display">Display</option>
								<option value="Hide">Hide</option>
							</select>
						</td>
					</tr>
				</table>
			</div>

			<div id="edit_banner_action_button">
				<button id="edit_banner_details_btn" onclick="edit_banner()">
					<img src="image/banner/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit_banner()">
					<img src="image/banner/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_banner()">
					<img src="image/banner/save_icon.png">
				</button>
			</div>

		</div>
	</div>

	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/banner/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_type/tick_icon.png">
				<div>
					Banner successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="add_new_banner_wrap">
		<div id="add_new_banner_wrap2">
			<div id="add_banner_top_title">
				Add New Banner
			</div>

			<div id="add_new_banner_details_box">
				<button id="close_insert_banner_btn" onclick="close_insert_banner()">
				<img src="image/banner/close_icon.png">
				</button>

				<div id="upload_banner_img_wrap">
					<div id="image_preview_wrap">
						<img src="" id="insert_banner_image_preview">
						<div id="image_preview_empty" onclick="upload_image()">
							<div id="image_preview_empty_title">Upload Image</div>
						</div>
					</div>
					<div>
						<input type="file" name="banner_image" accept="image/*" id="insert_image_upload" onchange="preview_banner_image('add')">
					</div>
					<div id="add_banner_error" class="add_banner_error"></div>
				</div>

				<div id="insert_banner_wrap">
					<div id="banner_insert_row">
						<div class="banner_insert_title"> Name</div>
						<div class="details_contain_row">
							: <input type="text" class="insert_banner_input_box" id="insert_banner_name" disabled>
						</div>
					</div>
					<div id="banner_insert_row">
						<div class="banner_insert_title">Status</div>
						<div class="details_contain_row">
							:	<select id="insert_status" class="insert_banner_input_box" onblur="insert_status_validation()">
									<option disabled selected value="0"> -- select an option -- </option>
									<option value="Display">Display</option>
									<option value="Hide">Hide</option>
								</select>
								<div id="insert_banner_status_error" class="edit_banner_error"></div>
						</div>
					</div>
				</div>
				
			</div>
			<div id="add_banner_action_button">
				<button onclick="add_banner()">
					<img src="image/banner/save_icon.png">
				</button>
			</div>
		</div>
	</div>

	<div id="add_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/banner/tick_icon.png">
				<div>
					Banner successfully added
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this banner?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_yes()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="min_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/banner/eror_icon.png">
				<div>
					Minimum must have at least 2 banner
				</div>
			</div>
		</div>
	</div>

	<div id="add_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/banner/eror_icon.png">
				<div>
					This file name already exist
				</div>
			</div>
		</div>
	</div>

</body>
	<script type="text/javascript">
	    var side_bar_btn = document.getElementById('banner_btn_wrap');
	    var side_bar_btn = side_bar_btn.offsetTop;
	    document.getElementById('admin_side_navigation_wrap').scrollTop = side_bar_btn;
  	</script>
</html>