<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/order.php");
	}

	$admin_position = $_SESSION["admin_position"];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/order.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" integrity="sha384-vSIIfh2YWi9wW0r9iZe7RJPrKwp6bG+s9QZMoITbCckVJqGCCRhc+ccxNcdpHuYu" crossorigin="anonymous">
	<script type="text/javascript" src="js/order.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('order_btn_wrap').style.background = "#ffff4d";
		document.getElementById('order_btn_title').style.color = "black";
		document.getElementById('order_icon').style.color = "black";
	</script>
	
	<div class="order_main_wrap">
		<div class="order_second_wrap">
			<div id="order_title">
				Orders
			</div>

			<div id="order_filter_header">
				<div id="order_search_bar">
					<?php
						if(isset($_GET['filter'])){
							$filter_contain = $_GET['filter'];
						}
						else{
							$filter_contain = "";
						}
					?>
					<input type="text" name="search_order" id="search_order" placeholder="Search Orders" onkeyup="filter_table()" value="<?php echo $filter_contain ?>" autocomplete="off">
				</div>
			</div>
			
				<?php
					if($admin_position == "Admin")
					{
						$pdf_btn="hide_pdf_btn";
					}
					else if($admin_position == "Superadmin")
					{
						$pdf_btn="display_pdf_btn";
					}
				?>
			<div id="pdf" class="<?php echo $pdf_btn?>">
				<a href="order_list_pdf.php" target="_blank">
					<button type="submit" id="pdf" name="order_list_pdf" class="btn btn-primary">
						<i class="fa fa-pdf" aria-hidden="true"></i>PDF
					</button>
				</a>
			</div>

			<div id="order_display_wrap">
				<table id="order_table">
					<tr>
						<th>
							Order ID
						</th>
						<th>
							Order Date
						</th>
						<th>
							Total
						</th>
						<th>
							Status
						</th>
						<th>
							Remark From Customer
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$select_order = mysqli_query($connect, "SELECT * FROM orders ORDER BY order_id DESC");
						$i=0;
						while($order_row = mysqli_fetch_assoc($select_order)){
					?>
							<tr id="order_row" onclick="showdetails(<?php echo $i ?>)" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" name="order_id" id="order_id<?php echo $i ?>" value="<?php echo $order_row['order_id'] ?>">
								<td class="order_column_1">
									<?php echo $order_row['order_id'] ?>
								</td>
								<td class="order_column_2">
									<?php
										$order_date = $order_row['order_date'];
								    	$order_date = strtotime($order_date);
								    	$order_date = date ("d-m-Y H:i:s", $order_date);  
									?>
									<?php echo $order_date ?>
								</td>
								<td class="order_column_3">
									RM<?php echo number_format($order_row['total_amount'], 2) ?>
								</td>
								<td class="order_column_4">
									<?php
										if($order_row['status'] == "Waiting for Shipment"){
											$order_status_class = "order_status_waiting";
										}
										else if($order_row['status'] == "Pending")
										{
											$order_status_class = "order_status_pending";
										}
										else if($order_row['status'] == "Cancelled")
										{
											$order_status_class = "order_status_cancelled";
										}
										else{
											$order_status_class = "order_status_shipped";
										}
									?>
									<div id="order_status<?php echo $i ?>" class="<?php echo $order_status_class ?> order_status"><?php echo $order_row['status'] ?></div>
								</td>
								<td class="order_column_5">
									<span id="customer_remark<?php echo $i ?>"><?php echo $order_row['customer_remark'] ?></span>
								</td>
								<td class="order_column_6">
									<button>
										<img src="image/orders/view_icon.png">
									</button>
								</td>
							</tr>
					<?php
							$i++;
						}
					?>
				</table>
			</div>
		</div>
	</div>


	<div id="order_details_wrap">
		<div id="order_details_wrap_2">
			<div id="order_details_box">
				<input type="hidden" id="order_id_in_view" value="">

				<button id="close_order_details_btn" onclick="close_order_details()">
					<img src="image/orders/close_icon.png">
				</button>

				<div id="order_details_title">
					ORDER ID. <span id="receipt_order_id_display"></span>
				</div>

				<div id="order_details">
					<div id="receipt_order_date_time"></div>

					<div id="order_status_wrap">
						<table>
							<tr>
								<td>Order status</td>
								<td>: 
									<select id="receipt_order_status" disabled>
										<option value="Waiting for Shipment">Waiting for Shipment</option>
										<option value="Shipped Out">Shipped Out</option>
										<option value="Pending">Pending</option>
										<option value="Cancelled">Cancelled</option>
									</select>
								</td>
							</tr>
							<tr id="delivery_date_row">
								<td>Delivery date</td>
								<td>: <span id="receipt_delivery_date"></span></td>
							</tr>
						</table>
					</div>

					<div id="order_customer_wrap">
						<div id="order_customer_title">
							Customer Details
						</div>
						<table>
							<tr>
								<td>ID</td>
								<td>: <span id="receipt_customer_id"></span></td>
							</tr>
							<tr>
								<td>Name</td>
								<td>: <span id="receipt_customer_name"></span></td>
							</tr>
							<tr>
								<td>Phone</td>
								<td>: <span id="receipt_customer_phone"></span></td>
							</tr>
							<tr>
								<td>email</td>
								<td>: <span id="receipt_customer_email"></span></td>
							</tr>
						</table>
					</div>

					<div class="break_line"></div>

					<div id="order_delivery_wrap">
						<div id="order_delivery_title">
							Delivery Address
						</div>
						<div>
							<span id="delivery_name"></span><input type="text" placeholder="Name" id="edit_delivery_name" onblur="order_name_validation()">
							<br>
							<span id="delivery_contact"></span><input type="text" placeholder="Contact Number" id="edit_delivery_contact" onblur="order_phone_validation()" data-mask="999-99999999">
							<br>
							<span id="delivery_address"></span><input type="text" placeholder="Address No, Jalan, Taman" id="edit_delivery_address" onblur="order_address_validation()">, 
							<br>
							<span id="delivery_postcode"></span><input type="text" placeholder="Postcode" id="edit_delivery_postcode" onblur="order_postcode_validation()"> <input type="text" placeholder="Area" id="edit_delivery_area" onblur="order_area_validation()"><span id="delivery_area"></span>,
							<br>
							<span id="delivery_state"></span><input type="text" placeholder="State" id="edit_delivery_state" onblur="order_state_validation()">.
						</div>
						<div id="edit_order_error" class="edit_order_error">
						</div>
					</div>


					<div id="order_product_wrap">
						<table id="order_product_table">
							<tr>
								<th>No</th>
								<th class="order_product_table_body_2">Description</th>
								<th>Quantity</th>
								<th class="order_product_title_right">Price (unit)</th>
								<th class="order_product_title_right">Discount (unit)</th>
								<th class="order_product_title_right">Amount</th>
							</tr>

							<tbody id="order_product_table_contain">
								
							</tbody>
						</table>

						<div id="customer_remark_wrap">
							Customer remark:
							<pre id="customer_remark_contain"></pre>
							<textarea id="customer_remark_textarea"></textarea>
						</div>
					</div>

					<div id="order_subtotal_wrap">
						<div id="order_subtotal_wrap_2">
							<table class="order_subtotal_table">
								<tr>
									<td  class="order_subtotal_table_title">Product Subtotal:</td>
									<td>RM<span id="merchandise_subtotal"></span></td>
								</tr>
								<tr>
									<td  class="order_subtotal_table_title">Shipping-Standard Delivery:</td>
									<td>RM<span id="receipt_shipping_fee"></span></td>
								</tr>
								<tr>
									<td  class="order_subtotal_table_title">Shipping Fee Discount:</td>
									<td>-RM<span id="receipt_shipping_fee_discount"></span></td>
								</tr>
								<tr>
									<td class="order_total_title">Order Total:</td>
									<td class="order_total_amount">RM<span id="receipt_order_total"></span></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="edit_order_action_button">
			<button id="edit_order_details_btn" onclick="edit_order()">
				<img src="image/orders/edit_icon.png">
			</button>
			<button id="cancel_edit_details_btn" onclick="cancel_edit_order()">
				<img src="image/orders/close_icon.png">
			</button>
			<button id="save_edit_details_btn" onclick="save_edit_order()">
				<img src="image/orders/save_icon.png">
			</button>
		</div>
	</div>


	<div class="alert_box_wrap" id="custom_card_details">
		<input type="hidden" id="card_id">
		<div class="custom_details_box">
			<button id="close_card_details_btn" onclick="close_card_details()">
				<img src="image/product/close_icon.png">
			</button>

			<div class="custom_details_title">
				Custom Card Details
			</div>

			<div class="card_image_wrap">
				<img src="" id="card_image">
				<div>
					<a href="" id="toggle_download_card_img">
						<i class="fas fa-download" id="download_card_img_btn"></i>
					</a>
				</div>
			</div>

			<div class="card_details_wrap">
				<div class="card_details_row">
					<div class="card_details_title">
						Card Name
					</div>
					<div class="card_details_output_wrap">
						: <span id="card_name"></span>
					</div>
				</div>

				<div class="card_details_row">
					<div class="card_details_title">
						Card Type
					</div>
					<div class="card_details_output_wrap">
						: 
						<select class="edit_card_input_box" disabled id="edit_card_type">
							<option value="vertical">Vertical</option>
							<option value="horizontal">Horizontal</option>
						</select>
					</div>
				</div>

				<div class="card_details_row">
					<div class="card_details_title">
						Card Message
					</div>
					<div class="card_details_output_wrap">
						: <pre id="card_message_display"></pre>
						<textarea id="edit_card_message" onblur="card_message_validation()"></textarea>
						<div id="card_message_error" class="card_message_error">Card message is required.</div>
					</div>
				</div>
			</div>

			<div id="edit_card_action_button">
				<button id="edit_card_details_btn" onclick="edit_card()">
					<img src="image/product/edit_icon.png">
				</button>
				<button id="cancel_edit_card_details_btn" onclick="cancel_edit_card()">
					<img src="image/product/close_icon.png">
				</button>
				<button id="save_card_details_btn" onclick="save_edit_card()">
					<img src="image/product/save_icon.png">
				</button>
			</div>

		</div>
	</div>





	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Order successfully updated
				</div>
			</div>
		</div>
	</div>

	<?php
		if(isset($_GET['filter'])){
	?>
			<script type="text/javascript">
				filter_table();
			</script>
	<?php
		}
	?>

	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>