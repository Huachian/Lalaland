<?php
	session_start();

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/product_customization.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/product_customization.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/product_customization.js"></script>
</head>
<body>
	<?php include("navigation_bar.php") ?>
	<script type="text/javascript">
		document.getElementById('custom_btn_wrap').style.background = "#ffff4d";
		document.getElementById('custom_btn_title').style.color = "black";
		document.getElementById('custom_icon').style.color = "black";
	</script>
	<div class="custom_main_wrap">
		<div class="custom_second_wrap">
			<div class="custom_page_title">
				Customization Card Product
			</div>
			<div id="custom_page_top_action_wrap">
				<div id="search_custom_wrap">
					<input type="text" id="search_custom" placeholder="Search Customization Card" onkeyup="filter_table()">
				</div>
			</div>

			<div id="custom_display_wrap">
				<table id="custom_table">
					<tr>
						<th id="custom_no_col">
							No
						</th>
						<th id="custom_card_type_col">
							Card Type
						</th>
						<th id="custom_card_price_col">
							Card Price
						</th>
						<th id="custom_card_stock_col">
							Stock
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$custom_card= mysqli_query($connect, "SELECT * FROM product_customization ORDER BY product_customization_id ASC");
						$i = 0;

						while($row = mysqli_fetch_assoc($custom_card)){
							$i++;
					?>
							<tr class="custom_row" id="custom_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<td onclick="show_custom_details('<?php echo $row['product_customization_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td id="custom_card_type" onclick="show_card_details('<?php echo $row['product_customization_id'] ?>', '<?php echo $i ?>')">
									<span id="card_type<?php echo $i ?>"><?php echo $row['card_type'] ?></span>
								</td>
								<td id="custom_card_price" onclick="show_card_details('<?php echo $row['product_customization_id'] ?>', '<?php echo $i ?>')">
									RM<span id="card_price<?php echo $i ?>"><?php echo number_format($row['card_price'], 2) ?></span>
								</td>
								<td id="custom_card_stock" onclick="show_card_details('<?php echo $row['product_customization_id'] ?>', '<?php echo $i ?>')">
									<?php
										if($row['card_stock'] == "In Stock"){
											$card_stock_tag = "in_stock_tag";
										}
										else{
											$card_stock_tag = "out_of_stock_tag";
										}
									?>
									<span class="<?php echo $card_stock_tag ?>" id="card_stock<?php echo $i ?>"><?php echo $row['card_stock'] ?></span>
								</td>
								<td id="card_type_button_column">
									<button onclick="show_card_details('<?php echo $row['product_customization_id']?>', '<?php echo $i ?>')">
										<img src="image/product_customization/view_icon.png">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>

	<div id="custom_details_wrap">
		<div id="custom_details_wrap2">
			<div id="custom_details_title">
				Custom Card Details
			</div>

			<div id="custom_details_box">
				<button id="close_custom_details_btn" onclick="close_card_details()">
					<img src="image/product_customization/close_icon.png">
				</button>

				<table id="custom_details_table">
					<tr>
						<input type="hidden" id="card_id">
						<td class="custom_details_table_title">
							Card Type
						</td>
						<td class="custom_details_table_contain">
							: <div id="card_type_div" class="details_contain"></div>
							<select id="edit_card_type" class="custom_card_input_box" disabled>
								<option value="Flat vertical">Flat vertical</option>
								<option value="Flat horizontal">Flat horizontal</option>
							</select>
						</td>
					</tr>
					<tr>
						<td class="custom_details_table_title">
							Card Price(RM)
						</td>
						<td class="custom_details_table_contain">
							: <div id="card_price_div" class="details_contain"></div>
							<input type="number" id="edit_card_price" class="custom_card_price_input_box" onblur="card_price_validation()"onkeypress="return event.charCode>=48 && event.charCode<=57 || event.keyCode == 46">
							<div id="edit_card_price_error" class="edit_error"></div>
						</td>
					</tr>
					<tr>
						<td class="custom_details_table_title">
							Stock
						</td>
						<td class="custom_details_table_contain">
							: <div id="card_stock_div" class="details_contain"></div>
							<select id="edit_card_stock" class="custom_card_input_box">
								<option value="In Stock">In Stock</option>
								<option value="Out of Stock">Out of Stock</option>
							</select>
						</td>
					</tr>
				</table>
			</div>

			<div id="edit_custom_action_button">
				<button id="edit_details_btn" onclick="edit_card()">
					<img src="image/product_customization/edit_icon.png">
				</button>
				<button id="cancel_edit_details_btn" onclick="cancel_edit()">
					<img src="image/product_customization/close_icon.png">
				</button>
				<button id="save_edit_details_btn" onclick="save_edit_type()">
					<img src="image/product_customization/save_icon.png">
				</button>
			</div>

		</div>
	</div>

	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_customization/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product_customization/tick_icon.png">
				<div>
					Card details successfully updated
				</div>
			</div>
		</div>
	</div>

</body>
<script type="text/javascript">
	$("#edit_card_price").on("input", function(){
	  if (/^0/.test(this.value)){
	    this.value = this.value.replace(/^0/, "");
	  }
	})

	//allow only 2 decimal point
	$('#edit_card_price').on('keypress',function (event) {
	    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
	        event.preventDefault();
	    }
	    var input = $(this).val();
	    if ((input.indexOf('.') != -1) && (input.substring(input.indexOf('.')).length > 2)) {
	        event.preventDefault();
	    }
	});

</script>
</html>