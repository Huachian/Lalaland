<?php
	session_start();
	include ("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: ../login_register.php?next=admin/promotion.php");
	}

	date_default_timezone_set("Asia/Kuala_Lumpur");
	$today_date = date("Y-m-d");
	$today_date = date_parse($today_date);

	$result = mysqli_query($connect, "SELECT * FROM promotion");

	while($row = mysqli_fetch_assoc($result)){
		if(date_parse($row['promotion_end_date']) < $today_date){
			$promotion_id = $row['promotion_id'];

			mysqli_query($connect, "UPDATE promotion SET status='Expired' WHERE promotion_id='$promotion_id'");
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift | Admin Panel</title>
	<link rel="icon" href="image/navigation_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/promotion.css">
	<script type="text/javascript" src="js/promotion.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="https://kit.fontawesome.com/49f22bfabd.js" crossorigin="anonymous"></script>
</head>
<body>
	<?php include("navigation_bar.php"); ?>
	<script type="text/javascript">
		document.getElementById('promotion_btn_wrap').style.background = "#ffff4d";
		document.getElementById('promotion_btn_title').style.color = "black";
		document.getElementById('promotion_icon').style.color = "black";
	</script>
	<div class="promotion_main_wrap">
		<div class="promotion_second_wrap">
			<div class="promotion_page_title">
				Promotion
			</div>
			<div id="promotion_top_action_wrap">
				<div id="search_promotion_wrap">
					<input type="text" id="search_promotion" placeholder="Search Promotion" onkeyup="filter_table()">
				</div>
				<div id="promotion_top_btn_wrap">
					<button onclick="add_promotion_popup();">Add Promotion</button>
				</div>
			</div>

			<div id="promotion_display_wrap">
				<table id="promotion_table">
					<tr>
						<th id="promotion_no_col">
							No
						</th>
						<th id="promotion_description_col">
							Promotion Description
						</th>
						<th>
							Product Type
						</th>
						<th>
							Start Date
						</th>
						<th>
							End Date
						</th>
						<th>
							Status
						</th>
						<th>
							
						</th>
					</tr>

					<?php
						$result = mysqli_query($connect, "SELECT * FROM promotion ORDER BY promotion_id DESC");
						$i=0;

						while($row = mysqli_fetch_assoc($result)){
							$i++;
					?>
							<tr class="promotion_row"  id="promotion_row<?php echo $i ?>" onmouseover="this.style.background='#ffff99'" onmouseout="filter_table()">
								<input type="hidden" id="promotion_delete_status<?php echo $i ?>" value="0">
								<td onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
									<span id="table_number<?php echo $i ?>"><?php echo $i ?></span>
								</td>
								<td class="promotion_description_contain_column" onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
									<span id="promotion_description<?php echo $i ?>"><?php echo $row['promotion_description'] ?></span>
								</td>
								<td onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
									<span id="promotion_product_type<?php echo $i ?>"><?php echo $row['promotion_product_type'] ?></span>
								</td>
								<td onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
								<?php
									$start_date = $row['promotion_start_date'];
							        $start_date = strtotime($start_date);
							        $start_date = date ("d-m-Y", $start_date);
								?>
									<span id="promotion_start_date<?php echo $i ?>"><?php echo $start_date ?></span>
								</td>
								<td onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
								<?php
									$end_date = $row['promotion_end_date'];
							        $end_date = strtotime($end_date);
							        $end_date = date ("d-m-Y", $end_date);
								?>
									<span id="promotion_end_date<?php echo $i ?>"><?php echo $end_date ?></span>
								</td>
								<td onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
									<?php
										if($row['status'] == "Enable"){
											date_default_timezone_set("Asia/Kuala_Lumpur");
											$today_date = date("Y-m-d");
											$today_date = date_parse($today_date);

											$start_date = date_parse($row['promotion_start_date']);

											if($start_date > $today_date){
												//havent reah the date
												$status_color = "status_waiting";
												$status = "Waiting";
											}
											else{
												//if reach date
												$status_color="status_enable";
												$status = $row['status'];
											}
										}
										else if($row['status'] == "Disable"){
											$status_color="status_disable";
											$status = $row['status'];
										}
										else if($row['status'] == "Expired"){
											$status_color="status_expired";
											$status = $row['status'];
										}
									?>
									<span class="<?php echo $status_color?>" id="promotion_status<?php echo $i ?>"><?php echo $status ?></span>
								</td>
								<td id="promotion_button_column">
									<button>
										<img src="image/promotion/view_icon.png" onclick="promotion_details_popup('<?php echo $row['promotion_id'] ?>', '<?php echo $i ?>')">
									</button>
									<button>
										<img src="image/promotion/dustbin_icon.png" onclick="delete_promotion('<?php echo $i ?>', '<?php echo $row['promotion_id'] ?>')">
									</button>
								</td>
							</tr>
					<?php
						}
					?>

				</table>
			</div>
		</div>
	</div>

	<div id="add_new_promotion_wrap">
		<div id="add_new_promotion_wrap2">
			<div id="add_promotion_top_title">
				Add New Promotion
			</div>

			<div id="add_new_promotion_details_box">
				<button id="close_insert_promotion_btn" onclick="close_add_promotion_popup()">
					<img src="image/promotion/close_icon.png">
				</button>

				<div id="promotion_insert_row">
					<div class="promotion_insert_title">Description</div>
					<div class="details_contain_row">
							: <textarea id="insert_promotion_description" class="insert_promotion_input_box" placeholder="Promotion Description" onblur="promotion_description_validation('add')"></textarea> 
						<div id="insert_description_error" class="insert_promotion_error"></div>
					</div>
				</div>
				<div id="promotion_insert_row">
					<div class="promotion_insert_title">Start Date</div>
					<div class="details_contain_row">
					<?php
						date_default_timezone_set("Asia/Kuala_Lumpur");
						$today_date = date("Y-m-d");
						$maxDate = date('Y-m-d', strtotime('+1 year'));
					?>
							: <input type="date" id="insert_promotion_start_date" class="insert_promotion_input_box" onblur="promotion_insert_start_date_validation()" min="<?php echo $today_date ?>" max="<?php echo $maxDate ?>" oninput="insert_end_date_check()">
						<div id="insert_start_date_error" class="insert_promotion_error"></div>
					</div>
				</div>
				<div id="promotion_insert_row">
					<div class="promotion_insert_title">End Date </div>
					<div class="details_contain_row">
							: <input type="date" id="insert_promotion_end_date" class="insert_promotion_input_box" onblur="promotion_insert_end_date_validation()" min="<?php echo $today_date ?>" max="<?php echo $maxDate ?>" oninput="insert_start_date_check()">
						<div id="insert_end_date_error" class="insert_promotion_error"></div>
					</div>
				</div>
				<div id="promotion_insert_row">
					<div class="promotion_insert_title">Status </div>
					<div class="details_contain_row">
							: <select id="insert_promotion_status" class="insert_promotion_input_box"  onblur="promotion_status_validation('add')">
								<option disabled selected value="0"> 
								-- select an option -- 
								</option>
								<option value="Enable">Enable</option>
								<option value="Disable">Disable</option>
							</select>
						<div id="insert_status_error" class="insert_promotion_error"></div>
					</div>
				</div>

			</div>
			<div>
				<button id="add_promotion_action_button" onclick="add_select_product_popup()">
					Select Product
				</button>
			</div>
		</div>
	</div>

	<div id="select_promotion_product_wrap">
		<div id="select_promotion_product_wrap2">
			<div class="back_btn_wrap">
				<button class="back_btn" onclick="back_to_add_promotion_popup()">
					<i class="fas fa-chevron-left"></i> Back
				</button>
			</div>
			<div id="select_promotion_product_header">
				Select Product for this Promotion
			</div>

			<div class="promotion_product_title">Product Type</div>
			<select id="promotion_product_type" class="promotion_product_input_box" onchange="get_product('add')">
				<option disabled selected value="0"> -- select an option -- </option>
				<?php
					$result = mysqli_query($connect, "SELECT * FROM product_type");

					while($row = mysqli_fetch_assoc($result)){
				?>
						<option value="<?php echo $row['product_type'] ?>"><?php echo $row['product_type'] ?></option>
				<?php
					}
				?>
			</select>
			<div id="insert_product_type_error"></div>

			<div id="promotion_product_display_wrap">
				<table id="promotion_product_table">
					<tr>
						<th>
							<input type="checkbox" name="checkbox_all" id="check_all" onclick="checkall(this)">
						</th>
						<th id="promotion_product_no_col">
							No
						</th>
						<th id="promotion_product_id_col">
							Product ID
						</th>
						<th id="promotion_product_name_col">
							Product Name
						</th>
						<th id="promotion_product_current_price_col">
							 Original / Current Price
						</th>
						<th id="promotion_product_discount_price_col">
							 Promotion Price
						</th>
						<th></th>
					</tr>

					<tbody class="promotion_product_details" id="promotion_product_details">
							
					</tbody>
				</table>
			</div>
		</div>

		<div class="confirm_btn_wrap">
			<button class="confirm_btn" onclick="add_promotion()">Confirm</button>
		</div>
	</div>

	<div id="promotion_details_wrap">
		<div id="promotion_details_wrap2">
			<div id="promotion_details_top_title">
			  	Promotion Details
			</div>
			<button id="close_insert_promotion_details_btn" onclick="close_promotion_details_popup()">
					<img src="image/promotion/close_icon.png">
			</button>
			<div id="promotion_details_box">
				<table id="promotion_details_table">
					<tr>
						<td class="promotion_details_table_title">
							Description
						</td>
						<td class="promotion_details_table_contain">
							:<div class="details_contain" id="description_div"></div>
							<textarea id="edit_promotion_description" class="edit_promotion_input_box" placeholder="Promotion Description" onblur="promotion_description_validation('edit')"></textarea>
							<div id="edit_description_error" class="edit_promotion_error">
						</td>
					</tr>
						<?php
							date_default_timezone_set("Asia/Kuala_Lumpur");

							$maxDate = date('Y-m-d', strtotime('+1 year'));
						?>
					<tr>
						<td class="product_details_table_title">
							 Start Date
						</td>
						<td class="product_details_table_contain">
							:<div class="details_contain" id="start_date_div"></div>
							<input type="date" id="edit_promotion_start_date" class="edit_promotion_input_box" max="<?php echo $maxDate ?>" onblur="promotion_edit_start_date_validation()" oninput="edit_end_date_check()">
							<div id="edit_start_date_error" class="edit_promotion_error"></div>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							 End Date
						</td>
						<td class="product_details_table_contain">
							:<div class="details_contain" id="end_date_div"></div>
							<input type="date" id="edit_promotion_end_date" class="edit_promotion_input_box" max="<?php echo $maxDate ?>" onblur="promotion_edit_end_date_validation(); edit_date_check_status();" onkeyup="edit_date_check_status()" onchange="edit_date_check_status()" oninput="edit_start_date_check()">
							<div id="edit_end_date_error" class="edit_promotion_error"></div>
						</td>
					</tr>
					<tr>
						<td class="product_details_table_title">
							 Status
						</td>
						<td class="product_details_table_contain">
							:<div class="details_contain" id="status_div"></div>
							<select id="edit_promotion_status" class="edit_promotion_input_box" onblur="promotion_status_validation('edit')">
								<option disabled value="0"> -- select an option -- </option>
								<option value="Enable">Enable </option>
								<option value="Disable">Disable</option>
								<option value="Expired" disabled>Expired</option>
							</select>
							<div id="edit_status_error" class="edit_promotion_error"></div>
						</td>
					</tr>
				</table>

			<div>
				<button id="promotion_details_action_button" onclick="view_select_product_popup()">
					View Promotion Product
				</button>
			</div>

			<div id="edit_promotion_details_action_button">
				<button id="edit_promotion_details_btn" onclick="edit_promotion_details(); calendar_date_validation('edit');">
					<img src="image/promotion/edit_icon.png">
				</button>
				<button id="cancel_edit_promotion_details_btn" onclick="cancel_edit_promotion_details()">
					<img src="image/promotion/close_icon.png">
				</button>
				<button id="save_edit_promotion_details_btn" onclick="save_edit_promotion_details()">
					<img src="image/promotion/save_icon.png">
				</button>
			</div>
			</div>
		</div>
	</div>

	<div id="view_select_promotion_product_wrap">
		<div id="view_select_promotion_product_wrap2">
			<div class="back_btn_wrap">
				<button class="back_btn" onclick="back_to_view_promotion_popup()"><i class="fas fa-chevron-left"></i> Back</button>
			</div>
			<div id="select_promotion_product_header">
				Select Product for this Promotion
			</div>

			<div class="promotion_product_title">Product Type</div>
			<select id="view_promotion_product_type" class="promotion_product_input_box" disabled>
				<option disabled selected value="0"> -- select an option -- </option>
				<?php
					$result = mysqli_query($connect, "SELECT * FROM product_type");

					while($row = mysqli_fetch_assoc($result)){
				?>
						<option value="<?php echo $row['product_type'] ?>"><?php echo $row['product_type'] ?></option>
				<?php
					}
				?>
			</select>

			<div id="view_promotion_product_display_wrap">
				<table id="view_promotion_product_table">
					<tr>
						<th>
							<input type="checkbox" name="checkbox_all" id="edit_promotion_check_all" onclick="edit_checkall(this)" disabled>
						</th>
						<th id="view_promotion_product_no_col">
							No
						</th>
						<th id="view_promotion_product_id_col">
							Product ID
						</th>
						<th id="view_promotion_product_name_col">
							Product Name
						</th>
						<th id="view_promotion_product_current_price_col">
							Original / Current Price
						</th>
						<th id="view_promotion_product_discount_price_col">
							Promotion Price
						</th>
						<th></th>
					</tr>
					<tbody id="view_promotion_product">
						
					</tbody>
				</table>
			</div>
		</div>

		<div id="edit_promotion_product_action_button">
			<button id="edit_promotion_product_btn" onclick="edit_promotion_product()">
				<img src="image/promotion/edit_icon.png">
			</button>
			<button id="cancel_edit_promotion_product_btn" onclick="cancel_edit_promotion_product()">
				<img src="image/promotion/close_icon.png">
			</button>
			<button id="save_edit_promotion_product_btn" onclick="save_edit_promotion_product()">
				<img src="image/promotion/save_icon.png">
			</button>
		</div>
	</div>

	<div id="edit_error_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/product/eror_icon.png">
				<div>
					Save the data before leave
				</div>
			</div>
		</div>
	</div>

	<div id="edit_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Promotion successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this promotion?
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes" onclick="delete_promotion_confirm()">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="set_promotion_product_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/eror_icon.png">
				<div id="set_promotion_product_alert_contain">
					Please fill in all promotion price
				</div>
			</div>
		</div>
	</div>

	<div id="edit_promotion_product_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/eror_icon.png">
				<div id="edit_promotion_product_alert_wrap_contain"></div>
			</div>
		</div>
	</div>

	<div id="add_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/orders/tick_icon.png">
				<div>
					Promotion successfully added
				</div>
			</div>
		</div>
	</div>
</body>

	<script type="text/javascript">
		//ignore 0 if user input 0 at first number
		function add_check_first_number(i){
			var price = document.getElementById("promotion_price_input_box"+i).value;
			if (/^0/.test(price)){
			    document.getElementById("promotion_price_input_box"+i).value = price.replace(/^0/, "");
			}
		}

		function edit_check_first_number(i){
			var price = document.getElementById("edit_promotion_price"+i).value;
			if (/^0/.test(price)){
			    document.getElementById("edit_promotion_price"+i).value = price.replace(/^0/, "");
			}
		}

		var validate = function(e){
		  var t = e.value;
		  e.value = (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t;
		}
	</script>
</html>