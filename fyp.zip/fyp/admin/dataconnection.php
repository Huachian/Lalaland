<?php
	$connect = mysqli_connect("localhost", "root", "", "fyp");
?>