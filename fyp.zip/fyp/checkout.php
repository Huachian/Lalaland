<?php
	session_start();
	include("dataconnection.php");

	if(isset($_SESSION["admin_position"])){
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Checkout | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/checkout.css">
	<script type="text/javascript" src="js/checkout.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<script type="text/javascript">
		sessionStorage.setItem('payment_page_valid', "no");
		sessionStorage.setItem('payment_status', "havent_done");
		
		let checkout_page_valid = sessionStorage.getItem('checkout_page_valid');

		if(checkout_page_valid != "yes"){
			window.location = "shopping_cart.php";
		}
	</script>

	<?php
		include("navigation_bar.php");
		$customer_id = $_SESSION["id"];
	?>

<style>
  tr.voucher_display_row:hover .voucher_card_left{
  	border-top:    3px solid #ffea96;
	border-right:  none;
	border-bottom: 3px solid #ffea96;
	border-left:   3px solid #ffea96;
	}
  tr.voucher_display_row:hover .voucher_card_right {
  	border-top:    3px solid #ffea96;
	border-right:  3px solid #ffea96;
	border-bottom: 3px solid #ffea96;
	border-left:   none;
  }
</style>

	<div id="checkout_main_wrap">
		<div id="address_wrap">
			<div id="address_title">
				<img src="image/checkout/address_icon.png">
				<span>Delivery Address</span>
			</div>
			<div id="default_address">
				<?php
					$default_address_data = mysqli_query($connect, "SELECT * FROM customer_address WHERE customer_id='$customer_id' AND address_default='Default'");
					$default_address_row = mysqli_fetch_assoc($default_address_data);
				?>
				<table>
					<tr>
						<input type="hidden" name="confirm_address_id" value="<?php echo $default_address_row['address_id']; ?>">
						<td id="receiver_name_tel">
							<span id="confirm_name"><?php echo $default_address_row['name']; ?></span> (+60) <span id="confirm_contact"><?php echo $default_address_row['contact']; ?></span>
						</td>
						<td id="receiver_address">
							<span id="confirm_address"><?php echo $default_address_row['address']; ?></span>, <span id="confirm_area"><?php echo $default_address_row['area']; ?></span> <span id="confirm_postcode"><?php echo $default_address_row['postcode']; ?></span>, <span id="confirm_state"><?php echo $default_address_row['state']; ?></span>.
						</td>
						<td id="default_tag">
							<span>Default</span>
						</td>
						<td id="address_btn_wrap">
							<button onclick="change_address()">Change</button>
						</td>
					</tr>
				</table>
			</div>

			<?php
				$all_address_data = mysqli_query($connect, "SELECT * FROM customer_address WHERE customer_id='$customer_id'");
			?>
			<div id="address_list_wrap">
				<div class="address_top_action">
					<button onclick="add_new_address_popup()">Add New Address</button>
					<a href="cus_address.php"><button>Manage Addresses</button></a>
				</div>
				<table>
					<?php
						$count = 0;
						while($all_address_row = mysqli_fetch_assoc($all_address_data)){
							$count++;
					?>
							<input type="hidden" name="address_id" value="<?php echo $all_address_row['address_id']; ?>" id="address_id<?php echo $count; ?>">
							<input type="hidden" name="select_address_default_value" id="select_address_default_value<?php echo $count; ?>" value="<?php echo $all_address_row['address_default'] ?>">
							<tr class="address_row" onclick="radio_check(<?php echo $count; ?>)">
								<td id="select_address">
									<?php
										$default_radio_btn = "";
										if($all_address_row['address_default'] == "Default"){
											$default_radio_btn = "checked";
										}
									?>
									<input type="radio" name="select_address" value="<?php echo $all_address_row['address_id']; ?>" <?php echo $default_radio_btn; ?> id="select_address<?php echo $count; ?>">
								</td>
								<td id="receiver_name_tel">
									<span id="selected_name<?php echo $count; ?>"><?php echo $all_address_row['name']; ?></span> (+60) <span id="selected_contact<?php echo $count; ?>"><?php echo $all_address_row['contact']; ?></span>
								</td>
								<td id="customer_address">
									<span id="selected_address<?php echo $count; ?>"><?php echo $all_address_row['address']; ?></span>, <span id="selected_area<?php echo $count; ?>"><?php echo $all_address_row['area']; ?></span> <span id="selected_postcode<?php echo $count; ?>"><?php echo $all_address_row['postcode']; ?></span>, <span id="selected_state<?php echo $count; ?>"><?php echo $all_address_row['state']; ?></span>.
								</td>
							<?php
								if($all_address_row['address_default'] == "Default"){
							?>
									<td id="default_tag">
										<span>Default</span>
									</td>
							<?php
								}
							?>
							</tr>
					<?php
						}
					?>
				</table>

				<div class="address_list_action">
					<button id="submit_address_btn" onclick="select_shipping_address()">Submit</button>
					<button id="cancle_address_btn" onclick="cancle_submit_address()">Cancel</button>
				</div>
			</div>
		</div>


		<div id="order_product_wrap">
				<table>
					<tr class="table_head">
						<td colspan="2" id="head1">Order Product</td>
						<td id="head2">Unit Price</td>
						<td id="head3">Quantity</td>
						<td id="head4">Total</td>
					</tr>

					<?php
						$total = 0;
						$sub_total = 0;
						$custom_cart_result = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='in process'");
						while($row = mysqli_fetch_assoc($custom_cart_result)){
							$product_id = $row['product_customization_id'];
							$card_type = $row['card_type'];
							$quantity = 1;

							if($card_type == "vertical"){
								$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat vertical'");
								$get_price_row = mysqli_fetch_assoc($get_price);

								$card_price = $get_price_row['card_price'];
							}
							else if($card_type == "horizontal"){
								$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat horizontal'");
								$get_price_row = mysqli_fetch_assoc($get_price);

								$card_price = $get_price_row['card_price'];
							}

							$total = $card_price * $quantity;
							$sub_total += $total;
					?>
							<tr class="display_order_product">
								<td id="body1"><img src="admin/image/customization/<?php echo $row['card_image'] ?>"></td>
								<td id="body2"><b>[Custom <?php echo $row['card_type']; ?> card]</b> <?php echo $row['card_name']; ?></td>
								<td id="body3">RM<?php echo number_format($card_price, 2); ?></td>
								<td id="body4"><?php echo $quantity ?></td>
								<td id="body5">RM<?php echo number_format($total, 2); ?></td>
							</tr>
					<?php
						}
					?>



					<?php
						$shopping_cart_result = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND status='in process'");
						while($row = mysqli_fetch_assoc($shopping_cart_result)){
							$product_id = $row['product_id'];
							$result_1 = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
							$row_1 = mysqli_fetch_assoc($result_1);
					?>
							<tr class="display_order_product">
								<td id="body1">
									<img src="admin/image/product_image/<?php echo $row_1['product_image'] ?>">
								</td>
								<td id="body2">
									<?php echo $row_1['product_name']; ?>
								</td>
								<td id="body3">
									<?php
										date_default_timezone_set("Asia/Kuala_Lumpur");
										$today_date = date("Y-m-d");
										$today_date = date_parse($today_date);

										$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

										$product_promotion_price = $row_1['product_price'];
										$found_promotion = "false";

										if(mysqli_num_rows($check_promotion) != 0){
											while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
												$promotion_id = $check_promotion_row['promotion_id'];

												$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
												$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

												if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
													$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

													$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

													if(mysqli_num_rows($check_promotion_product) != 0){
														if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
															$product_promotion_price = $check_promotion_product_result['promotion_price'];
														}
													}

													if(mysqli_num_rows($check_promotion_product) != 0){
														$found_promotion = "true";
													}
												}
											}
										}
										else{
											$product_promotion_price = 0;
											$found_promotion = "false";
										}


										if($found_promotion == "true"){
									?>		
											<div class="cancel_normal_price">
												RM<span><?php echo number_format($row_1['product_price'], 2); ?></span>
											</div>
											<div class="promotion_price">
												RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_promotion_price,2); ?></span>
											</div>
									<?php
										}
										else{
									?>
											<div>
												RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($row_1['product_price'], 2); ?></span>
											</div>
									<?php
										}
									?>
								</td>
								<td id="body4">
									<?php echo $row['quantity']; ?>
								</td>
								<td id="body5">
								<?php
									if($found_promotion == "true"){
										$total = $product_promotion_price * $row['quantity'];
									}
									else{
										$total = $row_1['product_price'] * $row['quantity'];
									}

									$sub_total += $total;
								?>
									RM<?php echo number_format($total, 2); ?>
								</td>
							</tr>
					<?php
						}
					?>
				</table>
		</div>

		<table id="promotecode_message_wrap">
			<tr class="row1">
				<td id="drop_message_title">
					Drop a message to us :
				</td>
				<td>
					<textarea rows="4" id="buyer_message"></textarea>
				</td>
			</tr>
			<tr class="row2">
				<td id="promo_code_title">
					<img src="image/checkout/promo_code_icon.PNG">
					Voucher :
				</td>
				<td>
					<button id="voucher_button" onclick="voucher_popup()"> 
						Select Voucher
					</button>
					<span id="selected_voucher_code"></span>
				</td>
			</tr>
		</table>


		<div class="select_payment_wrap">
			<div class="payment_method">
				<div id="payment_method_title">
					Payment Method
				</div>
				<div>
					<button>Debit / Credit Card</button>
				</div>
			</div>

			<div class="amount_summary">
				<table>
					<tr>
						<td id="amount_summary_title">Product Subtotal :</td>
						<td>RM<span id="product_subtotal"><?php echo number_format($sub_total, 2); ?></span></td>
						<input type="hidden" id="original_product_subtotal" value="<?php echo $sub_total ?>">
					</tr>
					<tr>
						<td id="amount_summary_title">Shipping fee :</td>
						<td>RM<span id="shipping_fee">10.00</span></td>
						<input type="hidden" id="original_shipping_fee" value="10">
					</tr>
					<tr id="total_price_row">
						<td id="amount_summary_title" style="font-weight: bold;">Total payment :</td>
						<td id="total_price">RM<span id="total_payment"><?php echo number_format($sub_total+10, 2); ?></span></td>
						<input type="hidden" id="original_total_payment" value="<?php echo $sub_total+10 ?>">
					</tr>
				</table>
			</div>

			<div id="make_payment_btn">
				<button type="button" onclick="go_payment()">Make Payment</button>
			</div>
		</div>
	</div>


	<!-- add new address form -->
  <div id="add_address_wrap">
    <div id="add_address_box">
      <div class="add_address_title">
        <h4>Add A New Address</h4>
      </div>

      <div class="add_address_body">
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_name" placeholder="Full Name" id="address_name" onblur="nameValidation()">
          <span id="adds_name_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_phone" placeholder="Phone Number" id="address_phone" onblur="phoneValidation()" data-mask="999-99999999">
          <span id="adds_phone_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="new_address" placeholder="Address" id="new_address" onblur="addressValidation()">
          <span id="adds_add_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_postcode" placeholder="Postcode" id="address_postcode" onblur="postcodeValidation()">
          <span id="adds_post_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_state" placeholder="State" id="address_state" onblur="stateValidation()">
          <span id="adds_state_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_area" placeholder="Area" id="address_area" onblur="areaValidation()">
          <span id="adds_area_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="checkbox" name="set_new_default" id="set_new_default">
          <div id="set_new_default_label">Set as default address</div>
        </div>
      </div>

      <div class="add_address_btn">
        <button id="cancel_add_address" onclick="cancel_address()">Cancel</button>
        <button onclick="submit_address()">Submit</button>
      </div>
    </div>
  </div>


  <div id="add_address_alert_wrap">
    <div id="add_address_alert_box">
      <div id="add_address_alert_contain">
        <img src="image/checkout/tick_icon.png">
        <div>
          Address Successfully Added
        </div>
      </div>
    </div>
  </div>


  	<div id="voucher_box_wrap">
		<div id="voucher_box_wrap_2">
			<div id="voucher_box_header">
					Select Voucher
			</div>

			<div id="voucher_non_select_item_error">
				Select items in cart first to apply vouchers
			</div>

			<div id="voucher_box_detais">
				<table class="voucher_inner_box">
				<?php
					date_default_timezone_set("Asia/Kuala_Lumpur");
					$today_date = date("Y-m-d");
					$today_date = date_parse($today_date);

					$result = mysqli_query($connect, "SELECT * FROM voucher WHERE status='Enable'");
					$i=0;

					while($row = mysqli_fetch_assoc($result)){
						$voucher_start_date = date_parse ($row['start_date']);
						$voucher_end_date = date_parse ($row['end_date']);

						if($today_date >= $voucher_start_date && $voucher_end_date >= $today_date){
							$i++;
				?>
							<tr class="voucher_display_row" id="voucher_display_row<?php echo $i ?>" onclick="select_voucher('<?php echo $row['voucher_id'] ?>', '<?php echo $row['voucher_code'] ?>', '<?php echo $i ?>')">
								<input type="hidden" id="voucher_fufile<?php echo $i ?>" value="">
								<input type="hidden" id="voucher_code<?php echo $i ?>" value="<?php echo $row['voucher_code'] ?>">
								<input type="hidden" id="voucher_qty<?php echo $i ?>" value="<?php echo $row['quantity'] ?>">

								<td class="voucher_card_left" id="voucher_card_left<?php echo $i ?>">
									<div class="voucher_card_left_type">
									<?php
										if($row['voucher_type'] == "Free Shipping"){
											$voucher_title = "free_shipping_voucher_title";
										}
										else{
											$voucher_title = "";
										}
									?>
										<span id="<?php echo $voucher_title ?>"><?php echo $row['voucher_type'] ?></span>
										<input type="hidden" id="voucher_type<?php echo $i ?>" value="<?php echo $row['voucher_type'] ?>">
									</div>
								</td>
								<td class="voucher_card_right" id="voucher_card_right<?php echo $i ?>">
									<div class="voucher_card_details">
										<div id="voucher_min_spend">
											Min Spend RM<?php echo $row['min_spend'] ?>
											<input type="hidden" id="voucher_min_spend<?php echo $i ?>" value="<?php echo $row['min_spend'] ?>">
										</div>
										<div id="voucher_second_details">
										<?php
											if($row['voucher_type'] == "Product Discount"){
										?>
												Product Discount RM<?php echo $row['discount_amount'] ?>
												<input type="hidden" id="voucher_discount_amount<?php echo $i ?>" value="<?php echo $row['discount_amount'] ?>">
										<?php
											}
											else{
										?>
												<input type="hidden" id="voucher_discount_amount<?php echo $i ?>" value="<?php echo $row['discount_amount'] ?>">
										<?php
											}
										?>
										</div>
										<div id="voucher_valid_date">
										<?php
											$date = strtotime($row['end_date']);
											$FormattedPhpDate = date('d.m.Y', $date);
										?>
											Valid till: <?php echo $FormattedPhpDate ?>
										</div>
									</div>

									<div class="min_spend_not_valid_wrap" id="min_spend_not_valid<?php echo $i ?>">
										Does not meet min. spend.
									</div>
									<div class="min_spend_not_valid_wrap" id="qty_not_valid<?php echo $i ?>">
										Voucher is not available.
									</div>
								</td>
							</tr>
				<?php
						}
					}

					if($i == 0){
				?>
						<tr>
							<td colspan="2">
								<div id="no_available_voucher_display">
									No available voucher found
								</div>
							</td>
						</tr>
				<?php
					}
				?>
				</table>
			</div>

			<div class="voucher_button_box">
				<button class="cancel_btn" onclick="cancel_voucher_popup()">CANCEL</button>
				<button class="proceed_btn" onclick="apply_voucher()">OK</button>
			</div>
		</div>
	</div>

	<div id="selected_voucher_not_available_popup" class="empty_alert_wrap">
		<div id="empty_alert_box">
			<div id="empty_alert_contain">
				<img src="image/checkout/eror_icon.png">
				<div>
					Oops! Something went wrong...
				</div>
			</div>
		</div>
	</div>


	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>