<?php 
	session_start();
	include("../dataconnection.php");

	$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);
	$quantity = mysqli_real_escape_string($connect, $_POST['quantity']);
	$operation = $_POST['operation'];
	
	if(isset($_SESSION["id"])){
		$customer_id = $_SESSION["id"];
	}
	
	if($operation == "add_qty" || $operation == "minus_qty" || $operation == "manual_key_in"){
		mysqli_query($connect, "UPDATE shopping_cart SET quantity='$quantity' WHERE customer_id='$customer_id' AND product_id='$product_id'");
	}

	if($operation == "delete_cart_item"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		if($product_type == "normal_product"){
			mysqli_query($connect, "DELETE FROM shopping_cart WHERE customer_id='$customer_id' AND product_id='$product_id'");
		}
		else{
			$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND card_id='$product_id'");
			$row = mysqli_fetch_assoc($result);
			
			unlink("../admin/image/customization/".$row['card_image']);

			mysqli_query($connect, "DELETE FROM customization_card WHERE customer_id='$customer_id' AND card_id='$product_id'");
		}
	}

	if($operation == "add_cart_1"){
		if(isset($_SESSION["id"])){
			$record_checking = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND product_id='$product_id'");
			$record_checking_row = mysqli_fetch_assoc($record_checking);
			
			if(isset($record_checking_row)){
				$record_quantity = $record_checking_row['quantity'];

				$record_quantity += 1;

				if($record_quantity > 999){
					$record_quantity = 999;
				}

				mysqli_query($connect, "UPDATE shopping_cart SET quantity='$record_quantity' WHERE customer_id='$customer_id' AND product_id='$product_id'");
			}
			else if(empty($record_checking_row)){
				mysqli_query($connect, "INSERT INTO shopping_cart (customer_id, product_id, quantity, status) VALUES ('$customer_id', '$product_id', 1, 'waiting checkout')");
			}

			echo "login_true";
		}
		else{
			echo "login_false";
		}
	}

	if($operation == "add_cart_2" || $operation == "buy_now"){
		if(isset($_SESSION["id"])){
			$record_checking = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND product_id='$product_id'");
			$record_checking_row = mysqli_fetch_assoc($record_checking);
			
			if(isset($record_checking_row)){
				$record_quantity = $record_checking_row['quantity'];
				$record_quantity += $quantity;

				if($record_quantity > 999){
					$record_quantity = 999;
				}

				mysqli_query($connect, "UPDATE shopping_cart SET quantity='$record_quantity' WHERE customer_id='$customer_id' AND product_id='$product_id'");
			}
			else if(empty($record_checking_row)){
				mysqli_query($connect, "INSERT INTO shopping_cart (customer_id, product_id, quantity, status) VALUES ('$customer_id', '$product_id', '$quantity', 'waiting checkout')");
			}

			echo "login_true";
		}
		else{
			echo "login_false";
		}
	}

	if($operation == "update_status"){
		$product_type = mysqli_real_escape_string($connect, $_POST['product_type']);
		if($product_type == "normal_product"){
			mysqli_query($connect, "UPDATE shopping_cart SET status='in process' WHERE customer_id='$customer_id' AND product_id='$product_id'");
		}
		else{
			mysqli_query($connect, "UPDATE customization_card SET status='in process' WHERE customer_id='$customer_id' AND card_id='$product_id'");
		}
	}
	
?>