<?php
	session_start();
	include("../dataconnection.php");
	$operation = $_POST['operation'];

	if(isset($_SESSION['id'])){
		$customer_id = $_SESSION['id'];
	}

	if($operation == "check_login"){
		if(isset($_SESSION['id'])){
			echo "login_true";
		}
		else{
			echo "login_false";
		}
	}


	if($operation == "save_card_img"){
		$card_type = mysqli_real_escape_string($connect, $_POST['card_type']);


		$targetDir = "../admin/image/customization/";
		$fileName = basename($_FILES["card_image"]["name"]);
		$targetFilePath = $targetDir . $fileName;
		$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

		$fileName = uniqid();
		$fileName .= ".".$fileType;
		$targetFilePath = $targetDir . $fileName;

		move_uploaded_file($_FILES["card_image"]["tmp_name"], $targetFilePath);

		if($card_type == "vertical"){
			$tem_card_type = "Flat vertical";
		}
		else{
			$tem_card_type = "Flat horizontal";
		}

		$result = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='$tem_card_type'");
		$row = mysqli_fetch_assoc($result);
		$product_customization_id = $row['product_customization_id'];

		mysqli_query($connect, "INSERT INTO customization_card (customer_id, card_type, card_image, status, product_customization_id) VALUES ('$customer_id', '$card_type', '$fileName', 'waiting design', '$product_customization_id')");

		$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' ORDER BY card_id DESC LIMIT 1");

		$row = mysqli_fetch_assoc($result);

		echo $row['card_id'];
	}


	if($operation == "add_to_cart"){
		$current_card_id = mysqli_real_escape_string($connect, $_POST['current_card_id']);
		$card_message = mysqli_real_escape_string($connect, $_POST['card_message']);
		$card_name = mysqli_real_escape_string($connect, $_POST['card_name']);

		mysqli_query($connect, "UPDATE customization_card SET card_name='$card_name', card_message='$card_message', status='waiting checkout' WHERE card_id='$current_card_id'");

		$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='waiting design'");

		while($row = mysqli_fetch_assoc($result)){
			unlink("../admin/image/customization/".$row['card_image']);
		}

		mysqli_query($connect, "DELETE FROM customization_card WHERE customer_id='$customer_id' AND status='waiting design'");
	}


	if($operation == "save_edit_card"){
		$card_id = mysqli_real_escape_string($connect, $_POST['card_id']);
		$card_message = mysqli_real_escape_string($connect, $_POST['card_message']);

		if($_FILES['card_image']["tmp_name"]){
			//img
			$targetDir = "../admin/image/customization/";
			$fileName = basename($_FILES["card_image"]["name"]);
			$targetFilePath = $targetDir . $fileName;
			$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

			$fileName = uniqid();
			$fileName .= ".".$fileType;
			$targetFilePath = $targetDir . $fileName;

			$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE card_id='$card_id'");
			$row = mysqli_fetch_assoc($result);

			unlink("../admin/image/customization/".$row['card_image']);

			move_uploaded_file($_FILES["card_image"]["tmp_name"], $targetFilePath);

			mysqli_query($connect, "UPDATE customization_card SET card_image='$fileName', card_message='$card_message' WHERE card_id='$card_id'");
		}
		else{
			mysqli_query($connect, "UPDATE customization_card SET card_message='$card_message' WHERE card_id='$card_id'");
		}
	}

?>