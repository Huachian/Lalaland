<?php
    session_start();
    include("../dataconnection.php");

    $operation = $_POST["operation"];

    if(isset($_SESSION["id"])){
        $customer_id = $_SESSION["id"];
    }

    if($operation == "update_profile"){
        $first_name = mysqli_real_escape_string($connect, $_POST["first_name"]);    
        $last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);    
        $phone_number = mysqli_real_escape_string($connect, $_POST["phone_number"]);
        $gender = mysqli_real_escape_string($connect, $_POST["gender"]);

        mysqli_query($connect, "UPDATE customer SET first_name='$first_name', last_name='$last_name', phone='$phone_number', gender='$gender' WHERE customer_id='$customer_id'");
    }

    if($operation == "delete_address"){
        $address_id = mysqli_real_escape_string($connect, $_POST["delete_address_id"]);    

        mysqli_query($connect, "DELETE FROM customer_address WHERE address_id='$address_id'");
    }

    if($operation == "add_new_address"){
        $address_name = mysqli_real_escape_string($connect, $_POST["address_name"]);
        $address_phone = mysqli_real_escape_string($connect, $_POST["address_phone"]);
        $new_address = mysqli_real_escape_string($connect, $_POST["new_address"]);
        $address_postcode = mysqli_real_escape_string($connect, $_POST["address_postcode"]);
        $address_state = mysqli_real_escape_string($connect, $_POST["address_state"]);
        $address_area = mysqli_real_escape_string($connect, $_POST["address_area"]);
        $address_default = mysqli_real_escape_string($connect, $_POST["address_default"]);

        if($address_default == "Default"){
            mysqli_query($connect, "UPDATE customer_address SET address_default='NotDefault' WHERE customer_id='$customer_id'");
        }

        mysqli_query($connect, "INSERT INTO customer_address (customer_id, name, contact, address, postcode, state, area, address_default) VALUES ('$customer_id', '$address_name', '$address_phone', '$new_address', '$address_postcode', '$address_state', '$address_area', '$address_default')");
    }

    if($operation == "save_edit_address"){
        $address_id = mysqli_real_escape_string($connect, $_POST["address_id"]);
        $address_name = mysqli_real_escape_string($connect, $_POST["address_name"]);
        $address_phone = mysqli_real_escape_string($connect, $_POST["address_phone"]);
        $address = mysqli_real_escape_string($connect, $_POST["address"]);
        $address_postcode = mysqli_real_escape_string($connect, $_POST["address_postcode"]);
        $address_state = mysqli_real_escape_string($connect, $_POST["address_state"]);
        $address_area = mysqli_real_escape_string($connect, $_POST["address_area"]);
        $address_default = mysqli_real_escape_string($connect, $_POST["address_default"]);

        if($address_default == "Default"){
            mysqli_query($connect, "UPDATE customer_address SET address_default='NotDefault' WHERE customer_id='$customer_id'");
        }

        mysqli_query($connect, "UPDATE customer_address SET name='$address_name', contact='$address_phone', address='$address', postcode='$address_postcode', state='$address_state', area='$address_area', address_default='$address_default' WHERE address_id='$address_id'");
    }

    if($operation == "change_default"){
        $address_id = mysqli_real_escape_string($connect, $_POST["address_id"]);

        mysqli_query($connect, "UPDATE customer_address SET address_default='NotDefault' WHERE customer_id='$customer_id'");
        mysqli_query($connect, "UPDATE customer_address SET address_default='Default' WHERE customer_id='$customer_id' AND address_id='$address_id'");
    }

    if($operation == "update_password"){
        $current_password = mysqli_real_escape_string($connect, $_POST["current_password"]);
        $new_password = mysqli_real_escape_string($connect, $_POST["new_password"]);

        $check_password = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id' AND password='$current_password'");
        $check_password_result = mysqli_num_rows($check_password);

        if($check_password_result > 0){
            if($current_password === $new_password){
                echo "password_same_with_old";
            }
            else{
                mysqli_query($connect, "UPDATE customer SET password='$new_password' WHERE customer_id='$customer_id'");
                echo "update_success";
            }
        }
        else{
            echo "update_fail";
        }  
    }

    if($operation == "check_send_reset_email"){
        $email = mysqli_real_escape_string($connect, $_POST['email']);

        $check_email = mysqli_query($connect, "SELECT * FROM customer WHERE email='$email'");
        $check_email_row = mysqli_num_rows($check_email);

        $check_email_1 = mysqli_query($connect, "SELECT * FROM superadmin WHERE email='$email'");
        $check_email_row_1 = mysqli_num_rows($check_email_1);

        $check_email_2 = mysqli_query($connect, "SELECT * FROM admin WHERE email='$email'");
        $check_email_row_2 = mysqli_num_rows($check_email_2);

        if($check_email_row > 0){
            $row = mysqli_fetch_assoc($check_email);

            if($row['reset_token'] == "inactive"){
                $check_email_row = 0;
                $customer_account_status = "inactive";
            }
            else{
                $customer_account_status = "";
            }
        }
        else{
            $customer_account_status = "";
        }

        if($check_email_row > 0 || $check_email_row_1 > 0 || $check_email_row_2 > 0){
            echo "yes";
        }
        else{
            if($customer_account_status == "inactive"){
                echo "inactive";
            }
            else{
                echo "no";
            }
        }
    }

    if($operation == "send_reset_email"){
        $email = mysqli_real_escape_string($connect, $_POST['email']);

        $check_email = mysqli_query($connect, "SELECT * FROM customer WHERE email='$email'");
        $check_email_row = mysqli_num_rows($check_email);

        $check_email_1 = mysqli_query($connect, "SELECT * FROM superadmin WHERE email='$email'");
        $check_email_row_1 = mysqli_num_rows($check_email_1);

        $check_email_2 = mysqli_query($connect, "SELECT * FROM admin WHERE email='$email'");
        $check_email_row_2 = mysqli_num_rows($check_email_2);

        if($check_email_row > 0){
            $row = mysqli_fetch_assoc($check_email);

            if($row['reset_token'] == "inactive"){
                $check_email_row = 0;
            }
        }

        if($check_email_row > 0 || $check_email_row_1 > 0 || $check_email_row_2 > 0){
            echo "yes";

            $token = bin2hex(random_bytes(12));

            if($check_email_row > 0){
                mysqli_query($connect, "UPDATE customer SET reset_token='$token' WHERE email='$email'");
            }
            else if($check_email_row_2 > 0){
                mysqli_query($connect, "UPDATE admin SET reset_token='$token' WHERE email='$email'");
            }
            else{
                mysqli_query($connect, "UPDATE superadmin SET reset_token='$token' WHERE email='$email'");
            }
            

            require '../phpmailer/PHPMailerAutoload.php';

            $mail = new PHPMailer;
                            // Enable verbose debug output

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = "smtp.gmail.com";  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'easygiftshop.malaysia@gmail.com';                 // SMTP username
            $mail->Password = 'easygiftfypproject';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;
            $mail->SMTPOptions = array(
                'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
                )
                );                                    // TCP port to connect to
            $mail->setFrom('easygiftshop.malaysia@gmail.com', 'Easy Gift');
            $mail->addAddress($email);     // Add a recipient

            $mail->addReplyTo('easygiftshop.malaysia@gmail.com', 'Easy Gift Admin');


            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Your Password Reset Link';
            $mail->Body    = "  <h1>
                                    <a href='http://localhost/fyp/index.php' style='color: black;'>
                                        <u>Easy Gift Store</u>
                                    </a>
                                </h1>
                                <div style='font-size: 20px; color:black;'>
                                    Reset your password
                                </div>
                                <div style='font-size: 15px; color:grey;'>
                                    Follow this link to reset your account password at <a href='http://localhost/fyp/index.php'>Easy Gift Store</a>. If you didn't request a new password, you can safely delete this email.
                                </div>
                                <div style='margin-top: 50px;'>
                                    <a href='".$_SERVER['SERVER_NAME']."/fyp/forgot_password.php?token=".$token."' style='color: white; font-size: 18px'>
                                        <span style='background: #39ac71;'>Reset your password</span>
                                    </a>
                                </div>
                                <div style='margin-top: 20px; margin-bottom: 30px;'>
                                    <span style='color: black;'>or</span> <a href='".$_SERVER['SERVER_NAME']."/fyp/index.php'>Visit our store</a>
                                </div>";

            $result=$mail->send();
        }
        else{
            echo "no";
        }
    }


    if($operation == "reset_password"){
        $reset_token = mysqli_real_escape_string($connect, $_POST['reset_token']);
        $password = mysqli_real_escape_string($connect, $_POST['password']);

        mysqli_query($connect, "UPDATE customer SET password='$password', reset_token='' WHERE reset_token='$reset_token'");
        mysqli_query($connect, "UPDATE superadmin SET password='$password', reset_token='' WHERE reset_token='$reset_token'");
        mysqli_query($connect, "UPDATE admin SET password='$password', reset_token='' WHERE reset_token='$reset_token'");
    }

?>