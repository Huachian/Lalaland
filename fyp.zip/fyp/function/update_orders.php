<?php
	session_start();
	include("../dataconnection.php");
	ini_set('date.timezone','Asia/Kuala_Lumpur'); 

	$customer_id = $_SESSION["id"];
	$operation = $_POST['operation'];

	if($operation == "order_success"){
		$address_id = mysqli_real_escape_string($connect, $_POST['address_id']);
		$buyer_message = mysqli_real_escape_string($connect, $_POST['buyer_message']);
		$total_amount = mysqli_real_escape_string($connect, $_POST['total_payment']);
		$voucher_id = mysqli_real_escape_string($connect, $_POST['voucher_id']);
		$voucher_code = mysqli_real_escape_string($connect, $_POST['voucher_code']);
		$order_date = date('Y-m-d H:i:s');
		$product_subtotal = 0;

		/* checking stock & voucher qty */	
		$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='in process'");
		
		$custom_card_stock_valid = "true";
		while($row = mysqli_fetch_assoc($result)){
			$card_type = $row['card_type'];

			if($card_type = "horizontal"){
				$card_type = "Flat horizontal";
			}
			else{
				$card_type = "Flat vertical";
			}

			$result_1 = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='$card_type'");
			$row_1 = mysqli_fetch_assoc($result_1);

			if($row_1['card_stock'] != "In Stock"){
				$custom_card_stock_valid = "false";
			}
		}


		$cart_products = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND status='in process'");

		$product_stock_valid = "true";
		while($cart_products_row = mysqli_fetch_assoc($cart_products)){
			$product_id = $cart_products_row['product_id'];

			$result_1 = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id' AND product_stock='In Stock' AND product_status='On Display'");
			$count = mysqli_num_rows($result_1);

			if($count == 0){
				$product_stock_valid = "false";
			}
		}


		$voucher_qty_valid = "true";
		if(!empty($voucher_id)){
			$result = mysqli_query($connect, "SELECT * FROM voucher WHERE voucher_id='$voucher_id'");
			$result_count = mysqli_num_rows($result);

			if($result_count > 0){
				$row = mysqli_fetch_assoc($result);

				date_default_timezone_set("Asia/Kuala_Lumpur");
				$today_date = date("Y-m-d");
				$today_date = date_parse($today_date);

				$voucher_end_date = date_parse($row['end_date']);

				if($row['quantity'] > 0 && $row['status']=="Enable" && $voucher_end_date >= $today_date){
					$voucher_qty_valid = "true";
				}
				else{
					$voucher_qty_valid = "false";
				}
			}
			else{
				$voucher_qty_valid = "false";
			}
		}


		if($custom_card_stock_valid == "true" && $product_stock_valid == "true" && $voucher_qty_valid == "true"){
			echo "yes";
			$cart_products = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='in process'");
		
			while($cart_products_row = mysqli_fetch_assoc($cart_products)){
				$card_type = $cart_products_row['card_type'];

				if($card_type == "vertical"){
					$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat vertical'");
					$get_price_row = mysqli_fetch_assoc($get_price);

					$quantity = 1;
					$price = $get_price_row['card_price'];
					$product_subtotal += $quantity * $price;
				}
				else if($card_type == "horizontal"){
					$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat horizontal'");
					$get_price_row = mysqli_fetch_assoc($get_price);

					$quantity = 1;
					$price = $get_price_row['card_price'];
					$product_subtotal += $quantity * $price;
				}
			}


			$cart_products = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND status='in process'");

			while($cart_products_row = mysqli_fetch_assoc($cart_products)){
				$product_id = $cart_products_row['product_id'];
				$quantity = $cart_products_row['quantity'];

				$product_details = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
				$product_details_row = mysqli_fetch_assoc($product_details);

				$product_price = $product_details_row['product_price'];


				date_default_timezone_set("Asia/Kuala_Lumpur");
				$today_date = date("Y-m-d");
				$today_date = date_parse($today_date);

				$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

				$product_promotion_price = $product_price;
				$found_promotion = "false";

				if(mysqli_num_rows($check_promotion) != 0){
					while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
						$promotion_id = $check_promotion_row['promotion_id'];

						$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
						$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

						if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
							$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

							$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

							if(mysqli_num_rows($check_promotion_product) != 0){
								if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
									$product_promotion_price = $check_promotion_product_result['promotion_price'];
								}
							}

							if(mysqli_num_rows($check_promotion_product) != 0){
								$found_promotion = "true";
							}
						}
					}
				}
				else{
					$product_promotion_price = 0;
					$found_promotion = "false";
				}


				if($found_promotion == "true"){
					$product_subtotal += $quantity * $product_promotion_price;
				}
				else{
					$product_subtotal += $quantity * $product_price;
				}
			}


			$voucher_details = mysqli_query($connect, "SELECT * FROM voucher WHERE voucher_id='$voucher_id'");
			$discount_amount = 0;
			$voucher_type = "";

			while($voucher_details_row = mysqli_fetch_assoc($voucher_details)){
				$voucher_type = $voucher_details_row['voucher_type'];
				$discount_amount = $voucher_details_row['discount_amount'];

				if($voucher_type == "Product Discount"){
					if($discount_amount > $product_subtotal){
						$discount_amount = $product_subtotal;
					}
				}

				$voucher_qty = $voucher_details_row['quantity'];
				$voucher_qty -= 1;
				
				mysqli_query($connect, "UPDATE voucher SET quantity='$voucher_qty' WHERE voucher_id='$voucher_id'");
			}

			$shipping_fee = 10;

			$get_address = mysqli_query($connect, "SELECT * FROM customer_address WHERE address_id='$address_id'");
			$address = mysqli_fetch_assoc($get_address);

			$delivery_name = $address['name'];
			$delivery_contact = $address['contact'];
			$delivery_address = $address['address'];
			$delivery_postcode = $address['postcode'];
			$delivery_state = $address['state'];
			$delivery_area = $address['area'];

			$select_last_order_id = mysqli_query($connect, "SELECT * FROM orders ORDER BY order_id desc");
			$last_order_id_row = mysqli_fetch_assoc($select_last_order_id);
			$last_order_id = $last_order_id_row['order_id'];

			if(empty($last_order_id)){
				$order_id = "#0001";
			}
			else{
				$idd = str_replace("#0", "", $last_order_id);
				$id = str_pad($idd + 1, 3, 0, STR_PAD_LEFT);
				$order_id = '#0'.$id;
			}

			mysqli_query($connect, "INSERT INTO orders (order_id, order_date, customer_id, product_subtotal, shipping_fee, voucher_id, voucher_code, voucher_type, discount_amount, total_amount, customer_remark, status, delivery_name, delivery_contact, delivery_address, delivery_postcode, delivery_state, delivery_area) VALUES ('$order_id', '$order_date', '$customer_id','$product_subtotal', '$shipping_fee', '$voucher_id', '$voucher_code', '$voucher_type', '$discount_amount', '$total_amount', '$buyer_message', 'Waiting for Shipment', '$delivery_name', '$delivery_contact', '$delivery_address', '$delivery_postcode', '$delivery_state', '$delivery_area')");

			$select_order_id = mysqli_query($connect, "SELECT order_id FROM orders WHERE customer_id='$customer_id' ORDER BY order_id DESC LIMIT 1");
			$order_id_row = mysqli_fetch_assoc($select_order_id);
			$order_id = $order_id_row['order_id'];

			$select_cart_products = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='in process'");
			while($cart_products_result = mysqli_fetch_assoc($select_cart_products)){
				$cart_product_id = $cart_products_result['card_id'];
				$cart_quantity = 1;
				$product_image = $cart_products_result['card_image'];
				$product_name = $cart_products_result['card_name'];
				$card_type = $cart_products_result['card_type'];

				if($card_type == "vertical"){
					$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat vertical'");
					$get_price_row = mysqli_fetch_assoc($get_price);

					$price = $get_price_row['card_price'];
				}
				else if($card_type == "horizontal"){
					$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat horizontal'");
					$get_price_row = mysqli_fetch_assoc($get_price);

					$price = $get_price_row['card_price'];
				}

				mysqli_query($connect, "INSERT INTO order_products (order_id, product_id, product_type, product_image, product_name, quantity, product_price, promotion_amount) VALUES ('$order_id', '$cart_product_id', 'custom product', '$product_image', '$product_name', '$cart_quantity', '$price', '0')");
			}


			$select_cart_products = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND status='in process'");
			while($cart_products_result = mysqli_fetch_assoc($select_cart_products)){
				$cart_product_id = $cart_products_result['product_id'];
				$cart_quantity = $cart_products_result['quantity'];

				$get_product_details = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$cart_product_id'");
				$product_details_result = mysqli_fetch_assoc($get_product_details);

				$product_image = $product_details_result['product_image'];
				$product_name = $product_details_result['product_name'];
				$price = $product_details_result['product_price'];


				date_default_timezone_set("Asia/Kuala_Lumpur");
				$today_date = date("Y-m-d");
				$today_date = date_parse($today_date);

				$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

				$product_promotion_price = $price;
				$promotion_amount = 0;

				if(mysqli_num_rows($check_promotion) != 0){
					while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
						$promotion_id = $check_promotion_row['promotion_id'];

						$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
						$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

						if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
							$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

							$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

							if(mysqli_num_rows($check_promotion_product) != 0){
								if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
									$product_promotion_price = $check_promotion_product_result['promotion_price'];

									$promotion_amount = $price - $product_promotion_price;
								}
							}

						}
					}
				}
				else{
					$product_promotion_price = 0;
				}


				mysqli_query($connect, "INSERT INTO order_products (order_id, product_id, product_type, product_image, product_name, quantity, product_price, promotion_amount) VALUES ('$order_id', '$cart_product_id', 'normal product', '$product_image', '$product_name', '$cart_quantity', '$price', '$promotion_amount')");
			}

			mysqli_query($connect, "UPDATE customization_card SET status='paid' WHERE customer_id='$customer_id' AND status='in process'");
			mysqli_query($connect, "DELETE FROM shopping_cart WHERE customer_id='$customer_id' AND status='in process'");
		}
		else{
			echo "no";
		}
	}

	if($operation == "check_voucher"){
		$selected_voucher_id = $_POST['selected_voucher_id'];

		$result = mysqli_query($connect, "SELECT * FROM voucher WHERE voucher_id='$selected_voucher_id'");
		$result_count = mysqli_num_rows($result);

		if($result_count > 0){
			$row = mysqli_fetch_assoc($result);

			date_default_timezone_set("Asia/Kuala_Lumpur");
			$today_date = date("Y-m-d");
			$today_date = date_parse($today_date);

			$voucher_end_date = date_parse($row['end_date']);

			if($row['quantity'] > 0 && $row['status']=="Enable" && $voucher_end_date >= $today_date){
				echo "yes";
			}
			else{
				echo "no";
			}
		}
		else{
			echo "no";
		}
	}
?>