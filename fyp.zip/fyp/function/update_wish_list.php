<?php
session_start();
include("../dataconnection.php");

	if(isset($_SESSION["id"])){
		$customer_id = $_SESSION["id"];
	}
	$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);
	$operation = $_POST['operation'];

	if ($operation == "add_to_wishlist"){
		if(isset($_SESSION["id"])){
			$check_existing = mysqli_query($connect, "SELECT * FROM wish_list WHERE customer_id='$customer_id' AND product_id='$product_id'");
			$existing_row = mysqli_fetch_assoc($check_existing);

			mysqli_query($connect, "INSERT INTO wish_list (customer_id, product_id) VALUES ('$customer_id', '$product_id')");
		}
		else{
			echo "login_false";
		}
	}

	if($operation == "add_cart"){
		if(isset($_SESSION["id"])){
			$record_checking = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' AND product_id='$product_id'");
			$record_checking_row = mysqli_fetch_assoc($record_checking);
			
			if(isset($record_checking_row)){
				$record_quantity = $record_checking_row['quantity'];
				mysqli_query($connect, "UPDATE shopping_cart SET quantity='$record_quantity'+1 WHERE customer_id='$customer_id' AND product_id='$product_id'");
			}
			else if(empty($record_checking_row)){
				mysqli_query($connect, "INSERT INTO shopping_cart (customer_id, product_id, quantity, status) VALUES ('$customer_id', '$product_id', 1, 'waiting checkout')");
			}

			echo "login_true";
		}
		else{
			echo "login_false";
		}
	}

	
	if($operation == "delete_wish_list"){
		$product_id = mysqli_real_escape_string($connect, $_POST['product_id']);

		mysqli_query($connect, "DELETE FROM wish_list WHERE product_id='$product_id'");
	}


?>
