<?php
	include("../dataconnection.php");

	$operation = $_POST["operation"];

    if($operation == "login_validation"){
    	$login_email = mysqli_real_escape_string($connect, $_POST['login_email']);
    	$login_password = mysqli_real_escape_string($connect, $_POST['login_password']);


    	$select_customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE email='$login_email' AND password='$login_password'");
    	$count_customer_details = mysqli_num_rows($select_customer_details);
    	$customer_row = mysqli_fetch_assoc($select_customer_details);


        $select_admin_details = mysqli_query($connect, "SELECT * FROM admin WHERE email='$login_email' AND password='$login_password'");
        $count_admin_details = mysqli_num_rows($select_admin_details);
        $admin_row = mysqli_fetch_assoc($select_admin_details);

        $select_superadmin_details = mysqli_query($connect, "SELECT * FROM superadmin WHERE email='$login_email' AND password='$login_password'");
        $count_superadmin_details = mysqli_num_rows($select_superadmin_details);
        $superadmin_row = mysqli_fetch_assoc($select_superadmin_details);

    	if($count_customer_details == 1){
    		if($customer_row['password'] == $login_password){
                if($customer_row['reset_token'] != "inactive"){
                    echo "customer";
                    session_start();
                    $_SESSION["id"] = $customer_row["customer_id"];
                }
                else{
                    echo "no";
                }
            }
            else{
                echo "no";
            }
    	}
        else if($count_admin_details == 1){
            if($admin_row['password'] == $login_password){
                echo "admin";
                session_start();
                $_SESSION["id"] = $admin_row["admin_id"];
                $_SESSION["admin_position"] = "Admin";
            }
            else{
                echo "no";
            }
        }
        else if($count_superadmin_details == 1){
            if($superadmin_row['password'] == $login_password){
                echo "admin";
                session_start();
                $_SESSION["id"] = $superadmin_row["superadmin_id"];
                $_SESSION["admin_position"] = "Superadmin";
            }
            else{
                echo "no";
            }
        }
    	else{
    		echo "no";
    	}
    }


    if($operation == "check_register_email"){
    	$register_email = mysqli_real_escape_string($connect, $_POST['email']);

    	$check_email = mysqli_query($connect, "SELECT * FROM customer WHERE email='$register_email'");
    	$check_email_row = mysqli_num_rows($check_email);

        $check_email_1 = mysqli_query($connect, "SELECT * FROM admin WHERE email='$register_email'");
        $check_email_row_1 = mysqli_num_rows($check_email_1);

        $check_email_2 = mysqli_query($connect, "SELECT * FROM superadmin WHERE email='$register_email'");
        $check_email_row_2 = mysqli_num_rows($check_email_2);

    	if($check_email_row > 0 || $check_email_row_1 > 0 ||  $check_email_row_2 > 0){
    		echo "no";
    	}
    	else{
    		echo "yes";
    	}
    }


    if($operation == "register"){
		$first_name = mysqli_real_escape_string($connect, $_POST['fname']);
		$last_name = mysqli_real_escape_string($connect, $_POST['lname']);
		$email = mysqli_real_escape_string($connect, $_POST['email']);
		$password = mysqli_real_escape_string($connect, $_POST['password']);
		$gender = mysqli_real_escape_string($connect, $_POST['gender']);
		$phone = mysqli_real_escape_string($connect, $_POST['phoneNo']);
		$address = mysqli_real_escape_string($connect, $_POST['address']);
		$postcode = mysqli_real_escape_string($connect, $_POST['postcode']);
		$state = mysqli_real_escape_string($connect, $_POST['state']);
		$area = mysqli_real_escape_string($connect, $_POST['area']);

        $select_last_customer_id = mysqli_query($connect, "SELECT * FROM customer ORDER BY customer_id desc");
        $last_customer_id_row = mysqli_fetch_assoc($select_last_customer_id);
        $last_customer_id = $last_customer_id_row['customer_id'];

        if(empty($last_customer_id)){
            $customer_id = "CUS_0001";
        }
        else{
            $idd = str_replace("CUS_0", "", $last_customer_id);
            $id = str_pad($idd + 1, 3, 0, STR_PAD_LEFT);
            $customer_id = "CUS_0".$id;
        }

		mysqli_query($connect, "INSERT INTO customer (customer_id, first_name, last_name, email, password, gender, phone) values ('$customer_id', '$first_name', '$last_name', '$email', '$password', '$gender', '$phone')");

		$get_customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE email='$email'");
		$customer_details = mysqli_fetch_assoc($get_customer_details);

		$customer_id = $customer_details['customer_id'];
		$customer_full_name = $first_name." ".$last_name;

		mysqli_query($connect, "INSERT INTO customer_address (customer_id, name, contact, address, postcode, state, area, address_default) VALUES ('$customer_id', '$customer_full_name', '$phone', '$address', '$postcode', '$state', '$area', 'Default')");
    }
?>