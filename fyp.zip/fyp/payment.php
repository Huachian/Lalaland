<?php
	session_start();
	include "dataconnection.php";

	if(isset($_SESSION["admin_position"])){
		header("Location: index.php");
	}
	
	$customer_id = $_SESSION['id'];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Payment - Secure Site | Easy Gift</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/payment.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/payment.js"></script>
</head>
<body>
	<script type="text/javascript">
		let payment_page_valid = sessionStorage.getItem('payment_page_valid');

		if(payment_page_valid != "yes"){
			window.location = "shopping_cart.php";
		}

		var payment_status = sessionStorage.getItem('payment_status');

		if(payment_status == "done"){
			window.location = "view_purchase.php";
		}
		else{
			sessionStorage.setItem('payment_status', "havent_done");
		}
	</script>
	
	<nav>
		<div class="backward">
			<button onclick="goBack()"><img src="image/payment/backward_icon.jpg"></button>
		</div>
		<div class="easy_gift_logo">
			<img src="image/navigation_top_bar/easy_gift_big_logo.PNG">
		</div>
	</nav>

	<div class="loader">
        <div id="circle_loader"></div>
        <div id="loader_title">Redirect you to secure page...</div>
    </div>
    
	<div class="main_wrap">
		<div class="top_title">
			<img src="image/payment/card_payment_icon.png">
			<span>Payment Details</span>
		</div>

		<div class="card_details">
			<div class="card_details_row1">
				<span>NAME ON CARD</span>
				<br>
				<input type="text" name="cardholder_name" id="cardholder_name" placeholder="Name on Card" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || (event.charCode == 32)" >
				<div class="icon"><img src="image/payment/cardholder_name_icon.png"></div>
				<span id="card_name_error"></span>
			</div>
			<div class="card_details_row2">
				<span>CARD NUMBER</span>
				<br>
				<input type="text" name="card_number" id="card_number" placeholder="xxxx xxxx xxxx xxxx" min="0" data-mask="0000 0000 0000 0000">
				<div class="icon"><img src="image/payment/card_number_icon.png"></div>
				<br>
				<span id="card_number_error"></span>
				<div class="card_type_wrap">
					<img src="image/payment/visa_card_icon.png">
					<img src="image/payment/master_card_icon.png">
				</div>
			</div>
			<div class="card_details_row3">
				<div>
					<span>EXPIRES ON</span>
					<br>
					<input type="text" name="expiry_date" id="expiry_date" placeholder="MM / YY" data-mask="00 / 00">
					<br>
					<span id="card_expiry_error"></span>
				</div>
				<div class="cvv_wrap">
					<span>CVV</span>
					<br>
					<input type="password" name="cvv" id="cvv" data-mask="000" placeholder="000" data-mask="000" onkeyup="click_payment()">
					<div class="icon"><img src="image/payment/cvv_icon.png"></div>
					<br>
					<span id="card_cvv_error"></span>
				</div>
			</div>
		</div>


		<div class="pay_btn_wrap">
			<button id="pay_btn" onclick="payment_validation()">Pay RM<span id="total_payment"></span></button>
		</div>
	</div>

	<div id="payment_process_wrap">
		<div id="payment_process_box">
			<div class="payment_process_contain">
				<div id="payment_process_title1">Do not refresh or close your browser</div>
		        <div id="circle_loader"></div>
		        <div id="payment_process_title2">Payment in processing...</div>
			</div>
		</div>
	</div>


	<div id="order_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/payment/tick_icon.png">
				<div>
					Order successfully updated
				</div>
			</div>
		</div>
	</div>

	<div id="checking_available_popup" class="empty_alert_wrap">
		<div id="empty_alert_box">
			<div id="empty_alert_contain">
				<img src="image/checkout/eror_icon.png">
				<div>
					Oops! Something went wrong...
				</div>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
	<script type="text/javascript">
		//page loader
		$(window).on('load',function(){
		    setTimeout(function(){
				$('.loader').fadeOut(1000);
			}, 1500); 

		    let total_payment = sessionStorage.getItem('total_payment');
		    total_payment = parseFloat(total_payment);
		    document.getElementById("total_payment").innerHTML = total_payment.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
		});

		function goBack(){
		  window.history.back();
		}

	</script>
</body>
</html>