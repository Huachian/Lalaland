-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table fyp.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.admin: ~2 rows (approximately)
INSERT IGNORE INTO `admin` (`admin_id`, `profile_picture`, `first_name`, `last_name`, `gender`, `email`, `phone`, `password`, `position`, `reset_token`) VALUES
	('ADMIN_0001', NULL, 'Tan', 'Wei Hong', 'Male', 'wei@gmail.com', '016-59530244', 'FYPtestingpass123!', 'Admin', NULL),
	('ADMIN_0002', NULL, 'Priscilla', 'Wong Hong Hui', 'Female', '1191200517@student.mmu.edu.my', '011-10704899', 'FYPpriscilla123!', 'Admin', NULL);

-- Dumping structure for table fyp.banner
CREATE TABLE IF NOT EXISTS `banner` (
  `banner_id` int NOT NULL AUTO_INCREMENT,
  `banner_name` varchar(255) NOT NULL,
  `banner_status` varchar(255) NOT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.banner: ~2 rows (approximately)
INSERT IGNORE INTO `banner` (`banner_id`, `banner_name`, `banner_status`) VALUES
	(34, 'giftshop.png', 'Display'),
	(35, '20233_mesa_de_trabajo_1.jpg', 'Display');

-- Dumping structure for table fyp.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.customer: ~2 rows (approximately)
INSERT IGNORE INTO `customer` (`customer_id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `reset_token`) VALUES
	('CUS_0001', 'Bryan', 'Kun', 'bryan@gmail.com', 'FYPtestingpass123!', 'Male', '011-23560021', NULL),
	('CUS_0002', 'Woon', 'Li Qi', 'li_qi@live.com', 'FYPtestingpass562@!', 'Male', '011-11421029', NULL);

-- Dumping structure for table fyp.customer_address
CREATE TABLE IF NOT EXISTS `customer_address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `address_default` varchar(255) NOT NULL DEFAULT 'NotDefault',
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.customer_address: ~3 rows (approximately)
INSERT IGNORE INTO `customer_address` (`address_id`, `customer_id`, `name`, `contact`, `address`, `postcode`, `state`, `area`, `address_default`) VALUES
	(1, 'CUS_0001', 'Bryan Tan', '011-23560021', 'No 20, Jalan Nakhoda, Taman Daya', '81000', 'Johor', 'Johor Bahru', 'Default'),
	(2, 'CUS_0002', 'Woon Li Qi', '011-11421029', 'No 43, Jalan Njm 3/4, Taman Nusa Jaya Mas', '81300', 'Johor', 'Johor Bahru', 'NotDefault'),
	(4, 'CUS_0002', 'Priscilla Wong', '011-10704899', 'No 136, Jalan Melaka Baru 3/2, Taman Melaka Baru', '75350', 'Melaka', 'Batu Berendam', 'Default');

-- Dumping structure for table fyp.customization_card
CREATE TABLE IF NOT EXISTS `customization_card` (
  `card_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(255) NOT NULL,
  `card_name` varchar(255) NOT NULL,
  `card_type` varchar(255) NOT NULL,
  `card_image` varchar(255) NOT NULL,
  `card_message` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `product_customization_id` int NOT NULL,
  PRIMARY KEY (`card_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.customization_card: ~2 rows (approximately)
INSERT IGNORE INTO `customization_card` (`card_id`, `customer_id`, `card_name`, `card_type`, `card_image`, `card_message`, `status`, `product_customization_id`) VALUES
	(1, 'CUS_0001', 'My Friend birthday card', 'horizontal', '6047a691eae5e.jpg', '\nHappy Birthday My Friend!\n-by Bryan', 'paid', 1),
	(2, 'CUS_0002', 'My Teacher Birthday Card', 'horizontal', '6048237931f74.jpg', 'Happy Birthday Ms Ainee and Ms Julie\n\n-by LI Ki', 'paid', 1);

-- Dumping structure for table fyp.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` varchar(255) NOT NULL,
  `order_date` datetime NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `product_subtotal` decimal(7,2) NOT NULL,
  `shipping_fee` decimal(7,2) NOT NULL,
  `voucher_id` int DEFAULT NULL,
  `voucher_code` varchar(255) DEFAULT NULL,
  `voucher_type` varchar(255) DEFAULT NULL,
  `discount_amount` decimal(7,2) NOT NULL,
  `total_amount` decimal(7,2) NOT NULL,
  `customer_remark` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `delivery_date` date NOT NULL,
  `delivery_name` varchar(255) NOT NULL,
  `delivery_contact` varchar(255) NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `delivery_postcode` varchar(255) NOT NULL,
  `delivery_state` varchar(255) NOT NULL,
  `delivery_area` varchar(255) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.orders: ~7 rows (approximately)
INSERT IGNORE INTO `orders` (`order_id`, `order_date`, `customer_id`, `product_subtotal`, `shipping_fee`, `voucher_id`, `voucher_code`, `voucher_type`, `discount_amount`, `total_amount`, `customer_remark`, `status`, `delivery_date`, `delivery_name`, `delivery_contact`, `delivery_address`, `delivery_postcode`, `delivery_state`, `delivery_area`) VALUES
	('#0001', '2021-01-19 08:43:19', 'CUS_0001', 308.00, 10.00, 0, '', '', 0.00, 318.00, '', 'Shipped Out', '2021-01-21', 'Bryan Tan', '011-23560021', 'No 20, Jalan Nakhoda, Taman Daya', '81000', 'Johor', 'Johor Bahru'),
	('#0002', '2021-02-10 14:23:45', 'CUS_0001', 147.00, 10.00, 0, '', '', 0.00, 157.00, '', 'Shipped Out', '2021-02-11', 'Bryan Tan', '011-23560021', 'No 20, Jalan Nakhoda, Taman Daya', '81000', 'Johor', 'Johor Bahru'),
	('#0003', '2021-03-02 00:45:36', 'CUS_0001', 299.00, 10.00, 1, 'MARCH2021', 'Free Shipping', 10.00, 299.00, '', 'Shipped Out', '2021-03-04', 'Bryan Tan', '011-23560021', 'No 20, Jalan Nakhoda, Taman Daya', '81000', 'Johor', 'Johor Bahru'),
	('#0004', '2021-03-03 00:46:36', 'CUS_0001', 668.00, 10.00, 1, 'MARCH2021', 'Free Shipping', 10.00, 668.00, '', 'Pending', '0000-00-00', 'Bryan Tan', '011-23560021', 'No 20, Jalan Nakhoda, Taman Daya', '81000', 'Johor', 'Johor Bahru'),
	('#0005', '2021-03-09 09:50:45', 'CUS_0001', 20.00, 10.00, 0, '', '', 0.00, 30.00, '', 'Shipped Out', '2021-03-09', 'Bryan Tan', '011-23560021', 'No 20, Jalan Nakhoda, Taman Daya', '81000', 'Johor', 'Johor Bahru'),
	('#0006', '2021-03-10 09:51:40', 'CUS_0002', 340.00, 10.00, 4, 'MARCH2021', 'Free Shipping', 10.00, 340.00, '', 'Waiting for Shipment', '0000-00-00', 'Priscilla Wong', '011-10704899', 'No 136, Jalan Melaka Baru 3/2, Taman Melaka Baru', '75350', 'Melaka', 'Batu Berendam'),
	('#0007', '2021-03-10 09:57:59', 'CUS_0002', 98.00, 10.00, 4, 'MARCH2021', 'Free Shipping', 10.00, 98.00, '', 'Shipped Out', '2021-03-10', 'Priscilla Wong', '011-10704899', 'No 136, Jalan Melaka Baru 3/2, Taman Melaka Baru', '75350', 'Melaka', 'Batu Berendam');

-- Dumping structure for table fyp.order_products
CREATE TABLE IF NOT EXISTS `order_products` (
  `order_item_id` int NOT NULL AUTO_INCREMENT,
  `order_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `product_type` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `product_price` decimal(7,2) NOT NULL,
  `promotion_amount` decimal(7,2) NOT NULL,
  PRIMARY KEY (`order_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.order_products: ~15 rows (approximately)
INSERT IGNORE INTO `order_products` (`order_item_id`, `order_id`, `product_id`, `product_type`, `product_image`, `product_name`, `quantity`, `product_price`, `promotion_amount`) VALUES
	(1, '#0001', 'C0003', 'normal product', '60326699e0070.jpg', 'Torino Leather Minimalist Wallet', 1, 129.00, 0.00),
	(2, '#0001', 'G0004', 'normal product', '60325f4d169fd.jpg', 'For Him Gift Set 4', 1, 179.00, 0.00),
	(3, '#0002', 'K0028', 'normal product', '60326f0393cb8.jpg', 'Key Loop Granite Felt', 1, 49.00, 0.00),
	(4, '#0002', 'K0027', 'normal product', '60326ecec7c2f.jpg', 'Key Loop Turmeric Felt', 1, 49.00, 0.00),
	(5, '#0002', 'K0026', 'normal product', '60326e864123d.jpg', 'Key Loop Marine Felt', 1, 49.00, 0.00),
	(6, '#0003', 'C0006', 'normal product', '60326b42922e4.jpg', 'Panama Leather Card Holder', 1, 299.00, 0.00),
	(7, '#0004', 'G0005', 'normal product', '60325f9a5a509.jpg', 'For Him Gift Set 5', 1, 269.00, 0.00),
	(8, '#0004', 'W0004', 'normal product', '6032747710b41.jpg', 'Chronograph White - Léon', 1, 399.00, 0.00),
	(9, '#0005', '1', 'custom product', '6047a691eae5e.jpg', 'My Friend birthday card', 1, 20.00, 0.00),
	(10, '#0006', '2', 'custom product', '6048237931f74.jpg', 'My Teacher Birthday Card', 1, 20.00, 0.00),
	(11, '#0006', 'F0021', 'normal product', '602e5907c0d3d.jpg', 'Bright Future', 1, 121.00, 0.00),
	(12, '#0006', 'F0020', 'normal product', '602e589327272.jpg', 'Pink x Pink', 1, 100.00, 0.00),
	(13, '#0006', 'F0024', 'normal product', '602e5adbb5c29.jpg', 'Colourful Baby Breath', 1, 120.00, 0.00),
	(14, '#0007', 'K0028', 'normal product', '60326f0393cb8.jpg', 'Key Loop Granite Felt', 1, 49.00, 0.00),
	(15, '#0007', 'K0027', 'normal product', '60326ecec7c2f.jpg', 'Key Loop Turmeric Felt', 1, 49.00, 0.00);

-- Dumping structure for table fyp.product
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` decimal(7,2) NOT NULL,
  `product_gender` varchar(255) NOT NULL,
  `product_type` varchar(255) NOT NULL,
  `product_otestccasions` varchar(255) NOT NULL,
  `product_description_1` varchar(255) NOT NULL,
  `product_description_2` varchar(255) DEFAULT NULL,
  `product_stock` varchar(255) NOT NULL,
  `product_status` varchar(255) NOT NULL,
  `occasions_id` int NOT NULL,
  `product_type_id` int NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.product: ~114 rows (approximately)
INSERT IGNORE INTO `product` (`product_id`, `product_image`, `product_name`, `product_price`, `product_gender`, `product_type`, `product_occasions`, `product_description_1`, `product_description_2`, `product_stock`, `product_status`, `occasions_id`, `product_type_id`) VALUES
	('B0001', '6032304bc3585.jpeg', 'Plush Princess Pink Box', 139.00, 'Newborn', 'Baby Box', 'Newborn', 'A gift box not just for the newborn child but also for the beloved mother - This gift box features the little necessities for your little pride &amp; joy but it also ensures that their loving mother is taken care of with a pack of chicken essence to help ', '', 'In Stock', 'On Display', 8, 8),
	('B0002', '603231da2d40f.png', 'Bashful Baby Blue Box', 139.00, 'Newborn', 'Baby Box', 'Newborn', 'A gift box not just for the newborn child but also for the beloved mother - This gift box features the little necessities for your little pride & joy but it also ensures that their loving mother is taken care of with a pack of chicken essence to help redu', '', 'In Stock', 'On Display', 8, 8),
	('B0003', '6032331fc98bb.jpeg', 'Prized Princess Treasure Trove', 199.00, 'Newborn', 'Baby Box', 'Newborn', 'Your prized princess deserves the best! Our Prized Princess Treasure Trove features an opulence of beautiful baby pink accessories - including a baby pink blanket, bottle, and plushie for your little princess to make her grand entry into the world.', '', 'In Stock', 'On Display', 8, 8),
	('B0004', '603233ace7da4.jpeg', 'New Born Baby Gift Box Medium 3', 150.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0005', '6032345c12f5d.jpeg', 'NEW BORN BABY GIFT BOX 03', 189.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0006', '603234b2ef957.jpeg', 'New Born Baby Gift Box Large 2', 229.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0007', '603234f41d29b.jpeg', 'Baby Blue Bundle Of Joy', 249.00, 'Newborn', 'Baby Box', 'Newborn', 'Our deluxe Baby Blue Bundle of Joy box is the most exclusive curation for your bundle of joy, painted in shades of brilliant blue - this bundle features all the best accessories for your little baby boy.', '', 'In Stock', 'On Display', 8, 8),
	('B0008', '603237ed8ad6c.jpeg', 'Pride & Joy Baby Box', 179.00, 'Newborn', 'Baby Box', 'Newborn', 'A box specially curated for your pride & joy, this beautiful baby box includes baby accessories in pink and blue, and a plush teddy for your little darling to be comfortably welcomed into the world.', '', 'In Stock', 'On Display', 8, 8),
	('B0009', '603238c041bbb.jpeg', 'New Born Baby Gift Box Large Extra Large', 319.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0010', '6032395f2d13c.jpeg', 'New Born Baby Gift Box Medium 2', 199.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0011', '603239b25e3c4.jpeg', 'NEW BORN BABY GIFT BOX 10', 219.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0012', '60323a11ce407.jpeg', 'New Born Baby Gift Box Extra Large 3', 319.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0013', '60323a8419ca2.jpeg', 'New Born Baby Gift Box Large', 229.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'Out of Stock', 'On Display', 8, 8),
	('B0014', '60323adad4870.jpeg', 'New Born Baby Gift Box Large 3', 229.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0015', '60323b27e7854.jpeg', 'New Born Baby Gift Box Extra Large 2', 319.00, 'Newborn', 'Baby Box', 'Newborn', 'Our cute little gift box is the perfect present for a family that just said welcome to a new baby!', '', 'In Stock', 'On Display', 8, 8),
	('B0016', '60323bb29c7cc.jpeg', 'Precious Prince Treasure Trove', 199.00, 'Newborn', 'Baby Box', 'Newborn', 'Nothing but the best for your precious prince. Our Precious Prince Treasure Trove features an abundance of beautiful baby blue accessories - including a baby blue blanket, bottle, and plushie for your little prince to make his grand entry into the world.', '', 'In Stock', 'On Display', 8, 8),
	('B0017', '60323c4e8cbe9.jpeg', 'Pretty In Pink Bundle Of Joy', 249.00, 'Newborn', 'Baby Box', 'Newborn', 'Our deluxe Pretty in Pink bundle of joy box is the most exclusive curation for your bundle of joy, painted in shades of peppy pink - this bundle features all the best accessories for your pretty little princess.', '', 'In Stock', 'On Display', 8, 8),
	('B0018', '60323c9793b55.jpeg', 'Apple Of My Eye Box', 159.00, 'Newborn', 'Baby Box', 'Newborn', 'A colour gift box filled with toiletries that will make a shower exciting and bubbly for your beloved bundle of joy! Every child enjoys their bath times when it is all about the fun!', '', 'In Stock', 'On Display', 8, 8),
	('C0001', '60326608bc0c7.jpg', 'Black Leather Minimalist Wallet', 100.00, 'For Him', 'Card Holder', 'Valentine', 'Fits up to five cards and folded cash.\nComes with a wallet box.', '', 'In Stock', 'On Display', 1, 3),
	('C0002', '6032664cb8066.jpg', 'Rum Leather Minimalist Wallet', 100.00, 'For Him', 'Card Holder', 'Valentine', 'Fits up to five cards and folded cash.\nComes with a wallet box.', '', 'In Stock', 'On Display', 1, 3),
	('C0003', '60326699e0070.jpg', 'Torino Leather Minimalist Wallet', 129.00, 'For Him', 'Card Holder', 'Valentine', 'Fits up to five cards and folded cash.\nComes with a wallet box.', '', 'In Stock', 'On Display', 1, 3),
	('C0004', '603266dbb4af0.jpg', 'Old School Leather Minimalist Wallet', 125.00, 'For Him', 'Card Holder', 'Valentine', 'Fits up to five cards and folded cash.\nComes with a wallet box.', '', 'In Stock', 'On Display', 1, 3),
	('C0005', '6032715dbb6cf.jpg', 'Panama Plus Leather Card Holder', 399.00, 'For Him', 'Card Holder', 'Valentine', 'The Panama Plus card holder has five pockets and four quick access card slots. It also offers a main pocket for folded cash and business cards.', '', 'In Stock', 'On Display', 1, 3),
	('C0006', '60326b42922e4.jpg', 'Panama Leather Card Holder', 299.00, 'For Him', 'Card Holder', 'Valentine', 'Panama card holder has two quick access card slots. It also offers a main pocket for folded cash and business cards. The card holder will age beautifully creating a unique patina because of the natural tannings.', '', 'In Stock', 'On Display', 1, 3),
	('F0001', '602d7b063e9fb.jpg', 'Smile Ping Pong ', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'The Chrysanthemum is the flower of the month for November. ', 'Wish you happy every day.', 'In Stock', 'On Display', 1, 1),
	('F0002', '602d7c0f374d3.jpg', 'Sunflower', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Sunflowers symbolize adoration, loyalty and longevity.', 'Sunflowers are known for being “happy” flowers, making them the perfect gift to bring joy to someone’s (or your) day.', 'In Stock', 'On Display', 1, 1),
	('F0003', '602d7cbeea4f9.jpg', 'Red Roses', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Red roses symbolize love and romance and are the perfect Valentine’s Day rose.', '', 'Out of Stock', 'On Display', 1, 1),
	('F0004', '602d7d41cf1a3.jpg', 'White Roses', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'White roses symbolize innocence and purity.', '', 'In Stock', 'On Display', 1, 1),
	('F0005', '602d7d6ce639b.jpg', 'Pink Roses', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Pink roses symbolize gratitude, grace, admiration, and joy.', '', 'In Stock', 'On Display', 1, 1),
	('F0006', '602d7dc1e8053.jpg', 'Blue Roses', 120.00, 'For Him', 'Flower Bouquet', 'Valentine', 'Blue roses symbolize mystery or attaining the impossible.', '', 'In Stock', 'On Display', 1, 1),
	('F0007', '602d7def0a4d9.jpg', 'Yellow Roses', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Yellow roses symbolize friendship.', '', 'In Stock', 'On Display', 1, 1),
	('F0008', '602d7e48a50ef.jpg', 'Purple Roses', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'The lavender(purple) rose is often a sign of enchantment and love at first sight. ', '', 'In Stock', 'On Display', 1, 1),
	('F0009', '602e57331d79c.jpg', 'Pink x White Classic Tulips', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Pink Tulips means caring &amp; good wishes.\nWhite Tulips means purity, innocence, forgiveness and respect.', '', 'In Stock', 'On Display', 1, 1),
	('F0010', '602e5765e4bc7.jpg', 'White Tulips ', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Red Tulips means love &amp; romance.\nWhite Tulips means purity, innocence, forgiveness and respect.', '', 'In Stock', 'On Display', 1, 1),
	('F0011', '602e54601aa5c.jpg', 'Yellow x White Tulips', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Yellow Tulips means brightness, sunshine and the start of spring.\nWhite Tulips means purity, innocence, forgiveness and respect.\n', '', 'In Stock', 'On Display', 1, 1),
	('F0012', '602d803d67c59.jpg', 'Blue Baby Breath', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Blue Baby Breath means honesty and respect.', '', 'In Stock', 'On Display', 1, 1),
	('F0013', '602d80cc00017.jpg', 'Purple Baby Breath', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Purple Baby Breath convey royalty and beauty.', '', 'In Stock', 'On Display', 1, 1),
	('F0014', '602e4da48e477.jpg', 'Rainbow Baby Breath', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Everything will be OK.', '', 'In Stock', 'On Display', 1, 1),
	('F0015', '602e4e0dbdb23.jpg', 'Sunflower with Baby Breath', 130.00, 'For Her', 'Flower Bouquet', 'Valentine', 'You are mine only one.', '', 'In Stock', 'On Display', 1, 1),
	('F0016', '602e4f1a04af6.jpg', 'Bunny Tails', 130.00, 'For Her', 'Flower Bouquet', 'Valentine', 'You are as cute as the bunny.', '', 'In Stock', 'On Display', 1, 1),
	('F0017', '602e4f89b9e37.jpg', 'Cotton Flower', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Cotton Flower means to cherish the people around you and as a promise of wealth and well-being, making it the perfect gift for birthdays, proposals or anniversaries.', '', 'Out of Stock', 'On Display', 1, 1),
	('F0018', '602e58070cb48.jpg', 'Purple x Pink', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Purple bunny tails x Purple baby breath with a special Pink Rose in the middle.', '', 'Out of Stock', 'On Display', 1, 1),
	('F0019', '602e58426a820.jpg', 'Blue x White', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Blue bunny tails x Blue baby breath with a special White Rose in the middle.', '', 'In Stock', 'On Display', 1, 1),
	('F0020', '602e589327272.jpg', 'Pink x Pink', 100.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Pink bunny tails x Pink baby breath with a special Pink Rose in the middle.', '', 'In Stock', 'On Display', 1, 1),
	('F0021', '602e5907c0d3d.jpg', 'Bright Future', 121.00, 'For Him', 'Flower Bouquet', 'Graduation', 'Happy Graduation ! With love and pride today and always.', '', 'In Stock', 'On Display', 7, 1),
	('F0022', '602e5a1935759.jpg', 'Cute Ducky', 120.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Two cute ping pong flower ducky surrounded by red roses.', '', 'Out of Stock', 'On Display', 1, 1),
	('F0023', '602e5a73085e3.jpg', 'Galaxy', 120.00, 'For Her', 'Flower Bouquet', 'Birthday', 'You are the galaxy for me.', '', 'Out of Stock', 'On Display', 6, 1),
	('F0024', '602e5adbb5c29.jpg', 'Colourful Baby Breath', 120.00, 'For Her', 'Flower Bouquet', 'Birthday', 'You made my life colourful.', '', 'In Stock', 'On Display', 6, 1),
	('F0025', '602e5c0027559.jpg', 'Heng Ong Huat', 120.00, 'For Her', 'Flower Bouquet', 'Birthday', 'Heng Kaw Kaw !\nHuat Kaw Kaw !\nOng Kaw Kaw !', '', 'Out of Stock', 'On Display', 6, 1),
	('F0026', '60482943a28e6.jpg', 'Pastel Rainbow Flower', 80.00, 'For Her', 'Flower Bouquet', 'Valentine', 'Pastel meets Rainbow.', '', 'In Stock', 'Hidden', 1, 1),
	('G0001', '60325de0a90ef.jpg', 'For Him Gift Set 1', 149.00, 'For Him', 'Gift Box', 'Birthday', '1 x pine wood box 25cmL x 20cmW x 14cmH\n1 x water bottle come with cover\n1 x ceramic cup with base and spoon\n1 x glass container with 6 Snickers', '', 'In Stock', 'On Display', 6, 10),
	('G0002', '60325e2ca8e30.jpg', 'For Him Gift Set 2', 179.00, 'For Him', 'Gift Box', 'Birthday', '1 x pine wood box 25cmL x 20cmW x 14cmH\n1 x water bottle come with cover\n1 x ceramic cup with base and spoon\n1 x glass container with 6 snackers\n1 x beverage filter', '', 'In Stock', 'On Display', 6, 10),
	('G0003', '60325e80830b3.jpg', 'For Him Gift Set 3', 199.00, 'For Him', 'Gift Box', 'Birthday', '1 x pine wood box 25cmL x 20cmW x 14cmH\n1 x "Him" ceramic cup with tray and spoon\n2 x towel\n2 x candle\n1 x glass water bottle with cover', '', 'In Stock', 'On Display', 6, 10),
	('G0004', '60325f4d169fd.jpg', 'For Him Gift Set 4', 179.00, 'For Him', 'Gift Box', 'Birthday', '1 x pine wood box 25cmL x 20cmW x 14cmH\n1 x "Him" ceramic cup with tray and spoon\n2 x candle\n2 x towel', '', 'In Stock', 'On Display', 6, 10),
	('G0005', '60325f9a5a509.jpg', 'For Him Gift Set 5', 269.00, 'For Him', 'Gift Box', 'Birthday', '1 x pine wood box 25cmL x 20cmW x 14cmH\n1 x "Him" ceramic cup with tray and spoon\n2 x towel\n2 x candle\n1 x name card tray\n1 x 32GB pendrive with box', '', 'In Stock', 'On Display', 6, 10),
	('G0006', '603260901234a.jpg', 'For Him Gift Set 6', 150.00, 'For Him', 'Gift Box', 'Birthday', '1 x pine wood box 25cmL x 20cmW x 14cmH\n1 x water bottle come with cover\n1 x ceramic cup with base and spoon\n1 x organizer tray', '', 'Out of Stock', 'On Display', 6, 10),
	('G0007', '603278911606c.jpg', 'Night Off', 188.00, 'For Her', 'Gift Box', 'Birthday', 'A little box of relaxation including bubble bath and candlelight, the highly coveted self-heating. Spacemask and a chocolate treat on the side!', '', 'In Stock', 'On Display', 6, 10),
	('G0008', '6032796bedf0c.jpg', 'Classic Gift Box // Blue', 233.00, 'For Her', 'Gift Box', 'Birthday', 'The perfect threesome: winter scarf, candle and a box of delicious truffles.  Perfect for birthdays, holidays and any-days!', '', 'In Stock', 'On Display', 6, 10),
	('G0009', '603279a9dc2be.jpg', 'Classic Gift Box // Pink', 233.00, 'For Her', 'Gift Box', 'Birthday', 'The perfect threesome: winter scarf, candle and a box of delicious truffles.  Perfect for birthdays, holidays and any-days!', '', 'In Stock', 'On Display', 6, 10),
	('G0010', '603279e6d417f.jpg', 'Happy Birthday Letterbox Gift', 133.00, 'For Her', 'Gift Box', 'Birthday', 'A bright blue mix for a very Happy Birthday.  This fab little letterbox gift includes a birthday chocolate bar and some great accessories.  Plus it fits straight through the letterbox so no need for waiting.', '', 'In Stock', 'On Display', 6, 10),
	('G0011', '60327a3e6266e.jpg', 'Happy Birthday Box', 155.00, 'For Her', 'Gift Box', 'Birthday', 'This gift is the perfect way to spread a little joy.', '', 'In Stock', 'On Display', 6, 10),
	('G0012', '60327a81debac.jpg', 'Luxury Gift Box for Her', 258.00, 'For Her', 'Gift Box', 'Birthday', 'All that glitters is here in the ultimate gift for the girl who has everything... packed with all our favourite luxury treats. ', '', 'Out of Stock', 'On Display', 6, 10),
	('G0013', '60327b3ea80e7.jpg', 'The Beauty Box', 388.00, 'For Her', 'Gift Box', 'Birthday', 'A fabulous box packed with all your favourite beauty treats, including organic body products from Nathalie Bond and our best-selling spacemask. ', '', 'In Stock', 'On Display', 6, 10),
	('G0014', '60327b8258e63.jpg', 'Little Restore', 322.00, 'For Her', 'Gift Box', 'Birthday', 'A gorgeous collection of scented botanicals that will create a wonderful bit of time off for someone special.', '', 'In Stock', 'On Display', 6, 10),
	('G0015', '60327be366700.jpg', 'Winter Luxe // Pink', 222.00, 'For Her', 'Gift Box', 'Birthday', 'For cosy nights in, this luxury gift is guaranteed to feel like a hug in a box, featuring our supersoft alpaca socks and best-selling chocolate from Love Cocoa.', '', 'In Stock', 'On Display', 6, 10),
	('G0016', '60327c3fc016e.jpg', 'The Kind Box', 236.00, 'For Her', 'Gift Box', 'Birthday', 'New for season, the gift box that features our favourite carry-on essentials, including organic mint tin, layflat notebook and a newly arrived KindBag made from plastic bottles!', '', 'In Stock', 'On Display', 6, 10),
	('G0017', '60327c7f11c6e.jpg', 'Thinking Of You', 153.00, 'For Her', 'Gift Box', 'Birthday', 'This little letterbox-sized gift is the perfect way to just let someone know they are in your thoughts, and it’s also a little bit of ‘time off’ in a box.  A cup of tea, a bar of chocolate and a self-heating eye mask.', '', 'In Stock', 'On Display', 6, 10),
	('K0001', '6032550ae7dd6.jpg', 'Flame Keychain', 10.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Fire keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0002', '60325537db32c.jpg', 'Le Chill Keychain', 10.00, 'For Kids', 'Keychain', 'Birthday', 'Chill', '', 'In Stock', 'On Display', 6, 2),
	('K0003', '603255789e627.jpg', 'Coffee Cat Keychain', 12.00, 'For Kids', 'Keychain', 'Birthday', 'Keychain for cat and coffee lovers!', '', 'In Stock', 'On Display', 6, 2),
	('K0004', '603255a1234e7.jpg', 'Peach Keychain', 13.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Peachy keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0005', '603255da6619c.jpg', 'Cactus Cat Keychain', 15.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Go Away keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0006', '6032561eada80.jpg', 'Toe Beans Keychain', 13.00, 'For Kids', 'Keychain', 'Birthday', 'Lovely toe', '', 'In Stock', 'On Display', 6, 2),
	('K0007', '6032564e2df61.jpg', 'Taro Leaf Keychain', 13.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Taro leaf keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0008', '6032567c1de0c.jpg', 'Monstera Leaf Keychain', 13.00, 'For Kids', 'Keychain', 'Birthday', 'Monstera Leaf', '', 'In Stock', 'On Display', 6, 2),
	('K0009', '603256a36486b.jpg', 'Cactus Keychain', 13.00, 'For Kids', 'Keychain', 'Birthday', 'Cactus', '', 'In Stock', 'On Display', 6, 2),
	('K0010', '603256cd02438.jpg', 'Strawberry Keychain', 13.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Strawberry keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0011', '603256f365891.jpg', 'Banana Leaf Keychain', 11.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Banana Leaf keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0012', '6032571945b73.jpg', 'Loaf Cat Keychain', 15.00, 'For Kids', 'Keychain', 'Birthday', 'Loaf Cat', '', 'In Stock', 'On Display', 6, 2),
	('K0013', '603258b467ce7.jpg', 'Rain Keychain', 29.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Rain keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0014', '60325a07a90a6.jpg', 'Moon Star Keychain', 30.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Moon Star keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0015', '60325af46383b.jpg', 'Ice Bear Keychain', 40.00, 'For Kids', 'Keychain', 'Birthday', 'A cute Ice Bear keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0016', '60325b13edb86.jpg', 'Bear Keychain', 40.00, 'For Kids', 'Keychain', 'Birthday', 'Bear', '', 'Out of Stock', 'On Display', 6, 2),
	('K0017', '60325bf31fc2e.jpg', 'Cute Cofee Keychain', 39.00, 'For Kids', 'Keychain', 'Birthday', 'A cute keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0018', '60325c17e97b5.jpg', 'Cute Pancake Keychain', 42.00, 'For Kids', 'Keychain', 'Birthday', 'Cute', '', 'In Stock', 'On Display', 6, 2),
	('K0019', '60325c449a6f2.jpg', 'Shrimpy Tempura Acrylic Keychain', 45.00, 'For Kids', 'Keychain', 'Birthday', 'A cute keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0020', '60325c6ae34f8.jpg', 'Salmon Nigiri Corgi and Bird Acrylic Keychain', 45.00, 'For Kids', 'Keychain', 'Birthday', 'A cute keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0021', '60325ca2d31c1.jpg', 'Kitty Sushi Roll Acrylic Keychain', 38.00, 'For Kids', 'Keychain', 'Birthday', 'A cute keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0022', '60325ce91d4c9.jpg', 'ATLA Appa Boba Acrylic Keychain', 38.00, 'For Kids', 'Keychain', 'Birthday', 'A cute keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0023', '60325d2e888c0.jpg', 'ATLA Jasmine Tea Acrylic Keychain', 45.00, 'For Kids', 'Keychain', 'Birthday', 'A cute keychain suitable for your kids!', '', 'In Stock', 'On Display', 6, 2),
	('K0024', '60326d5a9732c.jpg', 'Classic Leather Keyring', 50.00, 'For Him', 'Keychain', 'Birthday', 'This classic split-ring keyring will become one of your daily essentials.', '', 'In Stock', 'On Display', 6, 2),
	('K0025', '60326e478b3ac.jpg', 'Key Loop Charcoal Felt', 49.00, 'For Him', 'Keychain', 'Birthday', 'Losing your keys is still a drag but this Key Loop makes finding them pretty-easy. Premium felt + simple style', '', 'In Stock', 'On Display', 6, 2),
	('K0026', '60326e864123d.jpg', 'Key Loop Marine Felt', 49.00, 'For Him', 'Keychain', 'Birthday', 'Losing your keys is still a drag but this Key Loop makes finding them pretty-easy. Premium felt + simple style', '', 'In Stock', 'On Display', 6, 2),
	('K0027', '60326ecec7c2f.jpg', 'Key Loop Turmeric Felt', 49.00, 'For Him', 'Keychain', 'Birthday', 'Losing your keys is still a drag but this Key Loop makes finding them pretty-easy. Premium felt + simple style', '', 'In Stock', 'On Display', 6, 2),
	('K0028', '60326f0393cb8.jpg', 'Key Loop Granite Felt', 49.00, 'For Him', 'Keychain', 'Birthday', 'Losing your keys is still a drag but this Key Loop makes finding them pretty-easy. Premium felt + simple style', '', 'In Stock', 'On Display', 6, 2),
	('K0029', '60326f36c16c9.jpg', 'Key Loop Red Felt', 49.00, 'For Him', 'Keychain', 'Birthday', 'Losing your keys is still a drag but this Key Loop makes finding them pretty-easy. Premium felt + simple style', '', 'In Stock', 'On Display', 6, 2),
	('K0030', '60326f73af3d4.jpg', 'Key Loop Black Leather', 51.00, 'For Him', 'Keychain', 'Birthday', 'Premium leather + simple style', '', 'In Stock', 'On Display', 6, 2),
	('L0001', '60328249aa148.jpg', 'LEGO Classic Creative Green Bricks ', 25.00, 'For Kids', 'Lego', 'Birthday', 'This timeless building toy is bursting with ideas and inspiration in gorgeous green! As kids build, play and build again, it unlocks their imagination and encourages developmental skills that support future success.', '', 'In Stock', 'On Display', 6, 12),
	('L0002', '6032829d21312.jpg', 'LEGO Classic Bricks and Houses ', 100.00, 'For Kids', 'Lego', 'Birthday', 'Children understand the importance of ‘home’ very early in their lives – so this LEGO Classic Bricks and Houses set is an ideal way to introduce them to creative construction. As kids build, play and build again, they develop valuable skills that last a l', '', 'In Stock', 'On Display', 6, 12),
	('L0003', '6032834c7d193.jpg', 'LEGO City Police Patrol Car ', 50.00, 'For Kids', 'Lego', 'Birthday', 'Become an everyday hero with a Police Patrol Car play set!\nStart the powerful engine of the Police Patrol Car and protect the city! ', '', 'In Stock', 'On Display', 6, 12),
	('L0004', '6032846d6f083.jpg', 'LEGO Disney Princess Anna And Elsa', 80.00, 'For Kids', 'Lego', 'Birthday', 'Open the book and explore a whole micro-world in a castle! Cross the bridge into Arendelle Castle and check out all the cool things inside.', '', 'In Stock', 'On Display', 6, 12),
	('L0005', '603284c544e78.jpg', 'LEGO Marvel Spider-Man', 45.00, 'For Kids', 'Lego', 'Birthday', 'When super villain Sandman stirs up a sand tornado, it’s time to team up with Spider-Man and the young superhero in your life. ', '', 'In Stock', 'On Display', 6, 12),
	('M0001', '60482a59ee88e.jpg', 'Goofy Mug', 20.00, 'For Kids', 'Mug', 'Birthday', 'Goofy', '', 'In Stock', 'On Display', 6, 26),
	('T0001', '60328ab1b1dee.jpg', 'Dart game', 79.00, 'For Kids', 'Toy', 'Birthday', 'This dart game is perfect to play with younger children. The small figures have a touch-and-close fastening on top.', '', 'In Stock', 'On Display', 6, 13),
	('T0002', '60328bc972233.jpg', 'Garage with tow truck', 55.00, 'For Kids', 'Toy', 'Birthday', 'Your child can use their imagination as the garage has different levels, compartments, sliding doors, parking spaces and a detachable ramp.', '', 'Out of Stock', 'On Display', 6, 13),
	('T0003', '60328daeaf42c.jpg', 'Balancing and Nesting Game', 59.00, 'For Kids', 'Toy', 'Birthday', 'Balancing game. Includes nesting site, 70 wooden sticks, 20 cuckoo eggs, and one mama bird. Instructions included', '', 'In Stock', 'On Display', 6, 13),
	('T0004', '60328e3189db0.jpg', 'Space Lab Board Game', 69.00, 'For Kids', 'Toy', 'Birthday', 'Take a trip to outer space with our STEM Space Lab Board Game! A playful, other-worldly way to learn the names and order of the planets in our solar system.', '', 'In Stock', 'On Display', 6, 13),
	('W0001', '603273a7482af.jpg', 'Watch Black', 299.00, 'For Him', 'Watch', 'Birthday', 'Meticulously crafted by revered watch makers in Germany, of premium quality Swiss components, the Bauhaus style watch embodies timeless understated luxury and is limited to only 25 pieces worldwide. Paired with a first of its kind handmade full-grain bio ', '', 'In Stock', 'On Display', 6, 11),
	('W0002', '603276b105811.jpg', 'White - Luca', 299.00, 'For Him', 'Watch', 'Birthday', 'Meticulously crafted by revered watch makers in Germany, of premium quality Swiss components, the Bauhaus style watch embodies timeless understated luxury and is limited to only 25 pieces worldwide. Paired with a first of its kind handmade full-grain bio ', '', 'In Stock', 'On Display', 6, 11),
	('W0003', '603274390fb6d.jpg', 'Chronograph Black - Marco', 399.00, 'For Him', 'Watch', 'Birthday', 'Meticulously crafted by revered watch makers in Germany, of premium quality Swiss components, the Bauhaus style watch embodies timeless understated luxury and is limited to only 25 pieces worldwide. Paired with a first of its kind handmade full-grain bio ', '', 'In Stock', 'On Display', 6, 11),
	('W0004', '6032747710b41.jpg', 'Chronograph White - Léon', 399.00, 'For Him', 'Watch', 'Birthday', 'Meticulously crafted by revered watch makers in Germany, of premium quality Swiss components, the Bauhaus style watch embodies timeless understated luxury and is limited to only 25 pieces worldwide. Paired with a first of its kind handmade full-grain bio ', '', 'In Stock', 'On Display', 6, 11),
	('W0005', '603276efad088.jpg', 'MW1 Watch Model 023', 399.00, 'For Him', 'Watch', 'Birthday', 'Model 023 starts with our signature MW1 case in Silver. This 39mm combination creating a casual everyday look with timeless appeal suitable for any event.', '', 'In Stock', 'On Display', 6, 11),
	('W0006', '60327531ce066.jpg', 'MW1 Watch Model 145', 399.00, 'For Him', 'Watch', 'Birthday', 'Shop the Mister Wolf MW1 39mm Watch Model 145. A men’s watch with gold case, black leather band, white dial and black hands. Sydney design & assembly.', '', 'In Stock', 'On Display', 6, 11),
	('W0007', '60327575e037f.jpg', 'MW1 Watch Model 148', 399.00, 'For Him', 'Watch', 'Birthday', 'Model 148 starts with our signature MW1 case in Gold. The blue band and luminescent markers – are softened by the gold case.', '', 'In Stock', 'On Display', 6, 11);

-- Dumping structure for table fyp.product_customization
CREATE TABLE IF NOT EXISTS `product_customization` (
  `product_customization_id` int NOT NULL AUTO_INCREMENT,
  `card_type` varchar(255) NOT NULL,
  `card_price` decimal(7,2) NOT NULL,
  `card_stock` varchar(255) NOT NULL,
  PRIMARY KEY (`product_customization_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.product_customization: ~2 rows (approximately)
INSERT IGNORE INTO `product_customization` (`product_customization_id`, `card_type`, `card_price`, `card_stock`) VALUES
	(1, 'Flat horizontal', 30.00, 'In Stock'),
	(2, 'Flat vertical', 20.00, 'Out of Stock');

-- Dumping structure for table fyp.product_occasions
CREATE TABLE IF NOT EXISTS `product_occasions` (
  `occasions_id` int NOT NULL AUTO_INCREMENT,
  `occasions_name` varchar(255) NOT NULL,
  PRIMARY KEY (`occasions_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.product_occasions: ~2 rows (approximately)
INSERT IGNORE INTO `product_occasions` (`occasions_id`, `occasions_name`) VALUES
	(1, 'Valentine'),
	(6, 'Birthday');

-- Dumping structure for table fyp.product_type
CREATE TABLE IF NOT EXISTS `product_type` (
  `product_type_id` int NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) NOT NULL,
  `product_type` varchar(255) NOT NULL,
  PRIMARY KEY (`product_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.product_type: ~3 rows (approximately)
INSERT IGNORE INTO `product_type` (`product_type_id`, `prefix`, `product_type`) VALUES
	(1, 'F0', 'Flower Bouquet'),
	(2, 'K0', 'Keychain'),
	(11, 'W0', 'Watch');

-- Dumping structure for table fyp.promotion
CREATE TABLE IF NOT EXISTS `promotion` (
  `promotion_id` int NOT NULL AUTO_INCREMENT,
  `promotion_description` varchar(255) NOT NULL,
  `promotion_start_date` date NOT NULL,
  `promotion_end_date` date NOT NULL,
  `promotion_product_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.promotion: ~6 rows (approximately)
INSERT IGNORE INTO `promotion` (`promotion_id`, `promotion_description`, `promotion_start_date`, `promotion_end_date`, `promotion_product_type`, `status`) VALUES
	(2, 'Jan Promotion', '2021-01-01', '2021-01-31', 'Baby Box', 'Expired'),
	(3, 'February Promotion', '2021-02-01', '2021-02-28', 'Watch', 'Expired'),
	(4, 'March Promotion', '2021-03-01', '2021-03-31', 'Flower Bouquet', 'Enable'),
	(5, '1303 Promotion', '2021-03-13', '2021-03-13', 'Card Holder', 'Enable'),
	(6, 'March special', '2021-03-10', '2021-03-10', 'Flower Bouquet', 'Enable'),
	(7, 'Everyday Pink! Promotion for Pink Flowers', '2021-03-10', '2021-03-12', 'Flower Bouquet', 'Enable');

-- Dumping structure for table fyp.promotion_products
CREATE TABLE IF NOT EXISTS `promotion_products` (
  `promotion_item_id` int NOT NULL AUTO_INCREMENT,
  `promotion_id` int NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `original_price` decimal(7,2) NOT NULL,
  `promotion_price` decimal(7,2) NOT NULL,
  PRIMARY KEY (`promotion_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.promotion_products: ~17 rows (approximately)
INSERT IGNORE INTO `promotion_products` (`promotion_item_id`, `promotion_id`, `product_id`, `original_price`, `promotion_price`) VALUES
	(12, 2, 'B0002', 139.00, 100.00),
	(13, 2, 'B0004', 150.00, 120.00),
	(14, 2, 'B0005', 189.00, 122.20),
	(15, 2, 'B0006', 229.00, 200.00),
	(16, 3, 'W0001', 299.00, 259.99),
	(17, 3, 'W0003', 399.00, 389.99),
	(18, 3, 'W0005', 399.00, 389.99),
	(19, 4, 'F0015', 130.00, 120.00),
	(20, 4, 'F0016', 130.00, 120.00),
	(21, 4, 'F0021', 121.00, 100.00),
	(22, 4, 'F0025', 120.00, 100.00),
	(23, 5, 'C0001', 100.00, 80.00),
	(24, 5, 'C0003', 129.00, 110.00),
	(25, 5, 'C0004', 125.00, 115.00),
	(26, 6, 'F0001', 100.00, 80.00),
	(27, 6, 'F0005', 120.00, 110.99),
	(28, 7, 'F0001', 100.00, 70.00);

-- Dumping structure for table fyp.shopping_cart
CREATE TABLE IF NOT EXISTS `shopping_cart` (
  `cart_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.shopping_cart: ~5 rows (approximately)
INSERT IGNORE INTO `shopping_cart` (`cart_id`, `customer_id`, `product_id`, `quantity`, `status`) VALUES
	(35, 'CUS_0002', 'F0023', 1, 'waiting checkout'),
	(39, 'CUS_0001', 'K0029', 1, 'waiting checkout');

-- Dumping structure for table fyp.superadmin
CREATE TABLE IF NOT EXISTS `superadmin` (
  `superadmin_id` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`superadmin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.superadmin: ~1 rows (approximately)
INSERT IGNORE INTO `superadmin` (`superadmin_id`, `profile_picture`, `first_name`, `last_name`, `gender`, `email`, `phone`, `password`, `position`, `reset_token`) VALUES
	('SUPERADMIN_0001', '602efcc7040c2.jpg', 'Woon', 'Li Qi', 'Male', 'woonliqi3@gmail.com', '011-11151515', 'FYPtestingpass123!', 'Superadmin', '93ef6d25b21d43a921969aa1');

-- Dumping structure for table fyp.voucher
CREATE TABLE IF NOT EXISTS `voucher` (
  `voucher_id` int NOT NULL AUTO_INCREMENT,
  `voucher_code` varchar(255) NOT NULL,
  `min_spend` decimal(7,2) NOT NULL,
  `discount_amount` decimal(7,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `voucher_type` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.voucher: ~6 rows (approximately)
INSERT IGNORE INTO `voucher` (`voucher_id`, `voucher_code`, `min_spend`, `discount_amount`, `description`, `start_date`, `end_date`, `voucher_type`, `quantity`, `status`) VALUES
	(2, '0101NEWYEAR', 150.00, 30.00, '2021 new year', '2021-01-01', '2021-01-01', 'Product Discount', 50, 'Expired'),
	(3, 'FEBRUARYhappyDay', 60.00, 10.00, 'february free shipping', '2021-02-05', '2021-02-28', 'Free Shipping', 60, 'Expired'),
	(4, 'MARCH2021', 50.00, 10.00, 'free shipping for march 2021', '2021-03-01', '2021-03-31', 'Free Shipping', 48, 'Expired'),
	(5, 'HAPPRYDAY0123', 150.00, 20.00, 'none', '2021-03-10', '2021-03-13', 'Product Discount', 200, 'Expired'),
	(6, 'MAYwithEASYGIFT', 150.00, 20.00, 'none', '2021-05-01', '2021-05-31', 'Product Discount', 200, 'Expired'),
	(7, 'FREE_SHIP_0310', 15.00, 10.00, 'voucher 0310', '2021-03-10', '2023-01-28', 'Free Shipping', 99, 'Enable');

-- Dumping structure for table fyp.wish_list
CREATE TABLE IF NOT EXISTS `wish_list` (
  `wish_list_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  PRIMARY KEY (`wish_list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table fyp.wish_list: ~4 rows (approximately)
INSERT IGNORE INTO `wish_list` (`wish_list_id`, `customer_id`, `product_id`) VALUES
	(1, 'CUS_0002', 'F0002'),
	(6, 'CUS_0002', 'F0023'),
	(25, 'CUS_0001', 'K0028'),
	(26, 'CUS_0001', 'F0019');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
