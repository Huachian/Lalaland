<?php
	session_start();
	include "dataconnection.php";
	$customer_id = $_SESSION['id'];

  if(!isset($_SESSION['id'])){
    header("Location: login_register.php?next=view_purchase.php");
  }

  if(isset($_SESSION["admin_position"])){
    header("Location: index.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Your Purchase | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/view_purchase.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php
    include("navigation_bar.php");
  ?>
  <script type="text/javascript">
    sessionStorage.setItem('checkout_page_valid', "no");
    sessionStorage.setItem('payment_page_valid', "no");
  </script>

  <div class="purchase_main_wrap">
    <div class="sidebar_wrap">
      <?php
        $customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id'");
        $customer = mysqli_fetch_assoc($customer_details);
      ?>
      <div class="sidebar_header">
        <?Php echo $customer['first_name']." ".$customer['last_name']; ?>
      </div>

      <div class="sidebar_menu">
        <div class="sidebar_contain_head">
          <img src="image/cus_profile/profile_icon.png">
          <a href="cus_profile.php">My Account</a>
        </div>
        <div class="sidebar_contain_body">
          <ul>
            <li>
              <a href="cus_profile.php">Profile</a>
            </li>
            <li>
              <a href="cus_address.php">Addresses</a>
            </li>
            <li>
              <a href="cus_password.php">Change Password</a>
            </li>
          </ul>
        </div>

        <div class="sidebar_contain_head">
          <img src="image/cus_profile/my_orders_icon.jpg">
          <a href="view_purchase.php" style="color: #82b0a1;">My Purchase</a>
        </div>
      </div>
    </div>


    <div class="purchase_contain_wrap">
      <?php
        $purchase_result = mysqli_query($connect, "SELECT * FROM orders WHERE customer_id='$customer_id' ORDER BY order_date DESC");

        if(mysqli_num_rows($purchase_result) == 0){
          $display_empty = "display_empty";
        }
        else{
          $display_empty = "";
        }

        while($purchase_result_row = mysqli_fetch_assoc($purchase_result)){
          $order_id = $purchase_result_row['order_id'];

          $order_date = $purchase_result_row['order_date'];
          $order_date = strtotime($order_date);
          $order_date = date ("d-m-Y H:i:s", $order_date);  
      ?>
        <div class="purchase_row">
          <a href="view_order.php?order_id=<?php echo urlencode($order_id) ?>">
            <table>
              <tr class="table_head">
                <td colspan="4">
                  <div class="order_id">ORDER ID. <?php echo $order_id ?></div>
                  <div class="purchase_date"><?php echo $order_date ?></div>
                </td>
              </tr>

              <?php
                $order_products = mysqli_query($connect, "SELECT * FROM order_products where order_id='$order_id'");

                while($order_products_row = mysqli_fetch_assoc($order_products)){
                  $product_id = $order_products_row['product_id'];
                  $product_type = $order_products_row['product_type'];
                  $product_price = $order_products_row['product_price'];
                  $promotion_amount = $order_products_row['promotion_amount'];

                  if($product_type == "custom product"){
                    $image_path = "admin/image/customization/";
                  }
                  else{
                    $image_path = "admin/image/product_image/";
                  }
              ?>
                  <tr class="purchase_product_row">
                    <td class="table_body_1">
                      <img src="<?php echo $image_path ?><?php echo $order_products_row["product_image"] ?>">
                    </td>
                    <td class="table_body_2">
                      <div class="purchase_product_name">
                      <?php
                        if($product_type == "custom product"){
                          $custom_result = mysqli_query($connect, "SELECT * FROM customization_card where card_id='$product_id'");
                          $custom_row = mysqli_fetch_assoc($custom_result)
                      ?>
                          <b>[Custom <?php echo $custom_row['card_type']; ?> card]</b> 
                      <?php
                        }
                      ?>
                        <?php echo $order_products_row['product_name']; ?>
                      </div>
                    </td>
                    <td class="table_body_3">
                      x<?php echo $order_products_row['quantity']; ?>
                    </td>
                    <td class="table_body_4">
                    <?php
                      if($promotion_amount != 0){
                       $product_promotion_price = $product_price - $promotion_amount;
                    ?>
                        <div class="cancel_normal_price">
                          RM<span><?php echo number_format($order_products_row['product_price'], 2); ?></span>
                        </div>
                        <div class="promotion_price">
                          RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_promotion_price,2); ?></span>
                        </div>
                    <?php
                      }
                      else{
                    ?>
                        <div>
                          RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_price, 2); ?></span>
                        </div>
                    <?php
                      }
                    ?>
                    </td>
                  </tr>
              <?php
                }
              ?>
            </table>
          </a>
          <div class="purchase_summary">
            <div class="purchase_total_wrap">
              Order Total: <span class="purchase_total_amount">RM<?php echo number_format($purchase_result_row['total_amount'], 2) ?></span>
            </div>
            <div class="purchase_summary_btn">
              <a href="view_order.php?order_id=<?php echo urlencode($order_id) ?>" class="view_order_btn">View Order Details</a>
            </div>
          </div>
          <?php
            if($purchase_result_row['status'] == "Cancelled")
            {
              $status_color = "delivery_status_cancel";
            }
            else
            {
              $status_color = "delivery_status";
            }

          ?>
          <div class="<?php echo $status_color?>">
            <?php echo $purchase_result_row['status'] ?>
          </div>
        </div>
      <?php
        }
      ?>
    </div>

    <div id="<?php echo $display_empty ?>" class="empty_purchase_display_wrap">
      <div id="empty_purchase_display_wrap_2">
        <img src="image/view_purchase/sad_face_icon.png" id="sad_face_icon">
        <div id="empty_purchase_title">No Purchase Found</div>
      </div>
    </div>
  </div>

</body>
</html>