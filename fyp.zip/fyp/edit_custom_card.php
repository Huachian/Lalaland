<?php
	session_start();
	include ("dataconnection.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Edit Your Card | Easy Gift</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/edit_custom_card.css">
	<script type="text/javascript" src="js/edit_custom_card.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" integrity="sha384-vSIIfh2YWi9wW0r9iZe7RJPrKwp6bG+s9QZMoITbCckVJqGCCRhc+ccxNcdpHuYu" crossorigin="anonymous">
</head>
<body>
	<?php
		include ("navigation_bar.php");
	?>
	<script type="text/javascript">
		document.getElementById('custom_card_nav_btn').classList.add("active");
	</script>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="main_wrap">
		<div class="back_page">
			<button onclick="window.location = 'shopping_cart.php'">
				&#60; Back to shopping cart
			</button>
		</div>

		<div class="page_row" id="page_row_1">
			<div class="card_demo_wrap">
				<div class="card_patern_wrap">
					<div id="card_edit_title">
						Card Front
					</div>
				<?php
					if(isset($_GET['custom_card'])){
						$card_id = $_GET['custom_card'];
						$result = mysqli_query($connect, "SELECT * FROM customization_card WHERE card_id='$card_id'");
						$row = mysqli_fetch_assoc($result);

						$custom_card_type = $row['card_type'];
				?>
						<input type="hidden" id="ori_card_image" value="admin/image/customization/<?php echo $row['card_image'] ?>">
				<?php
					}
				

					if($custom_card_type == "vertical"){
				?>
					<div id="flat_vertical">
						<button id="vertical_change_image_btn" onclick="upload_image('<?php echo $custom_card_type ?>')">
							<i class="fas fa-redo"></i>
							Change Image
						</button>
						<button id="vertical_change_page_icon" onclick="change_vertical_card_view('<?php echo $custom_card_type ?>')">
							<img src="image/customization/change_icon.jpg">
							<input type="hidden" id="current_vertical_view" value="front">
						</button>
						<div id="vertical_card_front">
							<img src="admin/image/customization/<?php echo $row['card_image'] ?>" id="vertical_uploaded_image">

							<input type="file" id="vertical_card_img_upload" onchange="preview_product_image('vertical')" accept="image/x-png,image/jpeg">
						</div>
						<div id="vertical_card_back">
							<pre class="demo_text" id="vertical_demo_text"><?php echo $row['card_message'] ?></pre>

							<div id="card_logo">
								<img src="image/navigation_top_bar/easy_gift_big_logo.PNG">
							</div>
						</div>
					</div>
				<?php
					}
					else if($custom_card_type == "horizontal"){
				?>
						<div id="flat_horizontal">
							<button id="horizontal_change_image_btn" onclick="upload_image('<?php echo $custom_card_type ?>')">
								<i class="fas fa-redo"></i>
								Change Image
							</button>
							<button id="horizontal_change_page_icon" onclick="change_vertical_card_view('<?php echo $custom_card_type ?>')">
								<img src="image/customization/change_icon.jpg">
								<input type="hidden" id="current_horizontal_view" value="front">
							</button>
							<div id="horizontal_card_front">
								<img src="admin/image/customization/<?php echo $row['card_image'] ?>" id="horizontal_uploaded_image">

								<input type="file" id="horizontal_card_img_upload" onchange="preview_product_image('horizontal')" accept="image/x-png,image/jpeg">
							</div>
							<div id="horizontal_card_back">
								<pre class="demo_text" id="horizontal_demo_text"><?php echo $row['card_message'] ?></pre>

								<div id="card_logo">
									<img src="image/navigation_top_bar/easy_gift_big_logo.PNG">
								</div>
							</div>
						</div>
				<?php
					}
				?>
				</div>

				<div class="custom_selection_wrap" id="custom_selection_wrap">
					<div>
						<div class="upload_text_selection_header">
							Edit Card Back
						</div>
						<div class="upload_text_selection_description">
							<img src="image/customization/text_box_icon.png">
							<div>
								Customize your text below.
							</div>

							<div class="text_input_wrap">
								<textarea id="text_input" placeholder="Write your message here" onkeypress="update_demo_text('<?php echo $custom_card_type ?>')" onkeyup="update_demo_text('<?php echo $custom_card_type ?>')" disabled><?php echo $row['card_message'] ?></textarea>
							</div>
						</div>
						<div class="upload_text_selection_btn_wrap">
							<button id="edit_btn" onclick="edit_card('<?php echo $custom_card_type ?>')">Edit</button>
							<button id="save_edit_btn" onclick="save_dit_card('<?php echo $custom_card_type ?>', '<?php echo $card_id ?>')">Save Edit</button>
							<button id="cancel_edit_btn" onclick="cancel_edit_card('<?php echo $custom_card_type ?>', '<?php echo $card_id ?>')">Cancel</button>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<div id="card_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/customization/tick_icon.png">
				<div>
					successfully updated your card
				</div>
			</div>
		</div>
	</div>


	<?php
		include ("footer.php");
	?>

</body>
</html>