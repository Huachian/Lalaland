<?php
	session_start();
	include("dataconnection.php");

	$product_id = $_GET["product_id"];
	$result = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
	$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
	<title><?php echo $row['product_name'] ?> | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/product_page.css">
	<script type="text/javascript" src="js/product_page.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>
	<?php 
		include("navigation_bar.php"); 

		$product_id = $_GET["product_id"];
		$result = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
		$row = mysqli_fetch_assoc($result);

		if($row['product_stock'] == "In Stock"){
			$availability = "In Stock";
			$availability_id = "";

			$add_to_cart_function = "add_cart()";
			$add_to_cart_id = "";
			$add_to_cart_btn_contain = "Add To Cart";

			$buy_now_function = "buy_now()";
		}
		else if($row['product_stock'] == "Out of Stock"){
			$availability = "Out of Stock";
			$availability_id = "availability_no";

			$add_to_cart_function = "";
			$add_to_cart_id = "disable_add_to_cart";
			$add_to_cart_btn_contain = "Out of Stock";

			$buy_now_function = "";
		}

		if(isset($_SESSION["admin_position"])){
			$add_to_cart_function = "";
			$buy_now_function = "";
		}
	?>

	<div class="product_overall_wrap">
		<input type="hidden" name="product_id" value="<?php echo $row['product_id'] ?>" id="product_id">
		<div id="product_main_img">
			<?php
				if($availability == "Out of Stock"){
			?>
					<div class="out_of_stock">
						<div class="out_of_stock_contain_wrap">
							<div class="out_of_stock_contain">Out of Stock</div>
						</div>
					</div>
			<?php
				}
			?>
			<img src="admin/image/product_image/<?php echo $row["product_image"] ?>">
		</div>

		<div class="product_info">
			<h1 id="product_title"><?php echo $row['product_name'] ?></h1>
			<div class="price_wrap">
				<?php
					date_default_timezone_set("Asia/Kuala_Lumpur");
					$today_date = date("Y-m-d");
					$today_date = date_parse($today_date);

					$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

					$product_promotion_price = $row['product_price'];
					$found_promotion = "false";

					if(mysqli_num_rows($check_promotion) != 0){
						while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
							$promotion_id = $check_promotion_row['promotion_id'];

							$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
							$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

							if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
								$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

								$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

								if(mysqli_num_rows($check_promotion_product) != 0){
									if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
										$product_promotion_price = $check_promotion_product_result['promotion_price'];
									}
								}

								if(mysqli_num_rows($check_promotion_product) != 0){
									$found_promotion = "true";
								}
							}
						}
					}
					else{
						$product_promotion_price = 0;
						$found_promotion = "false";
					}


					if($found_promotion == "true"){
				?>
						<div class="promotion_price_wrap">
							<div class="cancel_normal_price">RM<?php echo number_format($row['product_price'],2); ?></div>
							<div class="promotion_price">RM<?php echo number_format($product_promotion_price,2); ?></div>
						</div>
				<?php
					}
					else{
				?>
						<div class="normal_product_price">RM<?php echo number_format($row['product_price'],2); ?></div>
				<?php
					}
				?>
			</div>
			<div class="product_descriptions">
				<ul>
					<span id="product_descriptions_title">Descriptions:</span>
					<li>
						<?php echo $row['product_description_1'] ?>
					</li>
						
					<?php
					if($row['product_description_2'] != null){
					?>
						<li>
							<?php echo $row['product_description_2'] ?>
						</li>
					<?php
					}
					?>
				</ul>
			</div>
			<div class="product_action">
				<div class="add_product_qty">
					<!-- <button class="minus_btn" onclick="minus(); check_cart_product_qty();">-</button>
					<input type="number" name="quantity" value="1" min="1" max="99" style="width: 50px;" onkeypress="return event.charCode>=48 && event.charCode<=57" onblur="min_qty_check(); check_cart_product_qty();">
					<button class="add_btn" onclick="add(); check_cart_product_qty();">+</button>
					<button type="button" name="add_to_cart_btn" class="add_to_cart_btn" id="<?php echo $add_to_cart_id ?>" onclick="<?php echo $add_to_cart_function ?>"><?php echo $add_to_cart_btn_contain ?></button>
					<?php
						if($add_to_cart_id != "disable_add_to_cart"){
					?>
							<button class="buy_now_btn" onclick="<?php echo $buy_now_function ?>">Buy Now</button>
					<?php	
						}
					?> -->
						
					<div class="wish_list_btn_wrap">
					<?php
						$check_wish_list = mysqli_query($connect, "SELECT * FROM wish_list WHERE customer_id='$customer_id' AND product_id='$product_id'");
						$wish_list = mysqli_num_rows($check_wish_list);

						if($wish_list > 0){
							$wish_list_icon_1 = "disable_wish_list_icon";
							$wish_list_icon_2 = "";
							$total_in_wish_list++;
					?>
							<input type="hidden" value="in_wish_list" id="wish_list_status">
					<?php
						}
						else{
							$wish_list_icon_1 = "";
							$wish_list_icon_2 = "disable_wish_list_icon";
					?>
							<input type="hidden" value="not_in_wish_list" id="wish_list_status">
					<?php
						}

						if(isset($_SESSION["admin_position"])){
							$wish_list_function = "";
						}
						else{
							$wish_list_function = "update_wishlist('".$product_id."')";
						}
					?>
						<div class="wish_list_btn <?php echo $wish_list_icon_1 ?>" id="wish_list_icon_1">
							<img src="image/search_result/wish_list_icon_1.png" class="wish_list_icon_1" onclick="<?php echo $wish_list_function ?>">
						</div>
						<div class="wish_list_btn <?php echo $wish_list_icon_2 ?>" id="wish_list_icon_2">
							<img src="image/search_result/wish_list_icon_2.png" class="wish_list_icon_2" onclick="<?php echo $wish_list_function ?>">
						</div>
						<div class="add_to_wish_list_title">
							Add To Wish List
						</div>
					</div>
				</div>

				<!-- <div class="attractive_label">
					<ul>
						<li>
							<img src="image/product_page/price_match_guarantee_icon.png">
							<span>Price Match Guarantee</span>
						</li>
						<li>
							<img src="image/product_page/secured_payments_icon.png">
							<span>Secured Payments</span>
						</li>
						<li>
							<img src="image/product_page/best_curated_gifts_icon.png">
							<span>Best Curated Gifts</span>
						</li>
					</ul>
				</div> -->
			</div>

			<div class="product_other_info">
				<!-- <div id="product_availability">
					Availability:
					<span id="<?php echo $availability_id ?>"><?php echo $availability ?></span>
				</div> -->
				<div id="product_type">
					Type:
					<span><?php echo $row['product_type'] ?></span>
				</div>
			</div>
		</div>
	</div>

	<div id="add_to_cart_popup_wrap">
		<div id="add_to_cart_popup_box">
			<div id="add_to_cart_popup_contain">
				<img src="image/product_page/add_to_cart_confirm.PNG">
				<div>
					Item has been added to your shopping cart
				</div>
			</div>
		</div>
	</div>

	<div id="max_qty_wrap">
		<div id="max_qty_box">
			<div id="max_qty_box_contain_wrap">
				<div id="max_qty_box_contain">
					Sorry, you can only add maximum 999 quantity
				</div>
				<div id="max_qty_confirm_btn">
					<button id="max_qty_confirm_yes" onclick="close_max_qty_wrap()">OK</button>
				</div>
			</div>
		</div>
	</div>


	<script type="text/javascript">
		//ignore 0 if user input 0 at first number
		$("[name='quantity']").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})
	</script>

	<?php
		include ("footer.php");
	?>
</body>
</html>