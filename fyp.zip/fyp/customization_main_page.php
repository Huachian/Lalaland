<?php
	session_start();
	include ("dataconnection.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Make Your Own Card | Easy Gift</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/customization_main_page.css">
</head>
<body>
	<?php
		include ("navigation_bar.php");
	?>
	<script type="text/javascript">
		document.getElementById('custom_card_nav_btn').classList.add("active");
	</script>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="custom_main_page_wrap">
		<div class="page_row" id="page_row_1">
			<div class="page_row_contain">
				<div class="page_contain_title">
					MAKE YOUR OWN CARD
				</div>

				<div class="page_contain_subtitle">
					A blank canvas for your own photo or design! Just pick the type of card you want to customize and get going.
				</div>

				<div class="card_patern_selection_wrap">
					<div class="card_patern_wrap">
						<div class="card_patern_image_wrap" id="flat_vertical_card_image"></div>

						<div class="card_patern_title_wrap">
							<div class="card_patern">
								Flat vertical
							</div>
							<div class="card_size">
								5” x 7”
							</div>
						</div>

						<div class="card_pattern_selection_btn">
							<a href="customization_card_information.php?custom_card_type=vertical"><button>Customize</button></a>
						</div>
					</div>

					<div class="card_patern_wrap">
						<div class="card_patern_image_wrap" id="flat_horizontol_card_image"></div>

						<div class="card_patern_title_wrap">
							<div class="card_patern">
								Flat horizontal
							</div>
							<div class="card_size">
								7” x 5”
							</div>
						</div>

						<div class="card_pattern_selection_btn">
							<a href="customization_card_information.php?custom_card_type=horizontal"><button>Customize</button></a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="page_row" id="page_row_2">
			<div class="page_row_contain">
				<div class="page_contain_title">
					GET THE PERFECT PRINT
				</div>

				<div class="perfect_print_tips_display_wrap">
					<div class="perfect_print_tips_box">
						<div class="perfect_print_tips_image_wrap" id="perfect_print_text_tips"></div>

						<div class="perfect_print_tips_title">
							Contain
						</div>

						<div class="perfect_print_tips_subtitle">
							Observe your text contain in card preview area.
						</div>
					</div>

					<div class="perfect_print_tips_box">
						<div class="perfect_print_tips_image_wrap" id="perfect_print_image_size_tips"></div>

						<div class="perfect_print_tips_title">
							Image size
						</div>

						<div class="perfect_print_tips_subtitle">
							The resolution should be 300dpi and no greater than 30mb.
						</div>
					</div>

					<div class="perfect_print_tips_box">
						<div class="perfect_print_tips_image_wrap" id="perfect_print_image_format_tips"></div>

						<div class="perfect_print_tips_title">
							Image format
						</div>

						<div class="perfect_print_tips_subtitle">
							We accept PNG & JPEG as well as SVG.
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
		include ("footer.php");
	?>

</body>
</html>