<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/footer.css">
</head>
<body>

	<footer>
		<div id="footer_wrap">
			<div id="footer_logo">
				<img src="image/navigation_top_bar/easy_gift_big_logo.PNG">
			</div>
			<div id="footer_contain">
				LALAGIFT is a leading thoughtful gifts price viewing place. Shoppers can find a wide variety of innovative, unique and personalisable products under one roof. LALAGIFT was founded in 2023.
			</div>

			<div id="footer_contact_info">
				<div><b style="color: #000066;">Customer Service Hotline:</b> (+60)11-123 4567</div>
				<div><b style="color: #000066;">Email:</b> LALAGIFT.my@gmail.com</div>
			</div>
		</div>
	</footer>

</body>
</html>