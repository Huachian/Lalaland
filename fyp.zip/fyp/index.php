<?php
	session_start();
	include "dataconnection.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
	<?php
		include "navigation_bar.php";
	?>
	<script type="text/javascript">
		document.getElementById('home_btn').classList.add("active");
	</script>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="main_wrap">
		<div class="main_page_top_banner_wrap">
			<div class="top_banner_contain_column">
				<img src="image/home_page/home_bulb_icon.png">
				<div class="top_banner_text_contain">
					<span class="top_banner_title">Leading thoughtful gift viewing platform</span>
					<br>
					<span class="top_banner_sub_title">The home of the personalised and unique gifts</span>
				</div>
			</div>
			<div class="top_banner_contain_column" id="unique_gifts_wrap">
				<img src="image/home_page/gift_icon.png">
				<div class="top_banner_text_contain">
					<span class="top_banner_title">Unique gifts</span>
					<br>
					<span class="top_banner_sub_title">Make by the best local creative artisans</span>
				</div>
			</div>
			<div class="top_banner_contain_column">
				<img src="image/home_page/heart_icon.png">
				<div class="top_banner_text_contain">
					<span class="top_banner_title">Love by you</span>
					<br>
					<span class="top_banner_sub_title">Ensure our customers are happy</span>
				</div>
			</div>
		</div>

		<div id="banner_slider">
			<?php
				$result = mysqli_query($connect, "SELECT * FROM banner WHERE banner_status='Display'");

				while($row = mysqli_fetch_assoc($result)){
			?>
					<img class="slides" src="admin/image/banner/<?php echo $row['banner_name'] ?>">
			<?php
				}
			?>
		</div>

		<div id="banner_button_wrap">
			<div id="banner_back_button" onclick="plusDivs(-1, 'manual_change')"><img src="image/home_page/previous_icon.png"></div>
			<div id="banner_next_button" onclick="plusDivs(1, 'manual_change')"><img src="image/home_page/next_icon.png"></div>

			<div id="current_banner_btn_wrap">
				<?php
					$result = mysqli_query($connect, "SELECT * FROM banner WHERE banner_status='Display'");
					$i=0;

					while($row = mysqli_fetch_assoc($result)){
						$i++;
				?>
						<button class="current_position" onclick="currentDiv(<?php echo $i ?>)"></button>
				<?php
					}
				?>
			</div>
		</div>


		<!-- <div class="for_who_detail_wrap">
			<div class="for_him" style="margin-right: 26px;">
				<span>For Him</span>
				<br>
				<a href="search_result.php?filter_gender[]=For Him"><img src="image/navigation_top_bar/him.PNG"></a>
			</div>

			<div class="for_her" style="margin-right: 26px;">
				<span>For Her</span>
				<br>
				<a href="search_result.php?filter_gender[]=For Her"><img src="image/navigation_top_bar/her.PNG"></a>
			</div>

			<div class="for_kid" style="margin-right: 26px;">
				<span>For Kids</span>
				<br>
				<a href="search_result.php?filter_gender[]=For Kids"><img src="image/navigation_top_bar/kid.PNG"></a>
			</div>

			<div class="newborn">
				<span>Newborn</span>
				<br>
				<a href="search_result.php?filter_gender[]=Newborn"><img src="image/navigation_top_bar/newborn.PNG"></a>
			</div>
		</div> -->
	</div>


	<script type="text/javascript">
		var slideIndex = 1;
		var start = 0;
		showDivs(slideIndex);

		function plusDivs(n, action){
		  showDivs(slideIndex += n, action);
		}

		function currentDiv(n){
		  showDivs(slideIndex = n);
		}

		function showDivs(n, action){
		  var slides = document.getElementsByClassName("slides");
		  var dots = document.getElementsByClassName("current_position");

		  if(n > slides.length){
		    slideIndex = 1;
		  }

		  if(n < 1){
		    slideIndex = slides.length;
		  }

		  for(var i = 0; i < slides.length; i++){
		    slides[i].style.display = "none";
		    dots[i].className = dots[i].className.replace(" banner_active", "");
		  }

		  slides[slideIndex-1].style.display = "block";  
		  dots[slideIndex-1].className += " banner_active";

		  if(start == 0){
		  	setTimeout("plusDivs(1, 'auto_change')", 3000);
		  	start += 1;
		  }
		  else if(action == "auto_change"){
		  	setTimeout("plusDivs(1, 'auto_change')", 3000);
		  }
		}
	</script>

	<?php
		include("footer.php");
	?>

</body>
</html>