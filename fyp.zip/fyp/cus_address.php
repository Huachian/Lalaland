<?php
  session_start();
  include "dataconnection.php";
  $customer_id = $_SESSION['id'];

  if(!isset($_SESSION['id'])){
    header("Location: login_register.php?next=cus_address.php");
  }

  if(isset($_SESSION["admin_position"])){
    header("Location: index.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Account | Easy Gift - Malaysia's Leading Online Gift Shop</title>
  <link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
  <link rel="stylesheet" type="text/css" href="css/cus_address.css">
  <script type="text/javascript" src="js/cus_address.js"></script>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
  <?php 
    include("navigation_bar.php"); 
  ?>
  <script type="text/javascript">
    sessionStorage.setItem('payment_page_valid', "no");
  </script>

  <div class="address_main_wrap">
    <div class="sidebar_wrap">
      <?php
        $customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id'");
        $customer = mysqli_fetch_assoc($customer_details);
      ?>
      <div class="sidebar_header">
        <?Php echo $customer['first_name']." ".$customer['last_name']; ?>
      </div>

      <div class="sidebar_menu">
        <div class="sidebar_contain_head">
          <img src="image/cus_profile/profile_icon.png">
          <a href="cus_profile.php">My Account</a>
        </div>
        <div class="sidebar_contain_body">
          <ul>
            <li>
              <a href="cus_profile.php">Profile</a>
            </li>
            <!-- <li>
              <a href="cus_address.php" style="color: #82b0a1;">Addresses</a>
            </li> -->
            <li>
              <a href="cus_password.php">Change Password</a>
            </li>
          </ul>
        </div>

        <!-- <div class="sidebar_contain_head">
          <img src="image/cus_profile/my_orders_icon.jpg">
          <a href="view_purchase.php">My Purchase</a>
        </div> -->
      </div>
    </div>


    <div class="address_display_box">
      <div class="address_display_head">
        <h2>My Addresses</h2>
        <div class="display_head_btn">
          <button onclick="add_new_address_popup();">
            <img src="image/cus_profile/add_icon.png">
            Add New Address
          </button>
        </div>
      </div>

      <?php
        $address_list_select = mysqli_query($connect, "SELECT * FROM customer_address WHERE customer_id='$customer_id'");
        $counter = 0;
        
        while($address_list = mysqli_fetch_assoc($address_list_select)){
          $counter++;
      ?>
          <div class="address_list_row" id="address_list_row<?php echo $counter ?>">
            <input type="hidden" name="address_default_value" value="<?php echo $address_list['address_default'] ?>" id="address_default_value<?php echo $counter ?>">
            <div class="address_data_row">
              <div class="address_data_title">
                Full name
              </div>
              <div id="address_data_name">
                <span id="name<?php echo $counter ?>"><?php echo $address_list['name']; ?></span>
                <?php
                  if($address_list['address_default'] == "Default"){
                    $default_status = "Default";
                    $default_calss = "default_address_tag";
                  }
                  else{
                    $default_status = "";
                    $default_calss = "not_default_address_tag";
                  }
                ?>
                    <span class='<?php echo $default_calss ?>' id='default_address_tag<?php echo $counter ?>'><?php echo $default_status; ?></span>
              </div>
            </div>

            <div class="address_data_row">
              <div class="address_data_title">
                Phone
              </div>
              <div id="phone<?php echo $counter ?>"><?php echo $address_list['contact'] ?></div>
            </div>

            <div class="address_data_row">
              <div class="address_data_title">
                Address
              </div>
              <div>
                <span id="address<?php echo $counter ?>"><?php echo $address_list['address'] ?></span>
                <br>
                <span id="area<?php echo $counter ?>"><?php echo $address_list['area'] ?></span>
                <br>
                <span id="postcode<?php echo $counter ?>"><?php echo $address_list['postcode'] ?></span> <span id="state<?php echo $counter ?>"><?php echo $address_list['state'] ?></span>
              </div>
            </div>

            <div class="address_data_btn">
              <button onclick="edit_address(<?php echo $address_list['address_id'] ?>, <?php echo $counter ?>)">Edit</button>
              <button onclick="delete_popup(<?php echo $address_list['address_id'] ?>, <?php echo $counter ?>)">Delete</button>
              <?php
                if($address_list['address_default'] == "Default"){
                  $change_default_btn = "change_default_btn_no";
                }
                else{
                  $change_default_btn = "change_default_btn_yes";
                }
              ?>
              <button class="<?php echo $change_default_btn ?>" onclick="change_default_btn(<?php echo $address_list['address_id'] ?>, <?php echo $counter ?>)" id ="change_default_btn<?php echo $counter ?>">Set As Default</button>
            </div>
          </div>
      <?php
        }
      ?>

      
    </div>
  </div>


  <!-- add new address form -->
  <div id="add_address_wrap">
    <div id="add_address_box">
      <div class="add_address_title">
        <h4>Add A New Address</h4>
      </div>

      <div class="add_address_body">
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_name" placeholder="Full Name" id="address_name" onblur="nameValidation('add')">
          <span id="adds_name_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_phone" placeholder="Phone Number (Example: xxx-xxxxxxxx)" id="address_phone" onblur="phoneValidation('add')" data-mask="999-99999999">
          <span id="adds_phone_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="new_address" placeholder="Address" id="new_address" onblur="addressValidation('add')">
          <span id="adds_add_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_postcode" placeholder="Postcode" id="address_postcode" onblur="postcodeValidation('add')">
          <span id="adds_post_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_state" placeholder="State" id="address_state" onblur="stateValidation('add')">
          <span id="adds_state_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="text" class="textbox2" name="address_area" placeholder="Area" id="address_area" onblur="areaValidation('add')">
          <span id="adds_area_error" class="add_address_error"></span>
        </div>
        <div class="add_address_row">
          <input type="checkbox" name="set_new_default" id="set_new_default">
          <div id="set_new_default_label">Set as default address</div>
        </div>
      </div>

      <div class="add_address_btn">
        <button id="cancel_add_address" onclick="cancel_address()">Cancel</button>
        <button onclick="submit_address()">Submit</button>
      </div>
    </div>
  </div>

  
  <!-- edit address form -->
  <div id="edit_address_wrap">
    <div id="edit_address_box">
      <div class="edit_address_title">
        <h4>Edit Address</h4>
      </div>


      <div class="edit_address_body">
        <input type="hidden" name="edit_address_id" value="" id="edit_address_id">
        <input type="hidden" name="edit_address_row_counter" value="" id="edit_address_row_counter">
        <div class="edit_address_row">
          <input type="text" class="textbox2" name="address_name" placeholder="Full Name" id="edit_address_name" onblur="nameValidation('edit')">
          <span id="edit_name_error" class="add_address_error"></span>
        </div>
        <div class="edit_address_row">
          <input type="text" class="textbox2" name="address_phone" placeholder="Phone Number (Example: xxx-xxxxxxxx)" id="edit_address_phone" onblur="phoneValidation('edit')" data-mask="999-99999999">
          <span id="edit_phone_error" class="add_address_error"></span>
        </div>
        <div class="edit_address_row">
          <input type="text" class="textbox2" name="new_address" placeholder="Address" id="edit_address" onblur="addressValidation('edit')">
          <span id="edit_add_error" class="add_address_error"></span>
        </div>
        <div class="edit_address_row">
          <input type="text" class="textbox2" name="address_postcode" placeholder="Postcode" id="edit_address_postcode" onblur="postcodeValidation('edit')">
          <span id="edit_post_error" class="add_address_error"></span>
        </div>
        <div class="edit_address_row">
          <input type="text" class="textbox2" name="address_state" placeholder="State" id="edit_address_state" onblur="stateValidation('edit')">
          <span id="edit_state_error" class="add_address_error"></span>
        </div>
        <div class="edit_address_row">
          <input type="text" class="textbox2" name="address_area" placeholder="Area" id="edit_address_area" onblur="areaValidation('edit')">
          <span id="edit_area_error" class="add_address_error"></span>
        </div>
        <div class="edit_address_row">
          <input type="checkbox" name="set_new_default" id="edit_default">
          <div id="edit_default_label">Set as default address</div>
        </div>
      </div>

      <div class="edit_address_btn">
        <button id="cancel_edit_address" onclick="cancel_address()">Cancel</button>
        <button onclick="save_edit_address()">Save</button>
      </div>
    </div>
  </div>


  <div id="delete_confirm_wrap">
    <div id="delete_confirm_box">
      <div id="delete_confirm_contain">
        <div id="delete_confirm_title">
          Delete Address?
        </div>
        <div id="delete_confirm_btn">
          <button id="delete_confirm_yes" onclick="confirm_delete()">Delete</button>
          <button id="delete_confirm_no" onclick="cancel_delete()">Cancel</button>
        </div>
      </div>
    </div>
  </div>

  <div id="delete_error_wrap">
    <div id="delete_error_box">
      <div id="delete_error_contain">
        <img src="image/customer_address/eror_icon.png">
        <div>
          Cannot delete default address.
        </div>
      </div>
    </div>
  </div>

  <div id="add_address_alert_wrap">
    <div id="add_address_alert_box">
      <div id="add_address_alert_contain">
        <img src="image/customer_address/tick_icon.png">
        <div>
          Address Successfully Added
        </div>
      </div>
    </div>
  </div>

  <div id="edit_address_alert_wrap">
    <div id="edit_address_alert_box">
      <div id="edit_address_alert_contain">
        <img src="image/customer_address/tick_icon.png">
        <div>
          Address Successfully Saved
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>

