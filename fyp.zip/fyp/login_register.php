<?php
    session_start();
    include("dataconnection.php");

    if(isset($_SESSION["admin_position"])){
        header("Location: admin/index.php");
    }
    else if(isset($_SESSION['id'])){
        header("Location: index.php");
    }

    if(isset($_GET['product_id'])){
       $product_id = $_GET['product_id'];
    }
    else{
        $product_id = "none";
    }

    if(isset($_GET['custom_card_type'])){
        $custom_card_type = $_GET['custom_card_type'];
    }
    else{
        $custom_card_type = "none";
    }

    if(isset($_GET['next'])){
        $next_page = $_GET['next'];
    }
    else{
        $next_page = "none";
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Account | Easy Gift - Malaysia's Leading Online Gift Shop</title>
    <link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/login_register.css">
	<script type="text/javascript" src="js/login_register.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
    <?php include("navigation_bar.php") ?>
    <script type="text/javascript">
        document.getElementById('log_res_btn').classList.add("active");
    </script>

    <div class="overall_background">
		<div class="login_box">
    		<h2>Log in</h2>

            <div id="havent_login_pop_up">
                Please login first
            </div>

            <div id="login_error_wrap">
                <div id="login_register_error_icon">
                    <img src="image/login_register/cross_icon.png">
                </div>
                <span id="login_error">Email or password is invalid. Please try again.</span>
            </div>
            <div class="form_row">
                <p>Email address <span class="required">*</span></p>
                <input type="email" id="login_email" class="textbox" name="login_email" placeholder="Enter your email" onblur="login_email_validation()">
                <span id="login_email_error"></span>
            </div>

            <div class="form_row">
                <p>Password <span class="required">*</span></p>
                <input type="password" id="login_pass" class="textbox" name="login_pass" placeholder="Enter your password" onblur="login_password_validation()" onkeyup="login_press()">
                <div id="toggle_login_password" onclick="show_hide_password('login_password')"></div>
                <span id="login_pass_error"></span>
            </div>

            <div class="form_row">
          		<a href="forgot_password.php" id="lost_pass">Lost your password?</a>
            </div>

            <div class="form_actions">
             	<button type="button" name="loginbtn" id="login_button" class="login_btn" onclick="login_validation('<?php echo $product_id ?>', '<?php echo $custom_card_type ?>', '<?php echo $next_page ?>')">Log in</button>  

            	<div class="divider">
             	  <span>Or</span>
             	</div>

             	<button type="button" name="showregisterbtn" class="show_reg_btn" onclick="show_register_form()">Register an account</button>
            </div>
		</div>


        <div class="register_box" style="display: none;">
            <h2>Register</h2>
            <div id="fname_row">
                <div class="form_row">
                    <p>First Name  <span class="required">*</span></p>
                    <input type="text" class="textbox" name="reg_firstname" id="reg_fname" placeholder="Enter your First name" onblur="fname_validation()">
                    <span id="fname_error"></span>
                </div>
            </div>
            <div id="lname_row">
                <div class="form_row">
                    <p>Last Name  <span class="required">*</span></p>
                    <input type="text" class="textbox" name="reg_lastname" id="reg_lname" placeholder="Enter your Last name" onblur="lname_validation()">
                    <span id="lname_error"></span>
                </div>
            </div>
            <div id="email_row">
                <div class="form_row">
                    <p>Email address <span class="required">*</span></p>
                    <input type="email" class="textbox" name="reg_emailadd" id="reg_email" placeholder="Enter your Email address" onblur="email_validation()">
                    <span id="email_error"></span>
                </div>
            </div>
            <div class="form_row">
                <p>Password <span class="required">*</span></p>
                <input type="password" class="textbox" name="reg_password" id="reg_pass" placeholder="Enter your Password" onkeyup="new_password_guide()" onkeydown="javascript: var keycode = keyPressed_new_password(event); if(keycode==32){ return false; }" onblur="new_password_validation()" autocomplete="off">
                <div id="toggle_password" onclick="show_hide_password('register_password')"></div>
                <img src="image/login_register/tick_icon.png" id="new_password_tick_icon">
                <img src="image/login_register/cross_icon.png" id="new_password_cross_icon">
                <div id="password_format">*Please use a strong password.<br> (<span id="characters">Minimum 15 characters</span>, <span id="number">1 number</span>, <span id="small_letter">1 small letter</span>, <span id="upper_letter">1 upper letter</span>, <span id="symbol">1 symbol</span>)</div>
                <span id="pass_error"></span>
            </div>
            <div class="form_row">
                <p>Confirm Password <span class="required">*</span></p>
                <input type="password" class="textbox" name="confirm_pass" id="reg_confirm" placeholder="Enter your password" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" onblur="confirm_password_validation()" autocomplete="off">
                <div id="toggle_conpassword" onclick="show_hide_password('confirm_register_password')"></div>
                <img src="image/login_register/tick_icon.png" id="confirm_password_tick_icon">
                <img src="image/login_register/cross_icon.png" id="confirm_password_cross_icon">
                <span id="conpass_error"></span>
            </div>
            <div class="form_row">
                <p>Gender<span class="required">*</span></p>
                    <div class="gender_radiobox">
                        <input type="radio" name="gender" value="male" id="reg_male" onclick="select_gender()"> Male
                        <br>
                        <input type="radio" name="gender" value="female" id="reg_female" onclick="select_gender()"> Female
                    </div>
                <span id="gender_error"></span>
            </div>
            <div class="form_row">
                <p>Address  <span class="required">*</span></p>
                <input type="text" class="textbox" name="reg_address" id="reg_add" placeholder="Enter your Address" onblur="addressValidation()">
                <span id="add_error"></span>
            </div>
            <div class="form_row">
                <p>Postcode  <span class="required">*</span></p>
                <input type="text" class="textbox" name="reg_postcode" id="reg_postcode" placeholder="Enter your Postcode" onblur="postcodeValidation()">
                <span id="postcode_error"></span>
            </div>
            <div class="form_row">
                <p>State  <span class="required">*</span></p>
                <input type="text" class="textbox" name="reg_state" id="reg_state" placeholder="Enter your State" onblur="stateValidation()">
                <span id="state_error"></span>
            </div>
            <div class="form_row">
                <p>Area  <span class="required">*</span></p>
                <input type="text" class="textbox" name="reg_area" id="reg_area" placeholder="Enter your Area" onblur="areaValidation()">
                <span id="area_error"></span>
            </div>
            <div class="form_row">
                <p>Phone Number<span class="required">*</span></p>
                <input type="tel" class="textbox" name="reg_phone" id="reg_phone" placeholder="(Example: xxx-xxxxxxxx)" onblur="phoneValidation()" data-mask="999-99999999">
                <span id="phone_error"></span>
            </div>

            <div id="register_error_wrap">
                <div id="login_register_error_icon">
                    <img src="image/login_register/cross_icon.png">
                </div>
                <span id="register_error">Register details are invalid. Please try again.</span>
            </div>

            <div class="form_actions">
                <button type="button" name="regbtn" class="reg_btn" onclick="register('<?php echo $product_id ?>')">Register</button>

                <div class="divider">
                  <span>Or</span>
                </div>

                <button type="button" name="showloginbtn"  id="show_login_btn" class="show_login_btn" onclick="show_login_form()">Log in</button>
            </div>
        </div>
    </div>



    <div id="register_alert_wrap">
        <div id="register_alert_box">
          <div id="register_alert_contain">
            <img src="image/login_register/tick_icon.png">
            <div>
                Register Successfully
            </div>
          </div>
        </div>
    </div>

    <div id="login_success_alert_wrap" class="alert_box_wrap">
        <div class="alert_box">
            <div class="alert_box_contain">
                <img src="image/login_register/welcome_icon.png" id="welcome_icon">
                <div style="margin-top: -40px;">
                   Welcome Back!
                </div>
            </div>
        </div>
    </div>



    <?php
        if(isset($_GET['target'])){
            if($_GET['target'] == "register"){
    ?>
                <script type="text/javascript">
                    show_register_form();
                </script>
    <?php
            }
        }

        if(isset($_GET['next']) || isset($_GET['product_id']) || isset($_GET['custom_card_type'])){
    ?>
            <script type="text/javascript">
                document.getElementById("havent_login_pop_up").style.display = "block";

                setTimeout(function(){
                  $('#havent_login_pop_up').fadeOut('slow');
                }, 1000); 
            </script>
    <?php
        }




        include ("footer.php");
    ?>


    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>