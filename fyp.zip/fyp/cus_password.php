<?php
  session_start();
  include "dataconnection.php";

  if(!isset($_SESSION['id'])){
    header("Location: login_register.php?next=cus_password.php");
  }

  if(isset($_SESSION["admin_position"])){
    header("Location: index.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Account | Easy Gift - Malaysia's Leading Online Gift Shop</title>
  <link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/cus_password.css">
  <script type="text/javascript" src="js/cus_password.js"></script>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
  <?php include("navigation_bar.php");?>

  <script type="text/javascript">
    sessionStorage.setItem('checkout_page_valid', "no");
    sessionStorage.setItem('payment_page_valid', "no");
  </script>

  <div class="change_password_main_warp">
    <div class="sidebar_wrap">
      <?php
        $customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id'");
        $customer = mysqli_fetch_assoc($customer_details);
      ?>
      <div class="sidebar_header">
        <?Php echo $customer['first_name']." ".$customer['last_name']; ?>
      </div>

      <div class="sidebar_menu">
        <div class="sidebar_contain_head">
          <img src="image/cus_profile/profile_icon.png">
          <a href="cus_profile.php">My Account</a>
        </div>
        <div class="sidebar_contain_body">
          <ul>
            <li>
              <a href="cus_profile.php">Profile</a>
            </li>
            <!-- <li>
              <a href="cus_address.php">Addresses</a>
            </li> -->
            <li>
              <a href="cus_password.php" style="color: #D7A1F9;">Change Password</a>
            </li>
          </ul>
        </div>

        <!-- <div class="sidebar_contain_head">
          <img src="image/cus_profile/my_orders_icon.jpg">
          <a href="view_purchase.php">My Purchase</a>
        </div> -->
      </div>
    </div>

    <div class="change_password_box">
      <div class="change_password_head">
        <h2>Change Password</h2>
      </div>

      <div class="change_password_body">
        <div id="change_password_form">
          <div class="password_form_row">
            <div class="password_form_title">Current Password</div>
            <div><form autocomplete="off"><input type="password" name="current_password" onblur="current_password_validation()" id="current_password" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }"></form><div class="show_password" onclick="show_hide_current_password()" id="current_password_show_hide_icon"></div></div>
          </div>
          <div id="current_password_error_message"></div>

          <div class="password_form_row">
            <div class="password_form_title">New Password</div>
            <div><form autocomplete="off"><input type="password" name="new_password" id="new_password" onkeyup="new_password_guide()" onkeydown="javascript: var keycode = keyPressed_new_password(event); if(keycode==32){ return false; }" onblur="new_password_validation()"></form><div class="show_password" onclick="show_hide_new_password()" id="new_password_show_hide_icon"></div></div>
          </div>
          <img src="image/customer_address/tick_icon.png" id="new_password_tick_icon">
          <img src="image/customer_address/cross_icon.png" id="new_password_cross_icon">
          <div id="new_password_error_message"></div>
          <div id="password_format">*Please use a strong password.<br> (<span id="characters">Minimum 15 characters</span>, <span id="number">1 number</span>, <span id="small_letter">1 small letter</span>, <span id="upper_letter">1 upper letter</span>, <span id="symbol">1 symbol</span>)</div>

          <div class="password_form_row">
            <div class="password_form_title">Confirm Password</div>
            <div><form autocomplete="off"><input type="password" name="confirm_password" id="confirm_password" onkeydown="javascript: var keycode = keyPressed(event); if(keycode==32){ return false; }" onblur="confirm_password_validation()"></form><div class="show_password" onclick="show_hide_confirm_password()" id="confirm_password_show_hide_icon"></div></div>
          </div>
          <div id="confirm_password_error_message"></div>
          <img src="image/customer_address/tick_icon.png" id="confirm_password_tick_icon">
          <img src="image/customer_address/cross_icon.png" id="confirm_password_cross_icon">
        </div>
        <div id="change_password_btn" onclick="change_password()">
          <button id="confirm_change_password">Confirm</button>
        </div>
      </div>
    </div>
  </div>

  <div id="change_password_error_wrap">
    <div id="change_password_error_box">
      <div id="change_password_error_contain">
        <img src="image/customer_address/eror_icon.png">
        <div>
          Current password is incorrect.
        </div>
      </div>
    </div>
  </div>

  <div id="same_with_old_password_error_wrap">
    <div id="change_password_error_box">
      <div id="change_password_error_contain">
        <img src="image/customer_address/eror_icon.png">
        <div>
          New password same with current password.
        </div>
      </div>
    </div>
  </div>

  <div id="change_password_success_wrap">
    <div id="change_password_success_box">
      <div id="change_password_success_contain">
        <img src="image/customer_address/tick_icon.png">
        <div>
          Password successfully changed.
        </div>
      </div>
    </div>
  </div>
</body>
</html>


