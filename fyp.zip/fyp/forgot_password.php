<?php
    include("dataconnection.php");

    if(isset($_SESSION["admin_position"])){
        header("Location: admin/index.php");
    }
    else if(isset($_SESSION['id'])){
        header("Location: index.php");
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Reset Password | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/forgot_password.css">
	<script type="text/javascript" src="js/forgot_password.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php include ("navigation_bar.php") ?>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="main_wrap">

	<?php
		if(isset($_GET['token'])){
			$reset_token = $_GET['token'];
			if(!empty($reset_token)){
				$check_customer = mysqli_query($connect, "SELECT * FROM customer where reset_token='$reset_token'");
				$check_customer_result = mysqli_num_rows($check_customer);
				$check_admin = mysqli_query($connect, "SELECT * FROM admin where reset_token='$reset_token'");
				$check_admin_result = mysqli_num_rows($check_admin);
				$check_superadmin = mysqli_query($connect, "SELECT * FROM superadmin where reset_token='$reset_token'");
				$check_superadmin_result = mysqli_num_rows($check_superadmin);

				if($check_customer_result > 0){
					$row = mysqli_fetch_assoc($check_customer);
				}
				else if($check_admin_result > 0){
					$row = mysqli_fetch_assoc($check_admin);
				}
				else if($check_superadmin_result > 0){
					$row = mysqli_fetch_assoc($check_superadmin);
				}
			}
			else{
				$check_customer_result = 0;
				$check_admin_result = 0;
				$check_superadmin_result = 0;
			}

			if($check_customer_result != 0 || $check_admin_result != 0 || $check_superadmin_result != 0){
	?>
				<div class="reset_password_box">
					<h2>
						Reset account password
					</h2>

					<div class="reset_password_subtitle">
						Enter a new password for <?php echo $row['email'] ?>
					</div>

					<div class="reset_password_input_wrap">
					<form autocomplete="off">
						<input type="password" autocomplete="new-password" placeholder="Password" id="reset_password" onkeyup="new_password_guide()" onkeydown="javascript: var keycode = keyPressed_new_password(event); if(keycode==32){ return false; }" onblur="new_password_validation()">
					</form>
						<div id="toggle_password" onclick="show_hide_password('new_password')"></div>
						<div id="password_format">*Please use a strong password.<br> (<span id="characters">Minimum 15 characters</span>, <span id="number">1 number</span>, <span id="small_letter">1 small letter</span>, <span id="upper_letter">1 upper letter</span>, <span id="symbol">1 symbol</span>)</div>
	                	<span id="pass_error"></span>
	                <form autocomplete="off">
						<input type="password" placeholder="Confirm Password" id="confirm_reset_password" onkeydown="javascript: var keycode = keyPressed_confirm_password(event); if(keycode==32){ return false; }" onblur="confirm_password_validation()">
					</form>
						<div id="toggle_conpassword" onclick="show_hide_password('confirm_new_password')"></div>
						<span id="conpass_error"></span>
					</div>

					<div class="reset_password_btn_wrap">
						<button id="submit_reset_password" onclick="reset_password('<?php echo $reset_token ?>')">Reset Password</button>
					</div>
				</div>
	<?php
			}
		}
		else{
	?>
			<div class="send_reset_box">
				<h2>
					Reset your password
				</h2>

				<div class="send_reset_subtitle">
					We will send you an email to reset your password.
				</div>

				<div id="reset_email_error_wrap">
					<div id="reset_email_error_icon">
	                    <img src="image/login_register/cross_icon.png">
	                </div>
	                <span id="reset_email_error">No account found with that email.</span>
				</div>

				<div id="reset_email_success_wrap">
	                <span>We've sent you an email with a link to update your password.</span>
				</div>

				<div class="reset_email_input_wrap">
					<input type="text" placeholder="Email" id="reset_password_email" onkeyup="reset_error_message()">
				</div>

				<div class="reset_password_btn_wrap">
					<button id="submit_reset_password_email" onclick="send_reset_email()">Submit</button>
					<br>
					<a href="login_register.php">
						<button id="cancel_reset_password">Cancel</button>
					</a>
					<div class="divider"></div>
					<a href="login_register.php?target=register">
						<button id="register_account_btn">Register an account</button>
					</a>
				</div>
			</div>
	<?php
		}
	?>
	</div>

	<div id="update_password_success" class="empty_alert_wrap">
		<div id="empty_alert_box">
			<div id="empty_alert_contain">
				<img src="image/customization/tick_icon.png">
				<div>
					Password successfully reset
				</div>
			</div>
		</div>
	</div>


	<?php
		if(isset($_GET['token']) && $check_customer_result == 0 && $check_admin_result == 0 && $check_superadmin_result == 0){
	?>
			<div class="empty_alert_wrap">
				<div id="empty_alert_box">
					<div id="empty_alert_contain">
						<img src="image/shopping_cart/eror_icon.png">
						<div>
							The link you trying to access is invalid
						</div>
					</div>
				</div>
			</div>
	<?php
		}
	?>

</body>
</html>