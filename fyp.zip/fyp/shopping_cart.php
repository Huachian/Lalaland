<?php
	session_start();
	include("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: login_register.php?next=shopping_cart.php");
	}

	if(isset($_SESSION["admin_position"])){
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Your Shopping Cart | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/shopping_cart.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/shopping_cart.js"></script>
</head>
<body>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
		sessionStorage.setItem('payment_status', "havent_done");
	</script>

	<?php
		include("navigation_bar.php");
		$customer_id = $_SESSION["id"];
		mysqli_query($connect, "UPDATE shopping_cart SET status='waiting checkout' WHERE customer_id='$customer_id'");
		mysqli_query($connect, "UPDATE customization_card SET status='waiting checkout' WHERE customer_id='$customer_id' AND status='in process'");
		$result = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' ORDER BY cart_id DESC");
		$result_1 = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='waiting checkout'");

		$check_shopping_cart = mysqli_num_rows($result);

		$result_1_count = mysqli_num_rows($result_1);

		$check_shopping_cart += $result_1_count;
	?>

	<div id="cart_warp">
		<div id="cart_title">
			Shopping Cart
		</div>

		<table id="cart_body">
			<?php
				if($check_shopping_cart == 0){
					$cart_summary_display = 0;
					$disable_empty_cart_wrap = "";
					$disable_shopping_cart_product_wrap = "disable_shopping_cart_product_wrap";
				}
				else{
					$cart_summary_display = 1;
					$disable_empty_cart_wrap = "disable_empty_cart_wrap";
					$disable_shopping_cart_product_wrap = "";
				}
			?>

				<div class="empty_cart_wrap" id="<?php echo $disable_empty_cart_wrap ?>">
					<img src="image/shopping_cart/cart_empty_icon.png" id="empty_cart_logo">
				</div>

				<tr class="cart_product_header" id="<?php echo $disable_shopping_cart_product_wrap ?>">
					<th style="width: 700px;" colspan="2">
						Product
					</th>
					<th style="width: 140px;">
						Price
					</th>
					<th style="width: 150px;">
						Quantity
					</th>
					<th style="width: 140px;">
						Total
					</th>
					<th style="width: 70px;">
						Action
					</th>
				</tr>


		<?php
			$total_qty_in_cart = 0;
			$counter = 0;

			$result_custom = mysqli_query($connect, "SELECT * FROM customization_card WHERE customer_id='$customer_id' AND status='waiting checkout' ORDER BY card_id DESC");

			while($row = mysqli_fetch_assoc($result_custom)){
				$product_id = $row['card_id'];
				$quantity = 1;
				$total_qty_in_cart += $quantity;
				$card_type = $row['card_type'];
				$counter++;

				if($card_type == "vertical"){
					$TYPE = "Flat vertical";
				}
				else{
					$TYPE = "Flat horizontal";
				}

				$check_stock = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='$TYPE'");
				$check_stock_row = mysqli_fetch_assoc($check_stock);
				$card_stock = $check_stock_row['card_stock'];
		?>
				<tr class="cart_product_row" id="cart_product_row<?php echo $counter ?>">
					<input type="hidden" value="custom_product" id="product_type<?php echo $counter ?>">
					<input type="hidden" name="product_id" id="product_id<?php echo $counter ?>" value="<?php echo $product_id ?>">
					<input type="hidden" name="quantity_in_cart" value="<?php echo $quantity ?>">
					<input type="hidden" name="cart_product_status" value="normal" id="cart_product_status<?php echo $counter ?>">
					<input type="hidden" value="<?php echo $card_stock ?>" id="product_stock<?php echo $counter ?>">
					<input type="hidden" value="On Display" id="product_status<?php echo $counter ?>">

					<td class="select_checkbox">
						<input type="checkbox" name="select_checkout_product" value="<?php echo $product_id ?>" onclick="select_product(<?php echo $counter ?>)" id="checkbox<?php echo $counter ?>">
					</td>

					<td>
						<a href="edit_custom_card.php?custom_card=<?php echo $product_id ?>">
						<?php
							if($card_type == "vertical"){
								$horizontal_img_display = "";
							}
							else{
								$horizontal_img_display = "horizontal_img_display";

							}
						?>	
							<div id="horizontal_card_wrap">
								<img class="cart_product_image" id="<?php echo $horizontal_img_display ?>" src="admin/image/customization/<?php echo $row["card_image"] ?>">
							</div>
							
							<span class="cart_product_name" id="cart_product_name<?php echo $counter ?>">
								<b>[Custom <?php echo $row['card_type']; ?> card]</b> 
								<?php echo $row['card_name']; ?>
								<br>
								<button id="edit_custom_card_btn">Edit</button>
							</span>
						</a>
					<?php
						if($card_stock != "In Stock"){
					?>
							<div id="custom_product_not_available_display">
								<div>
									Not available
								</div>
							</div>
					<?php
						}
					?>
					</td>

					<td class="product_price">
					<?php
						if($card_type == "vertical"){
							$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat vertical'");
							$get_price_row = mysqli_fetch_assoc($get_price);

							$card_price = $get_price_row['card_price'];
						}
						else if($card_type == "horizontal"){
							$get_price = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat horizontal'");
							$get_price_row = mysqli_fetch_assoc($get_price);

							$card_price = $get_price_row['card_price'];
						}
					?>
						RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($card_price, 2); ?></span>
					</td>

					<td class="quantity">
						<button class="minus_btn" name="minus_btn" disabled>-</button>
						<input type="number" name="quantity<?php echo $counter ?>" value="<?php echo $quantity ?>" style="width: 50px;" id="quantity<?php echo $counter ?>" class="input_quantity" disabled>
						<button class="add_btn" name="add_btn" disabled>+</button>
					</td>

					<td class="total">
						<?php
							$total = $card_price * $quantity;
						?>
						RM<span id="subtotal<?php echo $counter ?>"><?php echo number_format($total, 2); ?></span>
					</td>

					<td class="delete_row_btn">
						<button name="delete_btn" onclick="delete_cart_item(<?php echo $counter ?>)"><img src="image/shopping_cart/dustbin_icon.png"></button>
					</td>
				</tr>
		<?php
			}
		?>



		<?php
			while($row = mysqli_fetch_assoc($result)){
				$product_id = $row['product_id'];
				$quantity = $row['quantity'];
				$result_1 = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
				$row_1 = mysqli_fetch_assoc($result_1);
				$total_qty_in_cart += $quantity;
				$counter++;
		?>
				<tr class="cart_product_row" id="cart_product_row<?php echo $counter ?>">
					<input type="hidden" value="normal_product" id="product_type<?php echo $counter ?>">
					<input type="hidden" name="product_id" id="product_id<?php echo $counter ?>" value="<?php echo $product_id ?>">
					<input type="hidden" name="quantity_in_cart" value="<?php echo $quantity ?>">
					<input type="hidden" name="cart_product_status" value="normal" id="cart_product_status<?php echo $counter ?>">
					<input type="hidden" value="<?php echo $row_1['product_stock'] ?>" id="product_stock<?php echo $counter ?>">
					<input type="hidden" value="<?php echo $row_1['product_status'] ?>" id="product_status<?php echo $counter ?>">

					<td class="select_checkbox">
						<input type="checkbox" name="select_checkout_product" value="<?php echo $product_id ?>" onclick="select_product(<?php echo $counter ?>)" id="checkbox<?php echo $counter ?>">
					</td>
					<td>
						<a href="product_page.php?product_id=<?php echo $product_id ?>">
							<img class="cart_product_image" src="admin/image/product_image/<?php echo $row_1["product_image"] ?>">
							<span class="cart_product_name" id="cart_product_name<?php echo $counter ?>"><?php echo $row_1['product_name']; ?></span>
						</a>
				<?php
						if($row_1['product_stock'] != "In Stock" || $row_1['product_status'] != "On Display"){
				?>
							<div id="product_not_available_display">
								<div>
									Not available
								</div>
							</div>
				<?php
						}
				?>
					</td>
					<td class="product_price">
						<?php
							date_default_timezone_set("Asia/Kuala_Lumpur");
							$today_date = date("Y-m-d");
							$today_date = date_parse($today_date);

							$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

							$product_promotion_price = $row_1['product_price'];
							$found_promotion = "false";

							if(mysqli_num_rows($check_promotion) != 0){
								while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
									$promotion_id = $check_promotion_row['promotion_id'];

									$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
									$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

									if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
										$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

										$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

										if(mysqli_num_rows($check_promotion_product) != 0){
											if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
												$product_promotion_price = $check_promotion_product_result['promotion_price'];
											}
										}

										if(mysqli_num_rows($check_promotion_product) != 0){
											$found_promotion = "true";
										}
									}
								}
							}
							else{
								$product_promotion_price = 0;
								$found_promotion = "false";
							}


							if($found_promotion == "true"){
						?>		
								<div class="cancel_normal_price">
									RM<span><?php echo number_format($row_1['product_price'], 2); ?></span>
								</div>
								<div class="promotion_price">
									RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_promotion_price,2); ?></span>
								</div>
						<?php
							}
							else{
						?>
								<div>
									RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($row_1['product_price'], 2); ?></span>
								</div>
						<?php
							}
						?>
					</td>
					<td class="quantity <?php echo $disable_cart_row ?>">
						<button class="minus_btn" name="minus_btn" onclick="minus_qty(<?php echo $counter ?>); check_cart_product_qty(<?php echo $counter ?>);">-</button>
						<input type="number" name="quantity<?php echo $counter ?>" value="<?php echo $row['quantity']; ?>" min="1" max="999" style="width: 50px;" onkeypress="return event.charCode>=48 && event.charCode<=57" onkeyup="manual_key_in(<?php echo $counter ?>)" id="quantity<?php echo $counter ?>" class="input_quantity" onblur="min_qty_check(<?php echo $counter ?>); check_cart_product_qty(<?php echo $counter ?>);">
						<button class="add_btn" name="add_btn" onclick="add_qty(<?php echo $counter ?>); check_cart_product_qty(<?php echo $counter ?>);">+</button>
					</td>
					<td class="total">
						<?php
							if($found_promotion == "true"){
								$total = $product_promotion_price * $row['quantity'];
							}
							else{
								$total = $row_1['product_price'] * $row['quantity'];
							}
						?>
						RM<span id="subtotal<?php echo $counter ?>"><?php echo number_format($total, 2); ?></span>
					</td>
					<td class="delete_row_btn">
						<button name="delete_btn" onclick="delete_cart_item(<?php echo $counter ?>)"><img src="image/shopping_cart/dustbin_icon.png"></button>
					</td>
				</tr>
		<?php
			}
		?>
		</table>

		<?php
			if($cart_summary_display == 1){
				$disable_cart_summary = "";
			}
			else{
				$disable_cart_summary = "disable_cart_summary";
			}
		?>

		<div class="cart_summary" id="<?php echo $disable_cart_summary ?>">
			<div class="select_all_box">
				<input type="checkbox" name="select_all_checkbox" onclick="checkall(this)" id="select_all">
				<div>Select All (<span id="total_qty_in_cart"><?php echo $total_qty_in_cart ?></span>)</div>
			</div>

			<div class="total_price_box">
				<table>
					<tr>
						<td class="price_label">
							Subtotal
						</td>
						<td></td>
						<td>
							RM
						</td>
						<td id="price_number">
							<span id="summary_price">0.00</span>
						</td>
					</tr>
				</table>
			</div>
			<div class="checkout_box">
				<button onclick="update_status()">Check Out</button>
			</div>
		</div>
	</div>

	<div id="empty_alert_wrap" class="empty_alert_wrap">
		<div id="empty_alert_box">
			<div id="empty_alert_contain">
				<img src="image/shopping_cart/eror_icon.png">
				<div>
					You have not selected any items for checkout.
				</div>
			</div>
		</div>
	</div>

	<div id="product_not_available_popup" class="empty_alert_wrap">
		<div id="empty_alert_box">
			<div id="empty_alert_contain">
				<img src="image/shopping_cart/eror_icon.png">
				<div>
					Selected product are not available.
				</div>
			</div>
		</div>
	</div>
	
	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove this item?
				</div>
				<div id="delete_product_name">
				</div>
				<div id="delete_confirm_btn">
					<button id="delete_confirm_yes">Yes</button>
					<button id="delete_confirm_no">No</button>
				</div>
			</div>
		</div>
	</div>


	<div id="max_qty_wrap">
		<div id="max_qty_box">
			<div id="max_qty_box_contain_wrap">
				<div id="max_qty_box_contain">
					Sorry, you can only buy maximum 999 quantity
				</div>
				<div id="max_qty_confirm_btn">
					<button id="max_qty_confirm_yes" onclick="close_max_qty_wrap()">OK</button>
				</div>
			</div>
		</div>
	</div>


	<div id="max_checkout_amount_wrap">
		<div id="max_qty_box">
			<div id="max_qty_box_contain_wrap">
				<div id="max_qty_box_contain">
					Sorry, maximum check out amount is below RM100,000.00
				</div>
				<div id="max_qty_confirm_btn">
					<button id="max_qty_confirm_yes" onclick="close_max_amount_wrap()">OK</button>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		//ignore 0 if user input 0 at first number
		$(".input_quantity").on("input", function(){
		  if (/^0/.test(this.value)){
		    this.value = this.value.replace(/^0/, "");
		  }
		})
	</script>


	<?php
		if($cart_summary_display != 1){
			include("footer.php");
		}
	?>

	<!-- check buy now (select buy now action product) -->
	<?php
		$result = mysqli_query($connect, "SELECT * FROM shopping_cart WHERE customer_id='$customer_id' ORDER BY cart_id DESC");
		$counter = 0;
		while($row = mysqli_fetch_assoc($result)){
			$counter++;
			if(isset($_GET['product_id'])){
				if($row['product_id'] == $_GET['product_id']){
	?>
					<script type="text/javascript">
						document.getElementById("checkbox<?php echo $counter ?>").checked = true;
						select_product(<?php echo $counter ?>);
					</script>
	<?php
				}
				
			}
		}
	?>
</body>
</html>