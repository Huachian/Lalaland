<?php 
	session_start();
	include("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: login_register.php?next=wish_list.php");
	}

	if(isset($_SESSION["admin_position"])){
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Your Wish List | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/wish_list.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/wish_list.js"></script>
</head>
<body>
	<?php
		include("navigation_bar.php");
		$customer_id = $_SESSION["id"];
		$result = mysqli_query($connect, "SELECT * FROM wish_list WHERE customer_id='$customer_id'");
		$check_wishlist = mysqli_num_rows($result);
	?>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="wish_list_wrap">
		<div id="wish_list_header">
			<div>My Wish List  <img src="image/wish_list/star_icon.png" style="width: 20px; margin-left: 5px;"></div>
		</div>

		<table id="wish_list_body">
			<?php
				if($check_wishlist== 0){
					$disable_empty_wishlist_wrap = "";
					$disable_wishlist_title = "disable_shopping_cart_product_wrap";
				}
				else{
					$disable_empty_wishlist_wrap = "disable_empty_cart_wrap";
					$disable_wishlist_title = "";
				}
			?>

			<div id="empty_cart_wrap" class="<?php echo $disable_empty_wishlist_wrap ?>">
				<img src="image/wish_list/empty_wishlist.png" id="empty_cart_logo">
			</div>

			<tr id="wish_list_title" class="<?php echo $disable_wishlist_title ?>">
					<th style="width: 700px;" colspan="2">
						Product
					</th>
					<th style="width: 140px;">
						Price
					</th>
					<th style="width: 150px;">
						
					</th>
					<!-- <th style="width: 140px;">
						Action
					</th> -->
					<th style="width: 70px;">
						
					</th>
			</tr>

			<?php
				$counter = 0;
				$wish_list = mysqli_query($connect, "SELECT * FROM wish_list WHERE customer_id='$customer_id' ORDER BY wish_list_id DESC");
				while($row = mysqli_fetch_assoc($wish_list)){
					$counter++;
					$product_id = $row['product_id'];
					$product = mysqli_query($connect, "SELECT * FROM product WHERE product_id='$product_id'");
					$product_row = mysqli_fetch_assoc($product);

			?>
			<tr class="wishlist_product_row" id="wishlist_product_row<?php echo $counter ?>">
				<input type="hidden" name="product_id" id="product_id<?php echo $counter ?>" value="<?php echo $product_id ?>">
				<td class="wishlist_delete">
					<button id="delete_btn" onclick="delete_wish_list('<?php echo $counter ?>', '<?php echo $row['product_id'] ?>')">
						<img src="image/wish_list/dustbin_icon.png">
					</button>
				</td>
				<td>
					<a href="product_page.php?product_id=<?php echo $product_id ?>">
						<img class="wishlist_product_image" src="admin/image/product_image/<?php echo $product_row["product_image"] ?>">
						<span class="wishlist_product_name" id="product_name><?php echo $counter ?>"><?php echo $product_row['product_name']; ?></span>
					</a>

					<?php
						if($product_row['product_stock'] != "In Stock" || $product_row['product_status'] != "On Display"){
					?>
							<div id="product_not_available_display">
								<div>
									Not available
								</div>
							</div>
					<?php
						}
					?>
				</td>
				<td class="wishlist_product_price">
					<?php
						date_default_timezone_set("Asia/Kuala_Lumpur");
						$today_date = date("Y-m-d");
						$today_date = date_parse($today_date);

						$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

						$product_promotion_price = $product_row['product_price'];
						$found_promotion = "false";

						if(mysqli_num_rows($check_promotion) != 0){
							while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
								$promotion_id = $check_promotion_row['promotion_id'];

								$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
								$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

								if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
									$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

									$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

									if(mysqli_num_rows($check_promotion_product) != 0){
										if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
											$product_promotion_price = $check_promotion_product_result['promotion_price'];
										}
									}

									if(mysqli_num_rows($check_promotion_product) != 0){
										$found_promotion = "true";
									}
								}
							}
						}
						else{
							$product_promotion_price = 0;
							$found_promotion = "false";
						}


						if($found_promotion == "true"){
					?>		
							<div class="cancel_normal_price">
								RM<span><?php echo number_format($product_row['product_price'], 2); ?></span>
							</div>
							<div class="promotion_price">
								RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_promotion_price,2); ?></span>
							</div>
					<?php
						}
						else{
					?>
							<div>
								RM<span id="product_price<?php echo $counter ?>"><?php echo number_format($product_row['product_price'], 2); ?></span>
							</div>
					<?php
						}
					?>
				</td>
				<td>
					
				<!-- </td>
				<td class="wishlist_add_to_cart_btn">
					<?php
						if($product_row['product_stock'] != "In Stock" || $product_row['product_status'] != "On Display"){
					?>
							<button id="not_available_btn">
								Not Available
							</button>
					<?php
						}
						else{
					?>
							<button id="add_to_cart_btn" onclick="add_cart('<?php echo $counter ?>')">Add to cart</button>
					<?php
						}
					?>
				</td>
				<td> -->
					
				</td>
			</tr>

			<?php
				}
			?>

			<input type="hidden" id="total_wishlish_qty" value="<?php echo $counter ?>">
		</table>
	</div>

	<div id="delete_confirm_wrap">
		<div id="delete_confirm_box">
			<div id="delete_confirm_contain">
				<div id="delete_confirm_title">
					Do you want to remove it from Wishlist?
				</div>
				<div id="delete_confirm_btn">
					<input type="hidden" id="delete_product_id">
					<input type="hidden" id="delete_product_counter">
					<button id="delete_confirm_yes" onclick="delete_confirm_yes()">Yes</button>
					<button id="delete_confirm_no" onclick="cancel_delete()">No</button>
				</div>
			</div>
		</div>
	</div>

	<div id="add_success_alert_wrap" class="alert_box_wrap">
		<div class="alert_box">
			<div class="alert_box_contain">
				<img src="image/wish_list/tick_icon.png">
				<div>
					Item has been added to your shopping cart
				</div>
			</div>
		</div>
	</div>

	<?php
	   include ("footer.php");
	?>
</body>
</html>