<?php 
	session_start();
	include("dataconnection.php"); 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Search Result | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="css/search_result.css">
	<script type="text/javascript" src="js/search_result.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>
	<?php
		include("navigation_bar.php");

		if(empty($_GET['filter_product_type']) && empty($_GET['filter_product_occasions'])){
	?>
			<script type="text/javascript">
				document.getElementById('for_who_btn').classList.add("active");
			</script>
	<?php
		}
		else{
	?>
			<script type="text/javascript">
				document.getElementById('shop_button').classList.add("active");
			</script>
	<?php
		}
	?>

	<?php
		$search_contain=array();


		if(empty($_GET['search_keyword'])){
	
			if(isset($_GET['filter_max_price'])){
				$filter_max_price = $_GET['filter_max_price'];
				$filter_max_price_result = "product_price<='".$filter_max_price."'";

				array_push($search_contain, "Below RM".$filter_max_price);
			}
			else{
				$result = mysqli_query($connect, "SELECT MAX( product_price ) AS max FROM product");
				$row = mysqli_fetch_array($result);
				$largest_price = $row['max'];
				$filter_max_price_result = "product_price<='".$largest_price."'";
			}

			$filter_gender_result = "";
			if(isset($_GET['filter_gender'])){
				$filter_gender = $_GET['filter_gender'];

				$total_length = count($filter_gender);

				for($i=0; $i<$total_length; $i++){
					$filter_gender = $_GET['filter_gender'][$i];

					if($i+1 != $total_length){
						$filter_gender_result .= "product_gender='$filter_gender' OR ";
					}
					else{
						$filter_gender_result .= "product_gender='$filter_gender'";
					}

					array_push($search_contain, $filter_gender);
				}
			}
			else{
				$filter_gender_result = "product_gender=' '";
			}


			$filter_product_type_result = "";
			if(isset($_GET['filter_product_type'])){
				$filter_product_type = $_GET['filter_product_type'];

				$total_length = count($filter_product_type);

				for($i=0; $i<$total_length; $i++){
					$filter_product_type = $_GET['filter_product_type'][$i];

					if($i+1 != $total_length){
						$filter_product_type_result .= "product_type='$filter_product_type' OR ";
					}
					else{
						$filter_product_type_result .= "product_type='$filter_product_type'";
					}

					array_push($search_contain, $filter_product_type);
				}
			}
			else{
				$filter_product_type_result = "product_type=' '";
			}


			$filter_product_occasions_result = "";
			if(isset($_GET['filter_product_occasions'])){
				$filter_product_occasions = $_GET['filter_product_occasions'];

				$total_length = count($filter_product_occasions);

				for($i=0; $i<$total_length; $i++){
					$filter_product_occasions = $_GET['filter_product_occasions'][$i];

					if($i+1 != $total_length){
						$filter_product_occasions_result .= "product_occasions='$filter_product_occasions' OR ";
					}
					else{
						$filter_product_occasions_result .= "product_occasions='$filter_product_occasions'";
					}

					array_push($search_contain, $filter_product_occasions);
				}
			}
			else{
				$filter_product_occasions_result = "product_occasions=' '";
			}


			if(isset($_GET['filter_max_price'])){
				$query = "SELECT * FROM product WHERE product_status='On Display' AND ($filter_gender_result OR $filter_product_type_result OR $filter_product_occasions_result)";
			
				$result = mysqli_query($connect, $query);

				$total_filtered_result = 0;
				
				while($row = mysqli_fetch_assoc($result)){
					$product_id = $row['product_id'];
					$product_price = $row['product_price'];

					date_default_timezone_set("Asia/Kuala_Lumpur");
					$today_date = date("Y-m-d");
					$today_date = date_parse($today_date);

					$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

					$product_promotion_price = 0;
					$found_promotion = "false";

					if(mysqli_num_rows($check_promotion) != 0){
						while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
							$promotion_id = $check_promotion_row['promotion_id'];

							$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
							$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

							if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
								$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

								$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

								if(mysqli_num_rows($check_promotion_product) != 0){
									$found_promotion = "true";

									if($check_promotion_product_result['promotion_price'] < $product_price){
										$product_price = $check_promotion_product_result['promotion_price'];
									}
								}
							}
						}
					}
					else{
						$found_promotion = "false";
					}

					if($found_promotion == "true"){
						if($product_price <= $filter_max_price){
							$total_filtered_result++;
						}
					}
					else{
						if($product_price <= $filter_max_price){
							$total_filtered_result++;
						}
					}
				}
			}
			else{
				$query = "SELECT * FROM product WHERE product_status='On Display' AND ($filter_gender_result OR $filter_product_type_result OR $filter_product_occasions_result)";
			
				$result = mysqli_query($connect, $query);
				$total_filtered_result = mysqli_num_rows($result);
			}
		}
		else{ 
			if(isset($_GET['filter_max_price'])){
				$search_keyword = mysqli_real_escape_string($connect, $_GET['search_keyword']);
				array_push($search_contain, $search_keyword);

				$filter_max_price = $_GET['filter_max_price'];

				$result = mysqli_query($connect, "SELECT * FROM product WHERE product_status='On Display' AND (product_id LIKE '%$search_keyword%' OR product_name LIKE '%$search_keyword%' OR product_gender LIKE '%$search_keyword%' OR product_type LIKE '%$search_keyword%' OR product_occasions LIKE '%$search_keyword%')");

				$total_filtered_result = 0;
				while($row = mysqli_fetch_assoc($result)){
					$product_id = $row['product_id'];
					$product_price = $row['product_price'];

					date_default_timezone_set("Asia/Kuala_Lumpur");
					$today_date = date("Y-m-d");
					$today_date = date_parse($today_date);

					$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

					$product_promotion_price = 0;
					$found_promotion = "false";

					if(mysqli_num_rows($check_promotion) != 0){
						while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
							$promotion_id = $check_promotion_row['promotion_id'];

							$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
							$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

							if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
								$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

								$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

								if(mysqli_num_rows($check_promotion_product) != 0){
									$found_promotion = "true";

									if($check_promotion_product_result['promotion_price'] < $product_price){
										$product_price = $check_promotion_product_result['promotion_price'];
									}
								}
							}
						}
					}
					else{
						$found_promotion = "false";
					}

					if($found_promotion == "true"){
						if($product_price <= $filter_max_price){
							$valid_display = "true";
						}
						else{
							$valid_display = "false";
						}
					}
					else{
						if($row['product_price'] <= $filter_max_price){
							$valid_display = "true";
						}
						else{
							$valid_display = "false";
						}
					}					



					if($valid_display == "true"){
						if(empty($_GET['filter_gender']) && empty($_GET['filter_product_type']) && empty($_GET['filter_product_occasions'])){
							$total_filtered_result++;
						}
						else{
							if(isset($_GET['filter_gender'])){
								$filter_gender = $_GET['filter_gender'];

								$gender_valid = "false";
								for($i=0; $i<count($filter_gender); $i++){
									if($row['product_gender'] == $filter_gender[$i]){
										$gender_valid = "true";
									}
								}
							}
							else{
								$gender_valid = "false";
							}


							if(isset($_GET['filter_product_type'])){
								$filter_product_type = $_GET['filter_product_type'];

								$type_valid = "false";
								for($i=0; $i<count($filter_product_type); $i++){
									if($row['product_type'] == $filter_product_type[$i]){
										$type_valid = "true";
									}
								}
							}
							else{
								$type_valid = "false";
							}


							if(isset($_GET['filter_product_occasions'])){
								$filter_product_occasions = $_GET['filter_product_occasions'];

								$occasions_valid = "false";
								for($i=0; $i<count($filter_product_occasions); $i++){
									if($row['product_occasions'] == $filter_product_occasions[$i]){
										$occasions_valid = "true";
									}
								}
							}
							else{
								$occasions_valid = "false";
							}


							if($gender_valid == "true" || $type_valid == "true" || $occasions_valid == "true"){
								$total_filtered_result++;
							}
						}
					}
				}

				if(isset($_GET['filter_gender'])){
					$filter_gender = $_GET['filter_gender'];
					for($i=0; $i<count($filter_gender); $i++){
						array_push($search_contain, $filter_gender[$i]);
					}
				}

				if(isset($_GET['filter_product_type'])){
					$filter_product_type = $_GET['filter_product_type'];
					for($i=0; $i<count($filter_gender); $i++){
						array_push($search_contain, $filter_product_type[$i]);
					}
				}

				if(isset($_GET['filter_product_occasions'])){
					$filter_product_occasions = $_GET['filter_product_occasions'];
					for($i=0; $i<count($filter_gender); $i++){
						array_push($search_contain, $filter_product_occasions[$i]);
					}
				}
			}
			else{
				$search_keyword = mysqli_real_escape_string($connect, $_GET['search_keyword']);
				array_push($search_contain, $search_keyword);

				$result = mysqli_query($connect, "SELECT * FROM product WHERE product_status='On Display' AND (product_id LIKE '%$search_keyword%' OR product_name LIKE '%$search_keyword%' OR product_gender LIKE '%$search_keyword%' OR product_type LIKE '%$search_keyword%' OR product_occasions LIKE '%$search_keyword%')");
				$total_filtered_result = 0;


				while($row = mysqli_fetch_assoc($result)){
					$product_id = $row['product_id'];
					$product_price = $row['product_price'];

					date_default_timezone_set("Asia/Kuala_Lumpur");
					$today_date = date("Y-m-d");
					$today_date = date_parse($today_date);

					$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

					$product_promotion_price = 0;
					$found_promotion = "false";

					if(mysqli_num_rows($check_promotion) != 0){
						while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
							$promotion_id = $check_promotion_row['promotion_id'];

							$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
							$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

							if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
								$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

								$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

								if(mysqli_num_rows($check_promotion_product) != 0){

									if($check_promotion_product_result['promotion_price'] < $product_price){
										$product_price = $check_promotion_product_result['promotion_price'];
									}
								}
							}
						}
					}
				

					if(empty($_GET['filter_gender']) && empty($_GET['filter_product_type']) && empty($_GET['filter_product_occasions'])){
						$total_filtered_result++;
					}
					else{
						if(isset($_GET['filter_gender'])){
							$filter_gender = $_GET['filter_gender'];

							$gender_valid = "false";
							for($i=0; $i<count($filter_gender); $i++){
								if($row['product_gender'] == $filter_gender[$i]){
									$gender_valid = "true";
								}
							}
						}
						else{
							$gender_valid = "false";
						}


						if(isset($_GET['filter_product_type'])){
							$filter_product_type = $_GET['filter_product_type'];

							$type_valid = "false";
							for($i=0; $i<count($filter_product_type); $i++){
								if($row['product_type'] == $filter_product_type[$i]){
									$type_valid = "true";
								}
							}
						}
						else{
							$type_valid = "false";
						}


						if(isset($_GET['filter_product_occasions'])){
							$filter_product_occasions = $_GET['filter_product_occasions'];

							$occasions_valid = "false";
							for($i=0; $i<count($filter_product_occasions); $i++){
								if($row['product_occasions'] == $filter_product_occasions[$i]){
									$occasions_valid = "true";
								}
							}
						}
						else{
							$occasions_valid = "false";
						}


						if($gender_valid == "true" || $type_valid == "true" || $occasions_valid == "true"){
							$total_filtered_result++;
						}
					}
				}

				if(isset($_GET['filter_gender'])){
					$filter_gender = $_GET['filter_gender'];
					for($i=0; $i<count($filter_gender); $i++){
						array_push($search_contain, $filter_gender[$i]);
					}
				}

				if(isset($_GET['filter_product_type'])){
					$filter_product_type = $_GET['filter_product_type'];
					for($i=0; $i<count($filter_product_type); $i++){
						array_push($search_contain, $filter_product_type[$i]);
					}
				}

				if(isset($_GET['filter_product_occasions'])){
					$filter_product_occasions = $_GET['filter_product_occasions'];
					for($i=0; $i<count($filter_product_occasions); $i++){
						array_push($search_contain, $filter_product_occasions[$i]);
					}
				}
			}
		}

		$search_contain_display = "";
		$total_search_contain = count($search_contain);
		for($i=0; $i<$total_search_contain; $i++){

			if(empty($_GET['search_keyword'])){
				if(($i+1) != $total_search_contain){
					$search_contain_display .= $search_contain[$i]." / ";
				}
				else{
					$search_contain_display .= $search_contain[$i];
				}
			}
			else{
				if($i==0 && ($i+1) != $total_search_contain){
					$search_contain_display .= $search_contain[$i]." &#8594; (";
				}
				else if(($i+1) != $total_search_contain){
					$search_contain_display .= $search_contain[$i].", ";
				}
				else if(($i+1) == $total_search_contain && $total_search_contain != 1){
					$search_contain_display .= $search_contain[$i].")";
				}
				else{
					$search_contain_display .= $search_contain[$i];
				}
			}
			
		}
	?>

	<div class="search_result_header">
		<p id="search_result_p1">Search Results</p>
		<p id="search_result_p2">Showing <span><?php echo $total_filtered_result; ?></span> results for "<?php echo $search_contain_display ?>"</p>
		<div id="filters_option_wrap" style="display: none;">
			<div id="sort_by">
				<img src="image/search_result/sort_by_icon.png" id="sort_by_icon">
				<select id="sort_by_price" onchange="update_filter_page('sort_by_price')">
				<?php
					if($_GET['sort_by_price'] == "ASC"){
						$select_default = "";
						$select_asc = "selected";
						$select_desc = "";
					}
					else if($_GET['sort_by_price'] == "DESC"){
						$select_default = "";
						$select_asc = "";
						$select_desc = "selected";
					}
					else{
						$select_default = "selected";
						$select_asc = "";
						$select_desc = "";
					}
				?>
					<option value="none" <?php echo $select_default ?>>Sort By</option>
					<option value="ASC" <?php echo $select_asc ?>>PRICE: LOW TO HIGH</option>
					<option value="DESC" <?php echo $select_desc ?>>PRICE: HIGH TO LOW</option>
				</select>
			</div>

			<div id="filters_by" onclick="filter_pop_up()">
				<img src="image/search_result/filters_icon.png" id="filters_by_icon">
				<span>Filter</span>
			</div>
		</div>
	</div>

	<?php
		if(isset($_GET['product_page'])){
			$product_page = $_GET['product_page'];
		}
		else{
			$product_page = 1;
		}

		$num_per_page = 20;
		$display_start_from = ($product_page-1)*20;

		if(empty($_GET['search_keyword'])){

			$filter_gender_result = "";
			if(isset($_GET['filter_gender'])){
				$filter_gender = $_GET['filter_gender'];

				$total_length = count($filter_gender);

				for($i=0; $i<$total_length; $i++){
					$filter_gender = $_GET['filter_gender'][$i];

					if($i+1 != $total_length){
						$filter_gender_result .= "product_gender='$filter_gender' OR ";
					}
					else{
						$filter_gender_result .= "product_gender='$filter_gender'";
					}
				}
			}
			else{
				$filter_gender_result = "product_gender=' '";
			}


			$filter_product_type_result = "";
			if(isset($_GET['filter_product_type'])){
				$filter_product_type = $_GET['filter_product_type'];

				$total_length = count($filter_product_type);

				for($i=0; $i<$total_length; $i++){
					$filter_product_type = $_GET['filter_product_type'][$i];

					if($i+1 != $total_length){
						$filter_product_type_result .= "product_type='$filter_product_type' OR ";
					}
					else{
						$filter_product_type_result .= "product_type='$filter_product_type'";
					}
				}
			}
			else{
				$filter_product_type_result = "product_type=' '";
			}


			$filter_product_occasions_result = "";
			if(isset($_GET['filter_product_occasions'])){
				$filter_product_occasions = $_GET['filter_product_occasions'];

				$total_length = count($filter_product_occasions);

				for($i=0; $i<$total_length; $i++){
					$filter_product_occasions = $_GET['filter_product_occasions'][$i];

					if($i+1 != $total_length){
						$filter_product_occasions_result .= "product_occasions='$filter_product_occasions' OR ";
					}
					else{
						$filter_product_occasions_result .= "product_occasions='$filter_product_occasions'";
					}
				}
			}
			else{
				$filter_product_occasions_result = "product_occasions=' '";
			}


			$query = "SELECT * FROM product WHERE product_status='On Display' AND (".$filter_gender_result." OR ".$filter_product_type_result." OR ".$filter_product_occasions_result.") ORDER BY SUBSTR(product_id, 2, 9999999999999999) DESC";
	
			$display_result = mysqli_query($connect, $query);
		}
		else{
			$display_result = mysqli_query($connect, "SELECT * FROM product WHERE product_status='On Display' AND (product_id LIKE '%$search_keyword%' OR product_name LIKE '%$search_keyword%' OR product_gender LIKE '%$search_keyword%' OR product_type LIKE '%$search_keyword%' OR product_occasions LIKE '%$search_keyword%') ORDER BY SUBSTR(product_id, 2, 9999999999999999) DESC");
		}
	?>

	<div class="search_result_wrap">
		<?php
			if($total_filtered_result != 0){
				$counter = 0;
				$loop = 0;
				$total_in_wish_list = 0;


				$row = array();
				while($query_result = mysqli_fetch_assoc($display_result)){
					$product_id = $query_result['product_id'];
					$product_image = $query_result['product_image'];
					$product_name = $query_result['product_name'];
					$product_price = $query_result['product_price'];
					$product_gender = $query_result['product_gender'];
					$product_type = $query_result['product_type'];
					$product_occasions = $query_result['product_occasions'];
					$product_description_1 = $query_result['product_description_1'];
					$product_description_2 = $query_result['product_description_2'];
					$product_stock = $query_result['product_stock'];
					$product_status = $query_result['product_status'];


					//check for promotion price
					date_default_timezone_set("Asia/Kuala_Lumpur");
					$today_date = date("Y-m-d");
					$today_date = date_parse($today_date);

					$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

					$product_final_price = $product_price;
					$found_promotion = "false";

					if(mysqli_num_rows($check_promotion) != 0){
						while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
							$promotion_id = $check_promotion_row['promotion_id'];

							$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
							$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

							if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
								$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

								$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

								if(mysqli_num_rows($check_promotion_product) != 0){
									$found_promotion = "true";

									if($check_promotion_product_result['promotion_price'] < $product_final_price){
										$product_final_price = $check_promotion_product_result['promotion_price'];
									}
								}
							}
						}
					}
					else{
						$found_promotion = "false";
						$product_final_price = $product_price;
					}


					$tem_array = array("product_id"=>$product_id,
										"product_image" => $product_image,
										"product_name" =>$product_name,
										"product_price" => $product_price,
										"product_gender" => $product_gender,
										"product_type" => $product_type,
										"product_occasions" => $product_occasions,
										"product_description_1" => $product_description_1,
										"product_description_2" => $product_description_2,
										"product_stock" => $product_stock,
										"product_status" => $product_status,
										"product_final_price" => $product_final_price);

					array_push($row, $tem_array);
				}


				if(isset($_GET['sort_by_price'])){
					$sort_by_price = $_GET['sort_by_price'];

					if($sort_by_price == "ASC"){
						usort($row, function($a, $b) {
						    if($a['product_final_price']==$b['product_final_price']) return 0;
						    return $a['product_final_price'] > $b['product_final_price']?1:-1;
						});
					}
					else if($sort_by_price == "DESC"){

						usort($row, function($a, $b) {
						    if($a['product_final_price']==$b['product_final_price']) return 0;
						    return $a['product_final_price'] < $b['product_final_price']?1:-1;
						});
					}	
				}

				$i = 0;


				while($row){
					$i++;
					if($counter == $total_filtered_result || $loop == 20){
						break;
					}
					

					$product_id = $row[$i-1]['product_id'];

					if(isset($_GET['filter_max_price'])){
						$filter_max_price = $_GET['filter_max_price'];

						
						if($row[$i-1]['product_final_price'] <= $filter_max_price){
							$valid_display = "true";
						}
						else{
							$valid_display = "false";
						}
					}
					else{
						$valid_display = "true";
					}

				


					if(isset($_GET['search_keyword'])){
						if(empty($_GET['filter_gender']) && empty($_GET['filter_product_type']) && empty($_GET['filter_product_occasions'])){
							$valid_search_contain = "true";
						}
						else{
							if(isset($_GET['filter_gender'])){
								$filter_gender = $_GET['filter_gender'];

								$gender_valid = "false";
								for($j=0; $j<count($filter_gender); $j++){
									if($row[$i-1]['product_gender'] == $filter_gender[$j]){
										$gender_valid = "true";
									}
								}

							}
							else{
								$gender_valid = "false";
							}

							if(isset($_GET['filter_product_type'])){
								$filter_product_type = $_GET['filter_product_type'];

								$type_valid = "false";
								for($j=0; $j<count($filter_product_type); $j++){
									if($row[$i-1]['product_type'] == $filter_product_type[$j]){
										$type_valid = "true";
									}
								}
							}
							else{
								$type_valid = "false";
							}


							if(isset($_GET['filter_product_occasions'])){
								$filter_product_occasions = $_GET['filter_product_occasions'];

								$occasions_valid = "false";
								for($j=0; $j<count($filter_product_occasions); $j++){
									if($row[$i-1]['product_occasions'] == $filter_product_occasions[$j]){
										$occasions_valid = "true";
									}
								}
							}
							else{
								$occasions_valid = "false";
							}


							if($gender_valid == "true" || $type_valid == "true" || $occasions_valid == "true"){
								$valid_search_contain = "true";
							}
							else{
								$valid_search_contain = "false";
							}
						}
					}
					else{
						$valid_search_contain = "true";
					}


					if($valid_display == "true" && $valid_search_contain == "true"){
						$counter++;
						

						if($counter > $display_start_from){	
						$loop++;	
			?>
							<a href="product_page.php?product_id=<?php echo $row[$i-1]['product_id'] ?>" id="product_card_hyperlink">
							<div class="product_card">
								<div class="product_image_wrap">
									<?php
										if($row[$i-1]['product_stock'] == "Out of Stock"){
									?>
											<div class="out_of_stock">
												<div class="out_of_stock_contain_wrap">
													<div class="out_of_stock_contain">Out of Stock</div>
												</div>
											</div>
									<?php
										}
									?>
									<img src="admin/image/product_image/<?php echo $row[$i-1]["product_image"] ?>" class="product_image">
								</div>
								<div class="wish_list_wrap">
								<?php
									$check_wish_list = mysqli_query($connect, "SELECT * FROM wish_list WHERE customer_id='$customer_id' AND product_id='$product_id'");
									$wish_list = mysqli_num_rows($check_wish_list);

									if($wish_list > 0){
										$wish_list_icon_1 = "disable_wish_list_icon";
										$wish_list_icon_2 = "";
										$total_in_wish_list++;
								?>
										<input type="hidden" value="in_wish_list" id="wish_list_status<?php echo $counter ?>">
								<?php
									}
									else{
										$wish_list_icon_1 = "";
										$wish_list_icon_2 = "disable_wish_list_icon";
								?>
										<input type="hidden" value="not_in_wish_list" id="wish_list_status<?php echo $counter ?>">
								<?php
									}

									if(isset($_SESSION["admin_position"])){
										$wish_list_function = "";
									}
									else{
										$wish_list_function = "update_wishlist('".$counter."')";
									}
								?>
									<img src="image/search_result/wish_list_icon_1.png" class="wish_list_icon_1 <?php echo $wish_list_icon_1 ?>" id="wish_list_icon_1<?php echo $counter ?>" onclick="<?php echo $wish_list_function ?>">
									<img src="image/search_result/wish_list_icon_2.png" class="wish_list_icon_2 <?php echo $wish_list_icon_2 ?>" id="wish_list_icon_2<?php echo $counter ?>" onclick="<?php echo $wish_list_function ?>">
								</div>
								<div class="product_title">
									<?php echo $row[$i-1]['product_name']; ?>
								</div>
								<div class="product_price">
									<?php
										date_default_timezone_set("Asia/Kuala_Lumpur");
										$today_date = date("Y-m-d");
										$today_date = date_parse($today_date);


										$check_promotion = mysqli_query($connect, "SELECT * FROM promotion WHERE status='Enable'");

										$product_promotion_price = $row[$i-1]['product_price'];
										$found_promotion = "false";

										if(mysqli_num_rows($check_promotion) != 0){
											while($check_promotion_row = mysqli_fetch_assoc($check_promotion)){
												$promotion_id = $check_promotion_row['promotion_id'];

												$promotion_start_date = date_parse ($check_promotion_row['promotion_start_date']);
												$promotion_end_date = date_parse ($check_promotion_row['promotion_end_date']);

												if($today_date >= $promotion_start_date && $promotion_end_date >= $today_date){
													$check_promotion_product = mysqli_query($connect, "SELECT * FROM promotion_products WHERE promotion_id='$promotion_id' AND product_id='$product_id'");

													$check_promotion_product_result = mysqli_fetch_assoc($check_promotion_product);

													if(mysqli_num_rows($check_promotion_product) != 0){
														if($check_promotion_product_result['promotion_price'] < $product_promotion_price){
															$product_promotion_price = $check_promotion_product_result['promotion_price'];
														}
													}

													if(mysqli_num_rows($check_promotion_product) != 0){
														$found_promotion = "true";
													}
												}
											}
										}
										else{
											$product_promotion_price = 0;
											$found_promotion = "false";
										}


										if($found_promotion == "true"){
									?>
											<div class="promotion_price_wrap">
												<div class="cancel_normal_price">RM<?php echo number_format($row[$i-1]['product_price'],2); ?></div>
												<div class="promotion_price">RM<?php echo number_format($product_promotion_price,2); ?></div>
											</div>
									<?php
										}
										else{
									?>
											<div class="normal_product_price">RM<?php echo number_format($row[$i-1]['product_price'],2); ?></div>
									<?php
										}
									?>
								</div>
								<input type="hidden" name="product_id" id="product_id<?php echo $counter ?>" value="<?php echo $row[$i-1]['product_id']; ?>">
								
								<!-- <div class="card_btn_wrap">
									<?php
										if($row[$i-1]['product_stock'] == "Out of Stock"){
									?>
											<button type="button" name="disable_add_to_cart_btn" id="disable_add_to_cart_btn">Add To Cart</button>
									<?php
										}
										else if($row[$i-1]['product_stock'] == "In Stock"){
											if(isset($_SESSION["admin_position"])){
												$add_cart_function = "";
											}
											else{
												$add_cart_function = "add_cart('".$counter."')";
											}
									?>
											<button type="button" name="add_to_cart_btn" id="add_to_cart_btn" onclick="<?php echo $add_cart_function ?>">Add To Cart</button>
									<?php
										}
									?>
								</div>	 -->
							</div>
						</a>
			<?php
						}
			?>
						
			<?php
					}

				}
			}
			else{
		?>
				<div id="no_product_found_image_wrap">
					<img src="image/search_result/no_product_found_icon.jpg">
				</div>
		<?php
			}
		?>
		<input type="hidden" id="total_in_wish_list" value="<?php echo $total_in_wish_list ?>">
		
	</div>

	<?php
		$total_page = ceil($total_filtered_result/$num_per_page);

		if($total_filtered_result != 0){
	?>
			<div class="product_page_number">
				<ul>
					<?php
						if($product_page == 1){
						?>
							<li class='previous_btn_hidden'>
								<div><img src='image/search_result/previous_icon.png'></div>
							</li>
						<?php
						}
						else if($product_page > 1){
						?>
							<li class='previous_btn'>
								<div onclick='update_filter_page("update_page", "<?php echo $product_page-1 ?>")'><img src='image/search_result/previous_icon.png'></div>
							</li>
						<?php
						}


						for($i=1; $i<=$total_page; $i++){
							if($i == $product_page){
							?>
								<li>
									<div class='active_pagination' onclick='update_filter_page("update_page", "<?php echo $i ?>")'><?php echo $i ?></div>
								</li>
							<?php
							}
							else{
							?>
								<li>
									<div onclick='update_filter_page("update_page", "<?php echo $i ?>")'><?php echo $i ?></div>
								</li>
							<?php
							}
						}

						if($product_page == $total_page){
						?>
							<li class='next_btn_hidden'><div><img src='image/search_result/next_icon.png'></div></li>
						<?php
						}
						else if($i > $total_page){
						?>
							<li class='next_btn'>
								<div onclick='update_filter_page("update_page", "<?php echo $product_page+1 ?>")'><img src='image/search_result/next_icon.png'></div>
							</li>
						<?php
						}
					?>
				</ul>
			</div>
	<?php
		}
	?>

	<div class="filter_pop_up_wrap">
		<div id="close_area" onclick="close_filter_pop_up()"></div>
		<div class="filter_pop_up_box">
			<!-- <div class="filter_option_title">
				Filter Option
			</div> -->

			<div class="filter_option_wrap">
                <h3>Price</h3>
                <?php
            		$result = mysqli_query($connect, "SELECT MAX( product_price ) AS max FROM product");
					$found = 0;
					while($row = mysqli_fetch_array($result)){
						$largest_price = $row['max'];
						$found++;
					}

					if($found == 0){
						$largest_price = 1.00;
					}
					
					if(isset($_GET['filter_max_price'])){
						$filter_max_price = $_GET['filter_max_price'];
					}
					else{
						$filter_max_price = $largest_price;
					}
            	?>
            	<input type="hidden" id="max_price_value" value="<?php echo $largest_price ?>">
                <div class="price_range_display">
                	RM1.00 - RM<span id="target_filter_price"><?php echo number_format($filter_max_price, 2) ?></span>
                </div>
                <input type="range" min="1" max="<?php echo $largest_price ?>" value="<?php echo $filter_max_price ?>" class="filter_price_range_slider" id="filter_price_range_slider" oninput="change_filter_price()" onmouseup="update_filter_page('filter_price')">
            </div>

            <div class="filter_option_wrap">
            	<h3>Gender / Group</h3>
            	<?php
            		if(isset($_GET['filter_gender'])){
						$filter_gender = $_GET['filter_gender'];

						$for_him_checked = "";
						$for_her_checked = "";
						$for_kids_checked = "";
						$newborn_checked = "";

						for($i=0; $i<count($filter_gender); $i++){
							if($filter_gender[$i] == "For Him"){
								$for_him_checked = "checked";
							}
							else if($filter_gender[$i] == "For Her"){
								$for_her_checked = "checked";
							}
							else if($filter_gender[$i] == "For Kids"){
								$for_kids_checked = "checked";
							}
							else if($filter_gender[$i] == "Newborn"){
								$newborn_checked = "checked";
							}
						}
					}
					else{
						$for_him_checked = "";
						$for_her_checked = "";
						$for_kids_checked = "";
						$newborn_checked = "";
					}
            	?>
            	<div class="filter_option_row">
            		<input type="checkbox" value="For Him" class="gender_filter_option" onclick="update_filter_page('gender')" <?php echo $for_him_checked ?>>
            		<div>For Him</div>
            	</div>
            	<div class="filter_option_row">
            		<input type="checkbox" value="For Her" class="gender_filter_option" onclick="update_filter_page('gender')" <?php echo $for_her_checked ?>>
            		<div>For Her</div>
            	</div>
            	<div class="filter_option_row">
            		<input type="checkbox" value="For Kids" class="gender_filter_option" onclick="update_filter_page('gender')" <?php echo $for_kids_checked ?>>
            		<div>For Kids</div>
            	</div>
            	<div class="filter_option_row">
            		<input type="checkbox" value="Newborn" class="gender_filter_option" onclick="update_filter_page('gender')" <?php echo $newborn_checked ?>>
            		<div>Newborn</div>
            	</div>
            </div>

            <div class="filter_option_wrap">
            	<h3>Product Type</h3>
            	<?php
            		$result = mysqli_query($connect, "SELECT * FROM product_type");

            		while($row = mysqli_fetch_assoc($result)){
            			if(isset($_GET['filter_product_type'])){
							$filter_product_type = $_GET['filter_product_type'];

							$total_length = count($filter_product_type);

							for($i=0; $i<$total_length; $i++){
								if($filter_product_type[$i] == $row['product_type']){
									$product_type_checked = "checked";
									break;
								}
								else{
									$product_type_checked = "";
								}
							}
						}
						else{
							$product_type_checked = "";
						}
            	?>
        			<div class="filter_option_row">
	            		<input type="checkbox" value="<?php echo $row['product_type'] ?>" class="product_type_filter_option" onclick="update_filter_page('product_type')" <?php echo $product_type_checked ?>>
	            		<div><?php echo $row['product_type'] ?></div>
	            	</div>
            	<?php
            		}
            	?>
            </div>

            <div class="filter_option_wrap">
            	<h3>Product Ocassion</h3>
            	<?php
            		$result = mysqli_query($connect, "SELECT * FROM product_occasions");

            		while($row = mysqli_fetch_assoc($result)){
            			if(isset($_GET['filter_product_occasions'])){
							$filter_product_occasions = $_GET['filter_product_occasions'];

							$total_length = count($filter_product_occasions);

							for($i=0; $i<$total_length; $i++){
								if($filter_product_occasions[$i] == $row['occasions_name']){
									$product_occasions_checked = "checked";
									break;
								}
								else{
									$product_occasions_checked = "";
								}
							}
						}
						else{
							$product_occasions_checked = "";
						}
            	?>
        			<div class="filter_option_row">
	            		<input type="checkbox" value="<?php echo $row['occasions_name'] ?>" class="product_occasions_filter_option" onclick="update_filter_page('product_occasions')" <?php echo $product_occasions_checked ?>>
	            		<div><?php echo $row['occasions_name'] ?></div>
	            	</div>
            	<?php
            		}
            	?>
            </div>
		</div>
		<div id="close_pop_up_btn" onclick="close_filter_pop_up()">
			<img src="image/search_result/cross_icon.png">
		</div>
	</div>

	<?php
		include("footer.php");
	?>
</body>

	<script type="text/javascript">
		let filter_pop_up_action = sessionStorage.getItem('filter_pop_up');

		if(filter_pop_up_action == "yes"){
			filter_pop_up();
		}
		else{
			close_filter_pop_up();
		}
		
		sessionStorage.setItem('filter_pop_up', "no");
	</script>
</html>