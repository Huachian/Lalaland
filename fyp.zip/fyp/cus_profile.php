<?php
	session_start();
	include "dataconnection.php";

	if(!isset($_SESSION['id'])){
	  header("Location: login_register.php?next=cus_profile.php");
	}

	if(isset($_SESSION["admin_position"])){
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Account | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/cus_profile.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/cus_profile.js"></script>
</head>
<body>
	<?php include("navigation_bar.php"); ?>

	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

  <?php
    $cus_id = $_SESSION['id'];
    $result = mysqli_query($connect,"SELECT * FROM customer WHERE customer_id='$cus_id'");
    $row = mysqli_fetch_assoc($result);
  ?>

 
	<div class="profile_main_wrap">
	  <div class="sidebar_wrap">
	      <?php
	        $customer_details = mysqli_query($connect, "SELECT * FROM customer WHERE customer_id='$customer_id'");
	        $customer = mysqli_fetch_assoc($customer_details);
	      ?>
	      <div class="sidebar_header" id="sidebar_header">
	        <?Php echo $customer['first_name']." ".$customer['last_name']; ?>
	      </div>

	      <div class="sidebar_menu">
	        <div class="sidebar_contain_head">
	          <img src="image/cus_profile/profile_icon.png">
	          <a href="cus_profile.php">My Account</a>
	        </div>
	        <div class="sidebar_contain_body">
	          <ul>
	            <li>
	              <a href="cus_profile.php" style="color: #D7A1F9;">Profile</a>
	            </li>
	            <!-- <li>
	              <a href="cus_address.php">Addresses</a>
	            </li> -->
	            <li>
	              <a href="cus_password.php">Change Password</a>
	            </li>
	          </ul>
	        </div>

	        <!-- <div class="sidebar_contain_head">
	          <img src="image/cus_profile/my_orders_icon.jpg">
	          <a href="view_purchase.php">My Purchase</a>
	        </div> -->
	      </div>
	    </div>

    
	    <div class="profilebox">
		  	<div class="profile_head">
		        <h2>My Profile</h2>
		    </div>

		    <div class="profile_body">
		    	<table id="profile_table">
		    		<tr>
		    			<td class="profile_table_column_1">
		    				First name
		    			</td>
		    			<td>
		    				<form>
		    					<input type="text" name="first_name" id="first_name" value="<?php echo $customer['first_name'] ?>" disabled onblur="first_name_validation()" placeholder="First Name" autocomplete="off">
		    				</form>
		    				<span class="profile_error_messange" id="first_name_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Last name
		    			</td>
		    			<td>
		    				<form>
		    					<input type="text" name="last_name" id="last_name" value="<?php echo $customer['last_name'] ?>" disabled onblur="last_name_validation()" placeholder="Last Name" autocomplete="off">
		    				</form>
		    				<span class="profile_error_messange" id="last_name_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Email address
		    			</td>
		    			<td>
		    				<input type="text" name="email" value="<?php echo $customer['email'] ?>" disabled>
		    				<br>
		    				<span class="profile_error_messange"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1">
		    				Phone Number
		    			</td>
		    			<td>
		    				<input type="tel" name="phone_number" id="phone_number" value="<?php echo $customer['phone'] ?>" data-mask="999-99999999" disabled onblur="phone_validation()" placeholder="(Example: xxx-xxxxxxxx)" autocomplete="off">
		    				<br>
		    				<span class="profile_error_messange" id="phone_number_error"></span>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_table_column_1 gender_title">
		    				Gender
		    			</td>
		    			<td id="gender_selection">
		    				<input type="hidden" name="current_gender" id="current_gender" value="<?php echo $customer['gender'] ?>">
	    					<input type="radio" name="gender" id="gender_male" <?php if($customer['gender']=="Male") {echo "checked";}?> value="Male" disabled><div id="male_tag">Male</div>
	    					<input type="radio" name="gender" id="gender_female" <?php if($customer['gender']=="Female") {echo "checked";}?> value="Female" disabled><div id="female_tag">Female</div>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td class="profile_btn_wrap" colspan="2">
		    				<button id="edit_profile_btn" onclick="edit_profile()">Edit</button>
		    				<button id="cancel_edit_profile_btn" onclick="cancel_edit_profile()">Cancel</button>
		    				<button id="save_edit_profile_btn" onclick="save()">Save</button>
		    			</td>
		    		</tr>
		    	</table>
		    </div>
		</div>
	</div>


	<div id="edit_profile_alert_wrap">
	    <div id="edit_profile_alert_box">
	      <div id="edit_profile_alert_contain">
	        <img src="image/cus_profile/tick_icon.png">
	        <div>
	          Profile Successfully updated
	        </div>
	      </div>
	    </div>
  	</div>

  	<?php
		include ("footer.php");
	?>
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</body>
</html>