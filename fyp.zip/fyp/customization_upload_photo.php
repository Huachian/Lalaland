<?php
	session_start();
	include ("dataconnection.php");

	if(!isset($_SESSION['id'])){
	    header("Location: login_register.php?next=customization_main_page.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Upload your design | Easy Gift - Malaysia's Leading Online Gift Shop</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/customization_upload_photo.css">
	<script type="text/javascript" src="js/customization_card.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" integrity="sha384-vSIIfh2YWi9wW0r9iZe7RJPrKwp6bG+s9QZMoITbCckVJqGCCRhc+ccxNcdpHuYu" crossorigin="anonymous">
</head>
<body>
	<?php
		include ("navigation_bar.php");
	?>
	<script type="text/javascript">
		document.getElementById('custom_card_nav_btn').classList.add("active");
	</script>
	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
	</script>

	<div class="main_wrap">
		<div class="back_page">
			<button onclick="window.history.back()">
				&#60; Back
			</button>
		</div>

		<div class="page_row" id="page_row_1">
			<div class="card_demo_wrap">
			<?php
				$custom_card_type = $_GET['custom_card_type'];
			?>
				<div id="change_image_btn_wrap">
					<button id="change_image_btn" onclick="upload_image('<?php echo $custom_card_type ?>')">
						<i class="fas fa-redo"></i>
						Change Image
					</button>
				</div>
				<div class="card_patern_wrap">
				<?php
					if($custom_card_type == "vertical"){
				?>
						<div id="flat_vertical" onclick="upload_image('vertical')">
							<div id="flat_vertical_demo_title_wrap"  class="card_demo_title_wrap">
								<div class="card_title">Upload photo</div>
								<div>
									<button class="click_to_upload_img_btn">click here to upload image</button>
								</div>
							</div>

							<input type="file" id="vertical_card_img_upload" onchange="preview_product_image('vertical')" accept="image/x-png,image/jpeg">
							<img id="vertical_uploaded_image">
						</div>
				<?php
					}
					else if($custom_card_type == "horizontal"){
				?>
						<div id="flat_horizontal" onclick="upload_image('horizontal')">
							<div id="flat_horizontal_demo_title_wrap" class="card_demo_title_wrap">
								<div class="card_title">Upload photo</div>
								<div>
									<button class="click_to_upload_img_btn">click here to upload image</button>
								</div>
							</div>

							<input type="file" id="horizontal_card_img_upload" onchange="preview_product_image('horizontal')" accept="image/x-png,image/jpeg">
							<img id="horizontal_uploaded_image">
						</div>
				<?php
					}
				?>
				</div>

				<div>
					<div class="custom_selection_wrap">
						<div class="upload_image_selection_wrap">
							<div class="upload_image_selection_header">
								Upload Photo
							</div>
							<div class="upload_image_selection_description">
								<img src="image/customization/image_icon.png">
								<div>
									Click the card to upload your photo.
								</div>
							</div>
							<div class="upload_image_selection_btn_wrap">
								<button id="image_upload_next_button" onclick="image_upload_validation('<?php echo $custom_card_type ?>')">Next Step</button>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>

	</div>


	<div id="step_popup_wrap">
		<div id="step_popup_box">
			<div id="step_popup_box_contain_wrap">
				<div id="step_popup_box_contain">
					<div class="step_wrap">
						<div class="step_title">
							Step 1
						</div>
						<div class="step_line"></div>
						<div class="step_subtitle">
							Upload photo
						</div>
					</div>
					<div class="step_wrap">
						<div class="step_title">
							Step 2
						</div>
						<div class="step_line"></div>
						<div class="step_subtitle">
							Upload text
						</div>
					</div>
					<div class="step_wrap">
						<div class="step_title">
							Step 3
						</div>
						<div class="step_subtitle">
							Name the card
						</div>
					</div>
				</div>
				<div id="step_popup_confirm_btn">
					<button id="step_popup_confirm_yes" onclick="close_step_popup_wrap()">OK</button>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		var step_pop_up = sessionStorage.getItem('step_pop_up');

		if(step_pop_up == null || step_pop_up == "no"){
			document.getElementById("step_popup_wrap").style.display = "block";
		}


		function close_step_popup_wrap(){
			sessionStorage.setItem('step_pop_up', "already");
			document.getElementById("step_popup_wrap").style.display = "none";
		}
		
	</script>

	<?php
		include ("footer.php");
	?>
</body>
</html>