<?php
	session_start();
	include ("dataconnection.php");

	$custom_card_type = $_GET['custom_card_type'];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Custom Card | Easy Gift</title>
	<link rel="icon" href="image/navigation_top_bar/easy_gift_small_logo.png">
	<link rel="stylesheet" type="text/css" href="css/customization_card_information.css">
	<script type="text/javascript" src="js/customization_card.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
	<?php
		include ("navigation_bar.php");
	?>

	<script type="text/javascript">
		sessionStorage.setItem('checkout_page_valid', "no");
		sessionStorage.setItem('payment_page_valid', "no");
		sessionStorage.setItem('step_pop_up', "no");
	</script>
	
	<script type="text/javascript">
		document.getElementById('custom_card_nav_btn').classList.add("active");
	</script>


	<div class="main_wrap">
		<div class="back_page">
			<button onclick="window.location='customization_main_page.php'">
				&#60; Select Card Patern
			</button>
		</div>

		<div class="page_row" id="page_row_1">
			<div class="card_demo_wrap">
				<div class="card_patern_wrap">
				<?php
					$custom_card_type = $_GET['custom_card_type'];

					if($custom_card_type == "vertical"){
				?>
						<div id="flat_vertical">
							<div class="card_demo_title_wrap">
								<div class="card_title">BLANK FLAT VERTICAL CARD</div>
								<div>Upload your own photo or design</div>
							</div>
						</div>
				<?php
						$result = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat vertical'");
						$row = mysqli_fetch_assoc($result);

						$card_price = $row['card_price'];
						$card_stock = $row['card_stock'];
					}
					else if($custom_card_type == "horizontal"){
				?>
						<div id="flat_horizontal">
							<div class="card_demo_title_wrap">
								<div class="card_title">BLANK FLAT HORIZONTAL CARD</div>
								<div>Upload your own photo or design</div>
							</div>
						</div>
				<?php
						$result = mysqli_query($connect, "SELECT * FROM product_customization WHERE card_type='Flat horizontal'");
						$row = mysqli_fetch_assoc($result);

						$card_price = $row['card_price'];
						$card_stock = $row['card_stock'];
					}
				?>
				</div>

				<div class="card_pricing_wrap">
					<div class="pricing_header_wrap">
						<div class="pricing_header_title">CUSTOM GIFT CARD</div>
						<div>By Easy Gift</div>
					</div>

					<div class="price_wrap">
						Flat cards RM<?php echo number_format($card_price, 2) ?>
					</div>

					<div class="card_promote_word_wrap">
						<img src="image/customization/gift_card_icon.gif">
						<div>
							Free envelopes and all of our cards are recycled.
						</div>
					</div>

					<div class="custom_button_wrap">
					<?php
						if($card_stock == "In Stock"){
					?>
							<button class="custom_card_button" onclick="login_validation('<?php echo $custom_card_type ?>')">Customize card</button>
					<?php
						}
						else{
					?>
							<button class="custom_card_button" id="card_out_of_stock">Out of Stock</button>
					<?php
						}
					?>
						
					</div>
				</div>
			</div>
		</div>

		<?php
			if($custom_card_type == "vertical"){
				$size = '5" x 7"';
			}
			else{
				$size = '7" x 5"';
			}
		?>
		<div class="page_row" id="page_row_2">
			<div class="page_row_contain">
				<div class="page_contain_title">
					CARD INFORMATION
				</div>

				<div class="page_contain_subtitle">
					<?php echo $size ?> flat card with envelope and printed on 100% recycled paper.
				</div>

				<div class="page_contain_title">
					About this card
				</div>

				<div class="page_contain_subtitle">
					Couldn't find what you were looking for in our collection of cards? Or you'd just rather upload a design you've made yourself? You've found the right card. 100% customizable, just upload your photo and you'll be on your way!
				</div>
			</div>
		</div>
	</div>

	<?php
		include ("footer.php");
	?>
</body>
</html>